﻿Imports Microsoft.Phone.Shell
Imports WPExercise.ProductsServiceReference

Partial Public Class MainPage
  Inherits PhoneApplicationPage

  ' Constructor
  Public Sub New()
    InitializeComponent()
  End Sub

  Private Sub lstData_SelectionChanged(sender As System.Object, e As System.Windows.Controls.SelectionChangedEventArgs) Handles lstData.SelectionChanged
    Dim entity As Product

    entity = DirectCast(lstData.SelectedItem, Product)
    PhoneApplicationService.Current.State("ProductEntity") = entity

    NavigationService.Navigate(New Uri("/ProductDetail.xaml", _
       UriKind.Relative))

  End Sub

  Private Sub PhoneApplicationPage_OrientationChanged(sender As System.Object, e As Microsoft.Phone.Controls.OrientationChangedEventArgs)
    If e.Orientation.ToString().Contains("Portrait") Then
      lstData.ItemTemplate = DirectCast( _
           Me.Resources("listPortrait"), DataTemplate)
    Else
      lstData.ItemTemplate = DirectCast( _
           Me.Resources("listLandscape"), DataTemplate)
    End If

  End Sub
End Class
