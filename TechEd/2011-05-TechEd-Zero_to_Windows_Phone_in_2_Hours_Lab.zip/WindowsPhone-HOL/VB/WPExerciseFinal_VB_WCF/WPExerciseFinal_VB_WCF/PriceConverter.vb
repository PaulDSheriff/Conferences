﻿Imports System.Windows.Data

Public Class PriceConverter
  Implements IValueConverter

  Public Function Convert(value As Object, targetType As Type, _
      parameter As Object, _
      culture As System.Globalization.CultureInfo) As Object Implements IValueConverter.Convert
    Dim price As Decimal

    price = CDec(value)

    Return price.ToString("c")
  End Function

  Public Function ConvertBack(value As Object, _
       targetType As Type, _
       parameter As Object, _
       culture As System.Globalization.CultureInfo) As Object Implements IValueConverter.ConvertBack
    Throw New NotImplementedException()
  End Function
End Class
