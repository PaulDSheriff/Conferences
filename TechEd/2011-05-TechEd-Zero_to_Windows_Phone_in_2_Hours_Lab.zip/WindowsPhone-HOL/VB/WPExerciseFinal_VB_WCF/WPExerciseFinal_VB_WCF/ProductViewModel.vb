﻿Imports WPExercise.ProductsServiceReference
Imports System.Collections.ObjectModel
Imports System.ComponentModel

Public Class ProductViewModel
  Implements INotifyPropertyChanged

  Public Sub New()
    If Application.Current.ApplicationLifetimeObjects.Count > 0 Then
      GetProducts()
    End If
  End Sub

  Public Event PropertyChanged(sender As Object, e As System.ComponentModel.PropertyChangedEventArgs) Implements System.ComponentModel.INotifyPropertyChanged.PropertyChanged

  Protected Sub RaisePropertyChanged(propertyName As String)
    RaiseEvent PropertyChanged(Me, _
       New PropertyChangedEventArgs(propertyName))
  End Sub

  Private _DataCollection As ObservableCollection(Of Product)

  Public Property DataCollection() As  _
   ObservableCollection(Of Product)
    Get
      Return _DataCollection
    End Get
    Set(value As ObservableCollection(Of Product))
      _DataCollection = value
      RaisePropertyChanged("DataCollection")
    End Set
  End Property

  Public Sub GetProducts()
    Dim client As New ProductsServiceClient()

    AddHandler client.GetProductsCompleted, _
       AddressOf client_GetProductsCompleted

    client.GetProductsAsync()
    client.CloseAsync()
  End Sub

  Private Sub client_GetProductsCompleted(sender As Object, _
   e As GetProductsCompletedEventArgs)
    DataCollection = e.Result
  End Sub
End Class