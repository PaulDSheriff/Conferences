﻿Imports System.Data
Imports System.Data.SqlClient

' NOTE: You can use the "Rename" command on the context menu to change the class name "ProductsService" in code, svc and config file together.
Public Class ProductsService
  Implements IProductsService

  Public Function GetProducts() As Products Implements IProductsService.GetProducts
    Dim dt As New DataTable()
    Dim ret As New Products()
    Dim prod As Product
    Dim da As SqlDataAdapter

    da = New SqlDataAdapter("SELECT ProductId, ProductName, ImageUri, Price FROM ProductWithImages", _
             "Server=Localhost;Database=Sandbox;Integrated Security=Yes")

    da.Fill(dt)

    For Each dr As DataRow In dt.Rows
      prod = New Product()

      prod.ProductId = Convert.ToInt32(dr("ProductId"))
      prod.ProductName = Convert.ToString(dr("ProductName"))
      prod.ImageUri = Convert.ToString(dr("ImageUri"))
      prod.Price = Convert.ToDecimal(dr("Price"))

      ret.Add(prod)
    Next

    Return ret
  End Function
End Class
