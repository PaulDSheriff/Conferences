﻿Imports Microsoft.Phone.Shell

Partial Public Class ProductDetail
  Inherits PhoneApplicationPage

  Public Sub New()
    InitializeComponent()
  End Sub

  Private Sub PhoneApplicationPage_Loaded(sender As System.Object, e As System.Windows.RoutedEventArgs)
    If PhoneApplicationService.Current. _
      State.ContainsKey("ProductEntity") Then
      Me.DataContext = DirectCast(PhoneApplicationService. _
            Current.State("ProductEntity"), Product)
    End If
  End Sub

  Private Sub ApplicationBarIconButton_Click(sender As System.Object, e As System.EventArgs)
    NavigationService.GoBack()
  End Sub
End Class
