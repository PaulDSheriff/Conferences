﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Xml.Linq

Public Class Products
  Public Sub New()
    GetAllProducts()
  End Sub


  Public Property DataCollection As List(Of Product)

  Public Function GetAllProducts() As List(Of Product)
    Dim XmlObject As XElement

    ' Retrieve Data from Xml File
    XmlObject = XElement.Load("Xml/Product.xml")

    ' Create list of Product objects
    Dim products = From prod In XmlObject.Descendants("Product")
                   Order By prod.Attribute("ProductName").Value
                   Select New Product() With { _
    .ProductId = Convert.ToInt32(prod.Attribute("ProductId").Value), _
    .ProductName = prod.Attribute("ProductName").Value, _
    .ImageUri = prod.Attribute("ImageUri").Value, _
    .Price = Convert.ToDecimal(prod.Attribute("Price").Value) _
    }

    DataCollection = products.ToList()

    Return DataCollection
  End Function
End Class
