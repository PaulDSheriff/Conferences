﻿Public Class Product
  Public Property ProductId As Integer
  Public Property ProductName As String
  Public Property ImageUri As String
  Public Property Price As Decimal
End Class