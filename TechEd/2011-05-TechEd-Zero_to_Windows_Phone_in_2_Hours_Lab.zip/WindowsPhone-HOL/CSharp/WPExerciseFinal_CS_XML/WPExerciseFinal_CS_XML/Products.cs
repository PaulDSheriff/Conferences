﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace WPExercise
{
  public class Products
  {
    public Products()
    {
      GetAllProducts();
    }

    public List<Product> DataCollection { get; set; }

    public List<Product> GetAllProducts()
    {
      XElement XmlObject;

      // Retrieve Data from Xml File
      XmlObject = XElement.Load("Xml/Product.xml");

      // Create list of Product objects
      var products =
         from prod in XmlObject.Descendants("Product")
         orderby prod.Attribute("ProductName").Value
         select new Product
         {
           ProductId =
             Convert.ToInt32(prod.Attribute("ProductId").Value),
           ProductName = prod.Attribute("ProductName").Value,
           ImageUri = prod.Attribute("ImageUri").Value,
           Price = Convert.ToDecimal(prod.Attribute("Price").Value)
         };

      DataCollection = products.ToList();

      return DataCollection;
    }
  }
}
