﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

// Need this to use the PhoneApplicationService
using Microsoft.Phone.Shell;

namespace WPExercise
{
  public partial class ProductDetail : PhoneApplicationPage
  {
    public ProductDetail()
    {
      InitializeComponent();
    }

    private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
    {
      // Check the State Dictionary to see if data exists
      if (PhoneApplicationService.Current.State.ContainsKey("ProductEntity"))
      {
        this.DataContext = (Product)PhoneApplicationService.Current.State["ProductEntity"];
      }
    }

    private void ApplicationBarIconButton_Click(object sender, EventArgs e)
    {
      // Save Data Here

      // Return to Previous Page
      NavigationService.GoBack();
    }
  }
}