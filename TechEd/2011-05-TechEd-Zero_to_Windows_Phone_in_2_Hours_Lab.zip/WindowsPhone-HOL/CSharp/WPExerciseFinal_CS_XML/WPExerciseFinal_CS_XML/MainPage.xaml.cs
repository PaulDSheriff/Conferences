﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

// Need this to use the PhoneApplicationService
using Microsoft.Phone.Shell;

namespace WPExercise
{
  public partial class MainPage : PhoneApplicationPage
  {
    // Constructor
    public MainPage()
    {
      InitializeComponent();
    }

    private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      Product entity;

      entity = (Product)lstData.SelectedItem;
      PhoneApplicationService.Current.State["ProductEntity"] = entity;

      NavigationService.Navigate(new Uri("/ProductDetail.xaml", UriKind.Relative));
    }

    private void PhoneApplicationPage_OrientationChanged(object sender, OrientationChangedEventArgs e)
    {
      if (e.Orientation.ToString().Contains("Portrait"))
        lstData.ItemTemplate =
          (DataTemplate)this.Resources["listPortrait"];
      else
        lstData.ItemTemplate =
          (DataTemplate)this.Resources["listLandscape"];

    }
  }
}