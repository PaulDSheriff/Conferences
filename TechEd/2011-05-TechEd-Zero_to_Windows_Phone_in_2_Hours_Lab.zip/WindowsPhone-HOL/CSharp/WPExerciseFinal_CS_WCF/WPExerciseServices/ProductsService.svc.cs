﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace WPExerciseServices
{
  // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "ProductsService" in code, svc and config file together.
  public class ProductsService : IProductsService
  {
    public Products GetProducts()
    {
      DataTable dt = new DataTable();
      Products ret = new Products();
      Product prod;
      SqlDataAdapter da;

      da = new SqlDataAdapter(
        "SELECT ProductId, ProductName, ImageUri, Price FROM ProductWithImages",
        "Server=Localhost;Database=Sandbox;Integrated Security=Yes");

      da.Fill(dt);

      foreach (DataRow dr in dt.Rows)
      {
        prod = new Product();

        prod.ProductId = Convert.ToInt32(dr["ProductId"]);
        prod.ProductName = Convert.ToString(dr["ProductName"]);
        prod.ImageUri = Convert.ToString(dr["ImageUri"]);
        prod.Price = Convert.ToDecimal(dr["Price"]);

        ret.Add(prod);
      }

      return ret;
    }
  }
}
