﻿using System;
using System.Collections.Generic;

namespace WPExerciseServices
{
  public class Product
  {
    public int ProductId { get; set; }
    public string ProductName { get; set; }
    public string ImageUri { get; set; }
    public decimal Price { get; set; }
  }

  public class Products : List<Product>
  {
  }
}