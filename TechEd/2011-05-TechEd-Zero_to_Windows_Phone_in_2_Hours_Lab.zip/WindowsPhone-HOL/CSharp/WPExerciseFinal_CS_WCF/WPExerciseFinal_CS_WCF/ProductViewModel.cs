﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using WPExercise.ProductServiceReference;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace WPExercise
{
  public class ProductViewModel : INotifyPropertyChanged
  {
    public ProductViewModel()
    {
      if (Application.Current.ApplicationLifetimeObjects.Count > 0)
        GetProducts();
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected void RaisePropertyChanged(string propertyName)
    {
      if (PropertyChanged != null)
        PropertyChanged(this, new
           PropertyChangedEventArgs(propertyName));
    }

    private ObservableCollection<Product> _DataCollection;

    public ObservableCollection<Product> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }

    public void GetProducts()
    {
      ProductsServiceClient client = new ProductsServiceClient();

      client.GetProductsCompleted += new
          EventHandler<GetProductsCompletedEventArgs>
              (client_GetProductsCompleted);
      client.GetProductsAsync();
      client.CloseAsync();
    }

    void client_GetProductsCompleted(object sender,
      GetProductsCompletedEventArgs e)
    {
      DataCollection = e.Result;
    }
  }
}
