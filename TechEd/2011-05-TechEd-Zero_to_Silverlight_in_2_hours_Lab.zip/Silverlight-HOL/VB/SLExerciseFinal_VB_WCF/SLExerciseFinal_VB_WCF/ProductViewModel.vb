﻿Imports System.Collections.ObjectModel
Imports System.ComponentModel
Imports SLExercise.ProductServiceReference

Public Class ProductViewModel
  Implements INotifyPropertyChanged

  Public Sub New()
    If Application.Current.Host.Source IsNot Nothing Then
      GetProducts()
    End If
  End Sub

#Region "RaisePropertyChanged Event"
  Public Event PropertyChanged(sender As Object, e As PropertyChangedEventArgs) Implements INotifyPropertyChanged.PropertyChanged

  Protected Sub RaisePropertyChanged(propertyName As String)
    RaiseEvent PropertyChanged(Me, New PropertyChangedEventArgs(propertyName))
  End Sub
#End Region

#Region "DataCollection Property"
  Private _DataCollection As ObservableCollection(Of Product)

  Public Property DataCollection() As ObservableCollection(Of Product)
    Get
      Return _DataCollection
    End Get
    Set(value As ObservableCollection(Of Product))
      _DataCollection = value
      RaisePropertyChanged("DataCollection")
    End Set
  End Property
#End Region

  Public Sub GetProducts()
    Dim client As New ProductsServiceClient()

    AddHandler client.GetProductsCompleted, AddressOf client_GetProductsCompleted

    client.GetProductsAsync()
    client.CloseAsync()
  End Sub

  Private Sub client_GetProductsCompleted(sender As Object, e As GetProductsCompletedEventArgs)
    DataCollection = e.Result
  End Sub
End Class
