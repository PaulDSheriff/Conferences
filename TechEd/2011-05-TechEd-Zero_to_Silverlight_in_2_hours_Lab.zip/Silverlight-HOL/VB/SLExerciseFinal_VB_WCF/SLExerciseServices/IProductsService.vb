﻿Imports System.ServiceModel

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IProductsService" in both code and config file together.
<ServiceContract()>
Public Interface IProductsService

  <OperationContract()>
  Function GetProducts() As Products

End Interface
