﻿using System.Windows.Controls;

namespace SLExerciseFinal
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }
  }
}
