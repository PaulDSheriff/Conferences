﻿using System.Windows.Controls;

namespace SLExerciseFinal
{
  public partial class ucProductDetail : UserControl
  {
    public ucProductDetail()
    {
      InitializeComponent();
    }
  }
}
