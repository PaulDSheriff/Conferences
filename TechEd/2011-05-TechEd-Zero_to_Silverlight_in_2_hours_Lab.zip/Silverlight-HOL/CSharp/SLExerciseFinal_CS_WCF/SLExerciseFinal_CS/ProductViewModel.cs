﻿using System;
using System.Windows;

using SLExerciseFinal.ProductsServiceReference;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace SLExerciseFinal
{
  public class ProductViewModel : INotifyPropertyChanged
  {
    public ProductViewModel()
    {
      // Check to see if we are in design mode or not
      if(Application.Current.Host.Source != null)
        GetProducts();
    }

    #region INotifyPropertyChanged Members
    public event PropertyChangedEventHandler PropertyChanged;

    protected void RaisePropertyChanged(string propertyName)
    {
      if (PropertyChanged != null)
        PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
    }
    #endregion

    private ObservableCollection<Product> _DataCollection;
    public ObservableCollection<Product> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }

    public void GetProducts()
    {
      ProductsServiceClient client = new ProductsServiceClient();

      client.GetProductsCompleted += new EventHandler<GetProductsCompletedEventArgs>(client_GetProductsCompleted);
      client.GetProductsAsync();
      client.CloseAsync();
    }

    void client_GetProductsCompleted(object sender, GetProductsCompletedEventArgs e)
    {
      DataCollection = e.Result;
    }
  }
}
