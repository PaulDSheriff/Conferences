﻿using System.Windows.Controls;

namespace SLExercise
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }
  }
}
