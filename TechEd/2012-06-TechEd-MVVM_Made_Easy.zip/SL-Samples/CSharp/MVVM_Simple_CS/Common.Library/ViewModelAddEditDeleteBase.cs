﻿
namespace Common.Library
{
  public class ViewModelAddEditDeleteBase : ViewModelBase
  {
    #region Private UI Variables
    private bool _IsAddMode = false;
    private bool _IsSaveEnabled = false;
    private bool _IsCancelEnabled = false;
    private bool _IsAddEnabled = true;
    private bool _IsListEnabled = true;
    private bool _IsDetailEnabled = false;
    private int _SelectedListIndex = -1;
    private string _Message = string.Empty;
    #endregion

    #region UI Properties
    public bool IsSaveEnabled
    {
      get { return _IsSaveEnabled; }
      set
      {
        if (_IsSaveEnabled != value)
        {
          _IsSaveEnabled = value;
          RaisePropertyChanged("IsSaveEnabled");
        }
      }
    }

    public bool IsCancelEnabled
    {
      get { return _IsCancelEnabled; }
      set
      {
        if (_IsCancelEnabled != value)
        {
          _IsCancelEnabled = value;
          RaisePropertyChanged("IsCancelEnabled");
        }
      }
    }

    public bool IsAddEnabled
    {
      get { return _IsAddEnabled; }
      set
      {
        if (_IsAddEnabled != value)
        {
          _IsAddEnabled = value;
          RaisePropertyChanged("IsAddEnabled");
        }
      }
    }

    public bool IsListEnabled
    {
      get { return _IsListEnabled; }
      set
      {
        if (_IsListEnabled != value)
        {
          _IsListEnabled = value;
          RaisePropertyChanged("IsListEnabled");
        }
      }
    }

    public int SelectedListIndex
    {
      get { return _SelectedListIndex; }
      set
      {
        if (_SelectedListIndex != value)
        {
          _SelectedListIndex = value;
          RaisePropertyChanged("SelectedListIndex");
        }
      }
    }

    public bool IsDetailEnabled
    {
      get { return _IsDetailEnabled; }
      set
      {
        if (_IsDetailEnabled != value)
        {
          _IsDetailEnabled = value;
          RaisePropertyChanged("IsDetailEnabled");
        }
      }
    }

    public bool IsAddMode
    {
      get { return _IsAddMode; }
      set
      {
        if (_IsAddMode != value)
        {
          _IsAddMode = value;
          RaisePropertyChanged("IsAddMode");
        }
      }
    }

    public string Message
    {
      get { return _Message; }
      set
      {
        if (_Message != value)
        {
          _Message = value;
          RaisePropertyChanged("Message");
        }
      }
    }
    #endregion
    
    #region SetNormalUIDisplay Method
    public void SetNormalUIDisplay()
    {
      IsAddMode = false;
      IsAddEnabled = true;
      IsSaveEnabled = false;
      IsCancelEnabled = false;
      IsListEnabled = true;
      IsDetailEnabled = false;
    }
    #endregion

    #region SetEditUIDisplay Method
    public void SetEditUIDisplay()
    {
      IsAddEnabled = false;
      IsSaveEnabled = true;
      IsCancelEnabled = true;
      IsListEnabled = false;
      IsDetailEnabled = true; 
      Message = string.Empty;
    }
    #endregion
  }
}
