﻿using System.Windows;
using System.Windows.Controls;

namespace MVVM_Simple
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    #region Load User Control Method
    private void LoadUserControl(UserControl uc)
    {
      borContent.Visibility = System.Windows.Visibility.Visible;
      contentArea.Children.Clear();
      contentArea.Children.Add(uc);
    }
    #endregion

    private void btnClear_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      borContent.Visibility = System.Windows.Visibility.Collapsed;
    }

    private void btnSimple_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucSimpleBinding());
    }

    private void btnSimpleBindingViewModel_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucSimpleBindingViewModel());
    }

    private void btnSearch_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucSearchSample());
    }

    private void btnPerson_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucPersonSample());
    }

    private void btnSimpleMVVMListOnly_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucListOnly());
    }

    private void btnSimpleMVVM_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucSimpleMVVM());
    }
  
    private void btnSimpleMVVM2_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucProducts());
    }
  }
}
