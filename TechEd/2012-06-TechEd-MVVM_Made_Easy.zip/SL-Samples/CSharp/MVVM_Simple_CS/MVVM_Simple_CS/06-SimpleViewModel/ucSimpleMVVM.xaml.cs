﻿using System.Windows;
using System.Windows.Controls;

using MVVM_Simple.ProductServiceReference;

namespace MVVM_Simple
{
  public partial class ucSimpleMVVM : UserControl
  {
    ProductViewModelSimple _ViewModel;

    public ucSimpleMVVM()
    {
      InitializeComponent();

      // Initialize the Product View Model Object
      _ViewModel = (ProductViewModelSimple)this.Resources["viewModel"];
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      // Load Products
      _ViewModel.LoadAll();
    }

    #region Edit Click Event
    private void btnEdit_Click(object sender, RoutedEventArgs e)
    {
      // Get Data Context from Button
      // So you can update the List Box SelectedValue
      _ViewModel.DetailData = (Product)((Button)sender).DataContext;
      _ViewModel.SetEditUIDisplay();
    }
    #endregion

    #region Add Click Event
    private void btnAdd_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.AddRecord();
    }
    #endregion

    #region Cancel Click Event
    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.CancelEdit();

      // TODO: Write code to undo changes
    }
    #endregion

    #region Save Click Event
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.SaveData();
    }
    #endregion
  }
}
