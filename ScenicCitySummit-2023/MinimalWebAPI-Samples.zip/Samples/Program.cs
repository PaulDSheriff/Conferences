using AdvWorksAPI;
using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.RepositoryLayer;

// **********************************************
// Create a WebApplicationBuilder object
// to configure the how the ASP.NET service runs
// **********************************************
var builder = WebApplication.CreateBuilder(args);

// **********************************************
// Add and Configure Your Services
// **********************************************


// **********************************************
// Configure Open API (Swagger)
// More Info: https://aka.ms/aspnetcore/swashbuckle
// **********************************************
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// **********************************************
// After adding and configuring services
// Create an instance of a WebApplication object
// **********************************************
var app = builder.Build();

// **********************************************
// Configure the HTTP Request Pipeline Below Here
// **********************************************
// Use Swagger and Swagger UI to generate
// a page to test your Web API calls
if (app.Environment.IsDevelopment()) {
  app.UseSwagger();
  app.UseSwaggerUI();
}

// **********************************************
// Map Minimal API Routes/Endpoints
// **********************************************
app.MapGet("/api/HelloAll", () => "Hello Scenic City Summit!").WithTags("Simple");
app.MapGet("/api/HelloWorld", () => Results.Ok("Hello World")).WithTags("Simple");
app.MapGet("/api/HelloPerson", (string name) => Results.Ok($"Hello {name}")).WithTags("Simple"); ;

new ProductRouter().AddRoutes(app);

app.MapPost($"/api/Product", (Product entity) => {
  entity = new ProductRepository().Insert(entity);

  return Results.Created($"/api/Product/{entity.ProductID}", entity);
}).WithTags("Product")
  .Produces(201)  
  .Produces(400)
  .Produces<Product>();

app.MapPut($"/api/Product/{{id:int}}", (int id, Product entity) => {
  entity = new ProductRepository().Update(id, entity);
  if (entity.ProductID == -1) {
    return Results.NotFound($"Product '{id}' Could Not be Found.");
  }
  else {
    return Results.Ok(entity);
  }
}).WithTags("Product")
  .Produces(200)
  .Produces(404)
  .Produces<Product>();

app.MapDelete($"/api/Product/{{id:int}}", (int id) =>
{
  bool ret = new ProductRepository().Delete(id);
  if (ret) {
    return Results.NoContent();
  }
  else {
    return Results.NotFound($"Product '{id}' Could Not be Found.");
  }
}).WithTags("Product")
  .Produces(204)
  .Produces(404);

// **********************************************
// Run the Application
// **********************************************
app.Run();
