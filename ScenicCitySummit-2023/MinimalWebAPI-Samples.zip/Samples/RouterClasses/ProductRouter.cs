﻿using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.RepositoryLayer;

namespace AdvWorksAPI
{
  public class ProductRouter : RouterBase
  {
    public ProductRouter()
    {
      UrlFragment = "api/product";
    }

    public override void AddRoutes(WebApplication app)
    {
      app.MapGet($"/{UrlFragment}", () => Get())
        .WithTags("Product")
        .Produces(201)
        .Produces(400)
        .Produces<List<Product>>();

      app.MapGet($"/{UrlFragment}/{{id:int}}", (int id) => Get(id))
        .WithTags("Product")
        .Produces(200)
        .Produces(404)
        .Produces<Product>();
    }

    protected virtual IResult Get()
    {
      List<Product> list;

      // Get all products
      list = new ProductRepository().Get();

      // Simulate not getting any data
      //list.Clear();

      if (list == null || list.Count == 0) {
        return Results.NotFound("No Products Found.");
      }
      else {
        return Results.Ok(list);
      }
    }

    protected virtual IResult Get(int id)
    {
      Product? entity;

      // Attempt to get a single product
      entity = new ProductRepository().Get(id);
      if (entity == null) {
        return Results.NotFound($"Product with ProductID = '{id}' was not found.");
      }
      else {
        return Results.Ok(entity);
      }
    }
  }
}
