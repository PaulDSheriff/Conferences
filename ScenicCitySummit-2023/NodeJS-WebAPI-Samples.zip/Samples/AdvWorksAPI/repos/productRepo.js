let fs = require('fs');

const FILE_NAME = './assets/products.json';

let productRepo = {
  get: function (resolve, reject) {
    fs.readFile(FILE_NAME, function (err, data) {
      if (err) {
        reject(err);
      }
      else {
        resolve(JSON.parse(data));
      }
    });
  },
  getById: function (id, resolve, reject) {
    fs.readFile(FILE_NAME, function (err, data) {
      if (err) {
        reject(err);
      }
      else {
        let product = JSON.parse(data).find(p => p.productID == id);
        resolve(product);
      }
    });
  },
  search: function (searchObject, resolve, reject) {
    fs.readFile(FILE_NAME, function (err, data) {
      if (err) {
        reject(err);
      }
      else {
        let products = JSON.parse(data);
        // Perform search
        if (searchObject) {
          // Example search object
          // let searchObject = {
          //   "productID": 680,
          //   "name": 'H'
          // };
          products = products.filter(
            p => (searchObject.productID ? p.productID == searchObject.productID : true) &&
                  (searchObject.name ? p.name.toLowerCase().indexOf(searchObject.name.toLowerCase()) >= 0 : true));
        }
  
        resolve(products);
      }
    });
  },
  insert: function (newData, resolve, reject) {
    fs.readFile(FILE_NAME, function (err, data) {
      if (err) {
        reject(err);
      }
      else {
        let products = JSON.parse(data);
        products.push(newData);
        fs.writeFile(FILE_NAME, JSON.stringify(products), function (err) {
          if (err) {
            reject(err);
          }
          else {
            resolve(newData);
          }
        });
      }
    });
  },
  update: function (changedData, id, resolve, reject) {
    fs.readFile(FILE_NAME, function (err, data) {
      if (err) {
        reject(err);
      }
      else {
        let products = JSON.parse(data);
        let product = products.find(p => p.productID == id);
        if (product) {
          Object.assign(product, changedData);
          fs.writeFile(FILE_NAME, JSON.stringify(products), function (err) {
            if (err) {
              reject(err);
            }
            else {
              resolve(changedData);
            }
          });
        }
      }
    });
  },
  delete: function (id, resolve, reject) {
    fs.readFile(FILE_NAME, function (err, data) {
      if (err) {
        reject(err);
      }
      else {
        let products = JSON.parse(data);
        let index = products.findIndex(p => p.productID == id);
        if (index != -1) {
          products.splice(index, 1);
          fs.writeFile(FILE_NAME, JSON.stringify(products), function (err) {
            if (err) {
              reject(err);
            }
            else {
              resolve(index);
            }
          });
        }
      }
    });
  }
};

module.exports = productRepo;
