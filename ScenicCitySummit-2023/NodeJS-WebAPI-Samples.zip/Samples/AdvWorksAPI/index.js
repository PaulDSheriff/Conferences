// Bring in the express server and create application
let express = require('express');
let productRepo = require('./repos/productRepo');
let cors = require('cors');
let app = express();
let port = 5002;

// Enable CORS for all traffic coming from your local machine
// References: https://expressjs.com/en/resources/middleware/cors.html
// let corsOptions = {
//   "origin": "https://www.pdsa.com"
// };
// app.use(cors(corsOptions));

// Configure middleware to support 
// JSON data parsing in request body
app.use(express.json());

// Use the express Router object
let router = express.Router();

// Create GET route to return data
router.get('/', function (req, res, next) {
  productRepo.get(function (data) {
    res.status(200).json({
      "status": 200,
      "statusText": "OK",
      "message": "All products retrieved.",
      "count" : data.length,
      "data": data
    });
  }, function(err) {
    next(err);
  });
});

// Create GET/search?id=n&name=str to search for products by 'id' and/or 'name'
router.get('/search', function (req, res, next) {
  let searchObject = {
    "productID": req.query.id,
    "name": req.query.name
  };

  productRepo.search(searchObject, function (data) {
    res.status(200).json({
      "status": 200,
      "statusText": "OK",
      "message": "Products matching search retrieved.",
      "count" : data.length,
      "data": data
    });
  }, function (err) {
    next(err);
  });
});

// Create GET/id to return a single product
router.get('/:id', function (req, res, next) {
  productRepo.getById(req.params.id, function (data) {
    if (data) {
      res.status(200).json({
        "status": 200,
        "statusText": "OK",
        "message": "Single product retrieved.",
        "data": data
      });
    }
    else {
      res.status(404).json({
        "status": 404,
        "statusText": "Not Found",
        "message": `The product '${req.params.id}' could not be found.`,
        "error": {
          "code": "NOT_FOUND",
          "message": `The product '${req.params.id}' could not be found.`
        }
      });
    }
  }, function(err) {
    next(err);
  });
});

router.post('/', function (req, res, next) {
  productRepo.insert(req.body, function(data) {
    res.status(201).json({
      "status": 201,
      "statusText": "Created",
      "message": "New Product Added.",
      "data": data
    });
  }, function(err) {
    next(err);
  });
});

router.put('/:id', function (req, res, next) {
  productRepo.getById(req.params.id, function (data) {
    if (data) {
      // Attempt to update the data
      productRepo.update(req.body, req.params.id, function (data) {
        res.status(200).json({
          "status": 200,
          "statusText": "OK",
          "message": `Product '${req.params.id}' updated.`,
          "data": data
        });
      });
    }
    else {
      res.status(404).json({
        "status": 404,
        "statusText": "Not Found",
        "message": `The product '${req.params.id}' could not be found.`,
        "error": {
          "code": "NOT_FOUND",
          "message": `The product '${req.params.id}' could not be found.`
        }
      });
    }
  }, function(err) {
    next(err);
  });
});

router.delete('/:id', function (req, res, next) {
  productRepo.getById(req.params.id, function (data) {
    if (data) {
      // Attempt to delete the data
      productRepo.delete(req.params.id, function (data) {
        res.status(200).json({
          "status": 200,
          "statusText": "OK",
          "message": `The product '${req.params.id}' has been deleted.`,
          "data": `Product '${req.params.id}' deleted.`
        });
      });
    }
    else {
      res.status(404).json({
        "status": 404,
        "statusText": "Not Found",
        "message": `The product '${req.params.id}' could not be found.`,
        "error": {
          "code": "NOT_FOUND",
          "message": `The product '${req.params.id}' could not be found.`
        }
      });
    }
  }, function(err) {
    next(err);
  });
});

// Prefix all routes with /api/
app.use('/api/', router);

// Create server to listen on port 5000
let server = app.listen(port, function () {
    console.log(`Node server is running on http://localhost:${port}}.`);
});
