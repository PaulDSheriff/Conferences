var express = require('express');
var router = express.Router();
let axios = require('axios');

/* GET home page. */
router.get('/', function(req, res, next) {
  axios.get('http://localhost:5002/api/')
  .then(response => {
    res.render('index',
      {
        "title": "Adventure Works",
        "data": response.data.data
      });
  })
  .catch(error => {
    console.log(error);
    res.send(error);
  });
});

module.exports = router;
