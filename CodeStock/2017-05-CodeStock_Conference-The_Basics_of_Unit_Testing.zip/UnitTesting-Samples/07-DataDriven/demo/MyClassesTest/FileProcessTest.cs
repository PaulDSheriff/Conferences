﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using MyClasses;
using System;

namespace MyClassesTest
{
  [TestClass]
  public class FileProcessTest
  {
		/// <summary>
		/// Get/Set the TestContext. 
		/// This property is set automatically from the unit testing framework.
		/// </summary>
		public TestContext TestContext { get; set; }
		
		/// <summary>
		/// This method tests the FileExists() method using a table called tests.FileProcessTest
		/// </summary>
		[TestMethod()]
    [DataSource("Sandbox")]
    public void FileExistsTestFromDB() {
      FileProcess fp = new FileProcess();
      string fileName;
      bool expectedValue;
      bool causesException;
      bool fromCall;

      // Get values from data row
      fileName = TestContext.DataRow["FileName"].ToString();
      expectedValue = Convert.ToBoolean(TestContext.DataRow["ExpectedValue"]);
      causesException = Convert.ToBoolean(TestContext.DataRow["CausesException"]);

      // Check assertion
      try {
        fromCall = fp.FileExists(fileName);
        Assert.AreEqual(expectedValue, fromCall,
          "File Name: " + fileName +
          " has failed it's existence test in test: FileExistsTestFromDB()");
      }
      catch (AssertFailedException ex) {
        // Rethrow assertion
        throw ex;
      }
      catch (Exception) {
        // See if method was expected to throw an exception
        Assert.IsTrue(causesException);
      }
    }

    [TestMethod]
    public void FileExistsTestTrue() {
      FileProcess fp = new FileProcess();
      bool fromCall;

      fromCall = fp.FileExists(@"C:\Windows\Regedit.exe");
      Assert.AreEqual(true, fromCall);
    }

    [TestMethod]
    public void FileExistsTestFalse() {
      FileProcess fp = new FileProcess();
      bool fromCall;

      fromCall = fp.FileExists(@"D:\NotExists.txt");
      Assert.AreEqual(false, fromCall);
    }

		[TestMethod]
		public void FileNameNullOrEmpty_ThrowsArgumentNullException() {
			FileProcess fp = new FileProcess();

			try {
				fp.FileExists("");
			}
			catch (ArgumentNullException) {
				// Test was a success
				return;
			}

			// Fail the test
			Assert.Fail("Call to FileExists() did NOT throw an ArgumentNullException.");
		}

		[TestMethod]
		[ExpectedException(typeof(ArgumentNullException))]
		public void FileNameNullOrEmpty_ThrowsArgumentNullException_UsingAttribute() {
			FileProcess fp = new FileProcess();

			fp.FileExists("");
		}
	}
}
