﻿namespace MyClasses
{
  public class Person {
		public string FirstName { get; set; }
		public string LastName { get; set; }
	}
}
