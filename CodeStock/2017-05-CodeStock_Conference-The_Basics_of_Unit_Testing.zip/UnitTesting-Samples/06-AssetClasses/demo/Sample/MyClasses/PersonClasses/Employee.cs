﻿using System;

namespace MyClasses {
	public class Employee : Person {
		
	}
}
