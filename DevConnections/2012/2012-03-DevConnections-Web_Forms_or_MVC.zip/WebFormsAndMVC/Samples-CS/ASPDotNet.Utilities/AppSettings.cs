﻿using System.Configuration;

namespace ASPDotNet.Utilities
{
   public class AppSettings
   {
      public static string ConnectionString
      {
         get
         {
            return ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
         }
      }

   }
}
