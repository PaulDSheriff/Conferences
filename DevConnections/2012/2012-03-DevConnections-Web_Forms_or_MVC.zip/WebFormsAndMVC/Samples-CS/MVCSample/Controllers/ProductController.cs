﻿using System;
using System.Web.Mvc;
using ASPDotNet.Utilities;
using ASPDotNet.ViewModels;
using ASPDotNet.BusinessLayer;

namespace MVCSample.Website.Controllers
{
   /// <summary>
   /// Demonstrates a complete list, details, add, edit and delete 
   /// feature using separate views for each action.
   /// </summary>
   public class ProductController : Controller
   {
      #region Index

      // Get the list of products and display when /Product is requested
      public ActionResult Index(ProductViewModel viewModel)
      {
         ActionResult result = null;

         try
         {
            viewModel.IsEditPanelVisible = false;
            viewModel.ConnectionString = AppSettings.ConnectionString;
            viewModel.LoadProducts();
            result = View(viewModel);
         }
         catch (Exception ex)
         {
            this.ModelState.AddModelError(string.Empty, ex.Message);
            result = View(viewModel);
         }

         return result;
      }

      #endregion

      #region Create Get

      // Initialize a new 'empty' model for /Product/Create
      public ActionResult Create()
      {
         ActionResult result = null;
         ProductViewModel viewModel = new ProductViewModel();

         try
         {
            viewModel.IsEditPanelVisible = true;
            viewModel.ConnectionString = AppSettings.ConnectionString;
            viewModel.LoadProducts();
            viewModel.Product = new Product();
            // viewModel.Pro
            result = View("Index", viewModel);
         }
         catch (Exception ex)
         {
            this.ModelState.AddModelError(string.Empty, ex.Message);
            result = View("Index", viewModel);
         }

         return result;
      }

      #endregion

      #region Create Post

      // Handle the form post action for /Product/Create
      [HttpPost]
      public ActionResult Create(ProductViewModel viewModel)
      {
         ActionResult result = null;

         try
         {
            viewModel.ConnectionString = AppSettings.ConnectionString;
            viewModel.Save();
            result = RedirectToAction("Index");
         }
         catch (Exception ex)
         {
            this.ModelState.AddModelError(string.Empty, ex.Message);
            result = View(viewModel);
         }

         return result;
      }

      #endregion

      #region Edit

      // Retrieve an instance of Product for /Product/Edit/# 
      public ActionResult Edit(int id)
      {
         ActionResult result = null;
         ProductViewModel viewModel = new ProductViewModel();

         try
         {
            viewModel.IsEditPanelVisible = true;
            viewModel.ConnectionString = AppSettings.ConnectionString;
            viewModel.Load(id);
            viewModel.LoadProducts();
            result = View("Index", viewModel);
         }
         catch (Exception ex)
         {
            this.ModelState.AddModelError(string.Empty, ex.Message);
            result = View("Index", viewModel);
         }

         return result;
      }

      #endregion

      #region Edit Post

      [HttpPost]
      public ActionResult Edit(ProductViewModel viewModel)
      {
         ActionResult result = null;

         try
         {
            viewModel.ConnectionString = AppSettings.ConnectionString;
            viewModel.Save();
            result = RedirectToAction("Index");
         }
         catch (Exception ex)
         {
            this.ModelState.AddModelError(string.Empty, ex);
            viewModel.Load(viewModel.Product.ProductId);
            result = View(viewModel);
         }

         return result;
      }

      #endregion

      #region Delete

      public ActionResult Delete(int id)
      {
         ActionResult result = null;
         ProductViewModel viewModel = new ProductViewModel();

         try
         {
            viewModel.IsEditPanelVisible = false;
            viewModel.ConnectionString = AppSettings.ConnectionString;
            viewModel.Delete(id);
            viewModel.LoadProducts();
            result = View("Index", viewModel);
         }
         catch (Exception ex)
         {
            this.ModelState.AddModelError(string.Empty, ex.Message);
            result = View("Index", viewModel);
         }

         return result;
      }

      #endregion
   }
}
