﻿using System;
using System.Web.Mvc;
using ASPDotNet.BusinessLayer;
using ASPDotNet.Utilities;

namespace MVCSample.Controllers
{
   /// <summary>
   /// Sample 03 - MVC Data Access - Controller class
   /// </summary>
   public class Sample03Controller : Controller
   {
      /// <summary>
      /// Get a collection of products from a repository.
      /// </summary>
      /// <returns>An ActionResult for a view of a product collection</returns>
      public ActionResult Index()
      {
         ProductCollection products = null;
         ProductRepository repository = null;
         ActionResult result = null;

         try
         {
            repository = new ProductRepository();
            repository.ConnectionString = AppSettings.ConnectionString;
            products = repository.GetAllProducts();
            result = View(products);
         }
         catch (Exception ex)
         {
            this.ModelState.AddModelError(string.Empty, ex.Message);
            products = new ProductCollection(); // empty collection
            result = View(products);
         }

         return result;
      }
   }
}
