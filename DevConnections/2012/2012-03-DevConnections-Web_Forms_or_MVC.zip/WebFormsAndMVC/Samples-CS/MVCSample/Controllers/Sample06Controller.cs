﻿using System;
using System.Web.Mvc;

namespace MVCSample.Controllers
{
   /// <summary>
   /// Sample 06 - MVC Exception Handling - Controller class
   /// </summary>
   public class Sample06Controller : Controller
   {
      /// <summary>
      /// Get the Index view
      /// </summary>
      /// <returns>An ActionResult instance</returns>
      public ActionResult Index()
      {
         return View();
      }

      /// <summary>
      /// Unhandled exception goes to the global error view
      /// </summary>
      /// <returns>An ActionResult instance</returns>
      public ActionResult UnhandledException()
      {
         throw new Sample06Exception("Unhandled exception!");
      }

      /// <summary>
      /// Handle an error using the HandleError attribute
      /// </summary>
      /// <returns>An ActionResult instance</returns>
      [HandleError(View = "CustomError")]
      public ActionResult HandledByAttribute()
      {
         throw new Sample06Exception("Unhandled exception!");
      }

      /// <summary>
      /// Handle a post request from the Index view 
      /// </summary>
      /// <param name="values">FormCollection of form values</param>
      /// <returns>An ActionResult instance</returns>
      [HttpPost]
      public ActionResult Index(FormCollection values)
      {
         try
         {
            throw new Sample06Exception("Unhandled exception!");
         }
         catch (Exception ex)
         {
            this.ModelState.AddModelError(string.Empty, ex.Message);   
         }

         return View();
      }
   }
}
