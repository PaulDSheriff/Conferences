﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ASPDotNet.BusinessLayer;

namespace MVCSample.Controllers
{
   /// <summary>
   /// Sample 04 - MVC Data Entry - Controller class
   /// </summary>
   public class Sample04Controller : Controller
   {
      /// <summary>
      /// 
      /// </summary>
      /// <returns>An ActionResult instance</returns>
      public ActionResult Index()
      {
         return RedirectToAction("AddCustomer");
      }

      /// <summary>
      /// Get the Add view page and bind to a new customer instance
      /// </summary>
      /// <returns>An ActionResult instance</returns>
      public ActionResult AddCustomer()
      {
         Customer customer = new Customer();
         return View(customer);
      }

      /// <summary>
      /// 
      /// </summary>
      /// <param name="values">FormCollection of the form values</param>
      /// <returns>An ActionResult instance</returns>
      [HttpPost]
      public ActionResult AddCustomer(Customer customer)
      {
         // Save the customer
         return View(customer);
      }
   }
}
