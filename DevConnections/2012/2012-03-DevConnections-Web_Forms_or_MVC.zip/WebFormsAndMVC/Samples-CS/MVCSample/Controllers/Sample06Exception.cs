﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCSample.Controllers
{
   /// <summary>
   /// Sample custom exception
   /// </summary>
   public class Sample06Exception : Exception
   {
      public Sample06Exception(string message) : base(message) { }
   }
}