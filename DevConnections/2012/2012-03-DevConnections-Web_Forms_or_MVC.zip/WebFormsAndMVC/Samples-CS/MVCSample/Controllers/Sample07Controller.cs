﻿using System.Web.Mvc;
using ASPDotNet.Utilities;
using ASPDotNet.ViewModels;

namespace MVCSample.Controllers
{
   public class Sample07Controller : Controller
   {
      public ActionResult Index()
      {
         return View();
      }

      [HttpPost]
      public JsonResult GetProducts()
      {
         ProductViewModel viewModel = new ProductViewModel();
         viewModel.ConnectionString = AppSettings.ConnectionString;
         viewModel.LoadProducts();

         return Json(viewModel.AllProducts);
      }
   }

}
