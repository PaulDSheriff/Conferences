﻿using System.Web.Mvc;

namespace MVCSample.Controllers
{
   /// <summary>
   /// Sample 02 - MVC Navigation - Controller class
   /// </summary>
   public class Sample02Controller : Controller
   {
      /// <summary>
      /// Requests to /Sample02 are redirected using 
      /// the RedirectToAction() method
      /// </summary>
      /// <returns>An ActionResult instance</returns>
      public ActionResult Index()
      {
         ActionResult result = null;

         result = RedirectToAction("Landing");

         return result;
      }

      /// <summary>
      /// Displays the 'Landing' view. 
      /// </summary>
      /// <returns>An ActionResult instance</returns>
      public ActionResult Landing()
      {
         return View();
      }

      /// <summary>
      /// Handles HTTP Post requests from the Landing view.
      /// </summary>
      /// <returns>An ActionResult instance</returns>
      [HttpPost]
      public ActionResult Landing(FormCollection values)
      {
         return View();
      }

      /// <summary>
      /// Displays the 'Target' view for the ActionLink example.
      /// </summary>
      /// <returns>An ActionResult instance</returns>
      public ActionResult Target()
      {
         return View();
      }

      /// <summary>
      /// Displays the 'Not Found' view for 404 errors, configured in 
      /// the customErrors element of the web.config
      /// </summary>
      /// <returns>An ActionResult instance</returns>
      public ActionResult NotFound()
      {
         return View();
      }
   }
}
