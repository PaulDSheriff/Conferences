﻿using System.Web.Mvc;
using System.Web.Security;
using ASPDotNet.BusinessLayer;
using ASPDotNet.ViewModels;

namespace MVCSample.Controllers
{
   public class SecurityController : Controller
   {
      public ActionResult Login()
      {
         ActionResult result = null;

         LoginViewModel viewModel = new LoginViewModel();
         if (this.Request.QueryString["ReturnUrl"] != null)
         {            
            Session["ReturnUrl"] = this.Request.QueryString["ReturnUrl"];
            result = RedirectToAction("Login");
         }
         else if (Session["ReturnUrl"] != null)
         {
            viewModel.ReturnUrl = Session["ReturnUrl"].ToString();
            result = View(viewModel);
         }
         else
         {
            result = View(viewModel);
         }
         
         return result;
      }

      [HttpPost]
      public ActionResult Login(LoginViewModel viewModel)
      {
         ActionResult result = null;

         viewModel.SignIn();
         switch (viewModel.AuthenticationResult)
         {
            case AuthenticationResult.Success:
               FormsAuthentication.SetAuthCookie(viewModel.LoginName, false);
               this.HttpContext.User = viewModel.CreatePrincipal();
               result = Redirect(viewModel.ReturnUrl);
               break;
            case AuthenticationResult.Failure:
               result = View(viewModel);
               break;
         }

         return result;
      }
   }
}
