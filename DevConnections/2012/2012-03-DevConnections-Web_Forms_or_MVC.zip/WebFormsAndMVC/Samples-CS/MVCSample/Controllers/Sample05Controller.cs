﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCSample.Controllers
{
   /// <summary>
   /// Sample 05 - MVC State - Controller class
   /// </summary>
   public class Sample05Controller : Controller
   {     
      /// <summary>
      /// Present the Index view with data from state
      /// </summary>
      /// <returns>An ActionResult instance</returns>
      public ActionResult Index()
      {
         // Store a value in ViewBag
         ViewBag.AnyValue = new DateTime(2009, 4, 9);

         ViewBag.JohnKuhn = "John Kuhn";

         ViewBag.CustomerId = 1;

         // Store a value in TempData
         this.TempData["CustomerName"] = "PDSA, Inc.";

         return View();
      }

      /// <summary>
      /// Handles post from the Index view
      /// </summary>
      /// <param name="values">form values</param>
      /// <returns>An ActionResult instance</returns>
      [HttpPost]
      public ActionResult Index(FormCollection values)
      {
         DateTime value = ViewBag.AnyValue ?? DateTime.Now;

         string customerName = this.TempData["CustomerName"].ToString();

         return View();
      }
   }
}
