﻿using System.Web.Mvc;

namespace MVCSample.Website.Controllers
{
   /// <summary>
   /// Handles requests to /Home 
   /// </summary>
   public class HomeController : Controller
   {
      /// <summary>
      /// View lists all of the samples.
      /// </summary>
      /// <returns>An ActionResult</returns>
      public ActionResult Index()
      {
         return View();
      }
   }
}
