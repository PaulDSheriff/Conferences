﻿using System;
using System.Data;
using ASPDotNet.BusinessLayer;
using System.Globalization;

namespace ASPDotNet.ViewModels
{
   public class ProductViewModel
   {
      #region Properties

      public Product Product { get; set; }
      public ProductCollection AllProducts { get; set; }
      public string ConnectionString { get; set; }
      public bool IsMessageVisible { get; set; }
      public bool IsEditPanelVisible { get; set; }
      public bool IsButtonPanelVisible { get; set; }
      public int ProductId { get; set; }
      public string ProductName { get; set; }
      public string Price { get; set; }
      public string Cost { get; set; }
      public bool IsActive { get; set; }
      public string MessageText { get; set; }
      public bool RefreshGrid { get; set; }

      #endregion

      public DataSet GetDataSet()
      {
         ProductRepository repository = new ProductRepository();
         repository.ConnectionString = this.ConnectionString;
         return repository.GetDataSet();
      }

      public void Edit(object p)
      {
         int id = Convert.ToInt32(p);

         this.Load(id);

         this.ProductId = this.Product.ProductId;
         this.ProductName = this.Product.ProductName;
         this.Price = this.Product.Price.ToString("C");
         this.Cost = this.Product.Cost.ToString("C");
         this.IsActive = this.Product.IsActive;

         this.IsEditPanelVisible = true;
         this.IsButtonPanelVisible = true;
      }

      public void Delete(object p)
      {
         int id = Convert.ToInt32(p);

         ProductRepository repository = new ProductRepository();
         repository.ConnectionString = this.ConnectionString;
         repository.Delete(id);

         this.IsEditPanelVisible = false;
         this.IsButtonPanelVisible = false;

         this.RefreshGrid = true;
      }

      public void Handle(Exception ex)
      {
         this.IsMessageVisible = true;
         this.MessageText = ex.Message;
      }

      private void CreateProduct()
      {
         if (this.Product == null)
         {
            this.Product = new Product();
            this.Product.ProductId = this.ProductId;
            this.Product.ProductName = this.ProductName;

            double value;
            if (double.TryParse(this.Price,
               NumberStyles.AllowCurrencySymbol | NumberStyles.AllowDecimalPoint | NumberStyles.AllowThousands,
               null, out value))
            {
               this.Product.Price = value;
            }
            else
            {
            }

            if (double.TryParse(this.Cost,
               NumberStyles.AllowCurrencySymbol | NumberStyles.AllowDecimalPoint | NumberStyles.AllowThousands,
               null, out value))
            {
               this.Product.Cost = value;
            }
            else
            {
            }

            this.Product.IsActive = this.IsActive;
         }
      }

      public void Save()
      {
         ProductRepository repository = new ProductRepository();
         repository.ConnectionString = this.ConnectionString;

         // Create an instance and perform data conversion for web forms
         this.CreateProduct();

         if (this.Product.ProductId > 0)
         {
            repository.Update(this.Product);
         }
         else
         {
            repository.Insert(this.Product);
         }

         this.IsEditPanelVisible = false;
         this.IsButtonPanelVisible = false;
         this.RefreshGrid = true;
      }

      public void Cancel()
      {
         this.IsEditPanelVisible = false;
         this.IsButtonPanelVisible = false;
      }

      public void LoadProducts()
      {
         ProductRepository repository = new ProductRepository();
         repository.ConnectionString = this.ConnectionString;
         this.AllProducts = repository.GetAllProducts();
      }

      public void Load(int id)
      {
         ProductRepository repository = null;
         repository = new ProductRepository();
         repository.ConnectionString = this.ConnectionString;
         this.Product = repository.Select(id);
      }

      public void Add()
      {
         this.ProductId = -1;
         this.ProductName = string.Empty;
         this.Price = string.Empty;
         this.Cost = string.Empty;
         this.IsActive = false;

         this.IsEditPanelVisible = true;
         this.IsButtonPanelVisible = true;
      }
   }
}
