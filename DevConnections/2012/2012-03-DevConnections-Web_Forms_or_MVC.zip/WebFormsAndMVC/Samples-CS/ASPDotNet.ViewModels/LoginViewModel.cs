﻿using ASPDotNet.BusinessLayer;
using System.Security.Principal;
using System.ComponentModel.DataAnnotations;

namespace ASPDotNet.ViewModels
{
   public class LoginViewModel
   {
      [Display(Name = "Login Name")]
      [Required(ErrorMessage = "Login name is required")]
      public string LoginName { get; set; }

      [Display(Name = "Password")]
      [Required(ErrorMessage = "Password is required")]
      public string Password { get; set; }

      public string ReturnUrl { get; set; }
      public AuthenticationResult AuthenticationResult { get; set; }
      public string ConnectionString { get; set; }
      public bool IsMessageVisible { get; set; }
      public bool IsEditPanelVisible { get; set; }
      public bool IsButtonPanelVisible { get; set; }
      public string MessageText { get; set; }
      private User User { get; set; }

      public void SignIn()
      {
         // Could use a variety of different approaches,
         // for example, the ASP.NET Membership Provider

         // As an example, get the user from a repository
         // and validate the credentials.
         UserRepository repository = new UserRepository();
         this.User = repository.Retrieve(this.LoginName);

         // Naïve validation of login name and password,
         // for demo use only.
         if (this.User.LoginName == this.LoginName & this.User.Password == this.Password)
         {
            this.AuthenticationResult = AuthenticationResult.Success;
         }
         else
         {
            this.AuthenticationResult = AuthenticationResult.Failure;
            this.MessageText = "Invalid login.";
         }
      }

      public IPrincipal CreatePrincipal()
      {
         GenericIdentity identity = new GenericIdentity(this.User.LoginName);
         GenericPrincipal result = new GenericPrincipal(identity, this.User.Roles.ToArray());
         return result;
      }
   }
}
