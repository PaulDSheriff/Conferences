﻿using System.Collections.Generic;

namespace ASPDotNet.BusinessLayer
{
   public class UserRepository
   {
      public User Retrieve(string loginName)
      {
         User result = new User();

         result.LoginName = loginName;
         result.Password = "P@ssw0rd";
         result.UserName = "John Kuhn";
         result.Roles = new List<string>();
         result.Roles.Add("Product User");

         return result;
      }
   }
}
