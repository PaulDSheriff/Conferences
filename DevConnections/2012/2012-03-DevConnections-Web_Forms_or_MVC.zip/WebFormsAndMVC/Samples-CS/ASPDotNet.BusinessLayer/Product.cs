﻿using System.ComponentModel.DataAnnotations;

namespace ASPDotNet.BusinessLayer
{
   public class Product
   {
      [Required(ErrorMessage = "Product ID is required")]
      public int ProductId { get; set; }

      [Display(Name = "Product Name")]
      [Required(ErrorMessage = "Product name is required")]
      public string ProductName { get; set; }

      [Display(Name = "Price")]
      [Required(ErrorMessage = "Price is required")]
      [DataType(DataType.Currency, ErrorMessage = "Price must be numeric.")]
      public double Price { get; set; }

      [Display(Name = "Cost")]
      [Required(ErrorMessage = "Cost is required")]
      [DataType(DataType.Currency, ErrorMessage = "Cost must be numeric.")]
      public double Cost { get; set; }

      [Display(Name = "Is Active?")]
      public bool IsActive { get; set; }
   }
}
