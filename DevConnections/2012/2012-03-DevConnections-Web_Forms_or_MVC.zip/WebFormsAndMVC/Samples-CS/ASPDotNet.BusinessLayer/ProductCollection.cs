﻿using System.Collections.Generic;

namespace ASPDotNet.BusinessLayer
{
   public class ProductCollection : List<Product>
   {
   }
}
