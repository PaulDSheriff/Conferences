﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace ASPDotNet.BusinessLayer
{
   public class Customer
   {
      /// <summary>
      /// Customer name property with data annotations
      /// </summary>
      [Display(Name = "Customer Name")]
      [Required(ErrorMessage = "Customer name is required.")]
      public string CustomerName { get; set; }

      /// <summary>
      /// Credit limit property with data annotations
      /// </summary>
      [Display(Name = "Credit Limit")]
      [Required(ErrorMessage = "Credit limit is required.")]
      [DataType(DataType.Currency, ErrorMessage = "Credit limit must be currency.")]
      public double CreditLimit { get; set; }
   }
}
