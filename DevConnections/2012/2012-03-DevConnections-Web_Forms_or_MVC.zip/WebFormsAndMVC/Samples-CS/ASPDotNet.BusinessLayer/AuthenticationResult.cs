﻿
namespace ASPDotNet.BusinessLayer
{
   public enum AuthenticationResult
   {
      Success,
      Failure
   }
}
