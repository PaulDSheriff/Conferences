﻿using System;
using System.Web.Routing;
using ASPDotNet.Utilities;
using System.Web;

namespace WebFormSample.Website
{
   public class Global : System.Web.HttpApplication
   {
      #region Application Start

      void Application_Start(object sender, EventArgs e)
      {
         RegisterRoutes(RouteTable.Routes);
      }

      public static void RegisterRoutes(RouteCollection routes)
      {
         routes.MapPageRoute(string.Empty,
             "Products",
             "~/Product/ProductView.aspx",
             true);
      }

      #endregion

      #region Application End

      void Application_End(object sender, EventArgs e)
      {
         //  Code that runs on application shutdown
      }

      #endregion 

      #region Application Error

      void Application_Error(object sender, EventArgs e)
      {
         // Capture the details of the last exception
         Exception ex = Server.GetLastError();
         
         // Do error logging, etc.
         // ex: Logger.Log(ex);
         
         // Clear the last error
         Server.ClearError();

         // Navigate to a custom error page
         HttpContext.Current.Response.Redirect("~/Views/Sample06_Display.aspx");
      }

      #endregion

      #region Session Start 

      void Session_Start(object sender, EventArgs e)
      {
         // Code that runs when a new session is started
      }

      #endregion

      #region Session End

      void Session_End(object sender, EventArgs e)
      {
         // Code that runs when a session ends. 
         // Note: The Session_End event is raised only when the sessionstate mode
         // is set to InProc in the Web.config file. If session mode is set to StateServer 
         // or SQLServer, the event is not raised.
      }

      #endregion
   }
}
