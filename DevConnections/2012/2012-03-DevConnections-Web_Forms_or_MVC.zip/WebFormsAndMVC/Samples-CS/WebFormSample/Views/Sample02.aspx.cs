﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ASPDotNet.Utilities;

namespace WebFormSample.Views
{
   /// <summary>
   /// Sample 02 - Navigation - Page controller class 
   /// </summary>
   public partial class Sample02 : System.Web.UI.Page
   {
      /// <summary>
      /// Use standard response redirect to navigate.
      /// </summary>
      /// <param name="sender"></param>
      /// <param name="e"></param>
      protected void lnkTargetPage_Click(object sender, EventArgs e)
      {
         Response.Redirect("~/Views/Sample02_Target.aspx");
      }     
   }
}