﻿using System;
using ASPDotNet.Utilities;

namespace WebFormSample.Views
{
   /// <summary>
   /// Sample 01 - WebForms Security - Page controller class
   /// </summary>
   /// <remarks>
   /// This page is secured by an authorization element in the web.config
   /// </remarks>
   public partial class Sample01 : System.Web.UI.Page
   {
      /// <summary>
      /// Determine programmatically whether the user has permission to view 
      /// a feature.
      /// </summary>
      /// <param name="sender"></param>
      /// <param name="e"></param>
      protected void lnkShowSecuredContent_Click(object sender, EventArgs e)
      {
         if (this.User.IsInRole("Administrator"))
         {
            pnlSecuredContent.Visible = true;
         }
         else
         {
            Response.Redirect("~/Security/AccessDenied.aspx");
         }
      }
   }
}