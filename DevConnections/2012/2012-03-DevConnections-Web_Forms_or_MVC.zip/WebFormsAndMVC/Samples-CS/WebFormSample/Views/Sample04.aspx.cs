﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebFormSample.Views
{
   /// <summary>
   /// Sample 04 - WebForms Data Entry - Page controller class
   /// </summary>
   public partial class ValidationControls : System.Web.UI.Page 
   {
      protected void Save_Click(object sender, EventArgs e)
      {
         // IsValid is true if the server-side execution of the
         // validators succeeds

         if (Page.IsValid)
         {

         }
      }
   }
}