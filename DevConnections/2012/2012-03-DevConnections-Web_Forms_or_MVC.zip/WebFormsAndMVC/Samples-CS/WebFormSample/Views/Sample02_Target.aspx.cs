﻿using System;

namespace WebFormSample.Views
{
   /// <summary>
   /// Sample 02 - Navigation - Page controller class
   /// </summary>
   /// <remarks>
   /// Landing page for navigation samples.
   /// </remarks>
   public partial class Sample02_Target : System.Web.UI.Page
   {
      protected void Page_Load(object sender, EventArgs e)
      {
         // Nothing to do
      }
   }
}