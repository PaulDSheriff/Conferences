﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebFormSample.Views
{
   public partial class PageError : System.Web.UI.Page
   {
      private void CauseAnError()
      {
         int i = 1;
         int j = 0;

         double k = i / j;
      }

      /// <summary>
      /// Scope exception handling to each event handler
      /// </summary>
      /// <param name="sender"></param>
      /// <param name="e"></param>
      protected void lnkHandledException_Click(object sender, EventArgs e)
      {
         this.CauseAnError();

         try
         {
            
         }
         catch (Exception ex)
         {
            litMessage.Text = ex.Message;
            pnlErrorDisplay.Visible = true;
         }
      }

      /// <summary>
      /// Handle the page error event
      /// </summary>
      /// <param name="e"></param>
      protected override void OnError(EventArgs e)
      {
         base.OnError(e);

         Response.Write("<h2>An Error Occurred</h2>\n");
         Response.Write(string.Format("<p>{0}</p>", Server.GetLastError().Message));
         Server.ClearError();
      }
   }
}