﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebFormSample.Views
{
   /// <summary>
   /// Sample 05 - WebForm State - Page controller class
   /// </summary>
   public partial class Sample05 : System.Web.UI.Page
   {
      protected void lnkSession_Click(object sender, EventArgs e)
      {
         Session["CustomerName"] = "PDSA, Inc.";
      }

      protected void lnkApplication_Click(object sender, EventArgs e)
      {
         Application["CustomerType"] = "Good Customer";
      }

      protected void lnkViewState_Click(object sender, EventArgs e)
      {
         ViewState["CustomerStatus"] = "Active";
      }

      protected override void OnPreRender(EventArgs e)
      {
         base.OnPreRender(e);

         if (Session["CustomerName"] != null)
         {
            litSessionValue.Text = Session["CustomerName"].ToString();
         }

         if (Application["CustomerType"] != null)
         {
            litApplicationValue.Text = Application["CustomerType"].ToString();
         }

         if (ViewState["CustomerStatus"] != null)
         {
            litViewStateValue.Text = ViewState["CustomerStatus"].ToString();
         }
      }
   }
}