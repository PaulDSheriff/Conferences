﻿using System;
using System.Web.Security;
using ASPDotNet.BusinessLayer;
using ASPDotNet.ViewModels;

namespace WebFormSample.Security
{
   public partial class Login : System.Web.UI.Page
   {
      private LoginViewModel _vm = null;

      protected override void OnInit(EventArgs e)
      {
         base.OnInit(e);
         _vm = new LoginViewModel();
      }

      protected void Page_Load(object sender, EventArgs e)
      {
         _vm.IsMessageVisible = MessagePanel.Visible;
         _vm.LoginName = txtLoginName.Text;
         _vm.Password = txtPassword.Text;
      }

      protected void btnSignIn_Click(object sender, EventArgs e)
      {
         _vm.SignIn();
         switch (_vm.AuthenticationResult)
         {
            case AuthenticationResult.Success:
               FormsAuthentication.RedirectFromLoginPage(_vm.LoginName, false);
               break;
            case AuthenticationResult.Failure:
               // Message will display at pre-render
               break;
         }
      }

      protected override void OnPreRender(EventArgs e)
      {
         base.OnPreRender(e);

         MessagePanel.Visible = _vm.IsMessageVisible;
         MessageLiteral.Visible = _vm.IsMessageVisible;
         MessageLiteral.Text = _vm.MessageText;
         txtLoginName.Text = _vm.LoginName;
      }
   }
}