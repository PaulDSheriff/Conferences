﻿using System;
using System.Web.UI.WebControls;
using ASPDotNet.Utilities;
using ASPDotNet.ViewModels;

namespace WebFormSample.Website.Product
{
   public partial class ProductView : System.Web.UI.Page
   {
      #region ViewModel Instance

      ProductViewModel _vm = null;

      #endregion

      #region ViewState Property

      private int ProductId
      {
         get
         {
            if (ViewState["ProductId"] == null) 
               ViewState["ProductId"] = 0;
            return (int)ViewState["ProductId"];
         }
         set
         {
            ViewState["ProductId"] = value;
         }
      }

      #endregion

      #region Page Init 

      protected override void OnInit(EventArgs e)
      {
         base.OnInit(e);
         _vm = new ProductViewModel();
         _vm.ConnectionString = AppSettings.ConnectionString;
      }

      #endregion

      #region Page Load

      protected void Page_Load(object sender, EventArgs e)
      {
         _vm.IsMessageVisible = MessagePanel.Visible;
         _vm.IsEditPanelVisible = EditPanel.Visible;
         _vm.IsButtonPanelVisible = ButtonPanel.Visible;
         _vm.ProductId = this.ProductId;
         _vm.ProductName = txtProductName.Text;
         _vm.Price = txtPrice.Text;
         _vm.Cost = txtCost.Text;
         _vm.IsActive = chkIsActive.Checked;
      }

      #endregion

      #region Create Product

      protected void lnkCreateProduct_Click(object sender, EventArgs e)
      {
         _vm.Add();
      }

      #endregion

      #region Save Product

      protected void btnSave_Click(object sender, EventArgs e)
      {
         _vm.Save();
      }

      #endregion

      #region Cancel Editing

      protected void btnCancel_Click(object sender, EventArgs e)
      {
         _vm.Cancel();
      }

      #endregion

      #region Product Data Source

      protected void ProductDataSource_ObjectCreated(object sender, ObjectDataSourceEventArgs e)
      {
         ((ProductViewModel)e.ObjectInstance).ConnectionString = AppSettings.ConnectionString;
      }

      #endregion

      #region GridView RowCommands

      protected void ProductGridView_RowCommand(object sender, GridViewCommandEventArgs e)
      {
         try
         {
            switch (e.CommandName)
            {
               case "select":
                  _vm.Edit(e.CommandArgument);
                  break;
               case "remove":
                  _vm.Delete(e.CommandArgument);
                  break;
            }
         }
         catch (Exception ex)
         {
            _vm.Handle(ex);
         }
      }

      #endregion

      #region Page PreRender

      protected override void OnPreRender(EventArgs e)
      {
         base.OnPreRender(e);

         if (_vm.RefreshGrid) 
            ProductGridView.DataBind();
         MessagePanel.Visible = _vm.IsMessageVisible;
         MessageLiteral.Visible = _vm.IsMessageVisible;
         EditPanel.Visible = _vm.IsEditPanelVisible;
         ButtonPanel.Visible = _vm.IsButtonPanelVisible;
         this.ProductId = _vm.ProductId;
         txtProductName.Text = _vm.ProductName;
         txtPrice.Text = _vm.Price;
         txtCost.Text = _vm.Cost;
         chkIsActive.Checked = _vm.IsActive;
      }

      #endregion

   }
}