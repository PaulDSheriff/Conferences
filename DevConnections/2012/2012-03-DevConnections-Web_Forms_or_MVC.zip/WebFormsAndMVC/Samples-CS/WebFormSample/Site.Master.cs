﻿using System;

namespace WebFormSample.Website
{
   public partial class SiteMaster : System.Web.UI.MasterPage
   {
      protected void Page_Load(object sender, EventArgs e)
      {
         // Nothing to do
      }
   }
}
