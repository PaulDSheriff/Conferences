﻿using System;
using ASPDotNet.Utilities;

namespace WebFormSample.Website
{
   /// <summary>
   /// Page controller for the page that contains hyperlinks 
   /// to each of the samples.
   /// </summary>
   public partial class _Default : System.Web.UI.Page { }
}
