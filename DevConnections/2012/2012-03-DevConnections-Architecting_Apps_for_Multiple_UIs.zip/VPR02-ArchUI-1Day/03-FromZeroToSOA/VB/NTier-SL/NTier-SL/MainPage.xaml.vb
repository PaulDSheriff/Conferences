﻿Imports NTier_SL.PersonServiceReference

Partial Public Class MainPage
  Inherits UserControl

  Public Sub New()
    InitializeComponent()
  End Sub

  Private Sub UserControl_Loaded(sender As System.Object, e As System.Windows.RoutedEventArgs)
    GetPersons()
  End Sub

  Private Sub GetPersons()
    Dim client As New PersonServicesClient()

    AddHandler client.GetPersonsCompleted, AddressOf client_GetPersonsCompleted

    client.GetPersonsAsync()
    client.CloseAsync()
  End Sub

  Private Sub client_GetPersonsCompleted(ByVal sender As Object, ByVal e As GetPersonsCompletedEventArgs)
    If e.Result.Status = OperationResult.Success Then
      lstData.DataContext = e.Result.DataCollection
    Else
      tbMessage.Text = e.Result.ErrorMessageExtended
    End If
  End Sub

  Private Sub btnUpdate_Click(sender As System.Object, e As System.Windows.RoutedEventArgs)
    Dim client As New PersonServicesClient()
    Dim entity As Person

    entity = DirectCast(lstData.SelectedItem, Person)

    AddHandler client.UpdateCompleted, AddressOf client_UpdatePersonCompleted

    client.UpdateAsync(entity)
    client.CloseAsync()
  End Sub

  Private Sub client_UpdatePersonCompleted(ByVal sender As Object, ByVal e As UpdateCompletedEventArgs)
    If e.Result.Status = OperationResult.Success Then
      MessageBox.Show("Person Updated")
    Else
      tbMessage.Text = e.Result.ErrorMessage
    End If
  End Sub
End Class