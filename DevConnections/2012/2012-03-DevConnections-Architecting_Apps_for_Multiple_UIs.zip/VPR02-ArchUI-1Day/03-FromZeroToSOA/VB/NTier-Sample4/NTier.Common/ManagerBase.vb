﻿Imports System.Runtime.Serialization

Public Class ManagerBase
  Public Sub New()
    RowsAffected = 0
    SQL = String.Empty
    Message = String.Empty
    ConnectString = String.Empty
  End Sub

  Public Property RowsAffected() As Integer
    Get
      Return m_RowsAffected
    End Get
    Set(ByVal value As Integer)
      m_RowsAffected = value
    End Set
  End Property
  Private m_RowsAffected As Integer

  Public Property SQL() As String
    Get
      Return m_SQL
    End Get
    Set(ByVal value As String)
      m_SQL = value
    End Set
  End Property
  Private m_SQL As String

  Public Property Message() As String
    Get
      Return m_Message
    End Get
    Set(ByVal value As String)
      m_Message = value
    End Set
  End Property
  Private m_Message As String

  Public Property ConnectString() As String
    Get
      Return m_ConnectString
    End Get
    Set(ByVal value As String)
      m_ConnectString = value
    End Set
  End Property
  Private m_ConnectString As String
End Class