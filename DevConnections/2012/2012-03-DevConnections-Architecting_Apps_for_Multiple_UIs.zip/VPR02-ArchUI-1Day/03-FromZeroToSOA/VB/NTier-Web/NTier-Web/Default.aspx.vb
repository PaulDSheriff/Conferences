﻿Imports NTier.EntityClasses
Imports NTier_Web.PersonServiceReference

Public Class _Default
  Inherits System.Web.UI.Page

#Region "Page Load Event"
  Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
    If Not Page.IsPostBack Then
      GetPersons()
    End If
  End Sub
#End Region

#Region "GetPersons Method"
  Private Sub GetPersons()
    Dim client As PersonServicesClient = Nothing
    Dim resp As PersonResponse

    Try
      client = New PersonServicesClient()

      resp = client.GetPersons()
      If resp.Status = NTier.Common.OperationResult.Success Then
        grdData.DataSource = resp.DataCollection
        grdData.DataBind()
      Else
        lblExceptions.Text = resp.ErrorMessage
      End If
    Catch ex As Exception
      lblExceptions.Text = ex.Message
    End Try
  End Sub
#End Region

#Region "Grid RowCommand Event"
  Protected Sub grdData_RowCommand(ByVal sender As [Object], ByVal e As GridViewCommandEventArgs)
    If e.CommandName = "Select" Then
      Dim btn As ImageButton

      btn = DirectCast(e.CommandSource, ImageButton)
      pnlEdit.Visible = True
      divActionBar.Visible = True
      grdData.Enabled = False
      ShowData(GetPerson(Convert.ToInt32(btn.Attributes("PersonId"))))
    End If
  End Sub
#End Region

#Region "GetPerson Method"
  Private Function GetPerson(ByVal personId As Integer) As Person
    Dim client As PersonServicesClient = Nothing
    Dim resp As PersonResponse
    Dim entity As New Person()

    Try
      client = New PersonServicesClient()

      entity.PersonId = personId
      resp = client.GetPerson(entity)
      If resp.Status = NTier.Common.OperationResult.Success Then
        entity = resp.DetailData
        ShowData(entity)
      Else
        lblExceptions.Text = resp.ErrorMessage
      End If
    Catch ex As Exception
      lblExceptions.Text = ex.Message
    End Try

    Return entity
  End Function
#End Region

#Region "ShowData Method"
  Private Sub ShowData(ByVal entity As Person)
    txtPersonId.Text = entity.PersonId.ToString()
    txtFirstName.Text = entity.FirstName.Trim()
    txtLastName.Text = entity.LastName.Trim()
    txtEmailAddress.Text = entity.EmailAddress.Trim()
  End Sub
#End Region

#Region "GetData Method"
  Private Function GetData() As Person
    Dim entity As New Person()

    entity.PersonId = Convert.ToInt32(txtPersonId.Text)
    entity.FirstName = txtFirstName.Text.Trim()
    entity.LastName = txtLastName.Text.Trim()
    entity.EmailAddress = txtEmailAddress.Text.Trim()

    Return entity
  End Function
#End Region

#Region "Save Click Event"
  Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As ImageClickEventArgs)
    Dim client As PersonServicesClient = Nothing
    Dim resp As PersonResponse

    Try
      client = New PersonServicesClient()

      resp = client.Update(GetData())
      If resp.Status = NTier.Common.OperationResult.Success Then
        pnlEdit.Visible = False
        divActionBar.Visible = False
        grdData.Enabled = True
        ' Resync Data
        GetPersons()
      Else
        lblExceptions.Text = resp.ErrorMessage.Replace(Environment.NewLine, "<br />")
      End If
    Catch ex As Exception
      lblExceptions.Text = ex.Message
    End Try

  End Sub
#End Region

#Region "Cancel Click Event"
  Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As ImageClickEventArgs)
    divActionBar.Visible = False
    pnlEdit.Visible = False
    grdData.Enabled = True
  End Sub
#End Region

End Class