using System;

using NTier.Common;
using NTier.EntityClasses;
using NTier.DataClasses;

namespace NTier.Services
{
  public partial class PersonServices : IPersonServices
  {
    #region GetPerson Method
    public PersonResponse GetPerson(Person entity)
    {
      PersonResponse ret = new PersonResponse();
      PersonManager mgr = null;

      try
      {
        mgr = new PersonManager(AppConfig.ConnectString);

        ret.DetailData = mgr.GetPerson(entity.PersonId);
        ret.Status = OperationResult.Success;
      }
      catch (Exception ex)
      {
        ret.ErrorMessage = ex.Message;
        ret.ErrorMessageExtended = ex.ToString();
        ret.Status = OperationResult.Exception;
      }

      return ret;
    }
    #endregion

    #region BuildCollection Methods
    public PersonResponse GetPersons()
    {
      PersonResponse ret = new PersonResponse();
      PersonManager mgr = null;

      try
      {
        mgr = new PersonManager(AppConfig.ConnectString);

        ret.DataCollection = mgr.GetPersons();
        if (ret.DataCollection.Count > 0)
        {
          ret.Status = OperationResult.Success;
          ret.RowsAffected = ret.DataCollection.Count;
        }
        else
        {
          ret.Status = OperationResult.NoRecords;
          ret.ErrorMessage = mgr.Message;
          ret.FriendlyErrorMessage = "No records were found for this table.";
        }
      }
      catch (Exception ex)
      {
        ret.ErrorMessage = ex.Message;
        ret.ErrorMessageExtended = ex.ToString();
        ret.Status = OperationResult.Exception;
      }

      return ret;
    }
    #endregion

    #region Update Method
    public PersonResponse Update(Person entity)
    {
      PersonResponse ret = new PersonResponse();
      PersonManager mgr = null;

      try
      {
        mgr = new PersonManager(AppConfig.ConnectString);

        ret.RowsAffected = mgr.UpdatePerson(entity);
        if (ret.RowsAffected == 0)
        {
          if (mgr.Message != string.Empty)
          {
            ret.Status = OperationResult.Failure;
            ret.FriendlyErrorMessage = mgr.Message;
            ret.ErrorMessage = mgr.Message;
          }
          else
          {
            ret.Status = OperationResult.NoRecords;
            ret.FriendlyErrorMessage = "The record(s) you were trying to update could no be found.";
            ret.ErrorMessage = ret.FriendlyErrorMessage;
          }
        }
        else
        {
          ret.DetailData = entity;
          ret.ErrorMessage = mgr.Message;
          ret.Status = OperationResult.Success;
        }
      }
      catch (ValidationException ex)
      {
        ret.ErrorMessage = ex.Message;
        ret.ErrorMessageExtended = ex.Message;
        ret.Status = OperationResult.ValidationFailed;
      }
      catch (Exception ex)
      {
        ret.ErrorMessage = ex.Message;
        ret.ErrorMessageExtended = ex.ToString();
        ret.Status = OperationResult.Exception;
      }

      return ret;
    }
    #endregion
  }
}