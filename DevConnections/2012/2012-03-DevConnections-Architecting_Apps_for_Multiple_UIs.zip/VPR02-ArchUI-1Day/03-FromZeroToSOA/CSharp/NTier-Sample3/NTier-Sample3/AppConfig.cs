﻿using System.Configuration;

namespace NTier_Sample3
{
  public class AppConfig
  {
    public static string ConnectString
    {
      get { return ConfigurationManager.ConnectionStrings["Sandbox"].ConnectionString; }
    }
  }
}
