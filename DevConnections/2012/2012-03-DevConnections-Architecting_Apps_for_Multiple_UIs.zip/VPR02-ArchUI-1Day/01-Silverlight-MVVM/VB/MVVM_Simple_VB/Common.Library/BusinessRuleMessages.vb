﻿Imports System.Text

Public Class BusinessRuleMessages
  Inherits List(Of BusinessRuleMessage)

#Region "ToString method"
  Public Overrides Function ToString() As String
    Dim sb As New StringBuilder(1024)

    For Each item As BusinessRuleMessage In Me
      sb.Append(item.Message + Environment.NewLine)
    Next

    Return sb.ToString()
  End Function
#End Region
End Class
