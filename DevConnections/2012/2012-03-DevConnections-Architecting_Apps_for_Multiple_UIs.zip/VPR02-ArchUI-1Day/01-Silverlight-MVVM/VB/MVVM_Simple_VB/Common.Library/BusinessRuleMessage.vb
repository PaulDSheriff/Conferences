﻿Public Class BusinessRuleMessage
#Region "Constructors"
  Public Sub New()
  End Sub

  Public Sub New(ByVal propName As String, ByVal msg As String)
    PropertyName = propName
    Message = msg
  End Sub
#End Region

#Region "Public Properties"
  Public Property PropertyName() As String
    Get
      Return m_PropertyName
    End Get
    Set(ByVal value As String)
      m_PropertyName = Value
    End Set
  End Property
  Private m_PropertyName As String
  Public Property Message() As String
    Get
      Return m_Message
    End Get
    Set(ByVal value As String)
      m_Message = Value
    End Set
  End Property
  Private m_Message As String
#End Region
End Class
