﻿Partial Public Class MainPage
  Inherits UserControl

  Public Sub New()
    InitializeComponent()
  End Sub

#Region "Load User Control Method"
  Private Sub LoadUserControl(ByVal uc As UserControl)
    borContent.Visibility = System.Windows.Visibility.Visible
    contentArea.Children.Clear()
    contentArea.Children.Add(uc)
  End Sub
#End Region

  Private Sub btnClear_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    contentArea.Children.Clear()
    borContent.Visibility = System.Windows.Visibility.Collapsed
  End Sub

  Private Sub btnSearch_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    LoadUserControl(New ucSearchSample())
  End Sub

  Private Sub btnPerson_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    LoadUserControl(New ucPersonSample())
  End Sub

  Private Sub btnNoBinding_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    LoadUserControl(New ucNoBinding())
  End Sub

  Private Sub btnBasicBinding_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    LoadUserControl(New ucBasicDataBinding())
  End Sub

  Private Sub btnSimpleMVVM_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    LoadUserControl(New ucSimpleMVVM())
  End Sub
End Class