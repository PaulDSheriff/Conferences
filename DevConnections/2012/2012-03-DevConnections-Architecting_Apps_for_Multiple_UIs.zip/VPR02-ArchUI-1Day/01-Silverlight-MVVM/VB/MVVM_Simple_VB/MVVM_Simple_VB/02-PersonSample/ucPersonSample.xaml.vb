﻿Partial Public Class ucPersonSample
  Inherits UserControl

  Private _ViewModel As PersonViewModel

  Public Sub New()
    InitializeComponent()

    ' Grab instance of View Model from XAML
    _ViewModel = DirectCast(Me.Resources("viewModel"), PersonViewModel)
  End Sub

  Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button1.Click
    _ViewModel.Validate()
  End Sub
End Class
