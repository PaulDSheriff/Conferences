﻿Imports System.Collections.ObjectModel
Imports System.ComponentModel
Imports System.Windows
Imports Common.Library
Imports MVVM_Simple.ProductServiceReference

Public Class ProductViewModel
  Inherits ViewModelBase

  Private _IsAddMode As Boolean = False
  Private WithEvents _Client As ProductServicesClient

#Region "Private UI Variables"
  Private _IsSaveEnabled As Boolean = False
  Private _IsCancelEnabled As Boolean = False
  Private _IsAddEnabled As Boolean = True
  Private _IsListEnabled As Boolean = True
  Private _IsDetailEnabled As Boolean = False
  Private _SelectedListIndex As Integer = -1
  Private _Messages As String = String.Empty

  Private _DataCollection As ObservableCollection(Of Product)
  Private _DetailData As Product
#End Region

#Region "UI Properties"
  Public Property IsSaveEnabled() As Boolean
    Get
      Return _IsSaveEnabled
    End Get
    Set(ByVal value As Boolean)
      If _IsSaveEnabled <> value Then
        _IsSaveEnabled = value
        RaisePropertyChanged("IsSaveEnabled")
      End If
    End Set
  End Property

  Public Property IsCancelEnabled() As Boolean
    Get
      Return _IsCancelEnabled
    End Get
    Set(ByVal value As Boolean)
      If _IsCancelEnabled <> value Then
        _IsCancelEnabled = value
        RaisePropertyChanged("IsCancelEnabled")
      End If
    End Set
  End Property

  Public Property IsAddEnabled() As Boolean
    Get
      Return _IsAddEnabled
    End Get
    Set(ByVal value As Boolean)
      If _IsAddEnabled <> value Then
        _IsAddEnabled = value
        RaisePropertyChanged("IsAddEnabled")
      End If
    End Set
  End Property

  Public Property IsListEnabled() As Boolean
    Get
      Return _IsListEnabled
    End Get
    Set(ByVal value As Boolean)
      If _IsListEnabled <> value Then
        _IsListEnabled = value
        RaisePropertyChanged("IsListEnabled")
      End If
    End Set
  End Property

  Public Property SelectedListIndex() As Integer
    Get
      Return _SelectedListIndex
    End Get
    Set(ByVal value As Integer)
      If _SelectedListIndex <> value Then
        _SelectedListIndex = value
        RaisePropertyChanged("SelectedListIndex")
      End If
    End Set
  End Property

  Public Property IsDetailEnabled() As Boolean
    Get
      Return _IsDetailEnabled
    End Get
    Set(ByVal value As Boolean)
      If _IsDetailEnabled <> value Then
        _IsDetailEnabled = value
        RaisePropertyChanged("IsDetailEnabled")
      End If
    End Set
  End Property

  Public Property IsAddMode() As Boolean
    Get
      Return _IsAddMode
    End Get
    Set(ByVal value As Boolean)
      If _IsAddMode <> value Then
        _IsAddMode = value
        RaisePropertyChanged("IsAddMode")
      End If
    End Set
  End Property

  Public Property Messages() As String
    Get
      Return _Messages
    End Get
    Set(ByVal value As String)
      If _Messages <> value Then
        _Messages = value
        RaisePropertyChanged("Messages")
      End If
    End Set
  End Property
#End Region

#Region "DataCollection Property"
  Public Property DataCollection() As ObservableCollection(Of Product)
    Get
      Return _DataCollection
    End Get
    Set(ByVal value As ObservableCollection(Of Product))
      _DataCollection = value
      RaisePropertyChanged("DataCollection")
    End Set
  End Property
#End Region

#Region "DetailData Property"
  Public Property DetailData() As Product
    Get
      Return _DetailData
    End Get
    Set(ByVal value As Product)
      _DetailData = value
      RaisePropertyChanged("DetailData")
    End Set
  End Property
#End Region

#Region "SetNormalUIDisplay Method"
  Public Sub SetNormalUIDisplay()
    IsAddMode = False
    IsAddEnabled = True
    IsSaveEnabled = False
    IsCancelEnabled = False
    IsListEnabled = True
    IsDetailEnabled = False
  End Sub
#End Region

#Region "SetEditUIDisplay Method"
  Public Sub SetEditUIDisplay()
    IsAddEnabled = False
    IsSaveEnabled = True
    IsCancelEnabled = True
    IsListEnabled = False
    IsDetailEnabled = True
  End Sub
#End Region

#Region "LoadAll Method"
  Public Sub LoadAll()
    _Client = New ProductServicesClient()

    ' This will call the GetProductsCompleted once the data is returned
    _Client.GetProductsAsync()
    _Client.CloseAsync()
  End Sub

  Private Sub _DataManager_GetProductsCompleted(ByVal sender As Object, ByVal e As ProductServiceReference.GetProductsCompletedEventArgs) Handles _Client.GetProductsCompleted
    If e.Result.Status = OperationResult.Success Then
      DataCollection = e.Result.DataCollection
      SelectedListIndex = 0
    Else
      Messages = e.Result.ErrorMessage
    End If
  End Sub
#End Region

#Region "AddRecord Method"
  Public Sub AddRecord()
    SetEditUIDisplay()
    IsAddMode = True

    ' Create Empty Object for UI to Display
    DetailData = New Product()
    DetailData.IntroductionDate = DateTime.Now
    DetailData.IsDiscontinued = False
  End Sub
#End Region

#Region "CancelEdit Method"
  Public Sub CancelEdit()
    SetNormalUIDisplay()

    IsAddMode = False

    ' TODO: Write Code to Undo Here
  End Sub
#End Region

#Region "SaveData Method"
  Public Sub SaveData()
    If IsAddMode Then
      InsertData()
    Else
      UpdateData()
    End If

    SetNormalUIDisplay()
  End Sub
#End Region

#Region "Insert Data"
  Public Sub InsertData()
    Dim client As New ProductServicesClient()

    DataCollection.Add(DetailData)

    ' Save Data - Calls InsertCompleted Event When Done
    client.InsertAsync(DetailData)
    client.CloseAsync()
  End Sub

  Private Sub _DataManager_InsertCompleted(ByVal sender As Object, ByVal e As ProductServiceReference.InsertCompletedEventArgs) Handles _Client.InsertCompleted
    If e.Result.Status = OperationResult.Exception Then
      Messages = e.Result.ErrorMessage
    Else
      Messages = "Insert Successful"
    End If
  End Sub
#End Region

#Region "Update Data"
  Public Sub UpdateData()
    Dim client As New ProductServicesClient()

    ' Save Data - Calls UpdateCompleted when done
    client.UpdateAsync(DetailData)
    client.CloseAsync()
  End Sub

  Private Sub _DataManager_UpdateCompleted(ByVal sender As Object, ByVal e As ProductServiceReference.UpdateCompletedEventArgs) Handles _Client.UpdateCompleted
    If e.Result.Status = OperationResult.Exception Then
      Messages = e.Result.ErrorMessage
    Else
      Messages = "Update Successful"
    End If
  End Sub
#End Region
End Class