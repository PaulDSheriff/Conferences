﻿Public Class PersonViewModel
  Inherits ViewModelBase

#Region "Constructor"
  Public Sub New()
    DetailData = New Person()
  End Sub
#End Region

#Region "Private Variables"
  Private _DetailData As Person
#End Region

#Region "Public Properties"
  Public Property DetailData() As Person
    Get
      Return _DetailData
    End Get
    Set(ByVal value As Person)
      _DetailData = value
      RaisePropertyChanged("DetailData")
    End Set
  End Property
#End Region

#Region "Validate Method"
  Public Function Validate() As Boolean
    IsMessageVisible = False
    MessageToDisplay = String.Empty

    If DetailData.Validate() = False Then
      IsMessageVisible = True
      MessageToDisplay = DetailData.BusinessRuleFailures.ToString()
    End If

    Return Not IsMessageVisible
  End Function
#End Region
End Class