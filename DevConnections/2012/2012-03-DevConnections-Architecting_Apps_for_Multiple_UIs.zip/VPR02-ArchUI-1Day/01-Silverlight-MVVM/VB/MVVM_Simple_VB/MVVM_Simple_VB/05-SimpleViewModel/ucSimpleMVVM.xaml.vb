﻿Imports System.Windows
Imports System.Windows.Controls

Imports MVVM_Simple.ProductServiceReference

Partial Public Class ucSimpleMVVM
  Inherits UserControl
  Private _ViewModel As ProductViewModel

  Public Sub New()
    InitializeComponent()

    ' Initialize the Product View Model Object
    _ViewModel = DirectCast(Me.Resources("viewModel"), ProductViewModel)
  End Sub

  Private Sub UserControl_Loaded(ByVal sender As Object, ByVal e As RoutedEventArgs)
    ' Load Products
    _ViewModel.LoadAll()
  End Sub

#Region "Edit Click Event"
  Private Sub btnEdit_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    ' Get Data Context from Button
    ' So you can update the List Box SelectedValue
    _ViewModel.DetailData = DirectCast(DirectCast(sender, Button).DataContext, Product)
    _ViewModel.SetEditUIDisplay()
  End Sub
#End Region

#Region "Add Click Event"
  Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    _ViewModel.AddRecord()
  End Sub
#End Region

#Region "Cancel Click Event"
  Private Sub btnCancel_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    _ViewModel.CancelEdit()

    ' TODO: Write code to undo changes
  End Sub
#End Region

#Region "Save Click Event"
  Private Sub btnSave_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    _ViewModel.SaveData()
  End Sub
#End Region
End Class
