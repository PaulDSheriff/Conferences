﻿Public Class SearchViewModel
  Inherits ViewModelBase

#Region "Constructor"
  Public Sub New()
    StartDate = DateTime.Now
    EndDate = DateTime.Now.AddDays(14)
  End Sub
#End Region

#Region "Private Variables"
  Private _StartDate As DateTime
  Private _EndDate As DateTime
#End Region

#Region "Public Properties"
  Public Property StartDate() As DateTime
    Get
      Return _StartDate
    End Get
    Set(ByVal value As DateTime)
      _StartDate = value
      RaisePropertyChanged("StartDate")
    End Set
  End Property

  Public Property EndDate() As DateTime
    Get
      Return _EndDate
    End Get
    Set(ByVal value As DateTime)
      _EndDate = value
      RaisePropertyChanged("EndDate")
    End Set
  End Property
#End Region

#Region "Search Method"
  Public Sub Search()
    ' Do something else
    If Validate() Then
    End If
  End Sub
#End Region

#Region "Validate Method"
  Public Function Validate() As Boolean
    ' Use this to determine if the validation succeeds or not.
    IsMessageVisible = False
    ' Reset Message to Display
    MessageToDisplay = String.Empty

    ' Check Start Date versus End Date
    If StartDate > EndDate Then
      MessageToDisplay = "Start Date Must Be Less Than End Date"
      IsMessageVisible = True
    End If

    Return Not IsMessageVisible
  End Function
#End Region
End Class