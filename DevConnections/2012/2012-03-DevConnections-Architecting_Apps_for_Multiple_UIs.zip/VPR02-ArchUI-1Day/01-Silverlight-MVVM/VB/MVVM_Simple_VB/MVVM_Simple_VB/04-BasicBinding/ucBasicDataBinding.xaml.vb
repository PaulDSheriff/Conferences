﻿Imports System.Collections.ObjectModel
Imports System.Windows
Imports System.Windows.Controls
Imports System.ComponentModel

Imports MVVM_Simple.ProductServiceReference

Partial Public Class ucBasicDataBinding
  Inherits UserControl
  Implements INotifyPropertyChanged

  Private _Entity As Product
  Private _IsAddMode As Boolean = False
  Private WithEvents _Client As New ProductServicesClient()

  Public Sub New()
    InitializeComponent()

    IsAddEnabled = True
    IsSaveEnabled = False
    IsCancelEnabled = False
  End Sub

#Region "INotifyPropertyChanged"
  Public Event PropertyChanged As PropertyChangedEventHandler Implements INotifyPropertyChanged.PropertyChanged

  Protected Sub RaisePropertyChanged(ByVal propertyName As String)
    RaiseEvent PropertyChanged(Me, New PropertyChangedEventArgs(propertyName))
  End Sub
#End Region


#Region "Private UI Variables"
  Private _IsSaveEnabled As Boolean = False
  Private _IsCancelEnabled As Boolean = False
  Private _IsAddEnabled As Boolean = True
#End Region

#Region "UI Properties"
  Public Property IsSaveEnabled() As Boolean
    Get
      Return _IsSaveEnabled
    End Get
    Set(ByVal value As Boolean)
      If _IsSaveEnabled <> value Then
        _IsSaveEnabled = value
        RaisePropertyChanged("IsSaveEnabled")
      End If
    End Set
  End Property

  Public Property IsCancelEnabled() As Boolean
    Get
      Return _IsCancelEnabled
    End Get
    Set(ByVal value As Boolean)
      If _IsCancelEnabled <> value Then
        _IsCancelEnabled = value
        RaisePropertyChanged("IsCancelEnabled")
      End If
    End Set
  End Property

  Public Property IsAddEnabled() As Boolean
    Get
      Return _IsAddEnabled
    End Get
    Set(ByVal value As Boolean)
      If _IsAddEnabled <> value Then
        _IsAddEnabled = value
        RaisePropertyChanged("IsAddEnabled")
      End If
    End Set
  End Property
#End Region

#Region "Loaded Event"
  Private Sub UserControl_Loaded(ByVal sender As Object, ByVal e As RoutedEventArgs)
    __Client.GetProductsAsync()
    __Client.CloseAsync()
  End Sub

  Private Sub _Client_GetProductsCompleted(ByVal sender As Object, ByVal e As GetProductsCompletedEventArgs) Handles _Client.GetProductsCompleted
    lstData.DataContext = e.Result.DataCollection
  End Sub
#End Region

#Region "SelectionChanged Event"
  Private Sub lstData_SelectionChanged(ByVal sender As Object, ByVal e As SelectionChangedEventArgs)
    _Entity = DirectCast(lstData.SelectedItem, Product)

    grdDetail.DataContext = _Entity
  End Sub
#End Region

#Region "Add Click Event"
  Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    ' Create blank Object and Put UI into Add Mode
    ' Put UI into Add Mode
    _IsAddMode = True
    SetEditUIDisplay()

    _Entity = New Product()
    _Entity.IntroductionDate = DateTime.Now

    grdDetail.DataContext = _Entity
  End Sub
#End Region

#Region "Cancel Click Event"
  Private Sub btnCancel_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    ' Cancel the Edit
    SetNormalUIDisplay()

    ' TODO: Write code to undo changes

    lstData.SelectedIndex = 0
  End Sub
#End Region

#Region "Save Click Event"
  Private Sub btnSave_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    If _IsAddMode Then
      AddData()
    Else
      UpdateData()
    End If

    SetNormalUIDisplay()
  End Sub
#End Region

#Region "AddData Method"
  Private Sub AddData()
    _Client = New ProductServicesClient()

    _Entity = DirectCast(grdDetail.DataContext, Product)

    Dim coll As ObservableCollection(Of Product) = DirectCast(lstData.DataContext, ObservableCollection(Of Product))
    coll.Add(_Entity)

    ' Save Data
    _Client.InsertAsync(_Entity)
    _Client.CloseAsync()
  End Sub

  Private Sub _Client_InsertCompleted(ByVal sender As Object, ByVal e As InsertCompletedEventArgs) Handles _Client.InsertCompleted
    If e.Result.Status = OperationResult.Exception Then
      tbMessages.Text = e.Result.ErrorMessage
    Else
      tbMessages.Text = "Insert Successful"
    End If
  End Sub
#End Region

#Region "UpdateData Method"
  Private Sub UpdateData()
    _Entity = DirectCast(lstData.SelectedItem, Product)
    _Client = New ProductServicesClient()

    ' Save Data
    _Client.UpdateAsync(_Entity)
    _Client.CloseAsync()
  End Sub

  Private Sub _Client_UpdateCompleted(ByVal sender As Object, ByVal e As UpdateCompletedEventArgs) Handles _Client.UpdateCompleted
    If e.Result.Status = OperationResult.Exception Then
      tbMessages.Text = e.Result.ErrorMessage
    Else
      tbMessages.Text = "Update Successful"
    End If
  End Sub
#End Region

#Region "SetNormalUIDisplay Method"
  Private Sub SetNormalUIDisplay()
    _IsAddMode = False
    IsAddEnabled = True
    IsSaveEnabled = False
    IsCancelEnabled = False
  End Sub
#End Region

#Region "SetEditUIDisplay Method"
  Private Sub SetEditUIDisplay()
    IsAddEnabled = False
    IsSaveEnabled = True
    IsCancelEnabled = True
  End Sub
#End Region
End Class
