﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Runtime.Serialization
Imports System.ServiceModel
Imports System.Text

<ServiceContract([Namespace]:="http://PDSA.Sample")> _
  Public Interface IProductServices
  <OperationContract()> _
  Function GetProducts() As ProductResponse

  <OperationContract()> _
  Function GetProduct(ByVal productId As Integer) As ProductResponse

  <OperationContract()> _
  Function Update(ByVal prod As Product) As ProductResponse

  <OperationContract()> _
  Function Insert(ByVal prod As Product) As ProductResponse

  <OperationContract()> _
  Function Delete(ByVal productId As Integer) As ProductResponse
End Interface
