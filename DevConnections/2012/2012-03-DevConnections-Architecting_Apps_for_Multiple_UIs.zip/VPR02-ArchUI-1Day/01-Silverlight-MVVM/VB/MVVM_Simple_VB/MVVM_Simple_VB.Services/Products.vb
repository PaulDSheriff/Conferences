﻿Public Class Products
  Inherits List(Of Product)

End Class
