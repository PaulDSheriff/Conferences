﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using MVVM_Simple.ProductServiceReference;

namespace MVVM_Simple
{
  public partial class ucNoBinding : UserControl
  {
    public ucNoBinding()
    {
      InitializeComponent();
    }

    bool _IsAddMode = false;

    #region Loaded Event
    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      ProductServicesClient client = new ProductServicesClient();

      client.GetProductsCompleted += new EventHandler<GetProductsCompletedEventArgs>(client_GetProductsCompleted);
      client.GetProductsAsync();
      client.CloseAsync();
    }

    void client_GetProductsCompleted(object sender, GetProductsCompletedEventArgs e)
    {
      lstData.DataContext = e.Result.DataCollection;
    }    
    #endregion

    #region SelectionChanged Event
    private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      Product entity;
      entity = (Product)lstData.SelectedItem;

      txtProductId.Text = entity.ProductId.ToString();
      txtProductName.Text = entity.ProductName;
      txtPrice.Text = entity.Price.ToString();
      txtIntroductionDate.Text = entity.IntroductionDate.ToShortDateString();
      chkIsDiscontinued.IsChecked = entity.IsDiscontinued;
    }
    #endregion

    #region Add Click Event
    private void btnAdd_Click(object sender, RoutedEventArgs e)
    {
      // Put UI into Add Mode
      _IsAddMode = true;
      SetEditUIDisplay();

      // Create empty input fields
      txtProductId.Text = "0";
      txtProductName.Text = string.Empty;
      txtIntroductionDate.Text = DateTime.Now.ToShortDateString();
      txtPrice.Text = "0";
      chkIsDiscontinued.IsChecked = true;
    }
    #endregion

    #region Cancel Click Event
    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      // Cancel the Edit
      SetNormalUIDisplay();

      // TODO: Write code to undo changes

      lstData.SelectedIndex = 0;
    }
    #endregion

    #region Save Click Event
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      if (_IsAddMode)
        AddData();
      else
        UpdateData();

      SetNormalUIDisplay();
    }
    #endregion

    #region AddData Method
    private void AddData()
    {
      ProductServicesClient client = new ProductServicesClient();
      Product entity = new Product();

      entity.ProductId = Convert.ToInt32(txtProductId.Text);
      entity.ProductName = txtProductName.Text;
      entity.Price = Convert.ToDecimal(txtPrice.Text);
      entity.IntroductionDate = Convert.ToDateTime(txtIntroductionDate.Text);
      entity.IsDiscontinued = Convert.ToBoolean(chkIsDiscontinued.IsChecked);

      ObservableCollection<Product> coll = (ObservableCollection<Product>)lstData.DataContext;
      coll.Add(entity);

      client.InsertCompleted += new EventHandler<InsertCompletedEventArgs>(client_InsertCompleted);
      // Save Data
      client.InsertAsync(entity);
      client.CloseAsync();
    }

    void client_InsertCompleted(object sender, InsertCompletedEventArgs e)
    {
      if (e.Result.Status == OperationResult.Exception)
        tbMessages.Text = e.Result.ErrorMessage;
      else
        tbMessages.Text = "Save Successful";
    }
    #endregion

    #region UpdateData Method
    private void UpdateData()
    {
      ProductServicesClient client = new ProductServicesClient();
      Product entity = (Product)lstData.SelectedItem;

      entity.ProductId = Convert.ToInt32(txtProductId.Text);
      entity.ProductName = txtProductName.Text;
      entity.Price = Convert.ToDecimal(txtPrice.Text);
      entity.IntroductionDate = Convert.ToDateTime(txtIntroductionDate.Text);
      entity.IsDiscontinued = Convert.ToBoolean(chkIsDiscontinued.IsChecked);

      // Save Data
      client.UpdateCompleted += new EventHandler<UpdateCompletedEventArgs>(client_UpdateCompleted);
      client.UpdateAsync(entity);
      client.CloseAsync();
    }

    void client_UpdateCompleted(object sender, UpdateCompletedEventArgs e)
    {
      if (e.Result.Status == OperationResult.Exception)
        tbMessages.Text = e.Result.ErrorMessage;
      else
        tbMessages.Text = "Save Successful";
    }
    #endregion

    #region SetNormalUIDisplay Method
    private void SetNormalUIDisplay()
    {
      _IsAddMode = false;
      btnAdd.IsEnabled = true;
      btnSave.IsEnabled = false;
      btnCancel.IsEnabled = false;
    }
    #endregion

    #region SetEditUIDisplay Method
    private void SetEditUIDisplay()
    {
      btnAdd.IsEnabled = false;
      btnSave.IsEnabled = true;
      btnCancel.IsEnabled = true;
    }
    #endregion
  }
}
