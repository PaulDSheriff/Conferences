﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using Common.Library;
using MVVM_Simple.ProductServiceReference;

namespace MVVM_Simple
{
  public class ProductViewModelListOnly : ViewModelBase
  {
    #region DataCollection Property
    private ObservableCollection<Product> _DataCollection;

    public ObservableCollection<Product> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region LoadAll Method
    public void LoadAll()
    {
      try
      {
        ProductServicesClient client = new ProductServicesClient();

        client.GetProductsCompleted += new EventHandler<GetProductsCompletedEventArgs>(client_GetProductsCompleted);
        client.GetProductsAsync();
        client.CloseAsync();
      }
      catch
      {
        // Ignore exception in design time
      }
    }

    void client_GetProductsCompleted(object sender, GetProductsCompletedEventArgs e)
    {
      DataCollection = e.Result.DataCollection;
    }
    #endregion
  }
}
