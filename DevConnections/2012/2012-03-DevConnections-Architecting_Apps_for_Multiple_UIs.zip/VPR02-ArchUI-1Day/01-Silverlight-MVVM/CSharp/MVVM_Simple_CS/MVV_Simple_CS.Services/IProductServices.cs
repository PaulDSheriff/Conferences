﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace MVV_Simple_CS.Services
{
  [ServiceContract(Namespace = "http://PDSA.Sample")]
  public interface IProductServices
  {
    [OperationContract]
    ProductResponse GetProducts();

    [OperationContract]
    ProductResponse GetProduct(int productId);

    [OperationContract]
    ProductResponse Update(Product prod);

    [OperationContract]
    ProductResponse Insert(Product prod);

    [OperationContract]
    ProductResponse Delete(int productId);
  }
}