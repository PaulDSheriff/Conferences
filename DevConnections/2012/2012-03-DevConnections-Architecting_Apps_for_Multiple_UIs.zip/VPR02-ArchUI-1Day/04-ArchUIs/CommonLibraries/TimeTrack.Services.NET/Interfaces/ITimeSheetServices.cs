using System.ServiceModel;

using TimeTrack.DataClasses;
using TimeTrack.EntityClasses;

namespace TimeTrack.Services
{
  [ServiceContract(Namespace = "http://TimeTrack.Services")]
  public interface ITimeSheetServices
  {
    [OperationContract]
    TimeSheetResponse GetTimeSheet(TimeSheet entity);

    [OperationContract]
    TimeSheetResponse GetAllTimeSheets();

    [OperationContract]
    TimeSheetResponse GetTimeSheetsByCustomer(Customer entity);

    [OperationContract]
    TimeSheetResponse Insert(TimeSheet entity);
  }
}
