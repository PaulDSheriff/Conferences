﻿using System;
using System.Runtime.Serialization;

namespace Common.Library
{
  #region OperationResult Enumeration
  /// <summary>
  /// Enumeration for the results of calls to data services
	/// You can add additional enumerations for what you need in your app
  /// </summary>
  public enum OperationResult
  {
    Unknown,
    Success,
    Exception,
    Failure,
    NoRecords,
    ValidationFailed
  }
  #endregion

  /// <summary>
  /// Class that all Response classes will inherit from.
	/// Allows you to add additional properties in one place
	/// Always return a Response class. Keeps your ViewModel layer consistent.
	/// Allows your Services to do all exception trapping, logging, etc.
  /// </summary>
  [DataContract]
  public class ResponseBase
  {
    #region Constructor
    public ResponseBase()
    {
      Status = OperationResult.Unknown;
      FriendlyErrorMessage = string.Empty;
      ErrorMessage = string.Empty;
    }
    #endregion

    #region Public Properties
    [DataMember]
    public OperationResult Status { get; set; }

    [DataMember]
    public string FriendlyErrorMessage { get; set; }

    [DataMember]
    public string ErrorMessage { get; set; }

    [DataMember]
    public string ErrorMessageExtended { get; set; }

    [DataMember]
    public int RowsAffected { get; set; }
    #endregion
  }
}
