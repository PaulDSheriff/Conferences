﻿using System;
using System.Windows;

using WCFSample5_CS.ProductServiceReference;

namespace WCFSample5_CS
{
  public partial class winProductList : Window
  {
    public winProductList()
    {
      InitializeComponent();
    }

    private void btnLoad_Click(object sender, RoutedEventArgs e)
    {
      GetProducts();
    }

    private void GetProducts()
    {
      ProductResponse resp;
      ProductServicesClient client = null;

      try
      {
        client = new ProductServicesClient();
        resp = client.GetProducts();

        switch (resp.Status)
        {
          case OperationResult.Success:
            lstData.DataContext = resp.DataCollection;
            break;
          case OperationResult.Exception:
            tbMessage.Text = resp.ErrorMessage;
            break;
          case OperationResult.Failure:
            tbMessage.Text = resp.FriendlyErrorMessage;
            break;
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        if (client != null)
          client.Close();
      }
    }
  }
}
