﻿using System;
using System.Windows;


using WCFSample5_CS.ProductServiceReference;

namespace WCFSample5_CS
{
  public partial class winProduct : Window
  {
    public winProduct()
    {
      InitializeComponent();

      this.DataContext = new Product();
    }

    #region GetProduct Methods
    private void btnGetProduct_Click(object sender, RoutedEventArgs e)
    {
      GetProduct();
    }

    private void GetProduct()
    {
      ProductResponse resp;
      ProductServicesClient client = null;

      try
      {
        client = new ProductServicesClient();
        resp = client.GetProduct(
           Convert.ToInt32(txtProductId.Text));

        switch (resp.Status)
        {
          case OperationResult.Success:
            this.DataContext = resp.DetailData;
            break;
          case OperationResult.Exception:
            tbMessage.Text = resp.ErrorMessage;
            break;
          case OperationResult.Failure:
            tbMessage.Text = resp.FriendlyErrorMessage;
            break;
        }        
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        if (client != null)
          client.Close();
      }
    }
    #endregion

    #region Update Methods
    private void btnUpdate_Click(object sender, RoutedEventArgs e)
    {
      UpdateProduct();
    }

    private void UpdateProduct()
    {
      Product prod = new Product();
      ProductServicesClient client = null;
      ProductResponse resp;

      try
      {
        prod = (Product)this.DataContext;
       
        client = new ProductServicesClient();
        resp = client.Update(prod);

        if (resp.Status == OperationResult.Success)
          MessageBox.Show("Product Update Successful");
        else
          MessageBox.Show(resp.FriendlyErrorMessage);
      }

      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        if (client != null)
          client.Close();
      }
    }
    #endregion

    #region Insert Methods
    private void btnInsert_Click(object sender, RoutedEventArgs e)
    {
      InsertProduct();
    }

    private void InsertProduct()
    {
      Product prod = new Product();
      ProductServicesClient client = null;
      ProductResponse resp;

      try
      {
        prod = (Product)this.DataContext;

        client = new ProductServicesClient();
        resp = client.Insert(prod);

        if (resp.Status == OperationResult.Success)
        {
          txtProductId.Text = resp.DetailData.ProductId.ToString();
          MessageBox.Show("Product Insert Successful");
        }
        else
          MessageBox.Show(resp.FriendlyErrorMessage);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        if (client != null)
          client.Close();
      }
    }
    #endregion

    #region Delete Methods
    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      DeleteProduct();
    }

    private void DeleteProduct()
    {
      ProductServicesClient client = null;
      ProductResponse resp;

      try
      {
        client = new ProductServicesClient();
        resp = client.Delete(Convert.ToInt32(txtProductId.Text));

        if (resp.Status == OperationResult.Success)
          MessageBox.Show("Product Delete Successful");
        else
          MessageBox.Show(resp.FriendlyErrorMessage);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        if (client != null)
          client.Close();
      }
    }
    #endregion
  }
}
