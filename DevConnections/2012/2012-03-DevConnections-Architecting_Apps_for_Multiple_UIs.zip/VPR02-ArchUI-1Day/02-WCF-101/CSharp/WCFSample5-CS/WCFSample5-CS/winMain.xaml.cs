﻿using System.Windows;

namespace WCFSample5_CS
{
  public partial class winMain : Window
  {
    public winMain()
    {
      InitializeComponent();
    }

    private void btnAddEditDelete_Click(object sender, RoutedEventArgs e)
    {
      winProduct win = new winProduct();

      win.Show();
    }

    private void btnList_Click(object sender, RoutedEventArgs e)
    {
      winProductList win = new winProductList();

      win.Show();
    }

    private void btnListAsync_Click(object sender, RoutedEventArgs e)
    {
      winProductListAsync win = new winProductListAsync();

      win.Show();
    }
  }
}
