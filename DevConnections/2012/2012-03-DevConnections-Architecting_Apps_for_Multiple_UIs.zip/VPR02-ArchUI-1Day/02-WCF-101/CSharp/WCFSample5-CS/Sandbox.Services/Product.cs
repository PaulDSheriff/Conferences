﻿using System;

using System.Runtime.Serialization;

namespace Sandbox.Services
{
  [DataContract]
  public class Product
  {
    public Product()
    {
    }

    public Product(int productId, string productName)
    {
      this.ProductId = productId;
      this.ProductName = productName;
    }

    [DataMember]
    public int ProductId { get; set; }

    [DataMember]
    public string ProductName { get; set; }

    [DataMember]
    public DateTime IntroductionDate { get; set; }

    [DataMember]
    public decimal Cost { get; set; }

    [DataMember]
    public decimal Price { get; set; }

    [DataMember]
    public bool IsDiscontinued { get; set; }
  }
}
