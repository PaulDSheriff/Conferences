﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Sandbox.Service.Host
{
  [ServiceContract(Namespace = "http://PDSA.WCF101.Sample2")]
  public interface IProductServices
  {
    [OperationContract]
    string GetProductName(int productId);
  }
}