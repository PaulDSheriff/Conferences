﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Configuration;
using System.Data;
using System.Data.SqlClient;

using WCFSample2_CS.SandboxServiceHost;

namespace WCFSample2_CS
{
  /// <summary>
  /// Interaction logic for frmProduct.xaml
  /// </summary>
  public partial class frmProduct : Window
  {
    public frmProduct()
    {
      InitializeComponent();
    }

    private void btnGetProduct_Click(object sender, RoutedEventArgs e)
    {
      GetProductName();
    }

    private void GetProductName()
    {
      ProductServicesClient client = null;

      try
      {
        client = new ProductServicesClient();
        txtProductName.Text = 
          client.GetProductName(
           Convert.ToInt32(txtProductId.Text));
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        if (client != null) 
          client.Close();
      }
    }
  }
}
