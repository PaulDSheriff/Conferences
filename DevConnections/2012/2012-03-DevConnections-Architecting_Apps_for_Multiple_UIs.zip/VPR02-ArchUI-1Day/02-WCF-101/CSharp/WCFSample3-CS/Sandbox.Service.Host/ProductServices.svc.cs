﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Sandbox.Service.Host
{
  public class ProductServices : IProductServices
  {
    public Product GetProduct(int productId)
    {
      Product ret = null;

      ret = new Product(productId, "Visual Studio .NET");

      return ret;
    }
  }
}
