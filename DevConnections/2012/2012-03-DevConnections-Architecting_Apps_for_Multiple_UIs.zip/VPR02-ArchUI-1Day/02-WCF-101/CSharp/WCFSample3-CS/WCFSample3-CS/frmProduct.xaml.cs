﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using WCFSample3_CS.SandboxServiceHost;

namespace WCFSample3_CS
{
  /// <summary>
  /// Interaction logic for frmProduct.xaml
  /// </summary>
  public partial class frmProduct : Window
  {
    public frmProduct()
    {
      InitializeComponent();
    }

    private void btnGetProduct_Click(object sender, RoutedEventArgs e)
    {
      GetProduct();
    }

    private void GetProduct()
    {
      Product prod;
      ProductServicesClient client = null;

      try
      {
        client = new ProductServicesClient();
        prod = client.GetProduct(
           Convert.ToInt32(txtProductId.Text));

        txtProductName.Text = prod.ProductName;
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        if (client != null)
          client.Close();
      }
    }
  }
}
