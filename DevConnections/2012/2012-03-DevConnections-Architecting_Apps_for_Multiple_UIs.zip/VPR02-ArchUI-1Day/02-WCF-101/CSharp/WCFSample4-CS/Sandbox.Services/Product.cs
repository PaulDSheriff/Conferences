﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Runtime.Serialization;

namespace Sandbox.Services
{
  [DataContract]
  public class Product
  {
    public Product(int productId, string productName)
    {
      this.ProductId = productId;
      this.ProductName = productName;
    }

    [DataMember]
    public int ProductId { get; set; }

    [DataMember]
    public string ProductName { get; set; }
  }
}
