﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sandbox.Services
{
  public class ProductServices : IProductServices
  {
    public Product GetProduct(int productId)
    {
      Product ret = null;

      ret = new Product(productId,
           "Visual Studio .NET");

      return ret;
    }
  }
}
