﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Sandbox.Services
{
  [ServiceContract(Namespace = "http://PDSA.WCF101.Sample4")]
  public interface IProductServices
  {
    [OperationContract]
    Product GetProduct(int productId);
  }
}