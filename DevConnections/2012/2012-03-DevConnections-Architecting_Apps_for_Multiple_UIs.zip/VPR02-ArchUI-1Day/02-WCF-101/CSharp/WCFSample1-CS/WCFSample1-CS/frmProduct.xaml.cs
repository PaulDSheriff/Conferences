﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace WCFSample1_CS
{
  /// <summary>
  /// Interaction logic for frmProduct.xaml
  /// </summary>
  public partial class frmProduct : Window
  {
    public frmProduct()
    {
      InitializeComponent();
    }

    private void btnGetProduct_Click(object sender, RoutedEventArgs e)
    {
      txtProductName.Text = 
         GetProductName(Convert.ToInt32(txtProductId.Text));
    }

    private string GetProductName(int productId)
    {
      // 2-Tier approach to data retrieval
      string ret = string.Empty;
      string sql = string.Empty;
      SqlCommand cmd = null;
      SqlConnection cnn = null;
      SqlParameter parm = null;

      sql = "SELECT ProductName ";
      sql += " FROM Product ";
      sql += " WHERE ProductId = @ProductId";
      try
      {
        cnn = new SqlConnection(
           ConfigurationManager.
             ConnectionStrings["ConnectString"].
               ConnectionString);
        cmd = new SqlCommand(sql, cnn);
        parm = new SqlParameter("@ProductId", productId);
        cmd.Parameters.Add(parm);
        cnn.Open();
        ret = cmd.ExecuteScalar().ToString();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        if (cnn != null & 
             cnn.State == ConnectionState.Open) 
          cnn.Close();
      }

      return ret;
    }
  }
}
