﻿using System;
using System.Windows;
using System.Windows.Controls;

using WCFSample_Silverlight.ProductServiceReference;

namespace WCFSample_Silverlight
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    ProductServicesClient client = null;

    private void btnLoad_Click(object sender, RoutedEventArgs e)
    {
      GetProducts();
    }

    private void GetProducts()
    {
      try
      {
        client = new ProductServicesClient();
        client.GetProductsCompleted += new EventHandler<GetProductsCompletedEventArgs>(client_GetProductsCompleted);
        client.GetProductsAsync();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }

    void client_GetProductsCompleted(object sender, GetProductsCompletedEventArgs e)
    {
      ProductResponse resp;

      try
      {
        resp = e.Result;

        switch (resp.Status)
        {
          case OperationResult.Success:
            lstData.DataContext = resp.DataCollection;
            break;
          case OperationResult.Exception:
            tbMessage.Text = resp.ErrorMessage;
            break;
          case OperationResult.Failure:
            tbMessage.Text = resp.FriendlyErrorMessage;
            break;
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        if (client != null)
          client.CloseAsync();
      }
    }
  }
}
