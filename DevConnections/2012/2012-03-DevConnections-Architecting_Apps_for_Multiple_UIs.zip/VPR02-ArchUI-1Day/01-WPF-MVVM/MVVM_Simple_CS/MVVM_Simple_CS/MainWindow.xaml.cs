﻿using System.Windows;
using System.Windows.Controls;

namespace MVVM_Simple
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    #region Load User Control Method
    private void LoadUserControl(UserControl uc)
    {
      borContent.Visibility = System.Windows.Visibility.Visible;
      contentArea.Children.Clear();
      contentArea.Children.Add(uc);
    }
    #endregion

    private void btnClear_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      borContent.Visibility = System.Windows.Visibility.Collapsed;
    }

    private void btnSearch_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucSearchSample());
    }

    private void btnPerson_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucPersonSample());
    }

    private void btnNoBindingListOnly_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucNoBindingListOnly());
    }

    private void btnNoBinding_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucNoBinding());
    }

    private void btnBasicBinding_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucBasicDataBinding());
    }

    private void btnSimpleMVVMListOnly_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucSimpleMVVMListOnly());
    }

    private void btnSimpleMVVM_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucSimpleMVVM());
    }

    private void btnSimpleMVVM2_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucSimpleMVVM2());
    }
  }
}
