﻿using System.Collections.ObjectModel;
using Common.Library;
using MVV_Simple_CS.Services;

namespace MVVM_Simple
{
  public class ProductViewModelListOnly : ViewModelBase
  {
    #region DataCollection Property
    private ObservableCollection<Product> _DataCollection;

    public ObservableCollection<Product> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region LoadAll Method
    public void LoadAll()
    {
      try
      {
        ProductServices client = new ProductServices();
        ProductResponse resp;

        resp = client.GetProducts();
        DataCollection = new ObservableCollection<Product>(resp.DataCollection);
      }
      catch
      {
        // Ignore exception in design time
      }
    }
    #endregion
  }
}
