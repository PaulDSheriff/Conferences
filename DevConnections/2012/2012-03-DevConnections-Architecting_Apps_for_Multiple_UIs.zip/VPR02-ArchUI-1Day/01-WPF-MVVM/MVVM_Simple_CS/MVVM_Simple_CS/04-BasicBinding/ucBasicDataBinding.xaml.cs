﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using MVV_Simple_CS.Services;

namespace MVVM_Simple
{
  public partial class ucBasicDataBinding : UserControl, INotifyPropertyChanged
  {
    Product _Entity;
    bool _IsAddMode = false;

    public ucBasicDataBinding()
    {
      InitializeComponent();

      IsAddEnabled = true;
      IsSaveEnabled = false;
      IsCancelEnabled = false;
    }

    #region INotifyPropertyChanged
    /// <summary>
    /// The PropertyChanged Event to raise to any UI object
    /// </summary>
    public event PropertyChangedEventHandler PropertyChanged;

    /// <summary>
    /// The PropertyChanged Event to raise to any UI object
    /// The event is only invoked if data binding is used
    /// </summary>
    /// <param name="propertyName">The property name that is changing</param>
    protected void RaisePropertyChanged(string propertyName)
    {
      PropertyChangedEventHandler handler = this.PropertyChanged;
      if (handler != null)
      {
        PropertyChangedEventArgs args = new PropertyChangedEventArgs(propertyName);

        // Raise the PropertyChanged event.
        handler(this, args);
      }
    }
    #endregion

    #region Private UI Variables
    private bool _IsSaveEnabled = false;
    private bool _IsCancelEnabled = false;
    private bool _IsAddEnabled = true;
    #endregion

    #region UI Properties
    public bool IsSaveEnabled
    {
      get { return _IsSaveEnabled; }
      set
      {
        if (_IsSaveEnabled != value)
        {
          _IsSaveEnabled = value;
          RaisePropertyChanged("IsSaveEnabled");
        }
      }
    }

    public bool IsCancelEnabled
    {
      get { return _IsCancelEnabled; }
      set
      {
        if (_IsCancelEnabled != value)
        {
          _IsCancelEnabled = value;
          RaisePropertyChanged("IsCancelEnabled");
        }
      }
    }

    public bool IsAddEnabled
    {
      get { return _IsAddEnabled; }
      set
      {
        if (_IsAddEnabled != value)
        {
          _IsAddEnabled = value;
          RaisePropertyChanged("IsAddEnabled");
        }
      }
    }
    #endregion

    #region Loaded Event
    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      ProductServices client = new ProductServices();
      ProductResponse resp;

      resp = client.GetProducts();
      ObservableCollection<Product> coll = new ObservableCollection<Product>(resp.DataCollection);

      lstData.DataContext = coll;
    }
    #endregion

    #region SelectionChanged Event
    private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      _Entity = (Product)lstData.SelectedItem;

      grdDetail.DataContext = _Entity;
    }
    #endregion

    #region Add Click Event
    private void btnAdd_Click(object sender, RoutedEventArgs e)
    {
      // Create blank Object and Put UI into Add Mode
      // Put UI into Add Mode
      _IsAddMode = true;
      SetEditUIDisplay();
      _Entity = new Product();
      _Entity.IntroductionDate = DateTime.Now;

      grdDetail.DataContext = _Entity;
    }
    #endregion

    #region Cancel Click Event
    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      // Cancel the Edit
      SetNormalUIDisplay();

      // TODO: Write code to undo changes

      lstData.SelectedIndex = 0;
    }
    #endregion

    #region Save Click Event
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      if (_IsAddMode)
        AddData();
      else
        UpdateData();

      SetNormalUIDisplay();
    }
    #endregion

    #region AddData Method
    private void AddData()
    {
      ProductServices client = new ProductServices();
      ProductResponse resp;

      _Entity = (Product)grdDetail.DataContext;

      // Insert Product
      resp = client.Insert(_Entity);
      if (resp.Status == OperationResult.Exception)
        tbMessages.Text = resp.ErrorMessage;
      else
      {
        tbMessages.Text = "Save Successful";

        // Get Collection
        ObservableCollection<Product> coll = (ObservableCollection<Product>)lstData.DataContext;
        // Add new entity to collection
        coll.Add(_Entity);
      }
    }
    #endregion

    #region UpdateData Method
    private void UpdateData()
    {
      ProductServices client = new ProductServices();
      ProductResponse resp;
      Product entity = (Product)lstData.SelectedItem;

      _Entity = (Product)lstData.SelectedItem;

      // Update Product
      resp = client.Update(entity);
      if (resp.Status == OperationResult.Exception)
        tbMessages.Text = resp.ErrorMessage;
      else
        tbMessages.Text = "Save Successful";
    }
    #endregion

    #region SetNormalUIDisplay Method
    private void SetNormalUIDisplay()
    {
      _IsAddMode = false;
      IsAddEnabled = true;
      IsSaveEnabled = false;
      IsCancelEnabled = false;
    }
    #endregion

    #region SetEditUIDisplay Method
    private void SetEditUIDisplay()
    {
      IsAddEnabled = false;
      IsSaveEnabled = true;
      IsCancelEnabled = true;
    }
    #endregion

    #region Data Has Changed Methods
    private void TextHasChanged(object sender, TextChangedEventArgs e)
    {
      // Only Change Mode if Element has Keyboard Focus
      if (((UIElement)sender).IsKeyboardFocused)
        SetEditUIDisplay();
    }

    private void CheckedHasChanged(object sender, RoutedEventArgs e)
    {
      if (((UIElement)sender).IsKeyboardFocused || ((UIElement)sender).IsMouseDirectlyOver)
        SetEditUIDisplay();
    }
    #endregion
  }
}
