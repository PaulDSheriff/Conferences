﻿using System;
using System.Collections.ObjectModel;
using Common.Library;
using MVV_Simple_CS.Services;

namespace MVVM_Simple
{
  public class ProductViewModel2 : ViewModelAddEditDeleteBase
  {
    #region Private UI Variables
    private ObservableCollection<Product> _DataCollection;
    private Product _DetailData;
    #endregion

    #region DataCollection Property
    public ObservableCollection<Product> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region DetailData Property
    public Product DetailData
    {
      get { return _DetailData; }
      set
      {
        _DetailData = value;
        RaisePropertyChanged("DetailData");
      }
    }
    #endregion
    
    #region LoadAll Method
    public void LoadAll()
    {
      try
      {
        ProductServices client = new ProductServices();
        ProductResponse resp;

        resp = client.GetProducts();
        if (resp.Status == OperationResult.Success)
        {
          DataCollection = new ObservableCollection<Product>(resp.DataCollection);
          SelectedListIndex = 0;
        }
        else
          Messages = resp.ErrorMessage;
      }
      catch
      {
        // Ignore exception in design time
      }
    }
    #endregion

    #region AddRecord Method
    public void AddRecord()
    {
      SetEditUIDisplay();
      IsAddMode = true;

      // Create Empty Object for UI to Display
      DetailData = new Product();
      DetailData.IntroductionDate = DateTime.Now;
      DetailData.IsDiscontinued = false;
    }
    #endregion

    #region CancelEdit Method
    public void CancelEdit()
    {
      SetNormalUIDisplay();

      IsAddMode = false;

      // TODO: Write Code to Undo Here
    }
    #endregion

    #region SaveData Method
    public void SaveData()
    {
      if (IsAddMode)
        InsertData();
      else
        UpdateData();

      SetNormalUIDisplay();
    }
    #endregion

    #region Insert Data
    public void InsertData()
    {
      ProductServices client = new ProductServices();
      ProductResponse resp;

      // Insert Product
      resp = client.Insert(DetailData);
      if (resp.Status == OperationResult.Exception)
        Messages = resp.ErrorMessage;
      else
        Messages = "Insert Successful";
    }
    #endregion

    #region Update Data
    public void UpdateData()
    {
      ProductServices client = new ProductServices();
      ProductResponse resp;

      // Insert Product
      resp = client.Insert(DetailData);
      if (resp.Status == OperationResult.Exception)
        Messages = resp.ErrorMessage;
      else
        Messages = "Update Successful";
    }
    #endregion
  }
}
