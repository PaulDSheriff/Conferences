﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

using MVV_Simple_CS.Services;

namespace MVVM_Simple
{
  public partial class ucNoBinding : UserControl
  {
    public ucNoBinding()
    {
      InitializeComponent();
    }

    bool _IsAddMode = false;

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      ProductServices client = new ProductServices();
      ProductResponse resp;

      resp = client.GetProducts();
      ObservableCollection<Product> coll = new ObservableCollection<Product>(resp.DataCollection);

      lstData.DataContext = coll;
    }

    #region SelectionChanged Event
    private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      Product entity;
      entity = (Product)lstData.SelectedItem;

      txtProductId.Text = entity.ProductId.ToString();
      txtProductName.Text = entity.ProductName;
      txtPrice.Text = entity.Price.ToString();
      txtIntroductionDate.Text = entity.IntroductionDate.ToShortDateString();
      chkIsDiscontinued.IsChecked = entity.IsDiscontinued;
    }
    #endregion

    #region Add Click Event
    private void btnAdd_Click(object sender, RoutedEventArgs e)
    {
      // Put UI into Add Mode
      _IsAddMode = true;
      SetEditUIDisplay();

      // Create empty input fields
      txtProductId.Text = "0";
      txtProductName.Text = string.Empty;
      txtIntroductionDate.Text = DateTime.Now.ToShortDateString();
      txtPrice.Text = "0";
      chkIsDiscontinued.IsChecked = true;
    }
    #endregion

    #region Cancel Click Event
    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      // Cancel the Edit
      SetNormalUIDisplay();

      // TODO: Write code to undo changes

      lstData.SelectedIndex = 0;
    }
    #endregion

    #region Save Click Event
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      if (_IsAddMode)
        AddData();
      else
        UpdateData();

      SetNormalUIDisplay();
    }
    #endregion

    #region AddData Method
    private void AddData()
    {
      ProductServices client = new ProductServices();
      ProductResponse resp;
      Product entity = new Product();
      
      entity.ProductId = Convert.ToInt32(txtProductId.Text);
      entity.ProductName = txtProductName.Text;
      entity.Price = Convert.ToDecimal(txtPrice.Text);
      entity.IntroductionDate = Convert.ToDateTime(txtIntroductionDate.Text);
      entity.IsDiscontinued = Convert.ToBoolean(chkIsDiscontinued.IsChecked);

      // Insert Product
      resp = client.Insert(entity);
      if (resp.Status == OperationResult.Exception)
        tbMessages.Text = resp.ErrorMessage;
      else
      {
        tbMessages.Text = "Save Successful";

        // Get Collection
        ObservableCollection<Product> coll = (ObservableCollection<Product>)lstData.DataContext;
        // Add new entity to collection
        coll.Add(entity);        
      }
    }
    #endregion

    #region UpdateData Method
    private void UpdateData()
    {
      ProductServices client = new ProductServices();
      ProductResponse resp;
      Product entity = (Product)lstData.SelectedItem;

      entity.ProductId = Convert.ToInt32(txtProductId.Text);
      entity.ProductName = txtProductName.Text;
      entity.Price = Convert.ToDecimal(txtPrice.Text);
      entity.IntroductionDate = Convert.ToDateTime(txtIntroductionDate.Text);
      entity.IsDiscontinued = Convert.ToBoolean(chkIsDiscontinued.IsChecked);

      // Update Product
      resp = client.Update(entity);
      if (resp.Status == OperationResult.Exception)
        tbMessages.Text = resp.ErrorMessage;
      else
        tbMessages.Text = "Save Successful";
    }
    #endregion

    #region SetNormalUIDisplay Method
    private void SetNormalUIDisplay()
    {
      _IsAddMode = false;
      btnAdd.IsEnabled = true;
      btnSave.IsEnabled = false;
      btnCancel.IsEnabled = false;
    }
    #endregion

    #region SetEditUIDisplay Method
    private void SetEditUIDisplay()
    {
      btnAdd.IsEnabled = false;
      btnSave.IsEnabled = true;
      btnCancel.IsEnabled = true;
    }
    #endregion
  }
}
