﻿using System.Windows;
using System.Windows.Controls;

using MVV_Simple_CS.Services;

namespace MVVM_Simple
{
  public partial class ucNoBindingListOnly : UserControl
  {
    public ucNoBindingListOnly()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      ProductServices client = new ProductServices();
      ProductResponse resp;

      resp = client.GetProducts();

      lstData.DataContext = resp.DataCollection;
    }
  }
}
