﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;

namespace MVV_Simple_CS.Services
{
  public class ProductServices
  {
    #region GetProducts Method
    public ProductResponse GetProducts()
    {
      ProductResponse ret = new ProductResponse();
      string sql = string.Empty;
      SqlCommand cmd = null;
      SqlConnection cnn = null;
      SqlDataAdapter da = null;
      DataSet ds = new DataSet();

      ret.Status = OperationResult.Unknown;
      sql = "SELECT * ";
      sql += " FROM Product ";
      sql += " ORDER BY ProductName ";
      try
      {
        cnn = new SqlConnection(
           ConfigurationManager.
             ConnectionStrings["ConnectString"].
               ConnectionString);
        cmd = new SqlCommand(sql, cnn);
        cnn.Open();

        da = new SqlDataAdapter(cmd);

        da.Fill(ds);

        ret.DataCollection = new Products();
        if (ds.Tables.Count > 0)
        {
          if (ds.Tables[0].Rows.Count > 0)
          {
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
              Product prod = new Product();

              prod.ProductId = Convert.ToInt32(dr["ProductId"]);
              prod.ProductName = Convert.ToString(dr["ProductName"]);
              prod.IntroductionDate = Convert.ToDateTime(dr["IntroductionDate"]);
              prod.Cost = Convert.ToDecimal(dr["Cost"]);
              prod.Price = Convert.ToDecimal(dr["Price"]);
              prod.IsDiscontinued = Convert.ToBoolean(dr["IsDiscontinued"]);

              ret.DataCollection.Add(prod);
            }

            ret.Status = OperationResult.Success;
            ret.FriendlyErrorMessage = "Data Retrieval was Successful";
          }
          else
          {
            ret.Status = OperationResult.Failure;
            ret.FriendlyErrorMessage = "No Products in Table";
          }
        }
      }
      catch (Exception ex)
      {
        // Fill in Response Exception
        ret.Status = OperationResult.Exception;
        ret.ErrorMessage = ex.ToString();
      }
      finally
      {
        if (cnn != null &
             cnn.State == ConnectionState.Open)
          cnn.Close();
      }

      return ret;
    }
    #endregion

    #region GetProduct Method
    public ProductResponse GetProduct(int productId)
    {
      ProductResponse ret = new ProductResponse();
      string sql = string.Empty;
      SqlCommand cmd = null;
      SqlConnection cnn = null;
      SqlParameter parm = null;
      SqlDataAdapter da = null;
      DataSet ds = new DataSet();
      DataRow dr;

      ret.Status = OperationResult.Unknown;
      sql = "SELECT * ";
      sql += " FROM Product ";
      sql += " WHERE ProductId = @ProductId";
      try
      {
        cnn = new SqlConnection(
           ConfigurationManager.
             ConnectionStrings["ConnectString"].
               ConnectionString);
        cmd = new SqlCommand(sql, cnn);
        parm = new SqlParameter("@ProductId",
          productId);
        cmd.Parameters.Add(parm);
        cnn.Open();

        da = new SqlDataAdapter(cmd);

        da.Fill(ds);

        if (ds.Tables.Count > 0)
        {
          if (ds.Tables[0].Rows.Count > 0)
          {
            dr = ds.Tables[0].Rows[0];

            ret.DetailData = new Product();
            ret.DetailData.ProductId = Convert.ToInt32(dr["ProductId"]);
            ret.DetailData.ProductName = Convert.ToString(dr["ProductName"]);
            ret.DetailData.IntroductionDate = Convert.ToDateTime(dr["IntroductionDate"]);
            ret.DetailData.Cost = Convert.ToDecimal(dr["Cost"]);
            ret.DetailData.Price = Convert.ToDecimal(dr["Price"]);
            ret.DetailData.IsDiscontinued = Convert.ToBoolean(dr["IsDiscontinued"]);

            ret.Status = OperationResult.Success;
            ret.FriendlyErrorMessage = "Data Retrieval was Successful";
          }
          else
          {
            ret.Status = OperationResult.Failure;
            ret.FriendlyErrorMessage = "Can't Find Product: " + productId.ToString();
          }
        }
      }
      catch (Exception ex)
      {
        // Fill in Response Exception
        ret.Status = OperationResult.Exception;
        ret.ErrorMessage = ex.ToString();
      }
      finally
      {
        if (cnn != null &
             cnn.State == ConnectionState.Open)
          cnn.Close();
      }

      return ret;
    }
    #endregion
    
    #region Update Method
    public ProductResponse Update(Product prod)
    {
      string sql = string.Empty;
      SqlCommand cmd = null;
      SqlConnection cnn = null;
      SqlParameter parm = null;
      ProductResponse ret = new ProductResponse();

      ret.Status = OperationResult.Unknown;
      sql = "UPDATE Product ";
      sql += " SET ";
      sql += " ProductName = @ProductName, ";
      sql += " IntroductionDate = @IntroductionDate, ";
      sql += " Cost = @Cost, ";
      sql += " Price = @Price, ";
      sql += " IsDiscontinued = @IsDiscontinued ";
      sql += " WHERE ProductId = @ProductId ";
      try
      {
        cnn = new SqlConnection(
           ConfigurationManager.
             ConnectionStrings["ConnectString"].
               ConnectionString);
        cmd = new SqlCommand(sql, cnn);
        parm = new SqlParameter("@ProductName",
          prod.ProductName);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@IntroductionDate",
          prod.IntroductionDate);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@Cost",
          prod.Cost);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@Price",
          prod.Price);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@IsDiscontinued",
          prod.IsDiscontinued);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@ProductId",
          prod.ProductId);
        cmd.Parameters.Add(parm);

        cnn.Open();

        cmd.ExecuteNonQuery();
        ret.Status = OperationResult.Success;
        ret.FriendlyErrorMessage = "Update was Successful";
      }
      catch (Exception ex)
      {
        // Publish exception here
        ret.Status = OperationResult.Exception;
        ret.ErrorMessage = ex.Message;
        ret.FriendlyErrorMessage = "The Update to the Product Table did not Work.";
      }
      finally
      {
        if (cnn != null &
             cnn.State == ConnectionState.Open)
          cnn.Close();
      }

      return ret;
    }
    #endregion

    #region Insert Method
    public ProductResponse Insert(Product prod)
    {
      string sql = string.Empty;
      SqlCommand cmd = null;
      SqlConnection cnn = null;
      SqlParameter parm = null;
      ProductResponse ret = new ProductResponse();

      ret.Status = OperationResult.Unknown;
      sql = "INSERT INTO Product(ProductName, ";
      sql += " IntroductionDate, Cost, Price, IsDiscontinued)";
      sql += " VALUES(@ProductName, @IntroductionDate, ";
      sql += " @Cost, @Price, @IsDiscontinued)";
      try
      {
        cnn = new SqlConnection(
           ConfigurationManager.
             ConnectionStrings["ConnectString"].
               ConnectionString);
        cmd = new SqlCommand(sql, cnn);
        parm = new SqlParameter("@ProductName",
          prod.ProductName);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@IntroductionDate",
          prod.IntroductionDate);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@Cost",
          prod.Cost);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@Price",
          prod.Price);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@IsDiscontinued",
          prod.IsDiscontinued);
        cmd.Parameters.Add(parm);

        cnn.Open();

        cmd.ExecuteNonQuery();

        // Retrieve Product ID
        cmd.Parameters.Clear();
        cmd.CommandText = "SELECT @@IDENTITY";
        prod.ProductId = Convert.ToInt32(cmd.ExecuteScalar());

        ret.Status = OperationResult.Success;
        ret.FriendlyErrorMessage = "Insert was Successful";
        // Return entity class so the IDENTITY value can be retrieved
        ret.DetailData = prod;
      }
      catch (Exception ex)
      {
        // Publish exception here
        ret.Status = OperationResult.Exception;
        ret.ErrorMessage = ex.Message;
        ret.FriendlyErrorMessage = "The Insert to the Product Table did not Work.";
      }
      finally
      {
        if (cnn != null &
             cnn.State == ConnectionState.Open)
          cnn.Close();
      }

      return ret;
    }
    #endregion

    #region Delete Method
    public ProductResponse Delete(int productId)
    {
      string sql = string.Empty;
      SqlCommand cmd = null;
      SqlConnection cnn = null;
      SqlParameter parm = null;
      ProductResponse ret = new ProductResponse();

      ret.Status = OperationResult.Unknown;
      sql = "DELETE FROM Product ";
      sql += " WHERE ProductId = @ProductId ";
      try
      {
        cnn = new SqlConnection(
           ConfigurationManager.
             ConnectionStrings["ConnectString"].
               ConnectionString);
        cmd = new SqlCommand(sql, cnn);
        parm = new SqlParameter("@ProductId",
          productId);
        cmd.Parameters.Add(parm);

        cnn.Open();

        cmd.ExecuteNonQuery();
        ret.Status = OperationResult.Success;
        ret.FriendlyErrorMessage = "Delete was Successful";
      }
      catch (Exception ex)
      {
        // Publish exception here
        ret.Status = OperationResult.Exception;
        ret.ErrorMessage = ex.Message;
        ret.FriendlyErrorMessage = "The Delete to the Product Table did not Work.";
      }
      finally
      {
        if (cnn != null &
             cnn.State == ConnectionState.Open)
          cnn.Close();
      }

      return ret;
    }
    #endregion
  }
}
