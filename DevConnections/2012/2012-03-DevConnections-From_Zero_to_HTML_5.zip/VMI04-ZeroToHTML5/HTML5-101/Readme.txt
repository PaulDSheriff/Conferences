﻿In order to get the most out of these demos, be sure to download:

- VS 2010 SP 1:  http://bit.ly/nQzsld
- Microsoft .NET Framework Reliability Update 1:  http://bit.ly/qOG7Ni

Some other tools you may find handy...
- Modernizr:  http://www.modernizr.com/
- JQuery UI:  http://www.JQueryUI.com/

These demos work best in Opera browser or IE 10 beta, though some require Chrome

You should download and install all major browsers for testing
  IE 10 - NOTE: You will need to install this in a VM until it is released.
  Chrome
  Opera
  Safari
  FireFox


Some blog posts to check out:

http://bit.ly/HTML5FormsAndMVC
http://bit.ly/qE7jLz

New in HTML 5
http://www.w3.org/TR/html5-diff/

New in CSS 3
http://www.css3.info/preview/
