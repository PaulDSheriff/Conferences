﻿In order to get the most out of these demos, be sure to download:

- VS 2010 SP 1:  http://bit.ly/nQzsld or VS 2012
- Microsoft .NET Framework Reliability Update 1:  http://bit.ly/qOG7Ni
- Opera Browser or IE 10 beta


Some other tools you may find handy...
- Modernizr:  http://www.modernizr.com/
- JQuery UI:  http://www.JQueryUI.com/
  View demos here: http://jqueryui.com/demos/ 
- Q-Tip: http://craigsworks.com/projects/qtip/demos/
  Gives you a tooltips that look like speech bubbles

These demos work best in Opera browser or IE 10 beta

Some blog posts to check out:

HTML 5 and ASP.NET MVC
http://bit.ly/HTML5FormsAndMVC

HTML 5 Updates for ASP.NET
http://bit.ly/qE7jLz


New in HTML 5
http://www.w3.org/TR/html5-diff/

New in CSS 3
http://www.css3.info/preview/

Box Shadow Reference
http://www.css3.info/preview/box-shadow/

JQuery Examples
http://www.noupe.com/jquery/50-amazing-jquery-examples-part1.html


Cool OS X Menu Systems
http://d2o0t5hpnwv4c1.cloudfront.net/358_jquery/example%20files/index.html

http://d2o0t5hpnwv4c1.cloudfront.net/358_jquery/example%20files/all-examples.html


Drop Down Menu
http://www.webdesigndev.com/wp-content/uploads/2009/07/fancydropdown.html#

http://codecanyon.net/item/drop-menu/full_screen_preview/81289?ref=1stwebdesigner


Circular Menu
http://www.cssplay.co.uk/menus/circular-sub.html#url


Large Menus
http://themes.pixelworkshop.fr/?theme=CSS3MegaMenu


Sliding Menu using JQuery
http://www.hv-designs.co.uk/tutorials/sliding_menu/sliding_menu.html


Ultimate Menus
http://codecanyon.net/item/css-ultimate-menus/123107?ref=1stwebdesigner


Tutorial
http://www.w3schools.com/html5/default.asp

Color Wheel
http://www.ficml.org/jemimap/style/color/wheel.html

Color Palettes
Blue
http://webdesign.about.com/od/colorpalettes/l/bl_palette_blue.htm
Green
http://webdesign.about.com/od/colorpalettes/l/bl_palette_green.htm
Red
http://webdesign.about.com/od/colorpalettes/l/bl_palette_red.htm


Named Colors/Hex/RGB Chart
http://webdesign.about.com/od/colorcharts/l/bl_namedcolors.htm

Color Themes
http://kuler.adobe.com

Psychology of Color
http://www.infoplease.com/spot/colors1.html

Gradient Resources
http://maveno.us/library/examples/html5/

Gradient Generator
http://www.colorzilla.com/gradient-editor/

HTML 5 Element Usage
http://joshduck.com/periodic-table.html