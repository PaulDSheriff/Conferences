﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OrderEntry.UserInterface.IoC
{
   public class Sample01
   {
      ILogger logger = LoggerFactory.CreateLogger("A");
   }

   #region Logger Interface 

   public interface ILogger
   {
      void Log(string message);
   }

   #endregion

   #region Logger Factory

   public class LoggerFactory
   {
      public static ILogger CreateLogger(string type)
      {
         ILogger result = NullLogger.Instance;

         switch (type)
         {
            case "A":
               result = new LoggerTypeA();
               break;

            case "B":
               result = new LoggerTypeB();
               break;
         }

         return result;
      }
   }

   #endregion

   #region Concrete Loggers

   public class LoggerTypeA : ILogger
   {
      #region ILogger Members

      public void Log(string message)
      {
         // Do something
      }

      #endregion
   }

   public class LoggerTypeB : ILogger
   {
      #region ILogger Members

      public void Log(string message)
      {
         // Do something
      }

      #endregion
   }

   #endregion

   #region Default null logger

   public class NullLogger : ILogger
   {
      private static NullLogger _instance;

      public static NullLogger Instance
      {
         get
         {
            if (_instance == null)
            {
               _instance = new NullLogger();
            }
            return _instance;
         }
      }

      #region ILogger Members

      public void Log(string message)
      {
         // Do nothing
      }

      #endregion
   }

   #endregion
}






















// ILogger logger = LoggerFactory.CreateLogger("A");