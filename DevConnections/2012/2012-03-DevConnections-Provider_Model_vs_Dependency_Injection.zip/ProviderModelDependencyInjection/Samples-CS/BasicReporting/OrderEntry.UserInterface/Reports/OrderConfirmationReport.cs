﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using OrderEntry.UserInterface.ViewModels;

namespace OrderEntry.UserInterface.Reports
{
    public class OrderConfirmationReport
    {
        int _orderId;
        List<OrderItem> _items;

        public OrderConfirmationReport(int orderId, List<OrderItem> items)
        {
            _orderId = orderId;
            _items = items;
        }

        public byte[] GetHTML()
        {
            byte[] result = null;
            StringBuilder html;

            html = new StringBuilder(1024);
            html.Append("<html>");
            html.Append("<body>");
            html.Append("<h1>");
            html.Append(String.Format("Order # {0}", _orderId));
            html.Append("</h1>");
            foreach (OrderItem item in _items)
            {
                html.Append("<p>");
                html.Append(String.Format("{0}, {1:C}", item.ProductName, item.Price));
                html.Append("</p>");
            }
            html.Append("</body>");
            html.Append("</html>");

            result = Encoding.ASCII.GetBytes(html.ToString().ToCharArray());

            return result;
        }

        public string Save()
        {
            string extension = string.Empty;
            byte[] content = null; ;

            content = this.GetHTML();
            extension = "htm";
            this.FileName = Path.Combine(Environment.GetEnvironmentVariable("TEMP"),
                String.Format("{0}.{1}", Guid.NewGuid().ToString(), extension));
            File.WriteAllBytes(this.FileName, content);
            return this.FileName;
        }

        public string FileName { get; set; }
    }
}
