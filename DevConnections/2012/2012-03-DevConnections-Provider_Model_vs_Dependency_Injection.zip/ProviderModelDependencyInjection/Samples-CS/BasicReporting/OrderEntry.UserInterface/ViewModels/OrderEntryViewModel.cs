﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Xml.Linq;
using System.Windows;
using System.IO;
using OrderEntry.UserInterface.Reports;

namespace OrderEntry.UserInterface.ViewModels
{
    public class OrderEntryViewModel : INotifyPropertyChanged
    {
        private DataRepository _repository;
        private ObservableCollection<OrderItem> _items;
        private decimal _orderTotal;
        private string _productId;
        private int _orderId;
        private bool _orderEnabled = true;
        private bool _printEnabled;
        private bool _closeEnabled = true;
        private string _closeButtonText = "Cancel";

        public OrderEntryViewModel()
        {
            _repository = new DataRepository();
            _items = new ObservableCollection<OrderItem>();
        }

        public ObservableCollection<OrderItem> OrderItems
        {
            get { return _items; }
            set
            {
                _items = value;
                this.OnPropertyChanged("DataCollection");
            }
        }

        public decimal OrderTotal
        {
            get { return _orderTotal; }
            set
            {
                _orderTotal = value;
                this.OnPropertyChanged("OrderTotal");
            }
        }

        public string ProductId
        {
            get { return _productId; }
            set
            {
                _productId = value;
                this.OnPropertyChanged("ProductId");
            }
        }

        public int OrderId
        {
            get { return _orderId; }
            set
            {
                _orderId = value;
                this.OnPropertyChanged("OrderId");
            }
        }

        public bool IsOrderEnabled
        {
            get { return _orderEnabled; }
            set
            {
                _orderEnabled = value;
                this.OnPropertyChanged("IsOrderEnabled");
            }
        }

        public bool IsPrintEnabled
        {
            get { return _printEnabled; }
            set
            {
                _printEnabled = value;
                this.OnPropertyChanged("IsPrintEnabled");
            }
        }

        public string CloseButtonText
        {
            get { return _closeButtonText; }
            set
            {
                _closeButtonText = value;
                this.OnPropertyChanged("CloseButtonText");
            }
        }

        public bool IsCloseEnabled
        {
            get { return _closeEnabled; }
            set
            {
                _closeEnabled = value;
                this.OnPropertyChanged("IsCloseEnabled");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public void AddProduct()
        {
            int id;

            if (int.TryParse(this.ProductId, out id))
            {
                this.AddProduct(id);
            }
            else
            {
                MessageBox.Show("Invalid Product ID.");
            }
            this.ProductId = string.Empty;

        }

        public void AddProduct(int productId)
        {
            Product product = _repository.GetProduct(productId);
            OrderItem item = new OrderItem();
            item.ProductId = product.ProductId;
            item.ProductName = product.ProductName;
            item.Price = product.Price;
            this.OrderItems.Add(item);
            this.OrderTotal += item.Price;
        }

        internal void PlaceOrder()
        {
            if (this.OrderItems.Count > 0)
            {
                this.OrderId++;
                this.IsPrintEnabled = true;
                this.CloseButtonText = "Close";
                this.IsCloseEnabled = false;
                this.IsOrderEnabled = false;
            }
            else
            {
                MessageBox.Show("Please enter some items.");
            }
        }

        public event ReportSavedEventHandler ReportSaved;

        private void OnReportSaved(OrderConfirmationReport report)
        {
            if (this.ReportSaved != null)
            {
                ReportSavedEventArgs args = new ReportSavedEventArgs(report);
                this.ReportSaved(this, args);
            }
        }

        internal void PrintOrder()
        {
            OrderConfirmationReport report = new OrderConfirmationReport(this.OrderId, this.OrderItems.ToList<OrderItem>());
            report.Save();
            this.OnReportSaved(report);
            this.IsPrintEnabled = false;
            this.IsCloseEnabled = true;
        }
    }

    #region Plumbing

    public class OrderItem
    {
        public int ProductId  { get; set; }
        public string ProductName  { get; set; }
        public decimal Price { get; set; }
    }

    public class Product
    {
        public string ProductName { get; set; }
        public int ProductId { get; set; }
        public decimal Price { get; set; }
    }

    public class DataRepository
    {
        List<Product> _products;

        public Product GetProduct(int productId)
        {
            Product result = default(Product);

            if (_products == null) this.GetProducts();
            var products = from prod in _products where prod.ProductId == productId select prod;
            foreach (Product p in products)
            {
                result = p;
            }

            return result;
        }

        private void GetProducts()
        {
            string productXml = string.Empty;
            XElement xe = null;

            productXml = File.ReadAllText(@"D:\Talks\ProviderModelDependencyInjection\Samples-CS\BasicReporting\OrderEntry.UserInterface\XML\Products.xml");

            xe = XElement.Parse(productXml);

            // Create a list of Product objects
            var products =
                from prod in xe.Descendants("Product")
                orderby prod.Element("ProductName").Value
                select new Product
                {
                    ProductId = Convert.ToInt32(prod.Element("ProductId").Value),
                    ProductName = prod.Element("ProductName").Value,
                    Price = Convert.ToDecimal(prod.Element("Price").Value)
                };

            _products = products.ToList<Product>();
        }
    }

    public class ReportSavedEventArgs
    {
        OrderConfirmationReport _report;

        public ReportSavedEventArgs(OrderConfirmationReport report)
        {
            _report = report;
        }

        public OrderConfirmationReport Report
        {
            get { return _report; }
        }
    }

    public delegate void ReportSavedEventHandler(object sender, ReportSavedEventArgs e);

    #endregion
}
