﻿using System;
using System.Text;
using System.Collections;
using System.ComponentModel;

namespace OrderEntry.HtmlReports
{
    public class OrderConfirmationReport : HtmlReportBase
    {
        public override string GetHtmlCore()
        {
            string name;
            decimal price;
            StringBuilder html;

            html = new StringBuilder(1024);
            html.Append("<h1>Order Confirmation</h1>");

            IEnumerator iterator = this.DataSource.GetEnumerator();
            while (iterator.MoveNext())
            {
                name = string.Empty;
                price = 0;
                PropertyDescriptorCollection attr = TypeDescriptor.GetProperties(iterator.Current);
                foreach (PropertyDescriptor pd in attr)
                {
                    if (pd.Name == "ProductName")
                    {
                        name = pd.GetValue(iterator.Current).ToString();
                    }
                    if (pd.Name == "Price")
                    {
                        price = (decimal)pd.GetValue(iterator.Current);
                    }
                }
                html.Append("<p>");
                html.Append(String.Format("{0}, {1:C}", name, price));
                html.Append("</p>");
            }

            return html.ToString();
        }
    }
}
