﻿using System;
using System.IO;
using System.Text;
using System.Collections;

using PDSA.Reporting;

namespace OrderEntry.HtmlReports
{
    public abstract class HtmlReportBase : PDSAReportBase
    {
        public override void Save()
        {
            this.FileName = this.CreateHtmlFile();
        }

        public abstract string GetHtmlCore();

        public override byte[] GetBytes()
        {
            byte[] result = null;
            StringBuilder html;

            html = new StringBuilder(1024);
            html.Append("<html>");
            html.Append("<body>");
            html.Append(this.GetHtmlCore());
            html.Append("</body>");
            html.Append("</html>");
            result = Encoding.ASCII.GetBytes(html.ToString().ToCharArray());

            return result;
        }

        private string CreateHtmlFile()
        {
            string extension = string.Empty;
            byte[] content = null;
            string fileName;

            content = this.GetBytes();
            extension = "htm";
            fileName = System.IO.Path.Combine(Environment.GetEnvironmentVariable("TEMP"),
                String.Format("{0}.{1}", Guid.NewGuid().ToString(), extension));
            File.WriteAllBytes(fileName, content);
            return fileName;
        }
    }
}
