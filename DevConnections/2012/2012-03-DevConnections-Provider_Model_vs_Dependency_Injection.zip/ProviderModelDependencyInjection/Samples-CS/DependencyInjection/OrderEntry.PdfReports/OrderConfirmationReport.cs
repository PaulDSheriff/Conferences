﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PdfSharp.Pdf;
using PdfSharp.Drawing;

namespace OrderEntry.PdfReports
{
    public class OrderConfirmationReport : PdfReportBase
    {
        public override void SaveCore(PdfDocument document)
        {
            document.Info.Title = "Order Confirmation";
            PdfPage page = document.AddPage();
            XGraphics gfx = XGraphics.FromPdfPage(page);
            XFont font = new XFont("Arial", 12, XFontStyle.Regular);
            gfx.DrawString("Order Confirmation", font, XBrushes.Black,
              new XRect(0, 0, page.Width, page.Height),
              XStringFormats.TopLeft);
        }
    }
}
