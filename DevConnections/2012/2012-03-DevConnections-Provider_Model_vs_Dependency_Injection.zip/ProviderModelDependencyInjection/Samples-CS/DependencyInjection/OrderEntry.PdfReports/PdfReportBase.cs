﻿using System;
using System.IO;
using System.Text;

using PDSA.Reporting;

using PdfSharp;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;

namespace OrderEntry.PdfReports
{
    public abstract class PdfReportBase : PDSAReportBase
    {
        PdfDocument _document;

        public abstract void SaveCore(PdfDocument document);

        public override void Save()
        {
            this.FileName = System.IO.Path.Combine(Environment.GetEnvironmentVariable("TEMP"),
                String.Format("{0}.{1}", Guid.NewGuid().ToString(), "pdf"));
            _document = new PdfDocument();
            this.SaveCore(_document);
            _document.Save(this.FileName);
        }
       
        public override byte[] GetBytes()
        {
            MemoryStream stream;
            stream = new MemoryStream();
            _document.Save(stream);
            return stream.GetBuffer();
        }
    }
}
