﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;

namespace OrderEntry.UserInterface
{
   /// <summary>
   /// Interaction logic for App.xaml
   /// </summary>
   public partial class App : Application
   {

      private static IUnityContainer _container;

      public static IUnityContainer Dependencies
      {
         get
         {
            return _container;
         }
      }

      protected override void OnStartup(StartupEventArgs e)
      {
         base.OnStartup(e);

         _container = new UnityContainer();
         UnityConfigurationSection section
           = (UnityConfigurationSection)ConfigurationManager.GetSection("unity");
         section.Configure(_container);
      }
   }
}
