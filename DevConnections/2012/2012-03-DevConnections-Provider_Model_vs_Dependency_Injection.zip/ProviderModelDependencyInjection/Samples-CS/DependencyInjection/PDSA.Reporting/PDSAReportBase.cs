﻿using System;
using System.Text;
using System.Collections;

namespace PDSA.Reporting
{
    public enum PDSAReportOutputType
    {
        Unknown,
        HTML,
        PDF,
        XLS
    }

    public abstract class PDSAReportBase
    {
        // Abstract base class for report class 

        private string mstrName;
        private string mstrDescription;

        public string Name
        {
            get { return mstrName; }
            set { mstrName = value; }
        }

        public string Description
        {
            get { return mstrDescription; }
            set { mstrDescription = value; }
        }

        public string FileName { get; set; }

        public IEnumerable DataSource { get; set; }

        public abstract byte[] GetBytes();

        public abstract void Save();
    }
}
