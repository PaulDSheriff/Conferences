﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using OrderEntry.UserInterface.ViewModels;
using System.ComponentModel;

namespace OrderEntry.UserInterface
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        OrderEntryViewModel _vm;

        public MainWindow()
        {
            InitializeComponent();
            _vm = (OrderEntryViewModel)this.Resources["viewModel"];
            _vm.ReportSaved += new ReportSavedEventHandler(vm_ReportSaved);
        }

        void vm_ReportSaved(object sender, ReportSavedEventArgs e)
        {
            ReportViewer viewer = new ReportViewer(e.Report);
            viewer.Show();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void PrintButton_Click(object sender, RoutedEventArgs e)
        {
            _vm.PrintOrderConfirmation();
        }

        private void OrderButton_Click(object sender, RoutedEventArgs e)
        {
            _vm.PlaceOrder();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            _vm.AddProduct();
        }

        private void Window_Closing(object sender, CancelEventArgs e)
        {
            e.Cancel = !_vm.IsCloseEnabled;
        }
    }
}
