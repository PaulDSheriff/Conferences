﻿using System;
using System.Configuration;

namespace OrderEntry.UserInterface.Configuration
{
    public class AppConfig
    {
        public static string ReportName
        {
            get
            {
                return ConfigurationManager.AppSettings["ReportName"].ToString();
            }
        }

        public static string OutputType
        {
            get
            {
                return ConfigurationManager.AppSettings["OutputType"].ToString();
            }
        }
    }
}
