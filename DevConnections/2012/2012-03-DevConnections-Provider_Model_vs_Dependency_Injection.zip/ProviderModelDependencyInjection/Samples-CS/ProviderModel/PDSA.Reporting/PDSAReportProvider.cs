﻿using System;
using System.Configuration;
using System.Configuration.Provider;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Runtime.Remoting;

namespace PDSA.Reporting
{
   public abstract class PDSAReportProvider : ProviderBase
   {

      private static PDSAReportProvider mProvider = null;
      private static PDSAReportProviderCollection mProviders = null;
      private static object mLock = new object();

      public PDSAReportProvider Provider
      {
         get { return mProvider; }
      }

      public PDSAReportProviderCollection Providers
      {
         get { return mProviders; }
      }

      public abstract PDSAReportBase Retrieve(string reportName);

      public static PDSAReportProvider GetProvider()
      {
         PDSAReportProvider.LoadProviders();
         return mProvider;
      }

      public static PDSAReportProvider GetProvider(string name)
      {
         PDSAReportProvider provider = null;
         PDSAReportProvider.LoadProviders();
         provider = (PDSAReportProvider)mProviders[name];
         return provider;
      }

      private static void LoadProviders()
      {

         PDSAReportProviderSection section = default(PDSAReportProviderSection);

         if (mProvider == null)
         {
            lock (mLock)
            {
               if (mProvider == null)
               {
                  mProviders = new PDSAReportProviderCollection();

                  Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                  foreach (ConfigurationSection sec in config.Sections)
                  {
                     if (sec.GetType() == typeof(PDSAReportProviderSection))
                     {
                        section = (PDSAReportProviderSection)sec;
                        break;
                     }
                  } 
                  
                  foreach (ProviderSettings settings in section.Providers)
                  {
                     string[] info = settings.Type.Split(",".ToCharArray());
                     string type = info[0];
                     string assm = info[1];
                     PDSAReportProvider instance = (PDSAReportProvider)Activator.CreateInstance(assm, type).Unwrap();
                     instance.Initialize(settings.Name, settings.Parameters);
                     mProviders.Add(instance);
                  }
                  mProvider = (PDSAReportProvider)mProviders[section.DefaultProvider];
                  if (mProvider == null)
                  {
                     throw new ProviderException("Unable to load default Report Provider");
                  }
               }
            }
         }
      }
   }
}
