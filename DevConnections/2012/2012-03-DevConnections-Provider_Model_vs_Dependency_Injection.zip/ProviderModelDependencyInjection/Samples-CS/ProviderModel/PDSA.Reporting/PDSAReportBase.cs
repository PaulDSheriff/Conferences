﻿using System;
using System.Data;
using System.Text;
using System.Collections;

using PDSA.Reporting.Exceptions;

namespace PDSA.Reporting
{
    public enum PDSAReportOutputType
    {
        Unknown,
        HTML,
        PDF,
        XLS
    }

    public abstract class PDSAReportBase
    {
        // Abstract base class for report class implemented by each provider

        private string mstrName;
        private string mstrPath;
        private string mstrDescription;

        public string Name
        {
            get { return mstrName; }
            set { mstrName = value; }
        }

        public string Path
        {
            get { return mstrPath; }
            set { mstrPath = value; }
        }

        public string Description
        {
            get { return mstrDescription; }
            set { mstrDescription = value; }
        }

        public IEnumerable DataSource { get; set; }

        public abstract byte[] GetBytes();

        public abstract void Save();

        /// Open a report using the default provider and report name. 
        public static PDSAReportBase Open(string reportName)
        {
            PDSAReportBase report = null;
            PDSAReportProvider provider = null;

            try
            {
                provider = PDSAReportProvider.GetProvider();
                report = provider.Retrieve(reportName);
            }
            catch
            {
                throw new PDSAReportNotFoundException(String.Format("An error occurred while attempting to open report {0}.", reportName));
            }

            return report;
        }

        public static PDSAReportBase Open(string reportName, PDSAReportOutputType outputType)
        {
            PDSAReportBase report = null;
            PDSAReportProvider provider = null;

            try
            {
                switch (outputType)
                {
                    case PDSAReportOutputType.HTML:
                        provider = PDSAReportProvider.GetProvider("HtmlReportProvider");
                        break;
                    case PDSAReportOutputType.PDF:
                        provider = PDSAReportProvider.GetProvider("PdfReportProvider");
                        break;
                    case PDSAReportOutputType.XLS:
                        throw new NotImplementedException("A report provider has not been implemented for Excel");
                }
                report = provider.Retrieve(reportName);
            }
            catch
            {
                throw new PDSAReportNotFoundException(String.Format("An error occurred while attempting to open report {0}.", reportName));
            }

            return report;
        }
        
        public static PDSAReportBase Open(string reportName, string outputType)
        {
            PDSAReportBase report = null;
            PDSAReportOutputType type; 

            try
            {
                type = PDSAReportOutputType.Unknown;
                if (!Enum.TryParse<PDSAReportOutputType>(outputType, true, out type))
                {
                    throw new PDSAReportException(String.Format("Cannot match '{0}' with a known output type", outputType)); 
                }
                report = PDSAReportBase.Open(reportName, type);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                throw new PDSAReportNotFoundException(String.Format("An error occurred while attempting to open report {0}.", reportName));
            }

            return report;
        }


        public string FileName { get; set; }
    }
}
