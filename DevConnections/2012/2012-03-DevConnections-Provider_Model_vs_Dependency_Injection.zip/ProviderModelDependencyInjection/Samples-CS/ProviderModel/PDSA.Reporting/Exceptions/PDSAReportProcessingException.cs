﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PDSA.Reporting.Exceptions
{
   public class PDSAReportProcessingException : PDSAReportException
   {
      public PDSAReportProcessingException() { }
      public PDSAReportProcessingException(string message) : base(message) { }
      public PDSAReportProcessingException(string message, Exception innerException) : base(message, innerException) { }
   }
}
