﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PDSA.Reporting.Exceptions
{
   public class PDSAReportNotFoundException : PDSAReportException
   {
      public PDSAReportNotFoundException(string message) : base(message) { }
   }
}
