﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PDSA.Reporting.Exceptions
{
   public class PDSAReportException : Exception
   {
      public PDSAReportException() { }
      public PDSAReportException(string message) : base(message) { }
      public PDSAReportException(string message, Exception innerException) : base(message, innerException) { }
   }
}
