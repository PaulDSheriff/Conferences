﻿using System;
using System.Configuration;

namespace PDSA.Reporting
{
   public class PDSAReportProviderSection : ConfigurationSection
   {
      [ConfigurationProperty("providers")]
      public ProviderSettingsCollection Providers
      {
         get { return (ProviderSettingsCollection)base["providers"]; }
      }

      [StringValidator(MinLength = 1), ConfigurationProperty("defaultProvider", DefaultValue = "HtmlReportProvider")]
      public string DefaultProvider
      {
         get { return base["defaultProvider"].ToString(); }
         set { base["defaultProvider"] = value; }
      }
   }
}
