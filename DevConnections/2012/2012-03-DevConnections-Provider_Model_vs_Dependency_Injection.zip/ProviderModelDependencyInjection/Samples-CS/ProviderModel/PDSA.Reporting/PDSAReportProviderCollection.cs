﻿using System;
using System.Configuration;
using System.Configuration.Provider;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Runtime.Remoting;

namespace PDSA.Reporting
{
   public class PDSAReportProviderCollection : ProviderCollection
   {
      public new PDSAReportProvider this[string index]
      {
         get { return (PDSAReportProvider)base[index]; }
      }

      public override void Add(ProviderBase provider)
      {
         if (provider == null)
         {
            throw new ArgumentNullException("provider");
         }
         if (!(provider is PDSAReportProvider))
         {
            throw new ArgumentException("Invalid provider type", "provider");
         }
         base.Add(provider);
      }
   }
}
