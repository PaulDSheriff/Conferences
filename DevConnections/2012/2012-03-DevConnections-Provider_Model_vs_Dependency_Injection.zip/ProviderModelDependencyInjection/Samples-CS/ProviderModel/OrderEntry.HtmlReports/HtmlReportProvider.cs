﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.Specialized;
using System.Configuration.Provider;
using PDSA.Reporting;

namespace OrderEntry.HtmlReports
{
    public class HtmlReportProvider : PDSAReportProvider
    {
        public override void Initialize(string name, NameValueCollection config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            // Assign the provider a default name if it doesn't have one
            if (string.IsNullOrEmpty(name))
            {
                name = "HtmlReportProvider";
            }

            // Add a default "description" attribute to config if the attribute doesn't exist or is empty
            if (string.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "Provider for HTML Reports");
            }

            base.Initialize(name, config);

            //if (string.IsNullOrEmpty(mstrUserName))
            //{
            //    mstrUserName = config.Item("UserName");
            //}
            //config.Remove("UserName");

            // Throw an exception if unrecognized attributes remain
            if (config.Count > 0)
            {
                string attr = config.GetKey(0);
                if ((!string.IsNullOrEmpty(attr)))
                {
                    throw new ProviderException(string.Format("Unrecognized attribute: {0}", attr));
                }
            }
        }

        public override PDSAReportBase Retrieve(string reportName)
        {
            PDSAReportBase result = null;
            if (reportName == "OrderConfirmationReport")
            {
                result = new OrderConfirmationReport();
            }
            return result;
        }
    }
}
