﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASPNET_Basics._03_ValidationControls
{
  public partial class EmployeeMaint : System.Web.UI.Page
  {
    protected void Page_Load(object sender, System.EventArgs e)
    {
      if (!Page.IsPostBack)
      {
        rvalBirthDate.MinimumValue = DateTime.Now.AddYears(-70).ToShortDateString();
        rvalBirthDate.MaximumValue = DateTime.Now.AddYears(-17).ToShortDateString();
        rvalBirthDate.ErrorMessage = string.Format("Enter a date between {0} and {1}", rvalBirthDate.MinimumValue, rvalBirthDate.MaximumValue);
      }
    }

    protected void btnSave_Click(object sender, System.EventArgs e)
    {
      if (Page.IsValid)
        Response.Redirect("Default.aspx");
    }

    protected void cvalState_ServerValidate(object source, ServerValidateEventArgs args)
    {
      switch (args.Value)
      {
        case "CA":
        case "NV":
        case "AZ":
          args.IsValid = true;
          break;
        default:
          args.IsValid = false;
          break;
      }
    }
  }
}