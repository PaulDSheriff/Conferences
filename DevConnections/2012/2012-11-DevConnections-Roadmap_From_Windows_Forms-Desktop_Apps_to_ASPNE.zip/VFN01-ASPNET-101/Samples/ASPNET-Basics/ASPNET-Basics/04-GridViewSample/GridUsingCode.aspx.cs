﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASPNET_Basics._04_GridViewSample
{
  public partial class GridUsingCode : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
        GridLoad();
    }

    private void GridLoad()
    {
      DataSet ds = new DataSet();
      SqlDataAdapter da = null;

      da = new SqlDataAdapter("SELECT * FROM Products", 
        ConfigurationManager.ConnectionStrings["NorthwindConnectionString"].ConnectionString);
      
      da.Fill(ds);

      grdProducts.DataSource = ds;
      grdProducts.DataBind();
    }
  }
}