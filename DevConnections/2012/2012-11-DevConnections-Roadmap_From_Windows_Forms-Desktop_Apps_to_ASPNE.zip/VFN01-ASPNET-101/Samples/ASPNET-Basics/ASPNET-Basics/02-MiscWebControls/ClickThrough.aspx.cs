﻿using System;
using System.Web.UI;

namespace ASPNET_Basics._02_MiscWebControls
{
  public partial class ClickThrough : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
        if (Request.QueryString["Name"] != null)
          lblInfo.Text = "You clicked on " + Request.QueryString["Name"].ToString();
    }
  }
}