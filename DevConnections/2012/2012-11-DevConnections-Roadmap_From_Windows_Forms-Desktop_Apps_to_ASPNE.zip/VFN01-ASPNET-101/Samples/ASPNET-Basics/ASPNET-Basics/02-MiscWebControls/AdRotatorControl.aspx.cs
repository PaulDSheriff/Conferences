﻿using System;
using System.Web.UI;

namespace ASPNET_Basics._02_MiscWebControls
{
  public partial class AdRotatorControl : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
        rblFilter.Items.FindByText("Both").Selected = true;
    }

    protected void rblFilter_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (rblFilter.SelectedItem.Text == "Both")
        adEmp.KeywordFilter = string.Empty;
      else
        adEmp.KeywordFilter = rblFilter.SelectedItem.Text;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      // Just here to cause a post-back
    }
  }
}