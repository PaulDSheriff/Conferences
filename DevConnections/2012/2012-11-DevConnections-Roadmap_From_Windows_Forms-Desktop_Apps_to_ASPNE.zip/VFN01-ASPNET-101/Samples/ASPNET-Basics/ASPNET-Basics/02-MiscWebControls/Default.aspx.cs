﻿using System;

namespace ASPNET_Basics._02_MiscWebControls
{
  public partial class Default : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {

    }
  }
}