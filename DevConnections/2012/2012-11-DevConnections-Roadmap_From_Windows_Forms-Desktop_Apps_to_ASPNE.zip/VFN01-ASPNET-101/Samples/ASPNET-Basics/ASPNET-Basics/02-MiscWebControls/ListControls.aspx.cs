﻿using System;
using System.Data;
using System.Web.UI.WebControls;

namespace ASPNET_Basics._02_MiscWebControls
{
  public partial class ListControls : System.Web.UI.Page
  {

    protected void btnRegionCheckList_Click(object sender, EventArgs e)
    {
      RegionLoad(clstRegions);
    }

    protected void btnRegionRadioList_Click(object sender, EventArgs e)
    {
      RegionLoad(rlstRegions);
    }

    private void RegionLoad(ListControl ctlRegions)
    {
      DataSet ds = new DataSet();

      ds.ReadXml(Server.MapPath("~/XML/Regions.xml"));

      ctlRegions.DataTextField = "RegionDescription";
      ctlRegions.DataValueField = "RegionID";
      ctlRegions.DataSource = ds;
      ctlRegions.DataBind();
    }
  }
}