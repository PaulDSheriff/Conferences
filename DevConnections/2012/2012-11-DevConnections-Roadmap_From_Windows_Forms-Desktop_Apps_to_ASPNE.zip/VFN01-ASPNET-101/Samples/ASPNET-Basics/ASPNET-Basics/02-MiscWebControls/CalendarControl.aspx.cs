﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASPNET_Basics._02_MiscWebControls
{
  public partial class CalendarControl : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
        cal.SelectedDate = cal.TodaysDate;
    }

    protected void cal_SelectionChanged(object sender, EventArgs e)
    {
      lblDate.Text = String.Format("Selected date: {0:d}", cal.SelectedDate);
    }

    protected void cal_VisibleMonthChanged(object sender, MonthChangedEventArgs e)
    {
      lblMonth.Text = String.Format("Visible Month: {0:MMMM yyyy}", e.NewDate);
    }
  }
}