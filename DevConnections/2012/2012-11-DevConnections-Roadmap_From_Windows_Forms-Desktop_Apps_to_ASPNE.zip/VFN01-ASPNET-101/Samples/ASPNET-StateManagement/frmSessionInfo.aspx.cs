using System;

partial class frmSessionInfo : System.Web.UI.Page
{
  protected void Page_Load(object sender, System.EventArgs e)
  {
    lblCodePage.Text = Session.CodePage.ToString();
    lblContents.Text = Session.Contents.ToString();
    lblCount.Text = Session.Count.ToString();
    lblIsCookieless.Text = Session.IsCookieless.ToString();
    lblIsNewSession.Text = Session.IsNewSession.ToString();
    lblIsReadOnly.Text = Session.IsReadOnly.ToString();
    lblIsSynchronized.Text = Session.IsSynchronized.ToString();
    lblLCID.Text = Session.LCID.ToString();
    lblMode.Text = Session.Mode.ToString();
    lblSessionID.Text = Session.SessionID.ToString();
    lblTimeOut.Text = Session.Timeout.ToString();
  }
}