using System;
using System.Diagnostics;

partial class frmSessionWrapper : System.Web.UI.Page
{
  protected void btnSessionVars_Click(object sender, System.EventArgs e)
  {
    AppSession.CurrentEmployeeID = 10;
    AppSession.LastMenuAccessed = "SessionVars.aspx";

    Debug.WriteLine(AppSession.CurrentEmployeeID);
  }
}