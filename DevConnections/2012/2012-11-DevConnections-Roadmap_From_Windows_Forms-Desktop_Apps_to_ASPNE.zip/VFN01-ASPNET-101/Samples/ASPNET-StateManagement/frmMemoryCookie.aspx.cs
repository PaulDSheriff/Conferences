using System;

partial class frmMemoryCookie : System.Web.UI.Page
{

  protected void Page_Load(object sender, System.EventArgs e)
  {
    if (Request.Cookies.Get("Email") == null)
    {
      //  Do Nothing
    }
    else
    {
      if (Request.Cookies.Get("Email").Value != "")
      {
        txtEMail.Text = Request.Cookies.Get("Email").Value;
      }
    }
  }

  protected void btnSubmit_Click(object sender, System.EventArgs e)
  {
    Response.Cookies.Get("Email").Value = txtEMail.Text;
    // Response.Cookies.Add(New HttpCookie("Email", txtEMail.Text))

    Response.Redirect("Default.aspx");
  }
}