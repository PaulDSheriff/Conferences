using System.Configuration;

public class WebAppConfig
{
  public static string ConnectString
  {
    get { return ConfigurationManager.ConnectionStrings["StateMgmt"].ConnectionString; }
  }
}