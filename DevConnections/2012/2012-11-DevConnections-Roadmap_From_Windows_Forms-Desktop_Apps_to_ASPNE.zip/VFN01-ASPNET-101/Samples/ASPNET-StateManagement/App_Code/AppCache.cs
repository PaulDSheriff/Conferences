using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Caching;

public class AppCache
{
  public static string FullName
  {
    get { return HttpContext.Current.Application["FullName"].ToString(); }
    set { HttpContext.Current.Application["FullName"] = value; }
  }

  public static string AppTheme
  {
    get { return HttpContext.Current.Application["AppTheme"].ToString(); }
    set { HttpContext.Current.Application["AppTheme"] = value; }
  }

  public static string LastExceptionMessage
  {
    get { return HttpContext.Current.Application["LastExceptionMessage"].ToString(); }
    set { HttpContext.Current.Application["LastExceptionMessage"] = value; }
  }

  public static string Name
  {
    get { return HttpContext.Current.Cache["Name"].ToString(); }
    set { HttpContext.Current.Cache["Name"] = value; }
  }

  public static void SetNameToExpireSliding(string value, int secondsToExpire)
  {
    HttpContext.Current.Cache.Insert("Name", value, null, DateTime.MaxValue, TimeSpan.FromSeconds((secondsToExpire)));
  }

  public static void SetNameToExpireAbsolutely(string value, int hoursToExpire)
  {
    HttpContext.Current.Cache.Insert("Name", value, null, DateTime.UtcNow.AddHours(hoursToExpire), System.Web.Caching.Cache.NoSlidingExpiration); //  Absolutely expire in 2 hours
  }

  public static string GetAllApplicationVars()
  {
    return GetAllApplicationVars("<br />");
  }

  public static string GetAllApplicationVars(string delimiter)
  {
    StringBuilder sb = new StringBuilder(2048);
    object value;

    sb.Append(new string('*', 80) + delimiter);
    sb.Append("All Application/Cache Variables" + delimiter);
    sb.Append(new string('*', 80) + delimiter);

    foreach (string key in HttpContext.Current.Application.Keys)
    {
      value = GetApplicationVarAsObject(key);
      if (value == null)
        sb.Append(key + "=null");
      else
        sb.Append(key + "=" + value.ToString());

      sb.Append(delimiter);
    }
    IDictionaryEnumerator enumerator = HttpContext.Current.Cache.GetEnumerator();
    while (enumerator.MoveNext())
    {
      value = GetCacheVarAsObject(enumerator.Key.ToString());
      if (value == null)
        sb.Append(enumerator.Key.ToString() + "=null");
      else
        sb.Append(enumerator.Key.ToString() + "=" + value.ToString());

      sb.Append(delimiter);
    }
    sb.Append(delimiter);
    sb.Append(new string('*', 80) + delimiter);

    return sb.ToString();
  }

  public static object GetCacheVarAsObject(string key)
  {
    object ret = null;

    if (HttpContext.Current.Cache != null)
    {
      if (HttpContext.Current.Cache[key] != null)
      {
        ret = HttpContext.Current.Cache[key];
      }
    }

    return ret;
  }

  private static object GetApplicationVarAsObject(string key)
  {
    object ret = null;

    if (HttpContext.Current.Application != null)
    {
      if (HttpContext.Current.Application[key] != null)
      {
        ret = HttpContext.Current.Application[key];
      }
    }

    return ret;
  }

  public static void ClearCacheVars()
  {
    Cache ch;

    ch = HttpContext.Current.Cache;

    List<string> keys = new List<string>();
    IDictionaryEnumerator enumerator = ch.GetEnumerator();
    while (enumerator.MoveNext())
    {
      keys.Add(enumerator.Key.ToString());
    }
    foreach (string key in keys)
    {
      ch.Remove(key);
    }
  }
}