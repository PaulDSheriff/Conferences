using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

public class SQLState
{
  private string mSessionId = string.Empty;
  private StateBag mStateBag;
  private string mState = string.Empty;
  private bool mIsFound;

  #region Constructor
  public SQLState(string sessionId)
  {
    mStateBag = new StateBag();

    if (sessionId.Length == 0)
    {
      throw new ApplicationException("Must Pass in sessionId to SQLState Constructor");
    }
    else
    {
      mSessionId = sessionId;

      Read();
    }
  }
  #endregion

  #region Public Properties
  public string State
  {
    get { return mState; }
    set { mState = value; }
  }

  public bool IsFound
  {
    get { return mIsFound; }
  }

  public string SessionID
  {
    get { return mSessionId; }
    set { mSessionId = value; }
  }

  public StateBag Bag
  {
    get { return mStateBag; }
  }

  public string this[string key]
  {
    get
    {
      if (mStateBag[key] == null)
      {
        return "";
      }
      else
      {
        return mStateBag[key].ToString();
      }
    }
  }
  #endregion

  #region Add Method
  public void Add(string key, string value)
  {
    mStateBag.Add(key, value);
  }

  #endregion

  #region ExecuteSQL Method
  private void ExecuteSQL(string sql)
  {
    SqlCommand cmd = null;

    cmd = new SqlCommand();
    cmd.Connection = new SqlConnection(WebAppConfig.ConnectString);
    cmd.Connection.Open();

    cmd.CommandText = sql;
    cmd.CommandType = CommandType.Text;

    cmd.ExecuteNonQuery();

    cmd.Connection.Close();
    cmd.Connection.Dispose();
  }
  #endregion

  public void Delete()
  {
    string sql = null;

    sql = "DELETE FROM SessionState ";
    sql += "WHERE SessionID = '" + mSessionId + "' ";

    ExecuteSQL(sql);
  }
  
  public void Clear()
  {
    string sql = null;

    mState = "";
    mStateBag.Clear();

    sql = "UPDATE SessionState ";
    sql += " SET StateBag = Null ";
    sql += " WHERE SessionID = '" + mSessionId + "' ";

    ExecuteSQL(sql);
  }

  public bool Read()
  {
    SqlDataAdapter da = null;
    DataSet ds = new DataSet();
    string sql = null;

    //  Initialize Variables
    mIsFound = false;
    mState = "";
    mStateBag.Clear();

    sql = "SELECT StateBag FROM SessionState ";
    sql += "WHERE SessionID = '" + mSessionId + "'";

    da = new SqlDataAdapter(sql, WebAppConfig.ConnectString);

    da.Fill(ds);

    mState = string.Empty;
    mIsFound = false;
    if (ds.Tables.Count > 0)
    {
      if (ds.Tables[0].Rows.Count > 0)
      {
        mIsFound = true;

        mState = ds.Tables[0].Rows[0]["StateBag"].ToString();
      }
    }
    if (mState.Length > 0)
    {
      String2Bag();
    }

    return mIsFound;
  }
  
  public void Write()
  {
    string sql = null;

    mState = Bag2String();

    if (mIsFound)
    {
      sql = "UPDATE SessionState SET ";
      sql += "StateBag = '" + mState + "', ";
      sql += "DateLastUpdated = '" + DateTime.Now.ToShortDateString() + "' ";
      sql += "WHERE SessionID = '" + mSessionId + "' ";
    }
    else
    {
      sql = "INSERT INTO SessionState(SessionID, ";
      sql += " StateBag, DateLastUpdated)";
      sql += "VALUES('" + mSessionId + "',";
      sql += "'" + mState + "', ";
      sql += "'" + DateTime.Now.ToShortDateString() + "')";
    }

    ExecuteSQL(sql);
  }
  
  private string Bag2String()
  {
    string state = string.Empty;

    foreach (string key in mStateBag.Keys)
    {
      state += key + "=" + mStateBag[key].ToString() + "|";
    }

    return state;
  }

    private void String2Bag()
  {
    string[] values = null;
    string key = null;
    string value = null;

    values = mState.Split("|".ToCharArray());
    for (int index = 0; index <= values.Length - 1; index++)
    {
      value = values[index].Trim();

      if (value.Length > 0)   {
        key = value.Substring(0, value.IndexOf("="));
        value = value.Substring(value.IndexOf("=") + 1);

        Add(key, value);
      }
    }
  }
} 