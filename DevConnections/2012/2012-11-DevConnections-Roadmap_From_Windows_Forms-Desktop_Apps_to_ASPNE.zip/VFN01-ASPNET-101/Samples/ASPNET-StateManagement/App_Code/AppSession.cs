using System;
using System.Text;
using System.Web;

public class AppSession
{
  public static int CurrentEmployeeID
  {
    get { return Convert.ToInt32(HttpContext.Current.Session["CurrentEmployeeID"]); }
    set { HttpContext.Current.Session["CurrentEmployeeID"] = value; }
  }

  public static string LastMenuAccessed
  {
    get { return HttpContext.Current.Session["LastMenuAccessed"].ToString(); }
    set { HttpContext.Current.Session["LastMenuAccessed"] = value; }
  }

  public static string Theme
  {
    get { return HttpContext.Current.Session["Theme"].ToString(); }
    set { HttpContext.Current.Session["Theme"] = value; }
  }

  public static string CurrentPageName
  {
    get { return HttpContext.Current.Session["CurrentPageName"].ToString(); }
    set { HttpContext.Current.Session["CurrentPageName"] = value; }
  }

  public static string CurrentUserFullName
  {
    get { return HttpContext.Current.Session["CurrentUserFullName"].ToString(); }
    set { HttpContext.Current.Session["CurrentUserFullName"] = value; }
  }

  public static string GetAllSessionVars()
  {
    return GetAllSessionVars("<br />");
  }

  public static string GetAllSessionVars(string delimiter)
  {
    StringBuilder sb = new StringBuilder(2048);
    System.Web.SessionState.HttpSessionState session;
    object value;

    session = HttpContext.Current.Session;

    sb.Append(new string('*', 80) + delimiter);
    sb.Append("All Session Variables" + delimiter);
    sb.Append(new string('*', 80) + delimiter);

    sb.Append("CookieMode=" + session.CookieMode + delimiter);
    sb.Append("Count=" + session.Count.ToString() + delimiter);
    sb.Append("IsCookieless=" + session.IsCookieless.ToString() + delimiter);
    sb.Append("IsNewSession=" + session.IsNewSession.ToString() + delimiter);
    sb.Append("IsReadOnly=" + session.IsReadOnly.ToString() + delimiter);
    sb.Append("IsSynchronized=" + session.IsSynchronized.ToString() + delimiter);
    sb.Append("LCID=" + session.LCID + delimiter);
    sb.Append("Mode=" + session.Mode.ToString() + delimiter);
    sb.Append("SessionID=" + session.SessionID + delimiter);
    sb.Append("Timeout=" + session.Timeout.ToString() + delimiter);
    sb.Append(delimiter);

    foreach (string key in session.Keys)
    {
      value = GetSessionVarAsObject(key);
      if (value == null)
        sb.Append(key + "=null");
      else
        sb.Append(key + "=" + value.ToString());

      sb.Append(delimiter);
    }
    sb.Append(delimiter);
    sb.Append(new string('*', 80) + delimiter);

    return sb.ToString();
  }

  private static object GetSessionVarAsObject(string key)
  {
    object ret = null;

    if (HttpContext.Current.Session != null)
    {
      if (HttpContext.Current.Session[key] != null)
      {
        ret = HttpContext.Current.Session[key];
      }
    }

    return ret;
  }
}