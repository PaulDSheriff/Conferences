using System;

partial class frmViewStateTest : System.Web.UI.Page
{
  protected void btnSubmit_Click(object sender, System.EventArgs e)
  {
    ViewState["FirstName"] = txtFirst.Text;
    ViewState["LastName"] = txtLast.Text;
    ViewState["Password"] = txtPassword.Text;

    lblResult.Text = txtLast.Text + ", " + txtFirst.Text + " (" + 
      txtPassword.Text + ")";
    lblStateResult.Text = ViewState.Count.ToString();
  }

  protected void btnStateCheck_Click(object sender, System.EventArgs e)
  {
    if (ViewState["FirstName"] == null)
    {
      lblResult.Text = "NO STATE BAG SETUP";
    }
    else
    {
      lblResult.Text = "FirstName=" + ViewState["FirstName"].ToString() + " - " + 
        "LastName=" + ViewState["LastName"].ToString() + " - " + 
        "Password=" + ViewState["Password"].ToString();

      lblStateResult.Text = ViewState.Count.ToString();
    }
  }
}