using System;

partial class frmCookie : System.Web.UI.Page
{

  protected void Page_Load(object sender, System.EventArgs e)
  {
    if (Request.Cookies.Get("EmailPerm") == null)
    {
      //  Do Nothing
    }
    else
    {
      if (Request.Cookies.Get("EmailPerm").Value != "")
      {
        txtEMail.Text = Request.Cookies.Get("EmailPerm").Value;
      }
    }
  }

  protected void btnSubmit_Click(object sender, System.EventArgs e)
  {
    Response.Cookies.Get("EmailPerm").Value = txtEMail.Text;
    Response.Cookies.Get("EmailPerm").Expires = DateTime.Today.AddDays(30);

    // Response.Cookies.Add(New HttpCookie("Email", txtEmail.Text))
    Response.Redirect("Default.aspx");
  }

  protected void cmdReset_Click(object sender, System.EventArgs e)
  {
    Response.Cookies.Get("EmailPerm").Expires = DateTime.Today.AddDays(-1);
    Response.Redirect("Default.aspx");
  }
} 
