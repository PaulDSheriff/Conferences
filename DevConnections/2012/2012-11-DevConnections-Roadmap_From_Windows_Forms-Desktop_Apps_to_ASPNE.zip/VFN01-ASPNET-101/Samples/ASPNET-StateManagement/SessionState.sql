DROP TABLE SessionState
GO
CREATE TABLE SessionState
(
	SessionID Char(30) NOT NULL,
	StateBag varchar(255) NULL,
	DateLastUpdated DateTime NULL
)