using System;

partial class MasterPage_StateMgmt : System.Web.UI.MasterPage 
{ 
} 
