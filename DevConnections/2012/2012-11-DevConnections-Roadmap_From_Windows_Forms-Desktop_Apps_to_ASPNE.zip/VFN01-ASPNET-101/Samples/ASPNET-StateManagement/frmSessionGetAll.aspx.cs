﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class frmSessionGetAll : System.Web.UI.Page
{

    protected void btnSetVars_Click(object sender, EventArgs e)
    {
      AppSession.CurrentEmployeeID = 10;
      AppSession.CurrentPageName = "frmSessionGetAll.aspx";
      AppSession.CurrentUserFullName = "John Smith";
      AppSession.LastMenuAccessed = "Main";
      AppSession.Theme = "Blue";
    }
    protected void btnGetAll_Click(object sender, EventArgs e)
    {
      lblInfo.Text = AppSession.GetAllSessionVars();
    }
    protected void btnClearAll_Click(object sender, EventArgs e)
    {
      Session.Clear();
    }
}
