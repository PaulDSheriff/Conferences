using System;

partial class frmLogout : System.Web.UI.Page
{
  protected void Page_Load(object sender, System.EventArgs e)
  {
    Session.Abandon();
  }
}