using System;

partial class frmSessionTestError : System.Web.UI.Page
{

  protected void Page_Load(object sender, System.EventArgs e)
  {
    if (Session["Email"] == null)
    {
      //  Do Nothing
    }
    else
    {
      txtEmail.Text = Session["Email"].ToString();
    }
  }

  protected void btnSubmit_Click(object sender, System.EventArgs e)
  {
    Session["Email"] = txtEmail.Text;

    Response.Redirect("Default.aspx");
  }
}