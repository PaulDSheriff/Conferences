using System;

partial class frmMaintainStateTest : System.Web.UI.Page
{

  protected void Page_Load(object sender, System.EventArgs e)
  {
    //  Evals true first time browser hits the page	
    if (Page.IsPostBack)
    {
      lblMsg.Text = "Back again";
    }
    else
    {
      txtEMail.Text = "Paul@info.com";
      lblMsg.Text = "First Time";
    }
  }

  protected void btnSubmit_Click(object sender, System.EventArgs e)
  {
    lblResult.Text = txtEMail.Text;
  }
}