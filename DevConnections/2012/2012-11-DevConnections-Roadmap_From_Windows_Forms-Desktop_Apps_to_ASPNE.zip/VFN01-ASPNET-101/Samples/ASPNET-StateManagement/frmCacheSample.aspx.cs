using System;

partial class frmCacheSample : System.Web.UI.Page
{

  protected void Page_Load(object sender, System.EventArgs e)
  {
    if (Cache["Name"] != null)
    {
      txtName.Text = Cache["Name"].ToString();
    }
  }

  protected void btnSubmit_Click(object sender, System.EventArgs e)
  {
    //  Cache["Name"] = txtName.Text  // Just like Application object
    //  Cache.Insert("Name", txtName.Text,  Nothing, DateTime.UtcNow.AddHours(2), System.Web.Caching.Cache.NoSlidingExpiration)  // Absolutely expire in 2 hours
    Cache.Insert("Name",
      txtName.Text, null,
      DateTime.MaxValue,
      TimeSpan.FromSeconds((10)));
    lblMessage.Visible = true;
  }

  protected void btnSubmitClass_Click(object sender, System.EventArgs e)
  {
    AppCache.Name = txtName.Text;
    AppCache.SetNameToExpireAbsolutely(txtName.Text, 2); //  Expire in exactly 2 hours
    AppCache.SetNameToExpireSliding(txtName.Text, 10); //  Expire sliding scale every 10 seconds
  }
}