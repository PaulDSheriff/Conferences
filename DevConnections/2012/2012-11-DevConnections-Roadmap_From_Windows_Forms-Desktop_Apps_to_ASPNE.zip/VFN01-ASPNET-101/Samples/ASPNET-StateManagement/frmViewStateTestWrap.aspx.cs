﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class frmViewStateTestWrap : System.Web.UI.Page
{
  private string FirstName
  {
    get
    {
      if (ViewState["FirstName"] == null)
        return string.Empty;
      else
        return ViewState["FirstName"].ToString();
    }
    set { ViewState["FirstName"] = value; }
  }

  private string LastName
  {
    get
    {
      if (ViewState["LastName"] == null)
        return string.Empty;
      else
        return ViewState["LastName"].ToString();
    }
    set { ViewState["LastName"] = value; }
  }

  private string Password
  {
    get
    {
      if (ViewState["Password"] == null)
        return string.Empty;
      else
        return ViewState["Password"].ToString();
    }
    set { ViewState["Password"] = value; }
  }

  protected void btnSubmit_Click(object sender, EventArgs e)
  {
    this.FirstName = txtFirst.Text;
    this.LastName = txtLast.Text;
    this.Password = txtPassword.Text;

    lblResult.Text = txtLast.Text + ", " + txtFirst.Text + 
        " (" + txtPassword.Text + ")";
    lblStateResult.Text = ViewState.Count.ToString();
  }

  protected void btnStateCheck_Click(object sender, EventArgs e)
  {
    if (this.FirstName == string.Empty)
    {
      lblResult.Text = "NO STATE BAG SETUP";
    }
    else
    {
      lblResult.Text = "FirstName=" + this.FirstName + " - " + 
          "LastName=" + this.LastName + " - " + 
          "Password=" + this.Password;

      lblStateResult.Text = ViewState.Count.ToString();
    }
  }
}
