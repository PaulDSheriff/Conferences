﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class frmCacheGetAll : System.Web.UI.Page
{
  protected void btnSetVars_Click(object sender, EventArgs e)
  {
    AppCache.AppTheme = "SiteTheme";
    AppCache.FullName = "A Customer Application";
    AppCache.LastExceptionMessage = "Last exception message";
    AppCache.Name = "PDSA, Inc.";
  }

  protected void btnGetAll_Click(object sender, EventArgs e)
  {
    lblInfo.Text = AppCache.GetAllApplicationVars();
  }
  protected void btnClearAll_Click(object sender, EventArgs e)
  {
    HttpContext.Current.Application.Clear();
    AppCache.ClearCacheVars();
  }
}
