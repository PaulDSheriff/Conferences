﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVV_Simple_CS.Services
{
  public class Products : List<Product>
  {
  }
}
