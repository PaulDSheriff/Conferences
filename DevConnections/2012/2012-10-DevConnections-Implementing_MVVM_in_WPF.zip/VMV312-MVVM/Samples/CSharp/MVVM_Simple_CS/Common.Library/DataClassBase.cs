﻿
namespace Common.Library
{
  public class DataClassBase : CommonBase
  {
    public DataClassBase()
    {
      _BusinessRuleFailures = new BusinessRuleMessages();
    }

    private BusinessRuleMessages _BusinessRuleFailures;

    public BusinessRuleMessages BusinessRuleFailures
    {
      get { return _BusinessRuleFailures; }
      set
      {
        _BusinessRuleFailures = value;
        RaisePropertyChanged("BusinessRuleFailures");
      }
    }
  }
}
