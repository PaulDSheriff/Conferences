﻿DROP TABLE FileProcessTest
GO
CREATE TABLE FileProcessTest
(
  TestId int IDENTITY(1,1) NOT NULL PRIMARY KEY NONCLUSTERED,
  FileName varchar(255) NOT NULL,
  ExpectedValue bit NOT NULL DEFAULT ((0))
)

INSERT INTO FileProcessTest(FileName, ExpectedValue) VALUES('D:\Test.txt', 1)
INSERT INTO FileProcessTest(FileName, ExpectedValue) VALUES('D:\Samples\TimeSheet.xls', 0)
INSERT INTO FileProcessTest(FileName, ExpectedValue) VALUES('C:\tmuninst.ini', 1)