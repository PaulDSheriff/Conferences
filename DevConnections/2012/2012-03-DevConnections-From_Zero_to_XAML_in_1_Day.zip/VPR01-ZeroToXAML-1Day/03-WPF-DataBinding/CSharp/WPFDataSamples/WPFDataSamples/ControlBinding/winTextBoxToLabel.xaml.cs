﻿using System.Windows;

namespace WPFDataSamples
{
  /// <summary>
  /// Interaction logic for winTextBoxToLabel.xaml
  /// </summary>
  public partial class winTextBoxToLabel : Window
  {
    public winTextBoxToLabel()
    {
      InitializeComponent();
    }
  }
}
