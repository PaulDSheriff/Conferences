﻿using System.Linq;
using System.Windows;

using WPFEFComponents;

namespace WPFDataSamples
{
  /// <summary>
  /// Interaction logic for winDataBindingEF.xaml
  /// </summary>
  public partial class winDataBindingEF : Window
  {
    public winDataBindingEF()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      AdventureWorksLTEntities dc = new AdventureWorksLTEntities();

      var items = from cust in dc.Customer
                  orderby cust.LastName
                  select cust;

      lstData.DataContext = items;
    }    
  }
}
