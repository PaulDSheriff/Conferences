﻿using System.Linq;
using System.Windows;

using WPFComponents;

namespace WPFDataSamples
{
  /// <summary>
  /// Interaction logic for winDataBindingLINQSQL.xaml
  /// </summary>
  public partial class winDataBindingLINQSQL : Window
  {
    public winDataBindingLINQSQL()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      AdvWorksDataContext dc = new AdvWorksDataContext();

      var items = from cust in dc.Customers
                  orderby cust.LastName
                  select cust;

      lstData.DataContext = items;
    }    
  }
}
