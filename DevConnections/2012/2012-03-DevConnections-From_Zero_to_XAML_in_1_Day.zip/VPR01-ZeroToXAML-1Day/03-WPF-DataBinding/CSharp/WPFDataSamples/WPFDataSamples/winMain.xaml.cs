﻿using System.Windows;

namespace WPFDataSamples
{
  public partial class winMain : Window
  {
    public winMain()
    {
      InitializeComponent();
    }

    #region Control To Control Binding
    private void btnTextBoxToLabel_Click(object sender, RoutedEventArgs e)
    {
      winTextBoxToLabel win = new winTextBoxToLabel();

      win.Show();
    }

    private void btnLabelToComboBox_Click(object sender, RoutedEventArgs e)
    {
      winComboToLabel win = new winComboToLabel();

      win.Show();
    }

    private void btnComboUsingTag_Click(object sender, RoutedEventArgs e)
    {
      winComboUsingTag win = new winComboUsingTag();

      win.Show();
    }

    private void btnFontFamilyBinding_Click(object sender, RoutedEventArgs e)
    {
      winFontBinding win = new winFontBinding();

      win.Show();
    }

    private void btnEnabled_Click(object sender, RoutedEventArgs e)
    {
      winEnabled win = new winEnabled();

      win.Show();
    }
    #endregion

    #region Data Binding using Code
    private void btnDataSet_Click(object sender, RoutedEventArgs e)
    {
      winDataBindingDataSet win = new winDataBindingDataSet();

      win.Show();
    }

    private void btnCollection_Click(object sender, RoutedEventArgs e)
    {
      winDataBindingCollection win = new winDataBindingCollection();

      win.Show();
    }

    private void btnDataBindingEF_Click(object sender, RoutedEventArgs e)
    {
      winDataBindingEF win = new winDataBindingEF();

      win.Show();
    }

    private void btnSimpleDataBinding_Click(object sender, RoutedEventArgs e)
    {
      winDataBindingLINQSQL win = new winDataBindingLINQSQL();

      win.Show();
    }
    #endregion

    #region ObjectDataProvider
    private void btnObjectDataProvider_Click(object sender, RoutedEventArgs e)
    {
      winObjectDataProviderLINQSQL win = new winObjectDataProviderLINQSQL();

      win.Show();
    }

    private void btnObjectDataProviderLINQXML_Click(object sender, RoutedEventArgs e)
    {
      winObjectDataProviderLINQXML win = new winObjectDataProviderLINQXML();

      win.Show();
    }

    private void btnObjectDataProviderEF_Click(object sender, RoutedEventArgs e)
    {
      winObjectDataProviderEF win = new winObjectDataProviderEF();

      win.Show();
    }

    private void btnXmlDataBinding_Click(object sender, RoutedEventArgs e)
    {
      winXmlDataProvider win = new winXmlDataProvider();

      win.Show();
    }
    #endregion

    #region ListView Control
    private void btnListViewSimple_Click(object sender, RoutedEventArgs e)
    {
      winListViewSimple win = new winListViewSimple();

      win.Show();
    }

    private void btnListViewWithSelect_Click(object sender, RoutedEventArgs e)
    {
      winListViewSelect win = new winListViewSelect();

      win.Show();
    }

    private void btnListViewByTitle_Click(object sender, RoutedEventArgs e)
    {
      winListViewTitleCombo win = new winListViewTitleCombo();

      win.Show();
    }
    #endregion

    #region DataModification Sample
    private void btnModify_Click(object sender, RoutedEventArgs e)
    {
      winSelectModifyLINQSQL win = new winSelectModifyLINQSQL();

      win.Show();
    }

    private void btnModifyEF_Click(object sender, RoutedEventArgs e)
    {
      winSelectModifyEF win = new winSelectModifyEF();

      win.Show();
    }
    #endregion

    #region Class Samples
    private void btnClass1_Click(object sender, RoutedEventArgs e)
    {
      winSimpleClass win = new winSimpleClass();

      win.Show();
    }

    private void btnClass2_Click(object sender, RoutedEventArgs e)
    {
      winCollectionClass win = new winCollectionClass();

      win.Show();
    }

    private void btnClass3_Click(object sender, RoutedEventArgs e)
    {
      winClientSettings win = new winClientSettings();

      win.Show();
    }

    private void btnClass4_Click(object sender, RoutedEventArgs e)
    {
      winSimplestViewModel win = new winSimplestViewModel();

      win.Show();
    }
    #endregion

    private void btnEFViewModel_Click(object sender, RoutedEventArgs e)
    {
      winCustomerEF win = new winCustomerEF();

      win.Show();
    }
  }
}