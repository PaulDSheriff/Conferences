﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using WPFEFComponents;

namespace WPFDataSamples
{
  public partial class winCustomerEF : Window
  {
    CustomerViewModel _ViewModel;

    public winCustomerEF()
    {
      InitializeComponent();

      _ViewModel = (CustomerViewModel)this.FindResource("viewModel");
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      _ViewModel.Load();
    }

    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.Save();
    }

    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      if (MessageBox.Show("Delete this Customer?", "Delete",
        MessageBoxButton.YesNo, 
        MessageBoxImage.Question) == MessageBoxResult.Yes)
      {
        _ViewModel.Delete();
      }
    }

    private void btnAdd_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.AddNew();

      // Display it in the ListBox
      this.lstCustomers.ScrollIntoView(_ViewModel.DetailData);
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.Cancel();
    }
  }
}