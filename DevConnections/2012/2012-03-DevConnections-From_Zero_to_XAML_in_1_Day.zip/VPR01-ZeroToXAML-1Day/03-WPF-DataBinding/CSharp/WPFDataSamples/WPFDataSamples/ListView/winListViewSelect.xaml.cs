﻿using System.Windows;

namespace WPFDataSamples
{
  /// <summary>
  /// Interaction logic for winListViewSelect.xaml
  /// </summary>
  public partial class winListViewSelect : Window
  {
    public winListViewSelect()
    {
      InitializeComponent();
    }
  }
}