﻿using System.Windows;

namespace WPFDataSamples
{
  /// <summary>
  /// Interaction logic for winComboUsingTag.xaml
  /// </summary>
  public partial class winComboUsingTag : Window
  {
    public winComboUsingTag()
    {
      InitializeComponent();
    }
  }
}
