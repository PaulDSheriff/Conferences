﻿using System.Windows;

namespace WPFDataSamples
{
  /// <summary>
  /// Interaction logic for winObjectDataProviderEF.xaml
  /// </summary>
  public partial class winObjectDataProviderEF : Window
  {
    public winObjectDataProviderEF()
    {
      InitializeComponent();      
    }
  }
}
