﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using WPFEFComponents;

namespace WPFDataSamples
{
  public partial class winSelectModifyEF : Window
  {
    public winSelectModifyEF()
    {
      InitializeComponent();
    }

    bool _IsAddMode = false;
    // A BindingListCollectionView is needed for data binding with updating
    private BindingListCollectionView CustomerView;
    // The Entity Framework data context
    AdventureWorksLTEntities dc = new AdventureWorksLTEntities();
    
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      // Create a collection of Customers
      var items = from item in dc.Customer
                  orderby item.LastName
                  select item;

      // Set this form's DataContext with collection of customers
      this.DataContext = items;

      // Turn Collection of Customers into BindingListCollectionView
      // This is needed for add/edit/delete
      this.CustomerView = (BindingListCollectionView)
        (CollectionViewSource.GetDefaultView(items));
    }

    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      // Commit the changes to the database
      this.dc.SaveChanges();
      _IsAddMode = false;
    }

    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      if (MessageBox.Show("Delete this Customer?", "Delete",
        MessageBoxButton.YesNo, 
        MessageBoxImage.Question) == MessageBoxResult.Yes)
      {
        // Remove the customer from the view
        this.CustomerView.RemoveAt(this.CustomerView.CurrentPosition);
        // Commit the delete to the database
        this.dc.SaveChanges();
      }
      _IsAddMode = false;
    }

    private void btnAdd_Click(object sender, RoutedEventArgs e)
    {
      // Set Add Flag
      _IsAddMode = true;
      // Create New Customer Record
      Customer newCust = 
        (Customer)(this.CustomerView.AddNew());
      // Fill in any default values
      newCust.FirstName = "<new>";
      newCust.ModifiedDate = DateTime.Now;
      newCust.NameStyle = false;
      newCust.PasswordHash = string.Empty;
      newCust.PasswordSalt = string.Empty;
      newCust.rowguid = System.Guid.NewGuid();
      // Commit it to the View
      this.CustomerView.CommitNew();
      // Display it in the ListBox
      this.lstCustomers.ScrollIntoView(newCust);
      txtFirst.Focus();
      txtFirst.SelectAll();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      if (_IsAddMode)
      {
        // If we were adding, then cancel it
        this.CustomerView.CancelNew();
        // Remove the new item from the Customer view
        this.CustomerView.Remove(this.CustomerView.CurrentItem);
      }
      else
      {
        // Cancel the edit
        this.CustomerView.CancelEdit();
        // Refresh the DataContext with the old values
        dc.Refresh(System.Data.Objects.RefreshMode.StoreWins,
          this.CustomerView);
        // Refresh the CustomerView
        this.CustomerView.Refresh();
      }
      _IsAddMode = false;     
    }
  }
}