﻿using System.Windows;

namespace WPFDataSamples
{
  /// <summary>
  /// Interaction logic for winXmlDataProvider.xaml
  /// </summary>
  public partial class winXmlDataProvider : Window
  {
    public winXmlDataProvider()
    {
      
      InitializeComponent();
    }
  }
}
