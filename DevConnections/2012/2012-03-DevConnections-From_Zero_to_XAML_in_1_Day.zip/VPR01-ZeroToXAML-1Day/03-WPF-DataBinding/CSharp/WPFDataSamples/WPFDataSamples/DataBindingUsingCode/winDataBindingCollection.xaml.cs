﻿using System.Windows;

using WPFComponents;

namespace WPFDataSamples
{
  /// <summary>
  /// Interaction logic for winDataBindingCollection.xaml
  /// </summary>
  public partial class winDataBindingCollection : Window
  {
    public winDataBindingCollection()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      MyCustomers custs = new MyCustomers();

      lstData.DataContext = custs.GetCustomerList();
    } 
  }
}
