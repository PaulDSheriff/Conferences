﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using WPFEFComponents;

namespace WPFDataSamples
{
  public class CustomerViewModel : DependencyObject
  {
    #region Constructor
    public CustomerViewModel()
    {
    }
    #endregion

    #region Private Variables
    /// <summary>
    /// Get/Set whether or not this view is in Add Mode.
    /// </summary>
    private bool _IsAddMode = false;
    /// <summary>
    /// Get/Set the BindingListCollectionView that is needed for data binding with updating
    /// </summary>
    private BindingListCollectionView _CustomerView = null;
    /// <summary>
    /// Get/Set the Entity Framework Data Context
    /// </summary>
    private AdventureWorksLTEntities _DataContext = null;
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the Currently Selected Customer Object
    /// </summary>
    public Customer DetailData
    {
      get { return (Customer)GetValue(DetailDataProperty); }
      set { SetValue(DetailDataProperty, value); }
    }
    public static readonly DependencyProperty DetailDataProperty =
          DependencyProperty.Register("DetailData", typeof(Customer), typeof(CustomerViewModel), null);

    /// <summary>
    /// Get/Set the Data Collection of Customer objects
    /// </summary>
    public IEnumerable<Customer> DataCollection
    {
      get { return (IEnumerable<Customer>)GetValue(DataCollectionProperty); }
      set { SetValue(DataCollectionProperty, value); }
    }
    public static readonly DependencyProperty DataCollectionProperty =
        DependencyProperty.Register("DataCollection", typeof(IEnumerable<Customer>), typeof(CustomerViewModel), null);
    #endregion

    #region Load Method
    public void Load()
    {
      // Create new instance of Entity Object
      _DataContext = new AdventureWorksLTEntities();

      // Create a collection of Customers
      var items = from item in _DataContext.Customer
                  orderby item.LastName
                  select item;

      // Set this form's DataContext with collection of customers
      this.DataCollection = items;

      // Turn Collection of Customers into BindingListCollectionView
      // This is needed for add/edit/delete
      this._CustomerView = (BindingListCollectionView)
        (CollectionViewSource.GetDefaultView(items));
    }
    #endregion

    #region Save Method
    public void Save()
    {
      // Commit the changes to the database
      this._DataContext.SaveChanges();
      _IsAddMode = false;
    }
    #endregion

    #region Delete Method
    public void Delete()
    {
      // Remove the customer from the view
      this._CustomerView.Remove(DetailData);
      // Commit the delete to the database
      this._DataContext.SaveChanges();
      _IsAddMode = false;
    }
    #endregion

    #region AddNew Method
    public void AddNew()
    {
      // Set Add Flag
      _IsAddMode = true;
      // Create New Customer Record
      Customer newCust =
        (Customer)(this._CustomerView.AddNew());
      // Fill in any default values
      newCust.FirstName = "<new>";
      newCust.ModifiedDate = DateTime.Now;
      newCust.NameStyle = false;
      newCust.PasswordHash = string.Empty;
      newCust.PasswordSalt = string.Empty;
      newCust.rowguid = System.Guid.NewGuid();
      // Commit it to the View
      this._CustomerView.CommitNew();
    }
    #endregion

    #region Cancel Method
    public void Cancel()
    {
      if (_IsAddMode)
      {
        // If we were adding, then cancel it
        this._CustomerView.CancelNew();
        // Remove the new item from the Customer view
        this._CustomerView.Remove(this._CustomerView.CurrentItem);
      }
      else
      {
        // Cancel the edit
        this._CustomerView.CancelEdit();
        // Refresh the DataContext with the old values
        _DataContext.Refresh(System.Data.Objects.RefreshMode.StoreWins,
          this._CustomerView);
        // Refresh the CustomerView
        this._CustomerView.Refresh();
      }
      _IsAddMode = false;
    }
    #endregion
  }
}
