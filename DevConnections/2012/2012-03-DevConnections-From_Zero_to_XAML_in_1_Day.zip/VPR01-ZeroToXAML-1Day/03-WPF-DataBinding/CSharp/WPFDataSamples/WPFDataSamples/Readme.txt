﻿WPF Data Samples
===========================================
To ensure that this demo works correctly, open the App.Config file and ensure that the Connection String points to the AdventureWorksLT database in your SQL Server. You might need to change your credentials as well.