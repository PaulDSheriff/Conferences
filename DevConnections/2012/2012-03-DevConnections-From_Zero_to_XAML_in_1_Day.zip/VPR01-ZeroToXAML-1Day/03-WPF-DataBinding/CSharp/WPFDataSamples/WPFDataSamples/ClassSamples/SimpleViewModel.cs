﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPFDataSamples
{
  public class SimpleViewModel : ObjectBase
  {
    private bool _IsBenefitsChecked = true;
    private bool _Is401kEnabled = true;
    private bool _IsHealthCareEnabled = true;
    private bool _IsDayCareEnabled = true;

    public bool IsBenefitsChecked
    {
      get { return _IsBenefitsChecked; }
      set
      {
        if (_IsBenefitsChecked != value)
        {
          _IsBenefitsChecked = value;
          Is401kEnabled = value;
          IsHealthCareEnabled = value;
          IsDayCareEnabled = value;
          RaisePropertyChanged("IsBenefitsChecked");
        }
      }
    }

    public bool Is401kEnabled
    {
      get { return _Is401kEnabled; }
      set
      {
        if (_Is401kEnabled != value)
        {
          _Is401kEnabled = value;
          RaisePropertyChanged("Is401kEnabled");
        }
      }
    }

    public bool IsHealthCareEnabled
    {
      get { return _IsHealthCareEnabled; }
      set
      {
        if (_IsHealthCareEnabled != value)
        {
          _IsHealthCareEnabled = value;
          RaisePropertyChanged("IsHealthCareEnabled");
        }
      }
    }

    public bool IsDayCareEnabled
    {
      get { return _IsDayCareEnabled; }
      set
      {
        if (_IsDayCareEnabled != value)
        {
          _IsDayCareEnabled = value;
          RaisePropertyChanged("IsDayCareEnabled");
        }
      }
    }
  }
}
