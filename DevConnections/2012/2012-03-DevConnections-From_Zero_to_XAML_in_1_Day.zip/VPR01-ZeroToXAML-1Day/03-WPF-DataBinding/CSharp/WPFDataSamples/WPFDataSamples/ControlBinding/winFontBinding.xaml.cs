﻿using System.Windows;

namespace WPFDataSamples
{
  /// <summary>
  /// Interaction logic for winFontBinding.xaml
  /// </summary>
  public partial class winFontBinding : Window
  {
    public winFontBinding()
    {
      InitializeComponent();
    }
  }
}
