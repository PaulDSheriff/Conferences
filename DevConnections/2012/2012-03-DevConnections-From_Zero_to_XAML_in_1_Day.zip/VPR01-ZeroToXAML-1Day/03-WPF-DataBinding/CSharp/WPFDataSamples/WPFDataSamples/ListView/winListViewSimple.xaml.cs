﻿using System.Windows;

namespace WPFDataSamples
{
  /// <summary>
  /// Interaction logic for winListViewSimple.xaml
  /// </summary>
  public partial class winListViewSimple : Window
  {
    public winListViewSimple()
    {
      InitializeComponent();
    }
  }
}
