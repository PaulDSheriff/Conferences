﻿using System.Windows;
using System.Windows.Controls;

namespace WPFDataSamples
{
  /// <summary>
  /// Interaction logic for winComboToLabel.xaml
  /// </summary>
  public partial class winComboToLabel : Window
  {
    public winComboToLabel()
    {
      InitializeComponent();
    }

    private void cboLanguage_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      // Get Selected Text From ComboBox
      lblFromCode.Content = 
        ((ComboBoxItem)cboLanguage.SelectedItem).Content;
    }
  }
}
