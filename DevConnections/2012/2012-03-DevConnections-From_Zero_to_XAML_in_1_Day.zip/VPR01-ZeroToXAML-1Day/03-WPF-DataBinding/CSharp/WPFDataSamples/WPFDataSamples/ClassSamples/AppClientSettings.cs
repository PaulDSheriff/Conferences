﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media;

namespace WPFDataSamples
{
  public class AppClientSettings
  {
    public AppClientSettings()
    {
      BackgroundBrush = new SolidColorBrush();
      BackgroundBrush.Color = Colors.Red;
    }

    public SolidColorBrush
            BackgroundBrush { get; set; }
  }
}
