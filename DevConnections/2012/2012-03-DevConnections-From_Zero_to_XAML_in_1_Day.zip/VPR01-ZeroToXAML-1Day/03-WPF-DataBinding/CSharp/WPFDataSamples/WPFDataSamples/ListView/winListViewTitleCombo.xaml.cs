﻿using System.Windows;

namespace WPFDataSamples
{
  /// <summary>
  /// Interaction logic for winListViewTitleCombo.xaml
  /// </summary>
  public partial class winListViewTitleCombo : Window
  {
    public winListViewTitleCombo()
    {
      InitializeComponent();
    }
  }
}