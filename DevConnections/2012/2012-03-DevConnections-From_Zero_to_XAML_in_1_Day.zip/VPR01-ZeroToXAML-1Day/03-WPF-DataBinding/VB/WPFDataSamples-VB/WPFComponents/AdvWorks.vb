Imports System.Collections
Imports System.Collections.Generic

Partial Class AdvWorksDataContext
  Public Function GetAllCustomers() As IEnumerable(Of Customer)
    Dim items = From cust In Me.Customers _
                        Order By cust.LastName _
                        Select cust

    Return items
  End Function

  Public Function GetCustomerTitles() As IQueryable(Of String)
    Dim items = (From cust In Me.Customers _
        Order By cust.Title _
        Select cust.Title).Distinct()

    Return items
  End Function

  Public Function GetCustomersByTitle(ByVal title As String) As IEnumerable(Of Customer)
    Dim items = From cust In Me.Customers _
        Order By cust.LastName _
        Where cust.Title = title _
        Select cust

    Return items
  End Function
End Class