﻿Imports System
Imports System.Data.Linq
Imports System.Linq
Imports System.Windows
Imports System.Windows.Data
Imports WPFComponents

Partial Public Class winSelectModifyLINQSQL
  Inherits Window

  Public Sub New()
    InitializeComponent()
  End Sub

  Private mIsAddMode As Boolean = False
  ' A BindingListCollectionView is needed for data binding with updating
  Private CustomerView As BindingListCollectionView
  ' The LINQ to SQL data context
  Private dc As New AdvWorksDataContext()

  Private Sub Window_Loaded(ByVal sender As Object, ByVal e As RoutedEventArgs)
    ' Create a collection of Customers
    Dim items = From item In dc.Customers _
        Order By item.LastName _
        Select item

    ' Set this form's DataContext with collection of customers
    Me.DataContext = items

    ' Turn Collection of Customers into BindingListCollectionView
    ' This is needed for add/edit/delete
    Me.CustomerView = DirectCast((CollectionViewSource.GetDefaultView(items)), BindingListCollectionView)
  End Sub

  Private Sub btnSave_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    ' Commit the changes to the database
    Me.dc.SubmitChanges()
    mIsAddMode = False
  End Sub

  Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    If MessageBox.Show("Delete this Customer?", "Delete", MessageBoxButton.YesNo, MessageBoxImage.Question) = MessageBoxResult.Yes Then
      ' Remove the customer from the view
      Me.CustomerView.RemoveAt(Me.CustomerView.CurrentPosition)
      ' Commit the delete to the database
      Me.dc.SubmitChanges()
    End If
    mIsAddMode = False
  End Sub

  Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    ' Set Add Flag
    mIsAddMode = True
    ' Create New Customer Record
    Dim newCust As Customer = DirectCast((Me.CustomerView.AddNew()), Customer)
    ' Fill in any default values
    newCust.FirstName = "<new>"
    newCust.ModifiedDate = DateTime.Now
    newCust.NameStyle = False
    newCust.PasswordHash = String.Empty
    newCust.PasswordSalt = String.Empty
    newCust.rowguid = System.Guid.NewGuid()
    ' Commit it to the View
    Me.CustomerView.CommitNew()
    ' Display it in the ListBox
    Me.lstCustomers.ScrollIntoView(newCust)
    txtFirst.Focus()
    txtFirst.SelectAll()
  End Sub

  Private Sub btnCancel_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    If mIsAddMode Then
      ' If we were adding, then cancel it
      Me.CustomerView.CancelNew()
      ' Remove the new item from the Customer view
      Me.CustomerView.Remove(Me.CustomerView.CurrentItem)
    Else
      ' Cancel the edit
      Me.CustomerView.CancelEdit()
      ' Refresh the DataContext with the old values
      dc.Refresh(RefreshMode.OverwriteCurrentValues, _
                 dc.GetChangeSet().Updates)
      ' Refresh the CustomerView
      Me.CustomerView.Refresh()
    End If
    mIsAddMode = False
  End Sub
End Class