﻿Class frmMain

#Region "Control Binding"
  Private Sub btnTextBoxToLabel_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnTextBoxToLabel.Click
    Dim win As New winTextBoxToLabel

    win.Show()
  End Sub

  Private Sub btnLabelToComboBox_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnLabelToComboBox.Click
    Dim win As New winComboToLabel

    win.Show()
  End Sub

  Private Sub btnComboUsingTag_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnComboUsingTag.Click
    Dim win As New winComboUsingTag

    win.Show()
  End Sub

  Private Sub btnFontFamilyBinding_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnFontFamilyBinding.Click
    Dim win As New winFontBinding

    win.Show()
  End Sub

  Private Sub btnEnabled_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnEnabled.Click
    Dim win As New winEnabled

    win.Show()
  End Sub
#End Region

#Region "Simple Data Samples"
  Private Sub btnSimpleDataBinding_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnSimpleDataBinding.Click
    Dim win As New winDataBindingLINQSQL

    win.Show()
  End Sub

  Private Sub btnObjectDataProvider_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnObjectDataProvider.Click
    Dim win As New winObjectDataProviderLINQSQL

    win.Show()
  End Sub

  Private Sub btnDataSet_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnDataSet.Click
    Dim win As New winDataBindingDataSet

    win.Show()
  End Sub

  Private Sub btnDataBindingEF_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnDataBindingEF.Click
    Dim win As New winDataBindingEF

    win.Show()
  End Sub

  Private Sub btnCollection_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnCollection.Click
    Dim win As New winDataBindingCollection

    win.Show()
  End Sub

  Private Sub btnObjectDataProviderLINQXML_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnObjectDataProviderLINQXML.Click
    Dim win As New winObjectDataProviderLINQXML

    win.Show()
  End Sub

  Private Sub btnObjectDataProviderEF_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnObjectDataProviderEF.Click
    Dim win As New winObjectDataProviderEF

    win.Show()
  End Sub

  Private Sub btnXmlDataBinding_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnXmlDataBinding.Click
    Dim win As New winXmlDataProvider

    win.Show()
  End Sub
#End Region

#Region "ListView Samples"
  Private Sub btnListViewSimple_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnListViewSimple.Click
    Dim win As New winListViewSimple

    win.Show()
  End Sub

  Private Sub btnListViewWithSelect_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnListViewWithSelect.Click
    Dim win As New winListViewSelect

    win.Show()
  End Sub

  Private Sub btnListViewByTitle_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnListViewByTitle.Click
    Dim win As New winListViewTitleCombo

    win.Show()
  End Sub
#End Region

#Region "Data Modification Sample"
  Private Sub btnModify_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnModify.Click
    Dim win As New winSelectModifyLINQSQL

    win.Show()
  End Sub

  Private Sub btnModifyEF_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnModifyEF.Click
    Dim win As New winSelectModifyEF

    win.Show()
  End Sub
#End Region

End Class
