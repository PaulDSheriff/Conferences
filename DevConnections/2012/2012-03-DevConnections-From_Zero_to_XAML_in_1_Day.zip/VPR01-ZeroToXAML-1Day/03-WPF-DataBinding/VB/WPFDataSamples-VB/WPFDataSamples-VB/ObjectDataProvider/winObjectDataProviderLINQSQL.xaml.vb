﻿Partial Public Class winObjectDataProviderLINQSQL

End Class
