﻿Imports WPFComponents

Partial Public Class winDataBindingCollection

  Private Sub Window1_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles MyBase.Loaded
    Dim custs As New MyCustomers()

    lstData.DataContext = custs.GetCustomerList()
  End Sub
End Class
