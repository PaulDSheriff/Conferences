﻿Imports System.Data
Imports System.Data.SqlClient

Partial Public Class winDataBindingDataSet

  Private Sub Window1_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles MyBase.Loaded
    Dim ds As New DataSet()
    Dim da As SqlDataAdapter

    da = New SqlDataAdapter("SELECT * FROM SalesLT.Customer ORDER BY LastName", _
                             AppConfig.ConnectString)

    da.Fill(ds)

    ' You must bind to a DataTable, not a DataSet
    lstData.DataContext = ds.Tables(0)
  End Sub
End Class
