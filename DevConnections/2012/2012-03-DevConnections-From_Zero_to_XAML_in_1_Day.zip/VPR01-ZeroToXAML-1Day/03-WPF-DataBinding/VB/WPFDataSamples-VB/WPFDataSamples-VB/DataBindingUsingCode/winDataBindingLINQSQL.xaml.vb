﻿Imports WPFComponents

Partial Public Class winDataBindingLINQSQL
  Private Sub winDataBindingLINQSQL_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles MyBase.Loaded
    Dim dc As New AdvWorksDataContext()

    Dim items = From cust In dc.Customers _
                Order By cust.LastName _
                Select cust

    lstData.DataContext = items
  End Sub
End Class
