﻿Partial Public Class winComboToLabel

  Private Sub cboLanguage_SelectionChanged(ByVal sender As System.Object, ByVal e As System.Windows.Controls.SelectionChangedEventArgs) Handles cboLanguage.SelectionChanged
    lblFromCode.Content = CType(cboLanguage.SelectedItem, ComboBoxItem).Content
  End Sub
End Class
