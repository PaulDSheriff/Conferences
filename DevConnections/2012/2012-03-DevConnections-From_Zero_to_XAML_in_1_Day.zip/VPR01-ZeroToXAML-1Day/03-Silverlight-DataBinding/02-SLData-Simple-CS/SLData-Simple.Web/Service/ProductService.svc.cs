﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace SLData_Simple.Web.Service
{
  // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "ProductService" in code, svc and config file together.
  public class ProductService : IProductService
  {
    public Products GetProducts()
    {
      DataTable dt = new DataTable();
      Products ret = new Products();
      SqlDataAdapter da;

      da = new SqlDataAdapter(
       "SELECT ProductName FROM Product",
       "Server=Localhost;Database=Sandbox;Integrated Security=Yes");

      da.Fill(dt);

      foreach (DataRow dr in dt.Rows)
      {
        ret.Add(new Product(
           dr["ProductName"].ToString()));
      }

      return ret;
    }
  }
}
