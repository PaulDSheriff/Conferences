﻿using System.Collections.Generic;

namespace SilverlightData101
{
  public class Customers : List<Customer>
  {
  }
}
