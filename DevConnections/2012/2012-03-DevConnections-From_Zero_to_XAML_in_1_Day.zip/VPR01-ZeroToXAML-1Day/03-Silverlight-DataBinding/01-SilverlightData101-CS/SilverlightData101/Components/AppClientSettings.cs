﻿using System.Windows.Media;

namespace SilverlightData101
{
  public class AppClientSettings
  {
    public AppClientSettings()
    {
      BackgroundBrush = new SolidColorBrush();
      BackgroundBrush.Color = Colors.Red;
    }

    public SolidColorBrush BackgroundBrush { get; set; }
  }
}
