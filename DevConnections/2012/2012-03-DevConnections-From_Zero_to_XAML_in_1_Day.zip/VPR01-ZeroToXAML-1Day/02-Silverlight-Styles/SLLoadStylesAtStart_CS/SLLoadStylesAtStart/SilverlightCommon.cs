﻿using System;
using System.Windows.Controls;
using System.Windows;
// Need to add reference to System.Xml.Linq.dll
// This is needed for XDocument
using System.Xml.Linq;
// This is needed for the XamlReader
using System.Windows.Markup;
// Needed for Stream
using System.IO;
// Needed for WebClient
using System.Net;

namespace SLLoadStylesAtStart
{
  public class SilverlightCommon
  {
    public static string GetCurrentUri(Application app)
    {
      string path = string.Empty;

      path = app.Host.Source.AbsoluteUri;
      if (path.ToLower().IndexOf(@"/bin") > 0)
      {
        path = path.Substring(0, path.ToLower().LastIndexOf(@"/bin")) + "/"; 
      }

      return path;
    }

    public static string GetCurrentWebHost()
    {
      string path;

      // Using HtmlPage works even if you are a Class
      path = System.Windows.Browser.HtmlPage.Document.DocumentUri.ToString();
      path = path.Substring(0, path.LastIndexOf("/"));

      return path;
    }
  }
}
