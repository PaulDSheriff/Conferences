﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
// Need to add reference to System.Xml.Linq.dll
// This is needed for XDocument
using System.Xml.Linq;
// This is needed for the XamlReader
using System.Windows.Markup;
// Needed for Stream
using System.IO;
// Needed for WebClient
using System.Net;

namespace SLLoadStylesAtStart
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private void btnLogin_Click(object sender, RoutedEventArgs e)
    {
      switch (txtUserName.Text.Trim().ToLower())
      {
        case "paul":
          LoadResourceDictionaryFromWeb("Green.xaml");
          break;

        case "billy":
          LoadResourceDictionaryFromWeb("Blue.xaml");
          break;
          
        case "russ":
          LoadResourceDictionaryFromWeb("Red.xaml");
          break;
      }

      btnLogin.IsEnabled = false;
      tbMessage.Visibility = System.Windows.Visibility.Visible;    
    }
    
    private void LoadResourceDictionaryFromWeb(string resourceName)
    {
      WebClient client = new WebClient();

      client.OpenReadCompleted += new OpenReadCompletedEventHandler(client_OpenReadCompleted);
      client.OpenReadAsync(new Uri(SilverlightCommon.GetCurrentWebHost() + "/" + resourceName, UriKind.RelativeOrAbsolute));
    }

    private void client_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
    {
      ResourceDictionary rd = new ResourceDictionary();

      // Get result as a Stream
      Stream st = e.Result;
      // Load stream into an XDocument object
      XDocument xaml = XDocument.Load(st);
      // Turn the XAML in XDocument object into a Resource Dictionary
      rd = XamlReader.Load(xaml.ToString()) as ResourceDictionary;
      // Close Stream
      st.Close();

      // Can remove just single style
      //App.Current.Resources.Remove("Grid.BackgroundColor");
      // Or can remove all styles
      App.Current.Resources.Clear();

      // Add to Application Dictionaries
      App.Current.Resources.MergedDictionaries.Add(rd);

      // Now navigate to the new page
      this.Content = new Page2();
    }
  }
}
