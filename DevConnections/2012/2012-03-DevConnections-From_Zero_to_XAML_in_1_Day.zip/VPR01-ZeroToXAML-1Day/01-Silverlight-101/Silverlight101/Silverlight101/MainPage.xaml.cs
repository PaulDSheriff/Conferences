﻿using System.Windows;
using System.Windows.Controls;

namespace Silverlight101
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    #region Load User Control Method
    private void LoadUserControl(UserControl uc)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(uc);
    }
    #endregion

    #region Menus
    private void btnClear_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
    }

    private void btnSample1_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucSample1_AbsPosition());
    }

    private void btnSample2_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucSample2_Grid());
    }

    private void btnSample3_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucSample3_GridResizeMargin());
    }

    private void btnSample4_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucSample4_StackPanel());
    }

    private void btnSample5_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucSample5_Canvas());
    }

    private void btnMarginPadding_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucMarginPadding());
    }

    private void btnStyle1_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucStackPanelResource());
    }

    private void btnStyle2_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucWindowResource());
    }

    private void btnCheckBoxes_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucCheckBoxes());
    }

    private void btnDatePicker_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucDatePicker());
    }

    private void btnLine_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucLine());
    }

    private void btnRectangle_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucRectangle());
    }

    private void btnImage_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucImage());
    }

    private void btnMedia_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucMedia());
    }

    private void btnPasswordBox_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucPasswordBox());
    }

    private void btnRadioButtons_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucRadioButtons());
    }

    private void btnTextBlock_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucTextBlock());
    }

    private void btnComboBox_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucComboBoxes());
    }

    private void btnListBox_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucListBox());
    }

    private void btnBorder_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucBorder());
    }

    private void btnTabs_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucTab());
    }

    private void btnScrollViewer_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucScrollViewer());
    }

    private void btnBindControls_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucEnabled());
    }

    private void btnToClass_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucLocalData());
    }

    private void btnToParent_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucLocalDataParent());
    }

    private void btnToCollectionClass_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucLocalDataCollection());
    }

    private void btnBusinessForm_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucProductForm());
    }
    #endregion

  }
}
