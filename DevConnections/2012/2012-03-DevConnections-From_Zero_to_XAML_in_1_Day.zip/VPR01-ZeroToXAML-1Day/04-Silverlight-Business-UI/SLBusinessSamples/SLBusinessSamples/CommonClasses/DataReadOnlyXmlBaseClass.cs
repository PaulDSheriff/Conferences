﻿using System;
using System.IO;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Xml.Linq;

namespace Common.Library
{
	public enum XmlFileLocation
	{
		Unknown,
		Project,
		LocalStorage,
		Server
	}

	public class DataReadOnlyXmlBaseClass : CommonBase
	{
		#region Constructors
		public DataReadOnlyXmlBaseClass()
		{
			FileName = string.Empty;
			TopElementName = string.Empty;
			FullFileName = string.Empty;
			FileLocation = XmlFileLocation.Unknown;
		}

		/// <summary>
		/// Call this Constructor to use and XML file in local storage (Isolated, or User App Data Path)
		/// </summary>
		/// <param name="fileName">The XML File Name (no path)</param>
		public DataReadOnlyXmlBaseClass(string fileName)
		{
			FileName = fileName;
			FileLocation = XmlFileLocation.LocalStorage;
			BuildXmlFullFileName();
		}

		/// <summary>
		/// Call this constructor to use an XML file in your Project (.exe) folder
		/// </summary>
		/// <param name="folderName">Optional folder name</param>
		/// <param name="fileName">The XML File Name (no path)</param>
		public DataReadOnlyXmlBaseClass(string folderName, string fileName)
		{
			FileName = fileName;
			FolderName = folderName;
			FileLocation = XmlFileLocation.Project;
			BuildXmlFullFileName();
		}
		#endregion

		#region Private Properties
		private XmlFileLocation _FileLocation = XmlFileLocation.Unknown;
		#endregion

		#region Public Properties
		public string FileName { get; set; }
		public string FolderName { get; set; }
		public string TopElementName { get; set; }
		public string FullFileName { get; set; }

		public XmlFileLocation FileLocation
		{
			get { return _FileLocation; }
			set
			{
				_FileLocation = value;
				BuildXmlFullFileName();
			}
		}
		#endregion

		#region XmlObject Property (XElement object)
		private XElement _XmlObject = null;

		public XElement XmlObject
		{
			get { return _XmlObject; }
			set
			{
				_XmlObject = value;
				RaisePropertyChanged("XmlObject");
			}
		}
		#endregion

		#region BuildXmlFullFileName Method
		public virtual void BuildXmlFullFileName()
		{
			switch (FileLocation)
			{
				case XmlFileLocation.Project:
#if SILVERLIGHT
					// Use Local XML File in Project
					FullFileName = FolderName + @"/" + FileName;
#else
					// Use Local XML File in Project
    			FullFileName = FileCommon.GetCurrentDirectory() + @"\" +
		          					 FolderName + @"\" + FileName;
#endif
					break;
				case XmlFileLocation.LocalStorage:
#if SILVERLIGHT
					// Use Isolated Storage
					FullFileName = FileName;
#else
					// Use User' Local Storage Area
    			FullFileName = FileCommon.GetUserAppDataPath() + @"\" + FileName;
#endif
					break;
			}
		}
		#endregion

		#region DoesLocalDataExist Method
		public virtual bool DoesLocalDataExist()
		{
			bool ret = false;

#if SILVERLIGHT
			try
			{
				// Always get from Isolated Storage if exists
				ret = IsolatedStorageSettings.ApplicationSettings.Contains(FileName);
			}
			catch
			{
				// Ignore exception
			}
			if (!ret)
			{
				try
				{
					// Get from Project if Isolated Storage is not there
					XmlObject = XElement.Load(FullFileName);
					ret = true;
				}
				catch
				{
					// Ignore exception and get data from server
				}
			}
#else
			// Get from User's Data Storage if exists
			ret = File.Exists(FullFileName);
#endif

			return ret;
		}
		#endregion

		#region LoadAll Method
		public void LoadAll()
		{
#if SILVERLIGHT
			try
			{
				// Always get from Isolated Storage if exists
				if (IsolatedStorageSettings.ApplicationSettings.Contains(FileName))
				{
					XmlObject = XElement.Parse(IsolatedStorageSettings.ApplicationSettings[FileName].ToString());
					BuildDataCollection();
				}
			}
			catch
			{
				// Ignore exception
			}
			if (FileLocation == XmlFileLocation.Project)
			{
				try
				{
					XmlObject = XElement.Load(FullFileName);
					BuildDataCollection();
				}
				catch
				{
					// Ignore exception
				}
			}
#else
			if (File.Exists(FullFileName))
			{
				XmlObject = XElement.Load(FullFileName);
			  BuildDataCollection();
			}
#endif

			// If data is not available locally
			// Get Data from WCF Service
			if (XmlObject == null)
				GetDataFromService();
		}

		public virtual void GetDataFromService()
		{
		}
		#endregion

		#region BuildDataCollection Method
		public virtual void BuildDataCollection()
		{
		}
		#endregion

		#region GetValue Method
		public object GetValue(XAttribute attr, object defaultValue)
		{
			if (attr == null)
				return defaultValue;
			else
				if (string.IsNullOrEmpty(attr.Value))
					return defaultValue;
				else
					return attr.Value;
		}

		public object GetValue(XElement elem, object defaultValue)
		{
			if (elem == null)
				return defaultValue;
			else
				if (string.IsNullOrEmpty(elem.Value))
					return defaultValue;
				else
					return elem.Value;
		}
		#endregion
	}
}