﻿using System.Windows;
using System.Windows.Controls;

namespace SLBusinessSamples
{
	public partial class ucAddress : UserControl
	{
		AddressViewModel _ViewModel;

		public AddressViewModel ViewModel
		{
			get { return _ViewModel; }
			set { _ViewModel = value; }
		}

		public ucAddress()
		{
			InitializeComponent();

			_ViewModel = (AddressViewModel)this.Resources["viewModel"];
		}

		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			// Load all countries/states/provinces
			_ViewModel.LoadAll();
			// Initialize Country/State/Province
			_ViewModel.Init();
			//_ViewModel.Init("Canada", "Alberta");
		}
	}
}
