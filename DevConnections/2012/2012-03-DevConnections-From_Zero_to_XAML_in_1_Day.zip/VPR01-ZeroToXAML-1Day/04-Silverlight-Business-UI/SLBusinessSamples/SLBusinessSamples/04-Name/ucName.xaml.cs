﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SLBusinessSamples
{
  public partial class ucName : UserControl
  {
    NameViewModel _ViewModel;

    public NameViewModel ViewModel
    {
      get { return _ViewModel; }
      set { _ViewModel = value; }
    }

    public ucName()
    {
      InitializeComponent();

      _ViewModel = (NameViewModel)this.Resources["viewModel"];
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      // Load all Salutations/Suffixes
      _ViewModel.LoadAll();
    }
  }
}
