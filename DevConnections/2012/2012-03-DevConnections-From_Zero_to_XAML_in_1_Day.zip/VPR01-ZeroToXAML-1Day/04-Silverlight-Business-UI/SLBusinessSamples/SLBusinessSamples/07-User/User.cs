﻿
using Common.Library;

namespace SLBusinessSamples
{
  public class User : CommonBase 
  {
    #region Private Variables
    private string _FirstName = string.Empty;
    private string _LastName = string.Empty;
    private string _LoginID = string.Empty;
    private string _EmailAddress = string.Empty;
    private string _EmailAddressReenter = string.Empty;
    private string _Password = string.Empty;
    private string _PasswordReenter = string.Empty;
    private string _SecurityQuestion = string.Empty;
    private string _SecurityAnswer = string.Empty;
    #endregion

    #region Public Properties
    public string FirstName
    {
      get { return _FirstName; }
      set
      {
        if (_FirstName != value)
        {
          _FirstName = value;
          RaisePropertyChanged("FirstName");
        }
      }
    }

    public string LastName
    {
      get { return _LastName; }
      set
      {
        if (_LastName != value)
        {
          _LastName = value;
          RaisePropertyChanged("LastName");
        }
      }
    }

    public string LoginID
    {
      get { return _LoginID; }
      set
      {
        if (_LoginID != value)
        {
          _LoginID = value;
          RaisePropertyChanged("LoginID");
        }
      }
    }

    public string EmailAddress
    {
      get { return _EmailAddress; }
      set
      {
        if (_EmailAddress != value)
        {
          _EmailAddress = value;
          RaisePropertyChanged("EmailAddress");
        }
      }
    }

    public string EmailAddressReenter
    {
      get { return _EmailAddressReenter; }
      set
      {
        if (_EmailAddressReenter != value)
        {
          _EmailAddressReenter = value;
          RaisePropertyChanged("EmailAddressReenter");
        }
      }
    }

    public string Password
    {
      get { return _Password; }
      set
      {
        if (_Password != value)
        {
          _Password = value;
          RaisePropertyChanged("Password");
        }
      }
    }

    public string PasswordReenter
    {
      get { return _PasswordReenter; }
      set
      {
        if (_PasswordReenter != value)
        {
          _PasswordReenter = value;
          RaisePropertyChanged("PasswordReenter");
        }
      }
    }

    public string SecurityQuestion
    {
      get { return _SecurityQuestion; }
      set
      {
        if (_SecurityQuestion != value)
        {
          _SecurityQuestion = value;
          RaisePropertyChanged("SecurityQuestion");
        }
      }
    }

    public string SecurityAnswer
    {
      get { return _SecurityAnswer; }
      set
      {
        if (_SecurityAnswer != value)
        {
          _SecurityAnswer = value;
          RaisePropertyChanged("SecurityAnswer");
        }
      }
    }
    #endregion
  }
}
