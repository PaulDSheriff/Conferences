﻿using System.Collections.ObjectModel;

using Common.Library;

namespace SLBusinessSamples
{
  public class UserViewModel : CommonBase
  {
    #region Private Variables
    private ObservableCollection<SecurityQuestion> _Questions = new ObservableCollection<SecurityQuestion>();
    private User _UserObject = new User();

    private bool _IsCreateMode = false;
    private bool _IsLoginIdEnabled = true;
    private bool _IsReenterEmailAddressVisible = true;
    private bool _IsReenterPasswordVisible = true;
    private string _UserButtonText = "Create User";
    #endregion

    #region Public Properties
    public ObservableCollection<SecurityQuestion> Questions
    {
      get { return _Questions; }
      set
      {
        _Questions = value;
        RaisePropertyChanged("Questions");
      }
    }

    public User UserObject
    {
      get { return _UserObject; }
      set
      {
        _UserObject = value;
        RaisePropertyChanged("UserObject");
      }
    }

    public bool IsCreateMode
    {
      get { return _IsCreateMode; }
      set
      {
        _IsCreateMode = value;
        IsLoginIdEnabled = value;
        IsReenterEmailAddressVisible = value;
        IsReenterPasswordVisible = value;

        if (value)
          UserButtonText = "Create User";
        else
          UserButtonText = "Update User";

        RaisePropertyChanged("IsCreateMode");
      }
    }

    public bool IsLoginIdEnabled
    {
      get { return _IsLoginIdEnabled; }
      set
      {
        if (_IsLoginIdEnabled != value)
        {
          _IsLoginIdEnabled = value;
          RaisePropertyChanged("IsLoginIdEnabled");
        }
      }
    }

    public bool IsReenterEmailAddressVisible
    {
      get { return _IsReenterEmailAddressVisible; }
      set
      {
        if (_IsReenterEmailAddressVisible != value)
        {
          _IsReenterEmailAddressVisible = value;
          RaisePropertyChanged("IsReenterEmailAddressVisible");
        }
      }
    }

    public bool IsReenterPasswordVisible
    {
      get { return _IsReenterPasswordVisible; }
      set
      {
        if (_IsReenterPasswordVisible != value)
        {
          _IsReenterPasswordVisible = value;
          RaisePropertyChanged("IsReenterPasswordVisible");
        }
      }
    }

    public string UserButtonText
    {
      get { return _UserButtonText; }
      set
      {
        if (_UserButtonText != value)
        {
          _UserButtonText = value;
          RaisePropertyChanged("UserButtonText");
        }
      }
    }
    #endregion

    #region LoadAll Method
    public void LoadAll()
    {
      QuestionsLoad();
    }
    #endregion

    #region Load Validation Tables Methods
    private void QuestionsLoad()
    {
      SecurityQuestionManager mgr = new SecurityQuestionManager();

      mgr.LoadAll();

      Questions = new ObservableCollection<SecurityQuestion>(mgr.DataCollection);
    }
    #endregion
  }
}
