﻿using System.Windows;
using System.Windows.Controls;

namespace SLBusinessSamples
{
  public partial class ucUser : UserControl
  {
    public ucUser()
    {
      InitializeComponent();

      _ViewModel = (UserViewModel)this.Resources["viewModel"];
    }

    UserViewModel _ViewModel;

    public UserViewModel ViewModel
    {
      get { return _ViewModel; }
      set { _ViewModel = value; }
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      _ViewModel.LoadAll();
    }

    #region Events
    public delegate void UserAddedEventHandler(object sender, UserProfileEventArgs e);
    public event UserAddedEventHandler UserAdded;
    public delegate void UserEditedEventHandler(object sender, UserProfileEventArgs e);
    public event UserEditedEventHandler UserEdited;
    public delegate void CancelledEventHandler(object sender, UserProfileEventArgs e);
    public event CancelledEventHandler Cancelled;

    public void RaiseUserAdded(UserProfileEventArgs args)
    {
      if (UserAdded != null)
        UserAdded(this, args);
    }

    public void RaiseUserEdited(UserProfileEventArgs args)
    {
      if (UserEdited != null)
        UserEdited(this, args);
    }
    
    public void RaiseCancelled(UserProfileEventArgs args)
    {
      if (Cancelled != null)
        Cancelled(this, args);
    }
    #endregion

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      RaiseCancelled(new UserProfileEventArgs());
    }

    private void btnCreate_Click(object sender, RoutedEventArgs e)
    {
      UserProfileEventArgs args = new UserProfileEventArgs();

      args.UserObject = _ViewModel.UserObject;
      if (_ViewModel.IsCreateMode)
        RaiseUserAdded(args);
      else
        RaiseUserEdited(args);
    }
  }
}
