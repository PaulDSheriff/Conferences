﻿using System.Collections.Generic;
using Common.Library;

namespace SLBusinessSamples
{
  public class PersonName : CommonBase
  {
    #region Private Variables
    private string _Salutation = string.Empty;
    private string _Suffix = string.Empty;
    private string _FirstName = string.Empty;
    private string _LastName = string.Empty;
    private string _MiddleName = string.Empty;
    private string _EmailAddress = string.Empty;
    private string _HomePhone = string.Empty;
    private string _CellPhone = string.Empty;
    #endregion

    #region Public Properties
    public string Salutation
    {
      get { return _Salutation; }
      set
      {
        if (_Salutation != value)
        {
          _Salutation = value;
          RaisePropertyChanged("Salutation");
        }
      }
    }

    public string Suffix
    {
      get { return _Suffix; }
      set
      {
        if (_Suffix != value)
        {
          _Suffix = value;
          RaisePropertyChanged("Suffix");
        }
      }
    }

    public string FirstName
    {
      get { return _FirstName; }
      set
      {
        if (_FirstName != value)
        {
          _FirstName = value;
          RaisePropertyChanged("FirstName");
        }
      }
    }

    public string LastName
    {
      get { return _LastName; }
      set
      {
        if (_LastName != value)
        {
          _LastName = value;
          RaisePropertyChanged("LastName");
        }
      }
    }

    public string MiddleName
    {
      get { return _MiddleName; }
      set
      {
        if (_MiddleName != value)
        {
          _MiddleName = value;
          RaisePropertyChanged("MiddleName");
        }
      }
    }

    public string EmailAddress
    {
      get { return _EmailAddress; }
      set
      {
        if (_EmailAddress != value)
        {
          _EmailAddress = value;
          RaisePropertyChanged("EmailAddress");
        }
      }
    }

    public string HomePhone
    {
      get { return _HomePhone; }
      set
      {
        if (_HomePhone != value)
        {
          _HomePhone = value;
          RaisePropertyChanged("HomePhone");
        }
      }
    }
    
    public string CellPhone
    {
      get { return _CellPhone; }
      set
      {
        if (_CellPhone != value)
        {
          _CellPhone = value;
          RaisePropertyChanged("CellPhone");
        }
      }
    }
    #endregion
  }
}