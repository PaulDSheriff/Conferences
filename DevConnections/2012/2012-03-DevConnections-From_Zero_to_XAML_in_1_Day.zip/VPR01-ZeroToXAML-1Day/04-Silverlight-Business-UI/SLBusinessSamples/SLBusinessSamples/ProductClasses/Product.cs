﻿using System;
using Common.Library;

namespace SLBusinessSamples
{
  public class Product : CommonBase
  {
    #region Private Variables
    private string _ProductName;
    private int _ProductId;
    private DateTime _IntroductionDate;
    private decimal _Price;
    #endregion

    #region Public Properties
    public string ProductName
    {
      get { return _ProductName; }
      set
      {
        if (_ProductName != value)
        {
          _ProductName = value;
          RaisePropertyChanged("ProductName");
        }
      }
    }

    public int ProductId
    {
      get { return _ProductId; }
      set
      {
        if (_ProductId != value)
        {
          _ProductId = value;
          RaisePropertyChanged("ProductId");
        }
      }
    }

    public DateTime IntroductionDate
    {
      get { return _IntroductionDate; }
      set
      {
        if (_IntroductionDate != value)
        {
          _IntroductionDate = value;
          RaisePropertyChanged("IntroductionDate");
        }
      }
    }

    public decimal Price
    {
      get { return _Price; }
      set
      {
        if (_Price != value)
        {
          _Price = value;
          RaisePropertyChanged("Price");
        }
      }
    }
    #endregion
  }
}
