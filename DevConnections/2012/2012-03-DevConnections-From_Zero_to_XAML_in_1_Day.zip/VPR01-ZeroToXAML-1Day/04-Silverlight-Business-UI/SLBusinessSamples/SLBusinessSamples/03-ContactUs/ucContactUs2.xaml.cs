﻿using System.Windows.Controls;

namespace SLBusinessSamples
{
  public partial class ucContactUs2 : UserControl
  {
    public ucContactUs2()
    {
      InitializeComponent();
    }
  }
}
