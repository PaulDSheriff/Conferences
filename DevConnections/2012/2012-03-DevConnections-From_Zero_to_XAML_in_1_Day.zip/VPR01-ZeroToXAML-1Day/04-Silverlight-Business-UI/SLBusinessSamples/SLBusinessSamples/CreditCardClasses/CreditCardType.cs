﻿using System.Collections.Generic;

using Common.Library;

namespace SLBusinessSamples
{
	public class CreditCardTypes : List<CreditCardType>
	{
	}

	public class CreditCardType : CommonBase
	{
		#region Private Variables
		private string _Name;
		#endregion

		#region Public Properties
		public string Name
		{
			get { return _Name; }
			set
			{
				if (_Name != value)
				{
					_Name = value;
					RaisePropertyChanged("Name");
				}
			}
		}
		#endregion
	}
}
