﻿using System;
using System.Collections.Generic;
using Common.Library;

namespace SLBusinessSamples
{
	public class CreditCardYears : List<CreditCardYear>
	{
		public List<CreditCardYear> GetYears()
		{
			return GetYears(12);
		}

		public List<CreditCardYear> GetYears(int yearsInFuture)
		{
			List<CreditCardYear> ret = new List<CreditCardYear>();
			int index = 0;

			for (index = DateTime.Now.Year; index <= (DateTime.Now.Year + yearsInFuture); index++)
			{
				ret.Add(new CreditCardYear(index.ToString()));
			}

			return ret;
		}
	}

	public class CreditCardYear : CommonBase
	{
		public CreditCardYear()
		{ 
		}

		public CreditCardYear(string year)
		{
			Year = year;
		}

		private string _Year;

		public string Year
		{
			get { return _Year; }
			set
			{
				if (_Year != value)
				{
					_Year = value;
					RaisePropertyChanged("Year");
				}
			}
		}
	}
}
