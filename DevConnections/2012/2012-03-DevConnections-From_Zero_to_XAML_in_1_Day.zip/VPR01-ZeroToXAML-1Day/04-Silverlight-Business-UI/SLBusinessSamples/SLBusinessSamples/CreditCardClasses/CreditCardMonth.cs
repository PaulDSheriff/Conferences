﻿using System.Collections.Generic;
using System.Globalization;
using Common.Library;

namespace SLBusinessSamples
{
	public class CreditCardMonths : List<CreditCardMonth>
	{
		public List<CreditCardMonth> GetMonths()
		{
			List<CreditCardMonth> ret = new List<CreditCardMonth>();
			int index = 0;
			DateTimeFormatInfo dtfi = new DateTimeFormatInfo();
			string[] MonthNames = null;
			// Get Month Names based on Culture;
			MonthNames = dtfi.MonthNames;

			for (index = 1; index <= 12; index++)
			{
				ret.Add(new CreditCardMonth(MonthNames[index - 1], index));
			}

			return ret;
		}

		public string GetMonthName(int monthNumber)
		{
			DateTimeFormatInfo dtfi = new DateTimeFormatInfo();
			string[] MonthNames = null;
			// Get Month Names based on Culture;
			MonthNames = dtfi.MonthNames;

			if (monthNumber > 0 && monthNumber < 12)
				return MonthNames[monthNumber - 1];
			else
				return "January";
		}
	}

	public class CreditCardMonth : CommonBase
	{
		public CreditCardMonth()
		{
		}

		public CreditCardMonth(string monthName, int monthNumber)
		{
			Month = monthName;
			MonthNumber = monthNumber;
		}

		private string _Month;
		private int _MonthNumber;

		public string Month
		{
			get { return _Month; }
			set
			{
				if (_Month != value)
				{
					_Month = value;
					RaisePropertyChanged("Month");
				}
			}
		}

		public int MonthNumber
		{
			get { return _MonthNumber; }
			set
			{
				if (_MonthNumber != value)
				{
					_MonthNumber = value;
					RaisePropertyChanged("MonthNumber");
				}
			}
		}
	}
}
