﻿using System.Windows;
using System.Windows.Controls;

namespace SLBusinessSamples
{
   public partial class ucLicenseButton : UserControl
   {
      public ucLicenseButton()
      {
         InitializeComponent();
      }

      #region ButtonText Property
      public string ButtonText
      {
         get { return (string)GetValue(ButtonTextProperty); }
         set { SetValue(ButtonTextProperty, value); }
      }

      // Using a DependencyProperty as the backing store for ButtonText.  This enables animation, styling, binding, etc...
      public static readonly DependencyProperty ButtonTextProperty =
          DependencyProperty.Register("ButtonText", typeof(string), typeof(ucLicenseButton), null);
      #endregion

      #region ButtonLongText Property
      public string ButtonLongText
      {
         get { return (string)GetValue(ButtonLongTextProperty); }
         set { SetValue(ButtonLongTextProperty, value); }
      }

      // Using a DependencyProperty as the backing store for ButtonText.  This enables animation, styling, binding, etc...
      public static readonly DependencyProperty ButtonLongTextProperty =
          DependencyProperty.Register("ButtonLongText", typeof(string), typeof(ucLicenseButton), null);
      #endregion
   }
}
