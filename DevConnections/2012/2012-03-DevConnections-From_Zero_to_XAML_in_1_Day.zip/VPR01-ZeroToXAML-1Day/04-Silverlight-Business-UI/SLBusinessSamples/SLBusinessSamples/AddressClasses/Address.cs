using System.Collections.Generic;
using Common.Library;

namespace SLBusinessSamples
{
  #region Country Address Type Enumeration
  /// <summary>
  /// An address type enumeration
  /// </summary>
  public enum AddressType : int
  {
    /// <summary>
    /// United States Address
    /// </summary>
    US,
    /// <summary>
    /// Canadian Address
    /// </summary>
    Canadian,
    /// <summary>
    /// United Kingdom Address
    /// </summary>
    UK,
    /// <summary>
    /// Other Address
    /// </summary>
    Other
  }
  #endregion
  
  /// <summary>
  /// A collection of Address Classes
  /// </summary>
	public class Addresses : List<Address>
	{
	}

  /// <summary>
  /// A class to hold Address information
  /// </summary>
  public class Address : CommonBase
	{
		#region Private Variables
		private AddressType _AddressType = AddressType.US;
		private string _Street1 = string.Empty;
		private string _Street2 = string.Empty;
		private string _Street3 = string.Empty;
		private string _City = string.Empty;
		private string _StateCode = string.Empty;
		private string _CountryName = string.Empty;
		private string _PostalCode = string.Empty;
		private string _PostalCodeExt = string.Empty;
		#endregion

		#region Public Properties
    /// <summary>
    /// Get/Set the Address Type
    /// </summary>
		public AddressType AddressType
		{
			get { return _AddressType; }
			set
			{
				if (_AddressType != value)
				{
					_AddressType = value;
					RaisePropertyChanged("AddressType");
				}
			}
		}

    /// <summary>
    /// Get/Set the Street 1 of the Address
    /// </summary>
		public string Street1
		{
			get { return _Street1; }
			set
			{
				if (_Street1 != value)
				{
					_Street1 = value;
          RaisePropertyChanged("Street1");
				}
			}
		}

    /// <summary>
    /// Get/Set the Street 2 of the Address
    /// </summary>
    public string Street2
		{
			get { return _Street2; }
			set
			{
				if (_Street2 != value)
				{
					_Street2 = value;
          RaisePropertyChanged("Street2");
				}
			}
		}

    /// <summary>
    /// Get/Set the Street 3 of the Address (if applicable)
    /// </summary>
    public string Street3
		{
			get { return _Street3; }
			set
			{
				if (_Street3 != value)
				{
					_Street3 = value;
          RaisePropertyChanged("Street3");
				}
			}
		}

    /// <summary>
    /// Get/Set the City of the Address
    /// </summary>
    public string City
		{
			get { return _City; }
			set
			{
				if (_City != value)
				{
					_City = value;
					RaisePropertyChanged("City");
				}
			}
		}

    /// <summary>
    /// Get/Set the US State Code of the Address (if applicable)
    /// </summary>
    public string StateCode
		{
			get { return _StateCode; }
			set
			{
				if (_StateCode != value)
				{
					_StateCode = value;
					RaisePropertyChanged("StateCode");
				}
			}
		}

    /// <summary>
    /// Get/Set the Country Name of the Address
    /// </summary>
		public string CountryName
		{
			get { return _CountryName; }
			set
			{
				if (_CountryName != value)
				{
					_CountryName = value;
					ChangeAddressType();
					RaisePropertyChanged("CountryName");
				}
			}
		}

    /// <summary>
    /// Get/Set the Postal Code of the Address
    /// </summary>
		public string PostalCode
		{
			get { return _PostalCode; }
			set
			{
				if (_PostalCode != value)
				{
					_PostalCode = value;
					RaisePropertyChanged("PostalCode");
				}
			}
		}

    /// <summary>
    /// Get/Set the Postal Code Extension of the Address (if applicable)
    /// </summary>
		public string PostalCodeExt
		{
			get { return _PostalCodeExt; }
			set
			{
				if (_PostalCodeExt != value)
				{
					_PostalCodeExt = value;
					RaisePropertyChanged("PostalCodeExt");
				}
			}
		}
		#endregion

		#region ChangeAddressType Method
    /// <summary>
    /// Change the address type based on a change to the CountryName
    /// </summary>
		protected virtual void ChangeAddressType()
		{
			if (CountryName != null)
			{
				switch (CountryName.ToLower())
				{
					case "united states":
						AddressType = AddressType.US;
						break;

					case "canada":
						AddressType = AddressType.Canadian;
						break;

					case "united kingdom":
						AddressType = AddressType.UK;
						break;

					default:
						AddressType = AddressType.Other;
						break;
				}
			}
		}
		#endregion
	}
}