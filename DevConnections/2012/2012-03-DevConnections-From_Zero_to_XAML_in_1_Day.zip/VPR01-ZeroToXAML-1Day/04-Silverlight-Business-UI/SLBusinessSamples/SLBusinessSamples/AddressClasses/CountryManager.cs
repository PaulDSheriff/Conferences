﻿using System;
using System.Collections.Generic;
using System.Linq;

using Common.Library;

namespace SLBusinessSamples
{
	public class CountryManager : DataReadOnlyXmlBaseClass
	{
		public const string FILE_NAME = "Countries.xml";
		public const string FOLDER_NAME = "Xml";
		public const string TOP_ELEMENT_NAME = "Country";

		#region Constructors
		public CountryManager()
		{
			FileName = FILE_NAME;
			FolderName = FOLDER_NAME;
			FileLocation = XmlFileLocation.Project;
			TopElementName = TOP_ELEMENT_NAME;

			// Build the full path and file name to the XML file in the Project
			BuildXmlFullFileName();
		}

		/// <summary>
		/// Call this constructor to use an XML file in your Project (.exe) folder
		/// </summary>
		/// <param name="folderName">Optional folder name</param>
		/// <param name="fileName">The XML File Name (no path)</param>
		public CountryManager(string folderName, string fileName)
		{
			FileName = fileName;
			FolderName = folderName;
			TopElementName = TOP_ELEMENT_NAME;
			FileLocation = XmlFileLocation.Project;
			BuildXmlFullFileName();
		}
		#endregion

		#region DataCollection Property
		private List<Country> _DataCollection = new List<Country>();

		public List<Country> DataCollection
		{
			get { return _DataCollection; }
			set
			{
				_DataCollection = value;
				RaisePropertyChanged("DataCollection");
			}
		}
		#endregion

		#region BuildDataCollection Method
		public override void BuildDataCollection()
		{
			if (XmlObject != null)
			{
				// Fill a list of Country objects
				var coll = from elem in XmlObject.Descendants(TopElementName)
									 select new Country
									 {
										 CountryCode = Convert.ToString(GetValue(elem.Element("CountryCode"), default(string))),
										 CountryName = Convert.ToString(GetValue(elem.Element("CountryName"), default(string))),
										 ISONumber = Convert.ToString(GetValue(elem.Element("ISONumber"), default(string))),
										 TwoLetterAbbreviation = Convert.ToString(GetValue(elem.Element("TwoLetterAbbreviation"), default(string)))
									 };

				// Assign to public property
				DataCollection = coll.ToList();
			}
		}
		#endregion
	}
}
