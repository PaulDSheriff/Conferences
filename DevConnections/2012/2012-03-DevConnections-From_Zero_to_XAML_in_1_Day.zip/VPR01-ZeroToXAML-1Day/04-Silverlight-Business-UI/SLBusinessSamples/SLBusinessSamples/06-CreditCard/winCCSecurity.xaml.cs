﻿using System.Windows;
using System.Windows.Controls;

namespace SLBusinessSamples
{
  public partial class winCCSecurity : ChildWindow
  {
    public winCCSecurity()
    {
      InitializeComponent();
    }

    private void btnOK_Click(object sender, RoutedEventArgs e)
    {
      this.DialogResult = true;
    }
  }
}

