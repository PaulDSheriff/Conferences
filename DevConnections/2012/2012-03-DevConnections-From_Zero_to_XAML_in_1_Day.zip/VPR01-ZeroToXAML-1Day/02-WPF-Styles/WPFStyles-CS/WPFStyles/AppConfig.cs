﻿using System.Configuration;

namespace WPFStyles
{
  public class AppConfig
  {
    protected static string GetSetting(string key)
    {
      return ConfigurationManager.AppSettings[key];
    }

    public static string ResourceFile
    {
      get { return GetSetting("ResourceFile"); }
    }
  }
}
