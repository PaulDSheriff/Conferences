﻿using System.Collections.Generic;
using Common.Library;

namespace WPFBusinessSamples
{
  public class SecurityQuestions : List<SecurityQuestion>
  {
  }

  public class SecurityQuestion : CommonBase
  {
    #region Private Variables
    private string _Description = string.Empty;
    #endregion

    #region Public Properties
    public string Description
    {
      get { return _Description; }
      set
      {
        if (_Description != value)
        {
          _Description = value;
          RaisePropertyChanged("Description");
        }
      }
    }
    #endregion
  }
}