﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFBusinessSamples
{
  public partial class ucUserHost : UserControl
  {
    public ucUserHost()
    {
      InitializeComponent();
    }

    private void btnAddUser_Click(object sender, RoutedEventArgs e)
    {
      userControl.ViewModel.IsCreateMode = true;
    }

    private void btnEditUser_Click(object sender, RoutedEventArgs e)
    {
      userControl.ViewModel.IsCreateMode = false;
    }

    private void userControl_UserAdded(object sender, UserProfileEventArgs e)
    {
      MessageBox.Show("User Added: " + e.UserObject.LastName);
    }

    private void userControl_UserEdited(object sender, UserProfileEventArgs e)
    {
      MessageBox.Show("User Edited: " + e.UserObject.LastName);
    }

    private void userControl_Cancelled(object sender, UserProfileEventArgs e)
    {
      MessageBox.Show("User Add/Edit Cancelled");
    }
  }
}
