﻿using System;

namespace WPFBusinessSamples
{
  public class UserProfileEventArgs : EventArgs
  {
    public UserProfileEventArgs()
    {
      UserObject = null;
    }

    public UserProfileEventArgs(User userObject)
    {
      UserObject = userObject;
    }

    public User UserObject { get; set; }
  }
}
