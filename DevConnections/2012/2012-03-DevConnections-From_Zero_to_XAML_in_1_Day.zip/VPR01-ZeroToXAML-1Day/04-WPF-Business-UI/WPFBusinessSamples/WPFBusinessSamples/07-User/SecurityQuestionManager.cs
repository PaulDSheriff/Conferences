﻿using System;
using System.Collections.Generic;
using System.Linq;

using Common.Library;

namespace WPFBusinessSamples
{
  public class SecurityQuestionManager : DataReadOnlyXmlBaseClass
  {
    public const string FILE_NAME = "SecurityQuestions.xml";
    public const string FOLDER_NAME = "Xml";
    public const string TOP_ELEMENT_NAME = "Question";

    #region Constructors
    public SecurityQuestionManager()
    {
      FileName = FILE_NAME;
      FolderName = FOLDER_NAME;
      FileLocation = XmlFileLocation.Project;
      TopElementName = TOP_ELEMENT_NAME;

      // Build the full path and file name to the XML file in the Project
      BuildXmlFullFileName();
    }

    /// <summary>
    /// Call this constructor to use an XML file in your Project (.exe) folder
    /// </summary>
    /// <param name="folderName">Optional folder name</param>
    /// <param name="fileName">The XML File Name (no path)</param>
    public SecurityQuestionManager(string folderName, string fileName)
    {
      FileName = fileName;
      FolderName = folderName;
      TopElementName = TOP_ELEMENT_NAME;
      FileLocation = XmlFileLocation.Project;
      BuildXmlFullFileName();
    }
    #endregion

    #region DataCollection Property
    private List<SecurityQuestion> _DataCollection = new List<SecurityQuestion>();

    public List<SecurityQuestion> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region BuildDataCollection Method
    public override void BuildDataCollection()
    {
      if (XmlObject != null)
      {
        // Fill a list of SecurityQuestion objects
        var coll = from elem in XmlObject.Descendants(TopElementName)
                   select new SecurityQuestion
                   {
                     Description = Convert.ToString(GetValue(elem.Element("Desc"), default(string)))
                   };

        // Assign to public property
        DataCollection = coll.ToList();
      }
    }
    #endregion
  }
}
