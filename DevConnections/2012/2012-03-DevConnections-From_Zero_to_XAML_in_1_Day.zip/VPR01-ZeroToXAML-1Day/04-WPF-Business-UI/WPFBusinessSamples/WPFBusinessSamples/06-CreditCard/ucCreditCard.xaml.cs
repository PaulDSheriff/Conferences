﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFBusinessSamples
{
  public partial class ucCreditCard : UserControl
  {
    CreditCardViewModel _ViewModel;

    public CreditCardViewModel ViewModel
    {
      get { return _ViewModel; }
      set { _ViewModel = value; }
    }

    public ucCreditCard()
    {
      InitializeComponent();

      _ViewModel = (CreditCardViewModel)this.Resources["viewModel"];
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      // Initialize CC Info
      _ViewModel.Init();
    }

    private void Image_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
      winCCSecurity win = new winCCSecurity();

      win.Show();
    }
  }
}