﻿using System.Collections.ObjectModel;

using Common.Library;

namespace WPFBusinessSamples
{
	public class NameViewModel : CommonBase
	{
		#region Private Variables
		private ObservableCollection<NamePrefix> _Salutations = new ObservableCollection<NamePrefix>();
		private ObservableCollection<NameSuffix> _Suffixes = new ObservableCollection<NameSuffix>();
		private PersonName _NameObject = new PersonName();
		#endregion

		#region Public Properties
    public ObservableCollection<NamePrefix> Salutations
		{
      get { return _Salutations; }
			set
			{
        _Salutations = value;
        RaisePropertyChanged("Salutations");
			}
		}

    public ObservableCollection<NameSuffix> Suffixes
		{
      get { return _Suffixes; }
			set
			{
        _Suffixes = value;
        RaisePropertyChanged("Suffixes");
			}
		}

		public PersonName NameObject
		{
			get { return _NameObject; }
			set
			{
				_NameObject = value;
				RaisePropertyChanged("NameObject");
			}
		}
		#endregion

		#region LoadAll Method
		public void LoadAll()
		{
      PrefixesLoad();
      SuffixesLoad();
		}
		#endregion

		#region Load Validation Tables Methods
		private void PrefixesLoad()
		{
      NamePrefixManager mgr = new NamePrefixManager();

      mgr.LoadAll();

      Salutations = new ObservableCollection<NamePrefix>(mgr.DataCollection);
    }

		private void SuffixesLoad()
		{
      NameSuffixManager mgr = new NameSuffixManager();

      mgr.LoadAll();

      Suffixes = new ObservableCollection<NameSuffix>(mgr.DataCollection);	
		}
		#endregion
	}
}
