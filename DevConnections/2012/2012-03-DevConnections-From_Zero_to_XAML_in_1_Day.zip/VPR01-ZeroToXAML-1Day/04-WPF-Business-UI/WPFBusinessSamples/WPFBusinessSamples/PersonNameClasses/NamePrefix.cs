﻿using System.Collections.Generic;
using Common.Library;

namespace WPFBusinessSamples
{
  public class NamePrefixes : List<NamePrefix>
  {
  }

  public class NamePrefix : CommonBase
  {
    #region Private Variables
    private string _Title = string.Empty;
    #endregion

    #region Public Properties
    public string Title
    {
      get { return _Title; }
      set
      {
        if (_Title != value)
        {
          _Title = value;
          RaisePropertyChanged("Title");
        }
      }
    }
    #endregion
  }
}