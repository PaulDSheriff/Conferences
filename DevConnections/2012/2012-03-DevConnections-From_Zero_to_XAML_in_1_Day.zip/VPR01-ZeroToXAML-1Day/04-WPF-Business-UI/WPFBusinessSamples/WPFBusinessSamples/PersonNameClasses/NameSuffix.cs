﻿using System.Collections.Generic;
using Common.Library;

namespace WPFBusinessSamples
{
  public class NameSuffixes : List<NameSuffix>
  {
  }

  public class NameSuffix : CommonBase
  {
    #region Private Variables
    private string _Suffix = string.Empty;
    #endregion

    #region Public Properties
    public string Suffix
    {
      get { return _Suffix; }
      set
      {
        if (_Suffix != value)
        {
          _Suffix = value;
          RaisePropertyChanged("Suffix");
        }
      }
    }
    #endregion
  }
}