﻿using System;
using System.Collections.Generic;
using System.Linq;

using Common.Library;

namespace WPFBusinessSamples
{
  public class NameSuffixManager : DataReadOnlyXmlBaseClass
  {
    public const string FILE_NAME = "NameSuffixes.xml";
    public const string FOLDER_NAME = "Xml";
    public const string TOP_ELEMENT_NAME = "NameSuffix";

    #region Constructors
    public NameSuffixManager()
    {
      FileName = FILE_NAME;
      FolderName = FOLDER_NAME;
      FileLocation = XmlFileLocation.Project;
      TopElementName = TOP_ELEMENT_NAME;

      // Build the full path and file name to the XML file in the Project
      BuildXmlFullFileName();
    }

    /// <summary>
    /// Call this constructor to use an XML file in your Project (.exe) folder
    /// </summary>
    /// <param name="folderName">Optional folder name</param>
    /// <param name="fileName">The XML File Name (no path)</param>
    public NameSuffixManager(string folderName, string fileName)
    {
      FileName = fileName;
      FolderName = folderName;
      TopElementName = TOP_ELEMENT_NAME;
      FileLocation = XmlFileLocation.Project;
      BuildXmlFullFileName();
    }
    #endregion

    #region DataCollection Property
    private List<NameSuffix> _DataCollection = new List<NameSuffix>();

    public List<NameSuffix> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region BuildDataCollection Method
    public override void BuildDataCollection()
    {
      if (XmlObject != null)
      {
        // Fill a list of NameSuffix objects
        var coll = from elem in XmlObject.Descendants(TopElementName)
                   select new NameSuffix
                   {
                     Suffix = Convert.ToString(GetValue(elem.Element("Suffix"), default(string)))
                   };

        // Assign to public property
        DataCollection = coll.ToList();
      }
    }
    #endregion
  }
}
