﻿using System;
using System.Collections.Generic;
using System.Linq;

using Common.Library;

namespace WPFBusinessSamples
{
	public class USStateManager : DataReadOnlyXmlBaseClass
	{
		public const string FILE_NAME = "USStates.xml";
		public const string FOLDER_NAME = "Xml";
		public const string TOP_ELEMENT_NAME = "USState";

		#region Constructors
		public USStateManager()
		{
			FileName = FILE_NAME;
			FolderName = FOLDER_NAME;
			FileLocation = XmlFileLocation.Project;
			TopElementName = TOP_ELEMENT_NAME;

			// Build the full path and file name to the XML file in the Project
			BuildXmlFullFileName();
		}

		/// <summary>
		/// Call this constructor to use an XML file in your Project (.exe) folder
		/// </summary>
		/// <param name="folderName">Optional folder name</param>
		/// <param name="fileName">The XML File Name (no path)</param>
		public USStateManager(string folderName, string fileName)
		{
			FileName = fileName;
			FolderName = folderName;
			TopElementName = TOP_ELEMENT_NAME;
			FileLocation = XmlFileLocation.Project;
			BuildXmlFullFileName();
		}
		#endregion

		#region DataCollection Property
		private List<USState> _DataCollection = new List<USState>();

		public List<USState> DataCollection
		{
			get { return _DataCollection; }
			set
			{
				_DataCollection = value;
				RaisePropertyChanged("DataCollection");
			}
		}
		#endregion

		#region BuildDataCollection Method
		public override void BuildDataCollection()
		{
			if (XmlObject != null)
			{
				// Fill a list of USState objects
				var coll = from elem in XmlObject.Descendants(TopElementName)
									 orderby elem.Element("StateCode").Value
									 select new USState
									 {
										 StateCode = Convert.ToString(GetValue(elem.Element("StateCode"), default(string))),
										 StateName = Convert.ToString(GetValue(elem.Element("StateName"), default(string))),
										 Capital = Convert.ToString(GetValue(elem.Element("Capital"), default(string)))
									 };

				// Assign to public property
				DataCollection = coll.ToList();
			}
		}
		#endregion
	}
}
