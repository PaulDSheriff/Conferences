﻿using System.Collections.Generic;

using Common.Library;

namespace WPFBusinessSamples
{
	public class Countries : List<Country>
	{
	}

	public class Country : CommonBase
	{
		#region Private Variables
		private string _CountryCode;
		private string _CountryName;
		private string _ISONumber;
		private string _TwoLetterAbbreviation;
		#endregion

		#region Public Properties
		public string CountryCode
		{
			get { return _CountryCode; }
			set
			{
				if (_CountryCode != value)
				{
					_CountryCode = value;
					RaisePropertyChanged("CountryCode");
				}
			}
		}

		public string CountryName
		{
			get { return _CountryName; }
			set
			{
				if (_CountryName != value)
				{
					_CountryName = value;
					RaisePropertyChanged("CountryName");
				}
			}
		}

		public string ISONumber
		{
			get { return _ISONumber; }
			set
			{
				if (_ISONumber != value)
				{
					_ISONumber = value;
					RaisePropertyChanged("ISONumber");
				}
			}
		}

		public string TwoLetterAbbreviation
		{
			get { return _TwoLetterAbbreviation; }
			set
			{
				if (_TwoLetterAbbreviation != value)
				{
					_TwoLetterAbbreviation = value;
					RaisePropertyChanged("TwoLetterAbbreviation");
				}
			}
		}
		#endregion
	}
}
