﻿using System.Collections.Generic;

using Common.Library;

namespace WPFBusinessSamples
{
	public class CanadianProvinces : List<CanadianProvince>
	{
	}

	public class CanadianProvince : CommonBase
	{
		#region Private Variables
		private string _Name;
		private string _Capital;
		private string _PostalAbbreviation;
		#endregion

		#region Public Properties
		public string Name
		{
			get { return _Name; }
			set
			{
				if (_Name != value)
				{
					_Name = value;
					RaisePropertyChanged("Name");
				}
			}
		}

		public string Capital
		{
			get { return _Capital; }
			set
			{
				if (_Capital != value)
				{
					_Capital = value;
					RaisePropertyChanged("Capital");
				}
			}
		}

		public string PostalAbbreviation
		{
			get { return _PostalAbbreviation; }
			set
			{
				if (_PostalAbbreviation != value)
				{
					_PostalAbbreviation = value;
					RaisePropertyChanged("PostalAbbreviation");
				}
			}
		}
		#endregion
	}
}
