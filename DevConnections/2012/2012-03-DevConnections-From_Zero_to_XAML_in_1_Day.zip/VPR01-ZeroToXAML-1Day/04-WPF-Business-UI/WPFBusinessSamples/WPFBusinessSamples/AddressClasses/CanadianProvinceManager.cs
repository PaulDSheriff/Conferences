﻿using System;
using System.Collections.Generic;
using System.Linq;

using Common.Library;

namespace WPFBusinessSamples
{
	public class CanadianProvinceManager : DataReadOnlyXmlBaseClass
	{
		public const string FILE_NAME = "CanadianProvinces.xml";
		public const string FOLDER_NAME = "Xml";
		public const string TOP_ELEMENT_NAME = "Province";

		#region Constructors
		public CanadianProvinceManager()
		{
			FileName = FILE_NAME;
			FolderName = FOLDER_NAME;
			FileLocation = XmlFileLocation.Project;
			TopElementName = TOP_ELEMENT_NAME;

			// Build the full path and file name to the XML file in the Project
			BuildXmlFullFileName();
		}

		/// <summary>
		/// Call this constructor to use an XML file in your Project (.exe) folder
		/// </summary>
		/// <param name="folderName">Optional folder name</param>
		/// <param name="fileName">The XML File Name (no path)</param>
		public CanadianProvinceManager(string folderName, string fileName)
		{
			FileName = fileName;
			FolderName = folderName;
			TopElementName = TOP_ELEMENT_NAME;
			FileLocation = XmlFileLocation.Project;
			BuildXmlFullFileName();
		}
		#endregion

		#region DataCollection Property
		private List<CanadianProvince> _DataCollection = new List<CanadianProvince>();

		public List<CanadianProvince> DataCollection
		{
			get { return _DataCollection; }
			set
			{
				_DataCollection = value;
				RaisePropertyChanged("DataCollection");
			}
		}
		#endregion

		#region BuildDataCollection Method
		public override void BuildDataCollection()
		{
			if (XmlObject != null)
			{
				// Fill a list of CanadianProvince objects
				var coll = from elem in XmlObject.Descendants(TopElementName)
									 orderby elem.Element("Name").Value
									 select new CanadianProvince
									 {
										 Name = Convert.ToString(GetValue(elem.Element("Name"), default(string))),
										 Capital = Convert.ToString(GetValue(elem.Element("Capital"), default(string))),
										 PostalAbbreviation = Convert.ToString(GetValue(elem.Element("PostalAbbreviation"), default(string)))
									 };

				// Assign to public property
				DataCollection = coll.ToList();
			}
		}
		#endregion
	}
}
