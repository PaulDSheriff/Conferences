﻿using System.Collections.Generic;
using Common.Library;

namespace WPFBusinessSamples
{
	public class USStates : List<USState>
	{
	}

	public class USState : CommonBase
	{
		#region Private Variables
		private string _StateCode;
		private string _StateName;
		private string _Capital;
		#endregion

		#region Public Properties
		public string StateCode
		{
			get { return _StateCode; }
			set
			{
				if (_StateCode != value)
				{
					_StateCode = value;
					RaisePropertyChanged("StateCode");
				}
			}
		}

		public string StateName
		{
			get { return _StateName; }
			set
			{
				if (_StateName != value)
				{
					_StateName = value;
					RaisePropertyChanged("StateName");
				}
			}
		}

		public string Capital
		{
			get { return _Capital; }
			set
			{
				if (_Capital != value)
				{
					_Capital = value;
					RaisePropertyChanged("Capital");
				}
			}
		}
		#endregion
	}
}
