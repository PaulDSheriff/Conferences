using System.Collections.Generic;
using Common.Library;

namespace WPFBusinessSamples
{
	public class Addresses : List<Address>
	{
	}

	public class Address : CommonBase
	{
		#region Country Address Type Enumeration
		public enum CountryAddressType : int
		{
			US,
			Canadian,
			UK,
			Other,
		}
		#endregion

		#region Private Variables
		private CountryAddressType _AddressType = CountryAddressType.US;
		private string _Address1 = string.Empty;
		private string _Address2 = string.Empty;
		private string _Address3 = string.Empty;
		private string _City = string.Empty;
		private string _Village = string.Empty;
		private string _StateCode = string.Empty;
		private string _CountryName = string.Empty;
		private string _PostalCode = string.Empty;
		private string _PostalCodeExt = string.Empty;
		#endregion

		#region Public Properties
		public CountryAddressType AddressType
		{
			get { return _AddressType; }
			set
			{
				if (_AddressType != value)
				{
					_AddressType = value;
					RaisePropertyChanged("AddressType");
				}
			}
		}

		public string Address1
		{
			get { return _Address1; }
			set
			{
				if (_Address1 != value)
				{
					_Address1 = value;
					RaisePropertyChanged("Address1");
				}
			}
		}

		public string Address2
		{
			get { return _Address2; }
			set
			{
				if (_Address2 != value)
				{
					_Address2 = value;
					RaisePropertyChanged("Address2");
				}
			}
		}

		public string Address3
		{
			get { return _Address3; }
			set
			{
				if (_Address3 != value)
				{
					_Address3 = value;
					RaisePropertyChanged("Address3");
				}
			}
		}

		public string City
		{
			get { return _City; }
			set
			{
				if (_City != value)
				{
					_City = value;
					RaisePropertyChanged("City");
				}
			}
		}

		public string Village
		{
			get { return _Village; }
			set
			{
				if (_Village != value)
				{
					_Village = value;
					RaisePropertyChanged("Village");
				}
			}
		}

		public string StateCode
		{
			get { return _StateCode; }
			set
			{
				if (_StateCode != value)
				{
					_StateCode = value;
					RaisePropertyChanged("StateCode");
				}
			}
		}

		public string CountryName
		{
			get { return _CountryName; }
			set
			{
				if (_CountryName != value)
				{
					_CountryName = value;
					ChangeAddressType();
					RaisePropertyChanged("CountryName");
				}
			}
		}

		public string PostalCode
		{
			get { return _PostalCode; }
			set
			{
				if (_PostalCode != value)
				{
					_PostalCode = value;
					RaisePropertyChanged("PostalCode");
				}
			}
		}

		public string PostalCodeExt
		{
			get { return _PostalCodeExt; }
			set
			{
				if (_PostalCodeExt != value)
				{
					_PostalCodeExt = value;
					RaisePropertyChanged("PostalCodeExt");
				}
			}
		}
		#endregion

		#region ChangeAddressType Method
		protected virtual void ChangeAddressType()
		{
			if (CountryName != null)
			{
				switch (CountryName.ToLower())
				{
					case "united states":
						AddressType = CountryAddressType.US;
						break;

					case "canada":
						AddressType = CountryAddressType.Canadian;
						break;

					case "united kingdom":
						AddressType = CountryAddressType.UK;
						break;

					default:
						AddressType = CountryAddressType.Other;
						break;
				}
			}
		}
		#endregion
	}
}