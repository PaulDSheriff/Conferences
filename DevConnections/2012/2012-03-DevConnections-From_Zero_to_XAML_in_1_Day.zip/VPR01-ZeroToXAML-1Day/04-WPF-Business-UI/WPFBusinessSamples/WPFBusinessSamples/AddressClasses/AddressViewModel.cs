﻿using System.Collections.ObjectModel;
using System.ComponentModel;

using Common.Library;

namespace WPFBusinessSamples
{
	public class AddressViewModel : CommonBase
	{
		#region Private Variables
		private ObservableCollection<CanadianProvince> _CanadianProvinces = new ObservableCollection<CanadianProvince>();
		private ObservableCollection<Country> _Countries = new ObservableCollection<Country>();
		private ObservableCollection<USState> _USStates = new ObservableCollection<USState>();
		private Address _AddressObject = new Address();

		private string _ZipPostalText = "Zip Code";
		private bool _IsVillageVisible = false;
		private bool _IsAddress3Visible = false;
		private bool _IsPostalCodeExtensionVisible = true;
		private bool _IsStateVisible = true;
		private bool _IsProvinceVisible = false;
		#endregion

		#region Public Properties
		public ObservableCollection<CanadianProvince> CanadianProvinces
		{
			get { return _CanadianProvinces; }
			set
			{
				_CanadianProvinces = value;
				RaisePropertyChanged("CanadianProvinces");
			}
		}

		public ObservableCollection<Country> Countries
		{
			get { return _Countries; }
			set
			{
				_Countries = value;
				RaisePropertyChanged("Countries");
			}
		}

		public ObservableCollection<USState> USStates
		{
			get { return _USStates; }
			set
			{
				_USStates = value;
				RaisePropertyChanged("USStates");
			}
		}

		public Address AddressObject
		{
			get { return _AddressObject; }
			set
			{
				_AddressObject = value;
				RaisePropertyChanged("AddressObject");
			}
		}

		public bool IsVillageVisible
		{
			get { return _IsVillageVisible; }
			set
			{
				if (_IsVillageVisible != value)
				{
					_IsVillageVisible = value;
					RaisePropertyChanged("IsVillageVisible");
				}
			}
		}

		public bool IsAddress3Visible
		{
			get { return _IsAddress3Visible; }
			set
			{
				if (_IsAddress3Visible != value)
				{
					_IsAddress3Visible = value;
					RaisePropertyChanged("IsAddress3Visible");
				}
			}
		}

		public bool IsPostalCodeExtensionVisible
		{
			get { return _IsPostalCodeExtensionVisible; }
			set
			{
				if (_IsPostalCodeExtensionVisible != value)
				{
					_IsPostalCodeExtensionVisible = value;
					RaisePropertyChanged("IsPostalCodeExtensionVisible");
				}
			}
		}

		public string ZipPostalText
		{
			get { return _ZipPostalText; }
			set
			{
				if (_ZipPostalText != value)
				{
					_ZipPostalText = value;
					RaisePropertyChanged("ZipPostalText");
				}
			}
		}

		public bool IsStateVisible
		{
			get { return _IsStateVisible; }
			set
			{
				if (_IsStateVisible != value)
				{
					_IsStateVisible = value;
					RaisePropertyChanged("IsStateVisible");
				}
			}
		}

		public bool IsProvinceVisible
		{
			get { return _IsProvinceVisible; }
			set
			{
				if (_IsProvinceVisible != value)
				{
					_IsProvinceVisible = value;
					RaisePropertyChanged("IsProvinceVisible");
				}
			}
		}
		#endregion

		#region Init Method
		public void Init()
		{
			Init("United States", "CA");
		}

		public void Init(string countryName, string stateOrProvince)
		{
			// Hook into CountryName change
			AddressObject.PropertyChanged += new PropertyChangedEventHandler(AddressObject_PropertyChanged);

			// Initialize Country and State/Province
			AddressObject.CountryName = countryName;
			AddressObject.StateCode = stateOrProvince;
		}
		#endregion

		#region Property Changed Event from AddressObject
		void AddressObject_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			switch (e.PropertyName.ToLower())
			{
				case "countryname":
					SetUI();
					break;

				default:
					break;
			}
		}
		#endregion

		#region LoadAll Method
		public void LoadAll()
		{
			CanadianProvincesLoad();
			CountriesLoad();
			USStateLoad();
		}
		#endregion

		#region Load Validation Tables Methods
		private void CanadianProvincesLoad()
		{
			CanadianProvinceManager mgr = new CanadianProvinceManager();

			mgr.LoadAll();

			CanadianProvinces = new ObservableCollection<CanadianProvince>(mgr.DataCollection);
		}

		private void CountriesLoad()
		{
			CountryManager mgr = new CountryManager();

			mgr.LoadAll();

			Countries = new ObservableCollection<Country>(mgr.DataCollection);
		}

		private void USStateLoad()
		{
			USStateManager mgr = new USStateManager();

			mgr.LoadAll();

			USStates = new ObservableCollection<USState>(mgr.DataCollection);
		}
		#endregion

		#region SetUI Method
		public void SetUI()
		{
			switch (AddressObject.AddressType)
			{
				case Address.CountryAddressType.US:
					ZipPostalText = "Zip Code";
					IsVillageVisible = false;
					IsAddress3Visible = false;
					IsStateVisible = true;
					IsProvinceVisible = false;
					IsPostalCodeExtensionVisible = true;
					break;

				case Address.CountryAddressType.Canadian:
					ZipPostalText = "Postal Code";
					IsVillageVisible = false;
					IsAddress3Visible = false;
					IsStateVisible = false;
					IsProvinceVisible = true;
					IsPostalCodeExtensionVisible = false;
					break;

				case Address.CountryAddressType.UK:
					ZipPostalText = "Postal Code";
					IsVillageVisible = true;
					IsAddress3Visible = false;
					IsStateVisible = false;
					IsProvinceVisible = false;
					IsPostalCodeExtensionVisible = false;
					break;

				case Address.CountryAddressType.Other:
					ZipPostalText = "Postal Code";
					IsVillageVisible = false;
					IsAddress3Visible = true;
					IsStateVisible = false;
					IsProvinceVisible = false;
					IsPostalCodeExtensionVisible = false;
					break;

				default:
					break;
			}
		}
		#endregion
	}
}
