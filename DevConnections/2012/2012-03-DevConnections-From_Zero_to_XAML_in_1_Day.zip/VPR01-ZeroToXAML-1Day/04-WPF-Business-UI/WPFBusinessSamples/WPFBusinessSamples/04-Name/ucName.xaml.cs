﻿using System.Windows;
using System.Windows.Controls;

namespace WPFBusinessSamples
{
  /// <summary>
  /// Interaction logic for ucName.xaml
  /// </summary>
  public partial class ucName : UserControl
  {
    NameViewModel _ViewModel;

    public NameViewModel ViewModel
    {
      get { return _ViewModel; }
      set { _ViewModel = value; }
    }

    public ucName()
    {
      InitializeComponent();

      _ViewModel = (NameViewModel)this.Resources["viewModel"];
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      // Load all Salutations/Suffixes
      _ViewModel.LoadAll();
    }
  }
}
