using System;
using Common.Library;

namespace WPFBusinessSamples
{
	public class CreditCard : CommonBase
	{
		#region Private Variables
		private string _BillingPostalCode;
		private string _CreditCardType;
		private string _NameOnCard;
		private string _CreditCardNumber;
		private string _ExpMonth;
		private string _ExpYear;
		private string _SecurityCode;
		#endregion

		#region Public Properties
		public string BillingPostalCode
		{
			get { return _BillingPostalCode; }
			set
			{
				if (_BillingPostalCode != value)
				{
					_BillingPostalCode = value;
					RaisePropertyChanged("BillingPostalCode");
				}
			}
		}

		public string CreditCardType
		{
			get { return _CreditCardType; }
			set
			{
				if (_CreditCardType != value)
				{
					_CreditCardType = value;
					RaisePropertyChanged("CreditCardType");
				}
			}
		}

		public string NameOnCard
		{
			get { return _NameOnCard; }
			set
			{
				if (_NameOnCard != value)
				{
					_NameOnCard = value;
					RaisePropertyChanged("NameOnCard");
				}
			}
		}

		public string CreditCardNumber
		{
			get { return _CreditCardNumber; }
			set
			{
				if (_CreditCardNumber != value)
				{
					_CreditCardNumber = value;
					RaisePropertyChanged("CreditCardNumber");
				}
			}
		}

		public string ExpMonth
		{
			get { return _ExpMonth; }
			set
			{
				if (_ExpMonth != value)
				{
					_ExpMonth = value;
					RaisePropertyChanged("ExpMonth");
				}
			}
		}

		public string ExpYear
		{
			get { return _ExpYear; }
			set
			{
				if (_ExpYear != value)
				{
					_ExpYear = value;
					RaisePropertyChanged("ExpYear");
				}
			}
		}

		public string SecurityCode
		{
			get { return _SecurityCode; }
			set
			{
				if (_SecurityCode != value)
				{
					_SecurityCode = value;
					RaisePropertyChanged("SecurityCode");
				}
			}
		}
		#endregion
	}
}