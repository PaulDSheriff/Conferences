﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;

using Common.Library;

namespace WPFBusinessSamples
{
	public class CreditCardViewModel : CommonBase
	{
		public CreditCardViewModel()
		{
			Load();
		}

		#region Private Variables
		private ObservableCollection<CreditCardType> _CardTypes;
		private ObservableCollection<CreditCardMonth> _Months;
		private ObservableCollection<CreditCardYear> _Years;
		private CreditCard _CreditCardObject;
		#endregion

		#region Public Properties
		public CreditCard CreditCardObject
		{
			get { return _CreditCardObject; }
			set
			{
				_CreditCardObject = value;
				RaisePropertyChanged("CreditCardObject");
			}
		}

		public ObservableCollection<CreditCardType> CardTypes
		{
			get { return _CardTypes; }
			set
			{
				_CardTypes = value;
				RaisePropertyChanged("CardTypes");
			}
		}

		public ObservableCollection<CreditCardMonth> Months
		{
			get { return _Months; }
			set
			{
				_Months = value;
				RaisePropertyChanged("Months");
			}
		}

		public ObservableCollection<CreditCardYear> Years
		{
			get { return _Years; }
			set
			{
				_Years = value;
				RaisePropertyChanged("Years");
			}
		}
		#endregion

		public void Load()
		{
			CreditCardMonths month = new CreditCardMonths();
			CreditCardYears year = new CreditCardYears();
			CreditCardTypeManager mgr = new CreditCardTypeManager();

			// Load Months
			Months = new ObservableCollection<CreditCardMonth>(month.GetMonths());
			// Load Years
			Years = new ObservableCollection<CreditCardYear>(year.GetYears());
			// Load Card Types
			mgr.LoadAll();
			CardTypes = new ObservableCollection<CreditCardType>(mgr.DataCollection);
		}

		public void Init()
		{
			CreditCardMonths month = new CreditCardMonths();

			// Initialize Credit Card Info
			CreditCardObject = new CreditCard();
			CreditCardObject.CreditCardType = "Visa";
			CreditCardObject.ExpMonth = month.GetMonthName(DateTime.Now.Month);
			CreditCardObject.ExpYear = (DateTime.Now.Year + 1).ToString();
		}
	}
}
