﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFBusinessSamples
{
  public partial class ucAddress : UserControl
  {
    AddressViewModel _ViewModel;

    public AddressViewModel ViewModel
    {
      get { return _ViewModel; }
      set { _ViewModel = value; }
    }

    public ucAddress()
    {
      InitializeComponent();

      _ViewModel = (AddressViewModel)this.Resources["viewModel"];
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      // Load all countries/states/provinces
      _ViewModel.LoadAll();
      // Initialize Country/State/Province
      _ViewModel.Init();
      //_ViewModel.Init("Canada", "Alberta");
    }
  }
}
