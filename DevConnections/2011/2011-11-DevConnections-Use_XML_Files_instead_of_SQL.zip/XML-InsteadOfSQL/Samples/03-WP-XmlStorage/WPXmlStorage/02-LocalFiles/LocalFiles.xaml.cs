﻿using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Xml.Linq;
using System.IO.IsolatedStorage;
using Microsoft.Phone.Controls;

using Common.Library;
using XMLDataClasses;

namespace WPXmlStorage
{
	public partial class LocalFiles : PhoneApplicationPage
	{
		#region Constructor
		public LocalFiles()
		{
			InitializeComponent();
		}
		#endregion

    XElement _Elements = null;
    string _FileName = "Product.xml";

    private void btnReadProject_Click(object sender, RoutedEventArgs e)
    {
      // Get File Name from Local Project
      _FileName = @"Xml/Product.xml";

      // Read file from local project
      _Elements = XElement.Load(_FileName);

      // Reset _FileName to 'key' for Isolated Storage
      _FileName = "Product.xml";

      // First delete old key from Isolated Storage
      IsolatedStorageSettings.ApplicationSettings.Remove(_FileName);
      // Now save new data
      IsolatedStorageSettings.ApplicationSettings[_FileName] = _Elements.ToString();

      MessageBox.Show("XML Written to Isolated Storage");
    }

    private void btnReadUserStorage_Click(object sender, RoutedEventArgs e)
    {
      if (IsolatedStorageSettings.ApplicationSettings.Contains(_FileName))
      {
        // Read file from local project
        _Elements = XElement.Parse(IsolatedStorageSettings.ApplicationSettings[_FileName].ToString());

        // Create a list of Product objects from XElement object
        var products = from prod in _Elements.Descendants("Product")
                       orderby prod.Attribute("ProductName").Value
                       select new Product
                       {
                         ProductId = Convert.ToInt32(prod.Attribute("ProductId").Value),
                         ProductName = prod.Attribute("ProductName").Value,
                         IntroductionDate = Convert.ToDateTime(prod.Attribute("IntroductionDate").Value),
                         Price = Convert.ToDecimal(prod.Attribute("Price").Value)
                       };

        lstData.DataContext = products;
      }
      else
        MessageBox.Show("XML File does not exist in Isolated Storage!");
    }

    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      if (IsolatedStorageSettings.ApplicationSettings.Contains(_FileName))
      {
        IsolatedStorageSettings.ApplicationSettings.Remove(_FileName);

        lstData.DataContext = null;

        MessageBox.Show("XML Deleted from Isolated Storage");
      }
    }
	}
}