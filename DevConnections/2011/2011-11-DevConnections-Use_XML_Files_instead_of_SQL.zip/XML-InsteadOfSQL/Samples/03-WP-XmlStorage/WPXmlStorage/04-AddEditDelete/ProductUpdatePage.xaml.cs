﻿using System.Windows;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using XMLDataClasses;

namespace WPXmlStorage
{
  public partial class ProductUpdatePage : PhoneApplicationPage
  {
    ProductViewModel _ViewModel;

    #region Constructor
    public ProductUpdatePage()
    {
      InitializeComponent();
    }
    #endregion

    #region Loaded Event Procedure
    private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
    {
      _ViewModel = (ProductViewModel)PhoneApplicationService.Current.State["ProductViewModel"];
      this.DataContext = _ViewModel;
    }
    #endregion

    #region Save Click Event Procedure
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.Save();
     
      NavigationService.GoBack();
    }
    #endregion

    #region Cancel Click Event Procedure    
    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      NavigationService.GoBack();
    }
    #endregion
  }
}