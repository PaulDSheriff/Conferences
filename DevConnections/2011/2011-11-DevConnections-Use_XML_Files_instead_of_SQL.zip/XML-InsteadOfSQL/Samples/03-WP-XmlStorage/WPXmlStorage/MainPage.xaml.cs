﻿using System;
using System.IO.IsolatedStorage;
using Microsoft.Phone.Controls;
using XMLDataClasses;

namespace WPXmlStorage
{
  public partial class MainPage : PhoneApplicationPage
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private void btnLinqXmlSample_Click(object sender, System.Windows.RoutedEventArgs e)
    {
      NavigationService.Navigate(new Uri("/01-LinqToXml/LinqToXml.xaml", UriKind.Relative));
    }

		private void btnLocalFile_Click(object sender, System.Windows.RoutedEventArgs e)
		{
			NavigationService.Navigate(new Uri("/02-LocalFiles/LocalFiles.xaml", UriKind.Relative));
		}

    private void btnGetFromServer_Click(object sender, System.Windows.RoutedEventArgs e)
    {
      NavigationService.Navigate(new Uri("/03-GetFromServer/ReadFromServerPage.xaml", UriKind.Relative));
    }

    private void btnProduct_Click(object sender, System.Windows.RoutedEventArgs e)
    {
      NavigationService.Navigate(new Uri("/04-AddEditDelete/ProductDisplayPage.xaml", UriKind.Relative));
    }

    private void btnDelete_Click(object sender, System.Windows.RoutedEventArgs e)
    {
      IsolatedStorageSettings.ApplicationSettings.Remove(ProductManager.FILE_NAME);
    }

  }
}