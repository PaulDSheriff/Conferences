﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows;

namespace XAML.Library
{
	/// <summary>
	/// Call this converter to change a True value to Visible and a False value to Collapsed/Hidden
	/// </summary>
	public class BooleanToVisibilityConverter : IValueConverter
	{
		/// <summary>
		/// Convert a True/False value to Visibility.Visible/Visibility.Collapsed value
		/// </summary>
		/// <param name="value">A boolean value</param>
		/// <param name="targetType">The type of object</param>
		/// <param name="parameter">Any parameters passed via XAML</param>
		/// <param name="culture">The current culture</param>
		/// <returns>A Visibility Enumeration</returns>
		public object Convert(object value, Type targetType,
													object parameter, CultureInfo culture)
		{
			if ((bool)value)
				return Visibility.Visible;
			else
#if SILVERLIGHT
        return Visibility.Collapsed;
#else
				return Visibility.Hidden;
#endif
		}

		/// <summary>
		/// NOT IMPLEMENTED
		/// </summary>
		/// <param name="value">A boolean value</param>
		/// <param name="targetType">The type of object</param>
		/// <param name="parameter">Any parameters passed via XAML</param>
		/// <param name="culture">The current culture</param>
		/// <returns>NOT IMPLEMENTED</returns>
		public object ConvertBack(object value, Type targetType,
															object parameter, CultureInfo culture)
		{
			throw new NotImplementedException("BooleanToVisibility ConvertBack Method Not Implemented");
		}
	}
}