﻿using System;
using System.Collections.Generic;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Xml.Linq;

using Common.Library;
using Music.DataClasses.MusicKindServiceReference;

namespace Music.DataClasses
{
	public class MusicKindManager : DataXmlBaseClass
	{
		public const string FILE_NAME = "MusicKinds.xml";
		public const string FOLDER_NAME = "Xml";
		public const string TOP_ELEMENT_NAME = "MusicKind";

		#region Constructors
		public MusicKindManager()
		{
			FileName = FILE_NAME;
			FolderName = FOLDER_NAME;
			FileLocation = XmlFileLocation.Project;
			TopElementName = TOP_ELEMENT_NAME;

			// Build the full path and file name to the XML file in the Project
			BuildXmlFullFileName();
		}

		/// <summary>
		/// Call this Constructor to use an XML file in local storage (Isolated, or User App Data Path)
		/// </summary>
		/// <param name="fileName">The XML File Name (no path)</param>
		public MusicKindManager(string fileName)
		{
			FileName = fileName;
			FolderName = string.Empty;
			FileLocation = XmlFileLocation.LocalStorage;
			TopElementName = TOP_ELEMENT_NAME;
			BuildXmlFullFileName();
		}

		/// <summary>
		/// Call this constructor to use an XML file in your Project (.exe) folder
		/// </summary>
		/// <param name="folderName">Optional folder name</param>
		/// <param name="fileName">The XML File Name (no path)</param>
		public MusicKindManager(string folderName, string fileName)
		{
			FileName = fileName;
			FolderName = folderName;
			TopElementName = TOP_ELEMENT_NAME;
			FileLocation = XmlFileLocation.Project;
			BuildXmlFullFileName();
		}
		#endregion

		#region DataCollection Property
		private List<MusicKind> _DataCollection = new List<MusicKind>();

		public List<MusicKind> DataCollection
		{
			get { return _DataCollection; }
			set
			{
				_DataCollection = value;
				RaisePropertyChanged("DataCollection");
			}
		}
		#endregion

		#region GetDataFromService Method
		MusicKindServiceClient _Client = null;

		protected override void GetDataFromService()
		{
			_Client = new MusicKindServiceClient();

			_Client.GetMusicKindXmlCompleted += new EventHandler<GetMusicKindXmlCompletedEventArgs>(_Client_GetMusicKindXmlCompleted);
			_Client.GetMusicKindXmlAsync();
		}

		void _Client_GetMusicKindXmlCompleted(object sender, GetMusicKindXmlCompletedEventArgs e)
		{
			XmlObject = XElement.Parse(e.Result);

			// Build Collection of Data
			BuildDataCollection();

#if SILVERLIGHT
			_Client.CloseAsync();
#else
			_Client.Close();
#endif
			_Client = null;
		}
		#endregion

		#region LoadAllIfNewerData Method
		public override void LoadAllIfNewerData()
		{
			DateTime lastUpdated = Convert.ToDateTime("1753-1-1");  // Minimum date in SQL Server
			int rows = int.MinValue;

			_Client = new MusicKindServiceClient();
			if (DoesLocalDataExist())
			{
				// Load local data
				LoadAll();
				// Get count and last update date
				lastUpdated = GetLastUpdateDate();
				rows = GetCount();
			}

      // Check to see if we need to retrieve data from server
      // Could add code here to only check once a week, or something
      _Client.GetMusicKindXmlIfChangedCompleted += new EventHandler<GetMusicKindXmlIfChangedCompletedEventArgs>(_Client_GetMusicKindXmlIfChangedCompleted);
			_Client.GetMusicKindXmlIfChangedAsync(lastUpdated, rows);
		}

		void _Client_GetMusicKindXmlIfChangedCompleted(object sender, GetMusicKindXmlIfChangedCompletedEventArgs e)
		{
			// e.Result will be empty if data has NOT changed
			if (e.Result != string.Empty)
			{
				// Data has changed, so parse and save locally
				XmlObject = XElement.Parse(e.Result);

				// Build Collection of Data
				BuildDataCollection();
			}

#if SILVERLIGHT
			_Client.CloseAsync();
#else
			_Client.Close();
#endif
			_Client = null;
		}
		#endregion

		#region BuildDataCollection Method
		public override void BuildDataCollection()
		{
			if (XmlObject != null)
			{
				// Save to local storage
				Save();

				// Fill a list of MusicKind objects
				var coll = from elem in XmlObject.Descendants(TopElementName)
									 orderby elem.Attribute("Kind").Value
									 select new MusicKind
									 {
										 KindId = Convert.ToInt32(GetValue(elem.Attribute("KindId"), default(int))),
										 Kind = Convert.ToString(GetValue(elem.Attribute("Kind"), default(string))),
										 LastUpdated = Convert.ToDateTime(GetValue(elem.Attribute("LastUpdated"), default(DateTime)))
									 };

				// Assign to public property
				DataCollection = coll.ToList();
			}
		}
		#endregion

		#region Insert Method
		public bool Insert(MusicKind entity)
		{
			// Create new MusicKind element
			var newElem = new XElement(TopElementName,
				new XAttribute("KindId", entity.KindId),
				new XAttribute("Kind", entity.Kind),
				new XAttribute("LastUpdated", entity.LastUpdated));

			// Add to element collection
			XmlObject.Add(newElem);

			// Save the file
			Save(XmlObject);

			return true;
		}
		#endregion

		#region Update Method
		public bool Update(MusicKind entity)
		{
			// Find the MusicKind element
			var XElem = (from elem in XmlObject.Descendants(TopElementName)
									 where elem.Attribute("KindId").Value == entity.KindId.ToString()
									 select elem).SingleOrDefault();

			// Update the data
			SetValue(XElem, XElem.Attribute("KindId"), "KindId", entity.KindId);
			SetValue(XElem, XElem.Attribute("Kind"), "Kind", entity.Kind);
			SetValue(XElem, XElem.Attribute("LastUpdated"), "LastUpdated", DateTime.Now);

			// Save the file
			Save(XmlObject);

			return true;
		}
		#endregion

		#region Delete Method
		public bool Delete(MusicKind entity)
		{
			// Find the MusicKind element
			var XElem = (from elem in XmlObject.Descendants(TopElementName)
									 where elem.Attribute("KindId").Value == entity.KindId.ToString()
									 select elem).SingleOrDefault();
			// Delete the element
			XElem.Remove();

			// Save the file
			Save(XmlObject);

			return true;
		}
		#endregion

		#region GetNextId Method
		public override int GetNextId()
		{
			return GetNextId("KindId");
		}
		#endregion

		#region GetLastUpdateDate Method
		public override DateTime GetLastUpdateDate()
		{
			return GetLastUpdateDate("LastUpdated");
		}
		#endregion

	}
}
