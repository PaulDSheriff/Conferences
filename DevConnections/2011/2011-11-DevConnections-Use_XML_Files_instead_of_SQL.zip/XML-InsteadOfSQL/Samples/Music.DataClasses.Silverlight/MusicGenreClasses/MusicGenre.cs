﻿using System;

using Common.Library;

namespace Music.DataClasses
{
	public class MusicGenre : CommonBase
	{
		#region Private Variables
		private int _GenreId;
		private string _Genre;
		private DateTime _LastUpdated;
		#endregion

		#region Public Properties
		public int GenreId
		{
			get { return _GenreId; }
			set
			{
				if (_GenreId != value)
				{
					_GenreId = value;
					RaisePropertyChanged("GenreId");
				}
			}
		}

		public string Genre
		{
			get { return _Genre; }
			set
			{
				if (_Genre != value)
				{
					_Genre = value;
					RaisePropertyChanged("Genre");
				}
			}
		}

		public DateTime LastUpdated
		{
			get { return _LastUpdated; }
			set
			{
				if (_LastUpdated != value)
				{
					_LastUpdated = value;
					RaisePropertyChanged("LastUpdated");
				}
			}
		}
		#endregion
	}
}
