using System;
using System.ComponentModel;
using Common.Library;

namespace Music.DataClasses
{
	public partial class Song : CommonBase
	{
		#region Private Variables
		private int mSongId = 0;
		private string mSongName = string.Empty;
		private string mArtist = string.Empty;
		private string mAlbum = string.Empty;
		private int mGenreId = 0;
		private int mKindId = 0;
		private string mTrackNumber = string.Empty;
		private int mRating = 0;
		private int mYear = 0;
		private DateTime mReleaseDate = DateTime.Now;
		private string mSize = string.Empty;
		private int mPlays = 0;
		private DateTime mDateAdded = DateTime.Now;
		#endregion

		#region Public Properties
		/// <summary>
		/// Get/Set the Song Id value
		/// </summary>
		public int SongId
		{
			get { return mSongId; }
			set
			{
				mSongId = value;
				RaisePropertyChanged("SongId");
			}
		}

		/// <summary>
		/// Get/Set the Song Name value
		/// </summary>
		public string SongName
		{
			get { return mSongName; }
			set
			{
				mSongName = value;
				RaisePropertyChanged("SongName");
			}
		}

		/// <summary>
		/// Get/Set the Artist value
		/// </summary>
		public string Artist
		{
			get { return mArtist; }
			set
			{
				mArtist = value;
				RaisePropertyChanged("Artist");
			}
		}

		/// <summary>
		/// Get/Set the Album value
		/// </summary>
		public string Album
		{
			get { return mAlbum; }
			set
			{
				mAlbum = value;
				RaisePropertyChanged("Album");
			}
		}

		/// <summary>
		/// Get/Set the Genre Id value
		/// </summary>
		public int GenreId
		{
			get { return mGenreId; }
			set
			{
				mGenreId = value;
				RaisePropertyChanged("GenreId");
			}
		}

		/// <summary>
		/// Get/Set the Kind Id value
		/// </summary>
		public int KindId
		{
			get { return mKindId; }
			set
			{
				mKindId = value;
				RaisePropertyChanged("KindId");
			}
		}

		/// <summary>
		/// Get/Set the Track Number value
		/// </summary>
		public string TrackNumber
		{
			get { return mTrackNumber; }
			set
			{
				mTrackNumber = value;
				RaisePropertyChanged("TrackNumber");
			}
		}

		/// <summary>
		/// Get/Set the Rating value
		/// </summary>
		public int Rating
		{
			get { return mRating; }
			set
			{
				mRating = value;
				RaisePropertyChanged("Rating");
			}
		}

		/// <summary>
		/// Get/Set the Year value
		/// </summary>
		public int Year
		{
			get { return mYear; }
			set
			{
				mYear = value;
				RaisePropertyChanged("Year");
			}
		}

		/// <summary>
		/// Get/Set the Release Date value
		/// </summary>
		public DateTime ReleaseDate
		{
			get { return mReleaseDate; }
			set
			{
				mReleaseDate = value;
				RaisePropertyChanged("ReleaseDate");
			}
		}

		/// <summary>
		/// Get/Set the Size value
		/// </summary>
		public string Size
		{
			get { return mSize; }
			set
			{
				mSize = value;
				RaisePropertyChanged("Size");
			}
		}

		/// <summary>
		/// Get/Set the Plays value
		/// </summary>
		public int Plays
		{
			get { return mPlays; }
			set
			{
				mPlays = value;
				RaisePropertyChanged("Plays");
			}
		}

		/// <summary>
		/// Get/Set the Date Added value
		/// </summary>
		public DateTime DateAdded
		{
			get { return mDateAdded; }
			set
			{
				mDateAdded = value;
				RaisePropertyChanged("DateAdded");
			}
		}
		#endregion
	}
}
