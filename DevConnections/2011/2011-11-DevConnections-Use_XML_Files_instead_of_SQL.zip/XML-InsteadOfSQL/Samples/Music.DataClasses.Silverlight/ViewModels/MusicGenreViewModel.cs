﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using Common.Library;

namespace Music.DataClasses
{
	public class MusicGenreViewModel : ViewModelBase
	{
		#region Private Variables
		private MusicGenre _OriginalData = null;
		private MusicGenreManager _ManagerObject = null;
		private MusicGenre _DetailData = null;
		private ObservableCollection<MusicGenre> _DataCollection = new ObservableCollection<MusicGenre>();
		#endregion

		#region Public Properties
		public MusicGenreManager ManagerObject
		{
			get { return _ManagerObject; }
			set
			{
				_ManagerObject = value;
				RaisePropertyChanged("ManagerObject");
			}
		}
		
		public MusicGenre DetailData
		{
			get { return _DetailData; }
			set
			{
				_DetailData = value;
				RaisePropertyChanged("DetailData");
			}
		}

		public ObservableCollection<MusicGenre> DataCollection
		{
			get { return _DataCollection; }
			set
			{
				_DataCollection = value;
				RaisePropertyChanged("DataCollection");
			}
		}
		#endregion

		#region CreateOrGetManagerObject Method
		protected MusicGenreManager CreateOrGetManagerObject()
		{
			// Maybe implement some caching here
			if (ManagerObject == null)
			{
				ManagerObject = new MusicGenreManager();
				ManagerObject.PropertyChanged += new PropertyChangedEventHandler(ManagerObject_PropertyChanged);
			}

			return ManagerObject;
		}
		#endregion

		#region LoadAll Method
		public void LoadAll()
		{
			// Create or Get the Manager Object
			CreateOrGetManagerObject();
			// Get all Data
			ManagerObject.LoadAll();
		}

		void ManagerObject_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
		{
			// Get All MusicGenres in XML and Put into Observable collection
#if SILVERLIGHT
			// Put List<MusicGenre> collection into Observable Collection
			// An ObserverableCollection in Silverlight 
			// does NOT have a constructor that accepts a List<T> like WPF
			foreach (MusicGenre item in ManagerObject.DataCollection)
				DataCollection.Add(item);
#else
			DataCollection =
				new ObservableCollection<MusicGenre>(ManagerObject.DataCollection);
#endif

			TotalRecords = DataCollection.Count;

			// Check for XML records, could mean the file does not exist
			if (TotalRecords == 0)
			{
				SetUIState(EditUIState.Exception);
				LastExceptionMessage = "No XML Records. This could mean the XML file does not exist in the User's Local Data Storage, or there are just no records in the XML file.";
			}
			else
				SetUIState(EditUIState.Normal);
		}
		#endregion

		#region Save Method
		public void Save()
		{
			if (IsAddMode)
				Insert();
			else
				Update();
		}
		#endregion

		#region Insert Method
		public void Insert()
		{
			if (ManagerObject.Insert(DetailData))
			{
				DataCollection.Add(DetailData);
				SetUIState(EditUIState.Normal);
				TotalRecords = DataCollection.Count;
			}
		}
		#endregion

		#region Update Method
		public void Update()
		{
			if (ManagerObject.Update(DetailData))
			{
				SetUIState(EditUIState.Normal);
			}
		}
		#endregion

		#region Delete Method
		public void Delete()
		{
			if (ManagerObject.Delete(DetailData))
			{
				DataCollection.Remove(DetailData);
				if (DataCollection.Count > 0)
				{
					if (SelectedIndex != DataCollection.Count - 1)
						SelectedIndex--;
					if (SelectedIndex < 0)
						SelectedIndex = 0;

					DetailData = DataCollection[SelectedIndex];
				}
			}

			TotalRecords = DataCollection.Count;
		}
		#endregion

		#region AddData Method
		public void AddData()
		{
			// Create or Get the Manager Object
			CreateOrGetManagerObject();

			DetailData = new MusicGenre();
			DetailData.GenreId = ManagerObject.GetNextId();
			DetailData.LastUpdated = DateTime.Now;

			IsAddMode = true;
			SetUIState(EditUIState.Edit);
		}
		#endregion

		#region EditData Method
		public void EditData()
		{
			CloneCurrent();
			IsAddMode = false;
			SetUIState(EditUIState.Edit);
		}
		#endregion

		#region CancelEdit Method
		public void CancelEdit()
		{
			Undo();
			SetUIState(EditUIState.Normal);
		}
		#endregion

		#region CloneCurrent Method
		public void CloneCurrent()
		{
			if (DetailData != null)
			{
				_OriginalData = new MusicGenre();

				_OriginalData.GenreId = DetailData.GenreId;
				_OriginalData.Genre = DetailData.Genre;
			}
		}
		#endregion

		#region Undo Method
		public void Undo()
		{
			if (_OriginalData != null)
			{
				DetailData.GenreId = _OriginalData.GenreId;
				DetailData.Genre = _OriginalData.Genre;
			
			}
		}
		#endregion
	}
}
