﻿Notes:
-----------------------------------------------------
Create a SQL Server database called Music
Install the scripts located in the \SqlScripts folder
Modify the connection string in the Web.Config file to point to your server

There is a table called TablesLastUpdated
This table is not used, but there are some triggers attached to the MusicKind and MusicGenre tables that show how this table can be updated everytime a change happens in these tables
You would use this table if you did not have a "LastUpdated" datetime field on each of your tables
