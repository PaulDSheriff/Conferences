﻿using System;
using System.Windows;
using System.Windows.Controls;

using Common.Library;
using Music.DataClasses;

namespace SL_Music
{
	public partial class ucMusicKind : UserControl
	{
		#region Constructor
		public ucMusicKind()
		{
			InitializeComponent();

			// Grab the Instance of the ViewModel
			_ViewModel = (MusicKindViewModel)this.Resources["viewModel"];
		}
		#endregion

		/// <summary>
		/// The ViewModel used for all data access
		/// </summary>
		private MusicKindViewModel _ViewModel = null;

		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			_ViewModel.LoadAll();
		}

		private void btnEdit_Click(object sender, RoutedEventArgs e)
		{
			// Display the current Record
			// Clicking on the Edit button does not change the 
			// Selected Item of the list box, so we need to do that
			lstData.SelectedItem = ((Button)sender).DataContext;

			_ViewModel.EditData();
		}

		private void btnDelete_Click(object sender, RoutedEventArgs e)
		{
			// Display the current Record
			// Clicking on the Delete button does not change the 
			// Selected Item of the list box, so we need to do that
			lstData.SelectedItem = ((Button)sender).DataContext;

			if (MessageBox.Show("Delete This Kind?", "Delete?", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
				_ViewModel.Delete();
		}

		private void btnAdd_Click(object sender, RoutedEventArgs e)
		{
			_ViewModel.AddData();
		}

		private void btnSave_Click(object sender, RoutedEventArgs e)
		{
			_ViewModel.Save();
		}

		private void btnCancel_Click(object sender, RoutedEventArgs e)
		{
			_ViewModel.CancelEdit();
		}

		private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			_ViewModel.DetailData = (MusicKind)lstData.SelectedItem;
			// Clone current record in case we edit and need to cancel
			_ViewModel.CloneCurrent();
		}
	}
}
