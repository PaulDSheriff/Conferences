﻿using System.Windows;
using System.Windows.Controls;

using Common.Library;
using Music.DataClasses;

namespace SL_Music
{
	public partial class ucDelete : UserControl
	{
		public ucDelete()
		{
			InitializeComponent();
		}

		private void btnDelete_Click(object sender, RoutedEventArgs e)
		{
			DeleteFromIsolatedStorage();
		}

		private void DeleteFromIsolatedStorage()
		{
			DataXmlBaseClass mgr = null;

			mgr = new MusicGenreManager();
			mgr.DeleteLocalStorage();

			mgr = new MusicKindManager();
			mgr.DeleteLocalStorage();

			mgr = new SongManager();
			mgr.DeleteLocalStorage();
		}
	}
}
