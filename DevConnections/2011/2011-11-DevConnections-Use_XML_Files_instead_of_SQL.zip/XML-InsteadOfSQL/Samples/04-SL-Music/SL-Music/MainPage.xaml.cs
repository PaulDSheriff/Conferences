﻿using System;
using System.Windows;
using System.Windows.Controls;

using Music.DataClasses;

namespace SL_Music
{
	public partial class MainPage : UserControl
	{
		public MainPage()
		{
			InitializeComponent();
		}

		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			// Perform some checking here periodically to get new data
      //CheckMusicGenre();
      //CheckMusicKind();
		}

		private void CheckMusicGenre()
		{
			MusicGenreManager mgr = new MusicGenreManager();

			mgr.LoadAllIfNewerData();
		}

		private void CheckMusicKind()
		{
			MusicKindManager mgr = new MusicKindManager();

			mgr.LoadAllIfNewerData();
		}

		private void lstMenus_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			ListBoxItem item = (ListBoxItem)((ListBox)sender).SelectedItem;

			// Get Tag from selected item. "Tag" has the name of the control to load in it
			if (item.Tag != null)
				if (item.Tag.ToString() != string.Empty)
					LoadMenu(item.Tag.ToString());
		}

		private void LoadMenu(string controlName)
		{
			UserControl ctl = null;
			Type typ;

			if (controlName.ToLower() == "clear")
			{
				contentArea.Children.Clear();
			}
			else
			{
				// Create a Type from the controlName parameter
				typ = Type.GetType(controlName);
				// Create an instance of this control
				ctl = (UserControl)Activator.CreateInstance(typ);
				// Clear Content Area for next control
				contentArea.Children.Clear();
				contentArea.Children.Add(ctl);
			}
		}
	}
}
