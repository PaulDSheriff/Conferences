﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SL_Music.Web
{
	public class MusicKindService : IMusicKindService
	{
		public string GetMusicKindXml()
		{
			return MusicDataServices.GetXmlFromTable("MusicKind", "MusicKinds");
		}

		public string GetMusicKindXmlIfChanged(DateTime lastUpdated, int rows)
		{
			string ret = string.Empty;

			if (MusicDataServices.HasDataChanged("MusicKind", "LastUpdated", lastUpdated, rows))
				ret = GetMusicKindXml();

			return ret;
		}
	}
}
