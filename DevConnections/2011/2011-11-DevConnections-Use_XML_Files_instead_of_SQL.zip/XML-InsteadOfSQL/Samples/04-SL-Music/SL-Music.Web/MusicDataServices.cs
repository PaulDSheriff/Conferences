﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SL_Music.Web
{
	public class MusicDataServices
	{
		public static string GetXmlFromTable(string tableName, string dataSetName)
		{
			string ret = string.Empty;
			string sql = string.Empty;
			SqlDataAdapter da;
			DataSet ds = new DataSet();

			sql = "SELECT * FROM " + tableName;

			da = new SqlDataAdapter(sql, 
				ConfigurationManager.ConnectionStrings["Music"].ConnectionString);

			da.Fill(ds);

			// Create Attribute based XML
			foreach (DataColumn item in ds.Tables[0].Columns)
				item.ColumnMapping = MappingType.Attribute;

			ds.DataSetName = dataSetName;
			ds.Tables[0].TableName = tableName;
			ret = ds.GetXml();

			return ret;
		}

		public static bool HasDataChanged(string tableName, string fieldName, 
			DateTime lastUpdated, int rows)
		{
			bool ret = false;
			string sql = string.Empty;
			SqlCommand cmd = null;
			int count = 0;

			// This will check for any INSERTs or UPDATEs
			sql = "SELECT Count(*) FROM " + tableName;
      sql += " WHERE Convert(char(19), " + fieldName +
        ", 101) > Convert(char(19),Cast('" +
        Convert.ToDateTime(lastUpdated).ToString("yyyy-MM-dd HH:mm:ss tt") + "' as datetime), 101)";

			try
			{
				cmd = new SqlCommand();
				cmd.CommandText = sql;
				cmd.CommandType = CommandType.Text;
				cmd.Connection = new SqlConnection(
					ConfigurationManager.ConnectionStrings["Music"].ConnectionString);
				cmd.Connection.Open();
				count = Convert.ToInt32(cmd.ExecuteScalar());

				if (count == 0)
				{
					// This will check for any DELETEs
					cmd.CommandText = "SELECT Count(*) FROM " + tableName;
					count = Convert.ToInt32(cmd.ExecuteScalar());

					// If these are different, at least one row has been deleted
					ret = (count != rows);
				}
				else
					ret = true;
			}
			catch (Exception ex)
			{
				// Do some exception handling here
				System.Diagnostics.Debug.WriteLine(ex.ToString());
				System.Diagnostics.Debugger.Break();
			}
			finally
			{
				if (cmd != null)
				{
					if (cmd.Connection != null)
					{
						cmd.Connection.Close();
						cmd.Connection.Dispose();
					}
					cmd.Dispose();
				}
			}

			return ret;
		}
	}
}