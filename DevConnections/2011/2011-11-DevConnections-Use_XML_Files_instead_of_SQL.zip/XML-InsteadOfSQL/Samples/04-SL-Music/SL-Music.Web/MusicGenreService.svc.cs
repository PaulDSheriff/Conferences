﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SL_Music.Web
{
	public class MusicGenreService : IMusicGenreService
	{
		public string GetMusicGenreXml()
		{
			return MusicDataServices.GetXmlFromTable("MusicGenre", "MusicGenres");
		}

		public string GetMusicGenreXmlIfChanged(DateTime lastUpdated, int rows)
		{
			string ret = string.Empty;

			if(MusicDataServices.HasDataChanged("MusicGenre", "LastUpdated", lastUpdated, rows))
					ret = GetMusicGenreXml();

			return ret;
		}
	}
}
