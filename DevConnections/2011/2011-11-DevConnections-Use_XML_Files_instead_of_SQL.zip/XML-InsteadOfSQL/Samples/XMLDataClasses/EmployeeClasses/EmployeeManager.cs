﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Xml.Linq;
using Common.Library;

using XMLDataClasses.EmployeeServiceReference;

namespace XMLDataClasses
{
	public class EmployeeManager : DataXmlBaseClass
	{
		public const string FILE_NAME = "Employee.xml";
		public const string FOLDER_NAME = "Xml";
		public const string TOP_ELEMENT_NAME = "Employee";

		#region Constructors
		public EmployeeManager()
		{
			FileName = FILE_NAME;
			FolderName = FOLDER_NAME;
			FileLocation = XmlFileLocation.Project;
			TopElementName = TOP_ELEMENT_NAME;

			// Build the full path and file name to the XML file in the Project
			BuildXmlFullFileName();
		}

		/// <summary>
		/// Call this Constructor to use an XML file in local storage (Isolated, or User App Data Path)
		/// </summary>
		/// <param name="fileName">The XML File Name (no path)</param>
		public EmployeeManager(string fileName)
		{
			FileName = fileName;
			FolderName = string.Empty;
			FileLocation = XmlFileLocation.LocalStorage;
			TopElementName = TOP_ELEMENT_NAME;
			BuildXmlFullFileName();
		}

		/// <summary>
		/// Call this constructor to use an XML file in your Project (.exe) folder
		/// </summary>
		/// <param name="folderName">Optional folder name</param>
		/// <param name="fileName">The XML File Name (no path)</param>
    public EmployeeManager(string folderName, string fileName)
		{
			FileName = fileName;
			FolderName = folderName;
			TopElementName = TOP_ELEMENT_NAME;
			FileLocation = XmlFileLocation.Project;
			BuildXmlFullFileName();
		}
		#endregion

		#region DataCollection Property
		private List<Employee> _DataCollection = new List<Employee>();

		public List<Employee> DataCollection
		{
			get { return _DataCollection; }
			set
			{
				_DataCollection = value;
				RaisePropertyChanged("DataCollection");
			}
		}
		#endregion

		#region GetDataFromService Method
		EmployeeServiceClient _Client = null;

		protected override void GetDataFromService()
		{
			_Client = new EmployeeServiceClient();
			
			_Client.GetEmployeeXmlCompleted += new EventHandler<GetEmployeeXmlCompletedEventArgs>(_Client_GetEmployeeXmlCompleted);
			_Client.GetEmployeeXmlAsync();
		}

		void _Client_GetEmployeeXmlCompleted(object sender, GetEmployeeXmlCompletedEventArgs e)
		{
			XmlObject = XElement.Parse(e.Result);

			// Build Collection of Data
			BuildDataCollection();

#if SILVERLIGHT
			_Client.CloseAsync();
#else
			_Client.Close();
#endif
			_Client = null;
		}
		#endregion

		#region BuildDataCollection Method
		public override void BuildDataCollection()
		{
			if (XmlObject != null)
			{
				// Save to local storage
				Save();

				// Fill a list of Employee objects
				var coll = from elem in XmlObject.Descendants(TopElementName)
									 orderby elem.Attribute("LastName").Value
									 select new Employee
									 {
										 EmployeeID = Convert.ToInt32(GetValue(elem.Attribute("EmployeeID"), default(int))),
										 FirstName = Convert.ToString(GetValue(elem.Attribute("FirstName"), default(string))),
										 LastName = Convert.ToString(GetValue(elem.Attribute("LastName"), default(string))),
										 SSN = Convert.ToString(GetValue(elem.Attribute("SSN"), default(string)))
									 };

				// Assign to public property
				DataCollection = coll.ToList();
			}
		}
		#endregion

		#region Insert Method
		public bool Insert(Employee entity)
		{
			// Create new Employee element
			var newElem = new XElement(TopElementName,
				new XAttribute("EmployeeID", entity.EmployeeID),
				new XAttribute("FirstName", entity.FirstName),
				new XAttribute("LastName", entity.LastName),
				new XAttribute("SSN", entity.SSN));

			// Add to element collection
			XmlObject.Add(newElem);

			// Save the file
			Save(XmlObject);

			return true;
		}
		#endregion

		#region Update Method
		public bool Update(Employee entity)
		{
			// Find the product element
			var XElem = (from elem in XmlObject.Descendants(TopElementName)
									 where elem.Attribute("EmployeeID").Value == entity.EmployeeID.ToString()
									 select elem).SingleOrDefault();

			// Update the data
			XElem.Attribute("FirstName").Value = entity.FirstName;
			XElem.Attribute("LastName").Value = entity.LastName.ToString();
			XElem.Attribute("SSN").Value = entity.SSN.ToString();

			// Save the file
			Save(XmlObject);

			return true;
		}
		#endregion

		#region Delete Method
		public bool Delete(Employee entity)
		{
			// Find the product element
			var XElem = (from elem in XmlObject.Descendants(TopElementName)
									 where elem.Attribute("EmployeeID").Value == entity.EmployeeID.ToString()
									 select elem).SingleOrDefault();
			// Delete the element
			XElem.Remove();

			// Save the file
			Save(XmlObject);

			return true;
		}
		#endregion

		#region GetNextEmployeeId Method
		public int GetNextEmployeeId()
		{
			return GetNextId("EmployeeID");
		}
		#endregion

		#region GetLastUpdateDate Method
		public override DateTime GetLastUpdateDate()
		{
			// There is NO LastUpdated field in the Employee's table
			return DateTime.Now;
		}
		#endregion
	}
}