﻿using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Xml.Linq;

using Common.Library;
using XMLDataClasses;

namespace WPF_XmlStorage
{
  public partial class ucReadFromLocal : UserControl
  {
    public ucReadFromLocal()
    {
      InitializeComponent();
    }

    XElement _Elements = null;
    string _FileName = string.Empty;

    private void btnReadProject_Click(object sender, RoutedEventArgs e)
    {
      // Get File Name from Local Project
      _FileName = FileCommon.GetCurrentDirectory()
        + @"\Xml\Product.xml";

      // Read file from local project
      _Elements = XElement.Load(_FileName);

      // Create new file name to store into AppDataPath
      _FileName = FileCommon.GetUserAppDataPath() + @"\Product.xml";

      // Make sure the directory exists
      if (!Directory.Exists(Path.GetDirectoryName(_FileName)))
        Directory.CreateDirectory(Path.GetDirectoryName(_FileName));

      File.WriteAllText(_FileName, _Elements.ToString());
      MessageBox.Show("File Written: " + _FileName);
    }

    private void btnReadUserStorage_Click(object sender, RoutedEventArgs e)
    {
      if(_FileName== string.Empty)
        _FileName = FileCommon.GetUserAppDataPath() + @"\Product.xml";

      if (File.Exists(_FileName))
      {
        // Read file from local project
        _Elements = XElement.Load(_FileName);

        // Create a list of Product objects from XElement object
        var products = from prod in _Elements.Descendants("Product")
                       orderby prod.Attribute("ProductName").Value
                       select new Product
                       {
                         ProductId = Convert.ToInt32(prod.Attribute("ProductId").Value),
                         ProductName = prod.Attribute("ProductName").Value,
                         IntroductionDate = Convert.ToDateTime(prod.Attribute("IntroductionDate").Value),
                         Price = Convert.ToDecimal(prod.Attribute("Price").Value)
                       };

        lstData.DataContext = products;
      }
      else
        MessageBox.Show("File: " + _FileName + " does not exist!");
    }

    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      if (File.Exists(_FileName))
      {
        File.Delete(_FileName);

        lstData.DataContext = null;

        MessageBox.Show("Local File Deleted");
      }
    }
  }
}
