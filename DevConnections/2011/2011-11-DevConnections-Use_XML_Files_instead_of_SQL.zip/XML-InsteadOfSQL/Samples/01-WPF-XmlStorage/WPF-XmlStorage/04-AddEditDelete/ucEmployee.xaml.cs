﻿using System.Windows;
using System.Windows.Controls;
using XMLDataClasses;

namespace WPF_XmlStorage
{
	public partial class ucEmployee : UserControl
	{
		public ucEmployee()
		{
			InitializeComponent();

			_ViewModel = (EmployeeViewModel)this.Resources["viewModel"];
		}

		EmployeeViewModel _ViewModel;

		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			_ViewModel.LoadAll();
		}

		private void btnEdit_Click(object sender, RoutedEventArgs e)
		{
			// Display the current Record
			// Clicking on the Edit button does not change the 
			// Selected Item of the list box, so we need to do that
			lstData.SelectedItem = ((Button)sender).DataContext;

			_ViewModel.EditData();
		}

		private void btnDelete_Click(object sender, RoutedEventArgs e)
		{
			// Display the current Record
			// Clicking on the Delete button does not change the 
			// Selected Item of the list box, so we need to do that
			lstData.SelectedItem = ((Button)sender).DataContext;

			if (MessageBox.Show("Delete This Employee?", "Delete?", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
				_ViewModel.Delete();
		}

		private void btnAdd_Click(object sender, RoutedEventArgs e)
		{
			_ViewModel.AddData();
		}

		private void btnSave_Click(object sender, RoutedEventArgs e)
		{
			_ViewModel.Save();
		}

		private void btnCancel_Click(object sender, RoutedEventArgs e)
		{
			_ViewModel.CancelEdit();
		}

		private void TextHasChanged(object sender, TextChangedEventArgs e)
		{
			// Only Change Mode if Element has Keyboard Focus
			if (((UIElement)sender).IsKeyboardFocused)
				if (!_ViewModel.IsSaveEnabled)
					_ViewModel.SetUIState(Common.Library.EditUIState.Edit);
		}

		private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			// Clone current record in case we edit and need to cancel
			_ViewModel.CloneCurrent();
		}
	}
}
