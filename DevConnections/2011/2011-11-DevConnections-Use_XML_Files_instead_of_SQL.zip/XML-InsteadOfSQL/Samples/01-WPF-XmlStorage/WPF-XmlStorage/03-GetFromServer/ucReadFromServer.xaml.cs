﻿using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Xml.Linq;

using Common.Library;
using WPF_XmlStorage.ProductServiceReference;
using XMLDataClasses;

namespace WPF_XmlStorage
{
  public partial class ucReadFromServer : UserControl
  {
    public ucReadFromServer()
    {
      InitializeComponent();
    }

    ProductServiceClient _Client = new ProductServiceClient();
    string _FileName = string.Empty;
    XElement _Elements = null;

    #region Get Xml From Server
    private void btnRead_Click(object sender, RoutedEventArgs e)
    {
      // Hook up callback
      _Client.GetProductXmlCompleted += new EventHandler<GetProductXmlCompletedEventArgs>(_Client_GetProductXmlCompleted);
      // Call Async method on server
      _Client.GetProductXmlAsync();
    }

    void _Client_GetProductXmlCompleted(object sender, GetProductXmlCompletedEventArgs e)
    {
      // Build XElement object from e.Result
      _Elements = XElement.Parse(e.Result);
      
      // Create a list of Product objects from XElement object
      var products = from prod in _Elements.Descendants("Product")
                     orderby prod.Attribute("ProductName").Value
                     select new Product
                     {
                       ProductId = Convert.ToInt32(prod.Attribute("ProductId").Value),
                       ProductName = prod.Attribute("ProductName").Value,
                       IntroductionDate = Convert.ToDateTime(prod.Attribute("IntroductionDate").Value),
                       Price = Convert.ToDecimal(prod.Attribute("Price").Value)
                     };

      // Close WCF Connection
      _Client.Close();

      lstData.DataContext = products;
      btnSave.IsEnabled = true;
    }
    #endregion

    #region Save Methods
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      SaveToUsersLocalFile();
    }

    private void SaveToUsersLocalFile()
    {
      // Create new file name to store into AppDataPath
      _FileName = FileCommon.GetUserAppDataPath() + @"\Product.xml";

      // Make sure the directory exists
      if (!Directory.Exists(Path.GetDirectoryName(_FileName)))
        Directory.CreateDirectory(Path.GetDirectoryName(_FileName));

      File.WriteAllText(_FileName, _Elements.ToString());
      MessageBox.Show("File Written: " + _FileName);
    }
    #endregion
  }
}