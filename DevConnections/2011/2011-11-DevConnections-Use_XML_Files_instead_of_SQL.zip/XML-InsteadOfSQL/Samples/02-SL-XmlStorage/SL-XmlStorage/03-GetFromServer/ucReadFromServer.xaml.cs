﻿using System;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Xml.Linq;
using System.Windows;
using System.Windows.Controls;
using XMLDataClasses;

using SL_XmlStorage.ProductServiceReference;

namespace SL_XmlStorage
{
	public partial class ucReadFromServer : UserControl
	{
		public ucReadFromServer()
		{
			InitializeComponent();
		}

    ProductServiceClient _Client = new ProductServiceClient();
    string _FileName = @"Product.xml";
    XElement _Elements = null;

		#region Get Xml From Server
		private void btnRead_Click(object sender, RoutedEventArgs e)
		{
    // Hook up callback
      _Client.GetProductXmlCompleted += new EventHandler<GetProductXmlCompletedEventArgs>(_Client_GetProductXmlCompleted);
      // Call Async method on server
      _Client.GetProductXmlAsync();
    }

    void _Client_GetProductXmlCompleted(object sender, GetProductXmlCompletedEventArgs e)
    {
      // Build XElement object from e.Result
      _Elements = XElement.Parse(e.Result);
      
      // Create a list of Product objects from XElement object
      var products = from prod in _Elements.Descendants("Product")
                     orderby prod.Attribute("ProductName").Value
                     select new Product
                     {
                       ProductId = Convert.ToInt32(prod.Attribute("ProductId").Value),
                       ProductName = prod.Attribute("ProductName").Value,
                       IntroductionDate = Convert.ToDateTime(prod.Attribute("IntroductionDate").Value),
                       Price = Convert.ToDecimal(prod.Attribute("Price").Value)
                     };

      // Close WCF Connection
      _Client.CloseAsync();

      lstData.DataContext = products;
      btnSave.IsEnabled = true;
    }
    #endregion

    #region Save Methods
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      SaveToUsersLocalFile();
    }

    private void SaveToUsersLocalFile()
    {
      // First delete old key from Isolated Storage
      IsolatedStorageSettings.ApplicationSettings.Remove(_FileName);
      // Now save new data
      IsolatedStorageSettings.ApplicationSettings[_FileName] = _Elements.ToString();

      MessageBox.Show("XML Written to Isolated Storage");
    }
    #endregion
  }
}
