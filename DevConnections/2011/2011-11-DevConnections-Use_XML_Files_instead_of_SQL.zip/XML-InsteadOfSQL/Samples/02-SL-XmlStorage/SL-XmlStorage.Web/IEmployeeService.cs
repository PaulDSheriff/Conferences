﻿using System.ServiceModel;

namespace SL_XmlStorage.Web
{
  [ServiceContract]
  public interface IEmployeeService
  {
    [OperationContract]
    string GetEmployeeXml();
  }
}
