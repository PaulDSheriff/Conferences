﻿using System;
using System.Windows;

using TimeSheetComponentsCS;

namespace TimeSheetWPFCS
{
  public partial class winTimeSheetSample2 : Window
  {
    #region Constructor
    public winTimeSheetSample2()
    {
      InitializeComponent();
    }
    #endregion

    #region Windows Loaded Event and Cancel Event
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      _TimeValidator = (TimeSheetSample2)this.FindResource("time2");
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      this.Close();
    }
    #endregion

    private TimeSheetSample2 _TimeValidator;

    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      if (ValidateData())
      {
        MessageBox.Show("Data is Valid");
      }
      else
      {
        MessageBox.Show(_TimeValidator.Messages);
      }
    }

    private bool ValidateData()
    {
      decimal value = 0;

      // Reset messages
      _TimeValidator.Messages = string.Empty;

      // **********************************************
      //  Check Data on Form for blank entries
      // **********************************************
      if (!Utilities.IsDate(txtEntryDate.Text))
        _TimeValidator.Messages += "Entry Date is Invalid." +
          Environment.NewLine;

      if (decimal.TryParse(txtHours.Text, out value) == false)
        _TimeValidator.Messages += "Hours must be in decimal format." +
          Environment.NewLine;

      return (_TimeValidator.ValidateData());
    }
  }
}