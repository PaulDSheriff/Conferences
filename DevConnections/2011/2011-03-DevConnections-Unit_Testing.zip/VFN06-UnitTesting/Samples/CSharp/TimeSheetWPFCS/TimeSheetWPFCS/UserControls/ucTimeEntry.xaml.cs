﻿using System.Windows.Controls;

using TimeSheetComponentsCS;

namespace TimeSheetWPFCS
{
  /// <summary>
  /// Interaction logic for ucTimeEntry.xaml
  /// </summary>
  public partial class ucTimeEntry : UserControl
  {
    public ucTimeEntry()
    {
      InitializeComponent();
    }
  }
}
