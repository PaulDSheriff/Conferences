﻿using System;

namespace WPListBoxImage
{
  public class Product
  {
    #region Constructors

    public Product()
    {
    }

    public Product(string name, decimal price, string imageUri)
    {
      this.ProductName = name;
      this.Price = price;
      this.ImageUri = imageUri;
    }
    #endregion

    public string ProductName { get; set; }
    public decimal Price { get; set; }
    public string ImageUri { get; set; }
  }
}