﻿using System.Windows;
using System.Windows.Controls;

namespace SLSpice
{
  public partial class ucRightLeft : UserControl
  {
    // Create Right/Left Animation Class
    private UserControlRightLeftAnimation _Animation = null;

    public ucRightLeft()
    {
      InitializeComponent();

      // Initialize the Animation Object with the Content Area to Draw the Controls
      _Animation = new UserControlRightLeftAnimation(contentArea);
    }

    private void btnHome_Click(object sender, RoutedEventArgs e)
    {
      if (!_Animation.AnimationRunning)
        _Animation.Animate(null);
    }

    private void btnCustomers_Click(object sender, RoutedEventArgs e)
    {
      if (!_Animation.AnimationRunning)
        _Animation.Animate(new ucPage1());
    }

    private void btnInvoices_Click(object sender, RoutedEventArgs e)
    {
      if (!_Animation.AnimationRunning)
        _Animation.Animate(new ucPage2());
    }

    private void btnVendors_Click(object sender, RoutedEventArgs e)
    {
      if (!_Animation.AnimationRunning)
        _Animation.Animate(new ucPage3());
    }
  }
}
