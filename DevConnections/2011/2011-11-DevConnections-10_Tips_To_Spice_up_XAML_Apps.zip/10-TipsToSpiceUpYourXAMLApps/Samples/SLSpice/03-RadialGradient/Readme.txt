﻿0, 0 – Radiate from Left to Right
0.5, 0 – Radiate from Top to Bottom
0.5, 0.5 – Radiate from Center
1, 0.5 – Radiate from Right to Left
