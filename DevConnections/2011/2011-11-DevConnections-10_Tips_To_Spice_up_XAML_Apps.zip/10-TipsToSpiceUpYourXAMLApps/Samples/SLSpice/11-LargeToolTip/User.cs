﻿using System.Collections.Generic;
using System.Windows.Controls;

namespace SLSpice
{
  public class Users : List<User>
  {
  }

  public class User
  {
    public string UserName { get; set; }
    public string EyeColor { get; set; }
    public string HairColor { get; set; }
    public string Hobbies { get; set; }
    public string UserPicture { get; set; }
  }
}
