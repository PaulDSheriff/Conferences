﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace SLSpice
{
	public partial class ucContentUC : UserControl
	{
		public ucContentUC()
		{
			InitializeComponent();
		}

		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			this.DataContext = this;
		}

		public string Text
		{
			get { return (string)GetValue(TextProperty); }
			set { SetValue(TextProperty, value); }
		}

		// Using a DependencyProperty as the backing store for Text.  This enables animation, styling, binding, etc...
		public static readonly DependencyProperty TextProperty =
				DependencyProperty.Register("Text", typeof(string), typeof(ucContentUC),null );




		public Uri ImageUri
		{
			get { return (Uri)GetValue(ImageUriProperty); }
			set { SetValue(ImageUriProperty, value); }
		}

		// Using a DependencyProperty as the backing store for ImageUri.  This enables animation, styling, binding, etc...
		public static readonly DependencyProperty ImageUriProperty =
				DependencyProperty.Register("ImageUri", typeof(Uri), typeof(ucContentUC), null);




		public string ToolTip
		{
			get { return (string)GetValue(ToolTipProperty); }
			set { SetValue(ToolTipProperty, value); }
		}

		// Using a DependencyProperty as the backing store for ToolTip.  This enables animation, styling, binding, etc...
		public static readonly DependencyProperty ToolTipProperty =
				DependencyProperty.Register("ToolTip", typeof(string), typeof(ucContentUC), null);

	}
}
