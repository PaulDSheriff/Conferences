﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace SLSpice
{
  public partial class ucButtonGradient : UserControl
  {
    public ucButtonGradient()
    {
      InitializeComponent();
    }

    #region Loaded Event
    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      this.DataContext = this;
    }
    #endregion

    #region Text Property
    public string Text
    {
      get { return (string)GetValue(TextProperty); }
      set { SetValue(TextProperty, value); }
    }

    // Using a DependencyProperty as the backing store for Text.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty TextProperty =
        DependencyProperty.Register("Text", typeof(string), typeof(ucButtonGradient), null);
    #endregion

    private void Border_MouseEnter(object sender, MouseEventArgs e)
    {
      borMenu.Background = (RadialGradientBrush)this.Resources["radialBrushTeal"];
    }

    private void Border_MouseLeave(object sender, MouseEventArgs e)
    {
      borMenu.Background = (LinearGradientBrush)this.Resources["linearBrushTealMultipleStops"];
    }
  }
}
