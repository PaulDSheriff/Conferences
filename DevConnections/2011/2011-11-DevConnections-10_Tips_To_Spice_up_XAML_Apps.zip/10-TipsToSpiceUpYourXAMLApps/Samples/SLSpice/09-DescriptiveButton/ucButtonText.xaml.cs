﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SLSpice
{
  public partial class ucButtonText : UserControl
  {
    public ucButtonText()
    {
      InitializeComponent();

      this.DataContext = this;
    }

    #region ButtonText Property
    public string ButtonText
    {
      get { return (string)GetValue(ButtonTextProperty); }
      set { SetValue(ButtonTextProperty, value); }
    }

    // Using a DependencyProperty as the backing store for ButtonText.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty ButtonTextProperty =
        DependencyProperty.Register("ButtonText", typeof(string), typeof(ucButtonText), null);
    #endregion

    #region ButtonLongText Property
    public string ButtonLongText
    {
      get { return (string)GetValue(ButtonLongTextProperty); }
      set { SetValue(ButtonLongTextProperty, value); }
    }

    // Using a DependencyProperty as the backing store for ButtonText.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty ButtonLongTextProperty =
        DependencyProperty.Register("ButtonLongText", typeof(string), typeof(ucButtonText), null);
    #endregion
    
    #region Animation/Storyboards
    Storyboard sb;

    private void Border_MouseEnter(object sender, MouseEventArgs e)
    {
      sb = (Storyboard)this.Resources["ScaleUpStory"];
      sb.Stop();
      sb.Begin();
    }

    private void borMenu_MouseLeave(object sender, MouseEventArgs e)
    {
      sb = (Storyboard)this.Resources["ScaleDownStory"];
      sb.Stop();
      sb.Begin();
    }
    #endregion
  }
}
