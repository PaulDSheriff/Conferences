﻿Imports SLData_Simple.ProductServiceReference

Partial Public Class MainPage
  Inherits UserControl

  Public Sub New()
    InitializeComponent()
  End Sub

  Private Sub btnLoad_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnLoad.Click
    Dim client As New ProductServiceClient()

    AddHandler client.GetProductsCompleted, AddressOf client_GetProductsCompleted

    client.GetProductsAsync()
    client.CloseAsync()
  End Sub

  Private Sub client_GetProductsCompleted(ByVal sender As Object, ByVal e As GetProductsCompletedEventArgs)
    lstData.DataContext = e.Result
  End Sub
End Class