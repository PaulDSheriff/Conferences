﻿Imports System.Data.SqlClient

' NOTE: You can use the "Rename" command on the context menu to change the class name "ProductService" in code, svc and config file together.
Public Class ProductService
    Implements IProductService

  Public Function GetProducts() As Products Implements IProductService.GetProducts
    Dim dt As New DataTable()
    Dim ret As New Products()
    Dim da As SqlDataAdapter

		da = New SqlDataAdapter( _
   "SELECT ProductName FROM Product", _
    "Server=Localhost;Database=Sandbox;Integrated Security=Yes")

    da.Fill(dt)

    For Each dr As DataRow In dt.Rows
      ret.Add(New Product( _
            dr("ProductName").ToString()))
    Next

    Return ret

  End Function

End Class
