﻿using System;
using System.Runtime.Serialization;

namespace Sandbox.Services
{
  [DataContract]
  public class RequestBase
  {
    public RequestBase()
    {
      CustomSearchName = string.Empty;
    }

    [DataMember]
    public string CustomSearchName { get; set; }
  }
}
