﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Sandbox.Services
{
  [ServiceContract(Namespace = "http://PDSA.SLData")]
  public interface IProductServices
  {
    [OperationContract]
    ProductResponse GetProduct(int productId);

    [OperationContract]
    ProductResponse GetAllProducts();

    [OperationContract]
    ProductResponse Update(Product prod);

    [OperationContract]
    ProductResponse Insert(Product prod);

    [OperationContract]
    ProductResponse Delete(int productId);

    [OperationContract]
    ProductResponse ProductSearch(ProductRequestSearch search);
  }
}