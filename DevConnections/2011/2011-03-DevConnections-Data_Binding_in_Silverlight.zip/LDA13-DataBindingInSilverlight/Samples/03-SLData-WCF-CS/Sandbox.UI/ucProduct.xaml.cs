﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using Sandbox.UI.SandboxServicesHost;

namespace Sandbox.UI
{
  public partial class ucProduct : UserControl
  {
    public ucProduct()
    {
      InitializeComponent();
    }
    
    #region GetProduct Methods
    private void btnGetProduct_Click(object sender, RoutedEventArgs e)
    {
      ProductServicesClient client = new ProductServicesClient();
      client.GetProductCompleted += new EventHandler<GetProductCompletedEventArgs>(client_GetProductCompleted);
      client.GetProductAsync(Convert.ToInt32(txtProductId.Text));
      client.CloseAsync();
    }

    void client_GetProductCompleted(object sender, GetProductCompletedEventArgs e)
    {
      switch (e.Result.Status)
      {
        case OperationResult.Success:
        this.DataContext = e.Result.DetailData;
          break;
        case OperationResult.Exception:
          tbMessage.Text = e.Result.ErrorMessage;
          break;
        case OperationResult.Failure:
          tbMessage.Text = e.Result.FriendlyErrorMessage;
          break;
      }
    }
    #endregion

    #region Update Methods
    private void btnUpdate_Click(object sender, RoutedEventArgs e)
    {
      ProductServicesClient client = new ProductServicesClient();
      client.UpdateCompleted += new EventHandler<UpdateCompletedEventArgs>(client_UpdateCompleted);
      client.UpdateAsync((Product)this.DataContext);
      client.CloseAsync();
    }

    void client_UpdateCompleted(object sender, UpdateCompletedEventArgs e)
    {
      switch (e.Result.Status)
      {
        case OperationResult.Success:
          tbMessage.Text = e.Result.FriendlyErrorMessage;
          break;
        case OperationResult.Exception:
          tbMessage.Text = e.Result.ErrorMessage;
          break;
      }
    }
    #endregion

    #region Insert Methods
    private void btnInsert_Click(object sender, RoutedEventArgs e)
    {
      ProductServicesClient client = new ProductServicesClient();
      client.InsertCompleted += new EventHandler<InsertCompletedEventArgs>(client_InsertCompleted);
      client.InsertAsync((Product)this.DataContext);
      client.CloseAsync();
    }

    void client_InsertCompleted(object sender, InsertCompletedEventArgs e)
    {
      switch (e.Result.Status)
      {
        case OperationResult.Success:
          tbMessage.Text = e.Result.FriendlyErrorMessage;
          break;
        case OperationResult.Exception:
          tbMessage.Text = e.Result.ErrorMessage;
          break;
      }
    }
    #endregion

    #region Delete Methods
    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      ProductServicesClient client = new ProductServicesClient();
      client.DeleteCompleted += new EventHandler<DeleteCompletedEventArgs>(client_DeleteCompleted);
      client.DeleteAsync(Convert.ToInt32(txtProductId.Text));
      client.CloseAsync();
    }

    void client_DeleteCompleted(object sender, DeleteCompletedEventArgs e)
    {
      switch (e.Result.Status)
      {
        case OperationResult.Success:
          tbMessage.Text = e.Result.FriendlyErrorMessage;
          break;
        case OperationResult.Exception:
          tbMessage.Text = e.Result.ErrorMessage;
          break;
      }
    }
    #endregion
  }
}
