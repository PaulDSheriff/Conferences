﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Sandbox.UI
{
  public partial class ucMain : UserControl
  {
    public ucMain()
    {
      InitializeComponent();
    }

    #region LoadUserControl Method
    private void LoadUserControl(UserControl uc)
    {
      this.Content = uc;
    }
    #endregion

    private void btnGetAProduct_Click(System.Object sender, System.Windows.RoutedEventArgs e)
    {
      LoadUserControl(new ucProduct());
    }

    private void btnProductList_Click(System.Object sender, System.Windows.RoutedEventArgs e)
    {
      LoadUserControl(new ucProductList());
    }

    private void btnProductSearch_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucProductSearch());
    }
  }
}
