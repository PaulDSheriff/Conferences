﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MVVMSample1_Web_CS
{
  public partial class SearchSamplePage : System.Web.UI.Page
  {
    #region ViewModel in View State
    private SearchViewModel _ViewModel = null;

    private SearchViewModel ViewModel
    {
      get
      {
        if (_ViewModel == null)
          if (ViewState["viewModel"] == null)
          {
            _ViewModel = new SearchViewModel();
            ViewState["viewModel"] = _ViewModel;
          }
          else
            _ViewModel = (SearchViewModel)ViewState["viewModel"];

        return _ViewModel;
      }
      set
      {
        ViewState["viewModel"] = value;
      }
    }
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
        FormShow();
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
      GetData();

      ViewModel.Search();
      lblMessage.Visible = ViewModel.IsMessageVisible;
      lblMessage.Text = ViewModel.MessageToDisplay;
    }

    private void FormShow()
    {
      txtStartDate.Text = ViewModel.StartDate.ToShortDateString();
      txtEndDate.Text = ViewModel.EndDate.ToShortDateString();
    }

    private void GetData()
    {
      ViewModel.StartDate = Convert.ToDateTime(txtStartDate.Text);
      ViewModel.EndDate = Convert.ToDateTime(txtEndDate.Text);
    }
  }
}