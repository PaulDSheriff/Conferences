﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MVVMSample1_Web_CS
{
  public partial class PersonSamplePage : System.Web.UI.Page
  {
    #region ViewModel in View State
    private PersonViewModel _ViewModel = null;

    private PersonViewModel ViewModel
    {
      get
      {
        if (_ViewModel == null)
          if (ViewState["viewModel"] == null)
          {
            _ViewModel = new PersonViewModel();
            ViewState["viewModel"] = _ViewModel;
          }
          else
            _ViewModel = (PersonViewModel)ViewState["viewModel"];

        return _ViewModel;
      }
      set
      {
        ViewState["viewModel"] = value;
      }
    }
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
        FormShow();
    }

    protected void btnValidate_Click(object sender, EventArgs e)
    {
      GetData();

      lblMessage.Visible = false;
      lblMessage.Text = string.Empty;
      ViewModel.Validate();
      lblMessage.Visible = ViewModel.IsMessageVisible;
      lblMessage.Text = ViewModel.MessageToDisplay;
    }
    
    private void FormShow()
    {
      txtFirstName.Text = ViewModel.DetailData.FirstName;
      txtLastName.Text = ViewModel.DetailData.LastName;
      txtBirthDate.Text = ViewModel.DetailData.BirthDate.ToShortDateString();
    }

    private void GetData()
    {
      ViewModel.DetailData.FirstName = txtFirstName.Text;
      ViewModel.DetailData.LastName = txtLastName.Text;
      ViewModel.DetailData.BirthDate = Convert.ToDateTime(txtBirthDate.Text);
    }
  }
}