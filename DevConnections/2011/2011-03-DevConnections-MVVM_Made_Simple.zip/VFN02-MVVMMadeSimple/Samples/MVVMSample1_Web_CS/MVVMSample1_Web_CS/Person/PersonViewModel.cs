﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVVMSample1_Web_CS
{
  [Serializable()]
  public class PersonViewModel : ViewModelBase
  {
    #region Constructor
    public PersonViewModel()
    {
      DetailData = new Person();
    }
    #endregion

    #region Public Properties
    public Person DetailData { get; set;}
    #endregion
    
    #region Validate Method
    public bool Validate()
    {
      IsMessageVisible = false;
      MessageToDisplay = string.Empty;

      if (DetailData.Validate() == false)
      {
        IsMessageVisible = true;
        MessageToDisplay = DetailData.BusinessRuleFailures.ToString();
      }

      return !IsMessageVisible;
    }
    #endregion
  }
}
