﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace MVVMSample1_Web_CS
{
  [Serializable()]
  public class DataClassBase : CommonBase
  {
    public DataClassBase()
    {
      BusinessRuleFailures = new BusinessRuleMessages();
    }

    public BusinessRuleMessages BusinessRuleFailures { get; set; }
  }
}
