﻿using System;
using System.ComponentModel;

namespace MVVMSample1_Web_CS
{
  [Serializable()]
  public class CommonBase
  {
    #region Constructors
    /// <summary>
    /// Constructor for the CommonBase class.
    /// </summary>
    protected CommonBase()
    {
    }
    #endregion
  }
}
