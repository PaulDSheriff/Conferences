﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVVMSample1_Web_CS
{
  [Serializable()]
  public class ViewModelBase : CommonBase
  {
    public string MessageToDisplay { get; set; }
    public bool IsMessageVisible { get; set; }
  }
}
