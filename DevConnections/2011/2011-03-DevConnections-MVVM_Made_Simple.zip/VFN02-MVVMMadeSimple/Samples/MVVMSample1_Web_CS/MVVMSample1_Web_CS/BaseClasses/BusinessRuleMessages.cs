﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVVMSample1_Web_CS
{
  [Serializable()]
  public class BusinessRuleMessages : List<BusinessRuleMessage>
  {
    #region ToString method
    public override string ToString()
    {
      return ToString("<br />");
    }

    public string ToString(string delimiter)
    {
      StringBuilder sb = new StringBuilder(1024);

      foreach (BusinessRuleMessage item in this)
      {
        sb.Append(item.Message + delimiter);
      }

      return sb.ToString();
    }
    #endregion
  }
}
