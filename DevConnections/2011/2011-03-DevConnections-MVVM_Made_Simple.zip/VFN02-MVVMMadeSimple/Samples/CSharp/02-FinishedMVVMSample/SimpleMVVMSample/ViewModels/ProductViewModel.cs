﻿using System.Collections.ObjectModel;
using System.Windows;

using WPFDataLayer;
using WPFEntityLayer;

namespace WPFViewModels
{
  public class ProductViewModel : ViewModelBase
  {
    #region Constructor
    public ProductViewModel()
    {
      // Make sure GetProducts has great exception handling!
      DataCollection = _DataManager.GetProducts();
    }
    #endregion

    #region Private Variables
    ProductManager _DataManager = new ProductManager();
    #endregion

    #region DataCollection Property
    private ObservableCollection<Product> _DataCollection = null;

    public ObservableCollection<Product> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region DetailData Property
    private Product _DetailData = null;

    public Product DetailData
    {
      get { return _DetailData; }
      set
      {
        _DetailData = value;
        RaisePropertyChanged("DetailData");
      }
    }
    #endregion

    #region AddRecord Method
    public void AddRecord()
    {
      SetViewStateMode(UIStateMode.Add);

      // Create Empty Object for UI to Display
      DetailData = new Product();
    }
    #endregion

    #region CancelEdit Method
    public void CancelEdit()
    {
      SetViewStateMode(UIStateMode.Cancel);

      // TODO: Write Code to Undo Here
    }
    #endregion

    #region SaveData Method
    public void SaveData()
    {
      if (IsAddMode)
      {
        _DataManager.Insert(DetailData);
        DataCollection.Add(DetailData);
        SetViewStateMode(UIStateMode.Normal);
      }
      else
      {
        _DataManager.Update(DetailData);
        SetViewStateMode(UIStateMode.Normal);
      }
    }
    #endregion

    #region DeleteData Method
    public void DeleteData()
    {
      _DataManager.Delete(DetailData);
      DataCollection.Remove(DetailData);
      SetViewStateMode(UIStateMode.Normal);
    }
    #endregion
  }
}
