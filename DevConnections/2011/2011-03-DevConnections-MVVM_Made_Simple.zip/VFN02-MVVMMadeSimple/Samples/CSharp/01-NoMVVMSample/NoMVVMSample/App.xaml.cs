﻿using System.Windows;

namespace NoMVVMSample
{
  public partial class App : Application
  {
  }
}
