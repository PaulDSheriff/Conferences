﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;

namespace NoMVVMSample
{
  public partial class winMoreDataBinding : Window, INotifyPropertyChanged
  {
    ProductManager _DataManager;
    bool _IsAddMode = false;

    #region INotifyPropertyChanged
    public event PropertyChangedEventHandler PropertyChanged;

    protected void RaisePropertyChanged(string propertyName)
    {
      if (PropertyChanged != null)
        PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
    }
    #endregion

    #region Constructor
    public winMoreDataBinding()
    {
      InitializeComponent();
    }
    #endregion

    #region Private UI Variables
    private bool _IsSaveEnabled = false;
    private bool _IsCancelEnabled = false;
    private bool _IsAddEnabled = true;
    #endregion

    #region UI Properties
    public bool IsSaveEnabled
    {
      get { return _IsSaveEnabled; }
      set
      {
        if (_IsSaveEnabled != value)
        {
          _IsSaveEnabled = value;
          RaisePropertyChanged("IsSaveEnabled");
        }
      }
    }

    public bool IsCancelEnabled
    {
      get { return _IsCancelEnabled; }
      set
      {
        if (_IsCancelEnabled != value)
        {
          _IsCancelEnabled = value;
          RaisePropertyChanged("IsCancelEnabled");
        }
      }
    }

    public bool IsAddEnabled
    {
      get { return _IsAddEnabled; }
      set
      {
        if (_IsAddEnabled != value)
        {
          _IsAddEnabled = value;
          RaisePropertyChanged("IsAddEnabled");
        }
      }
    }
    #endregion

    #region Loaded Event
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      _DataManager = new ProductManager();

      lstData.DataContext = _DataManager.GetProducts();
    }
    #endregion

    #region Add Click Event
    private void btnAdd_Click(object sender, RoutedEventArgs e)
    {
      // Create blank Object and Put UI into Add Mode
      // Put UI into Add Mode
      _IsAddMode = true;
      SetEditUIDisplay();

      grdDetail.DataContext = new Product();
    }

     #endregion

    #region Cancel Click Event
    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      // Cancel the Edit
      SetNormalUIDisplay();

      // TODO: Write code to undo changes

      lstData.SelectedIndex = 0;
    }
    #endregion

    #region Save Click Event
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      if (_IsAddMode)
        AddData();
      else
        UpdateData();

      SetNormalUIDisplay();
    }
    #endregion

    #region AddData Method
    private void AddData()
    {
      // Save the Current Item
      ProductManager mgr = new ProductManager();
      Product entity = (Product)grdDetail.DataContext;

      ObservableCollection<Product> coll = (ObservableCollection<Product>)lstData.DataContext;
      coll.Add(entity);

      // Save Data
      mgr.Update(entity);
    }
    #endregion

    #region UpdateData Method
    private void UpdateData()
    {
      ProductManager mgr = new ProductManager();
      Product entity = (Product)lstData.SelectedItem;

      // Save Data
      mgr.Update(entity);
    }
    #endregion

    #region SetNormalUIDisplay Method
    private void SetNormalUIDisplay()
    {
      _IsAddMode = false;
      IsAddEnabled = true;
      IsSaveEnabled = false;
      IsCancelEnabled = false;
    }
    #endregion

    #region SetEditUIDisplay Method
    private void SetEditUIDisplay()
    {
      IsAddEnabled = false;
      IsSaveEnabled = true;
      IsCancelEnabled = true;
    }
    #endregion

    #region Data Has Changed Methods
    private void TextHasChanged(object sender, TextChangedEventArgs e)
    {
      // Only Change Mode if Element has Keyboard Focus
      if (((UIElement)sender).IsKeyboardFocused)
        SetEditUIDisplay();
    }

    private void CheckedHasChanged(object sender, RoutedEventArgs e)
    {
      if (((UIElement)sender).IsKeyboardFocused || ((UIElement)sender).IsMouseDirectlyOver)
        SetEditUIDisplay();
    }
    #endregion
  }
}
