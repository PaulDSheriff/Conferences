﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace NoMVVMSample
{
  public partial class winNoBinding : Window
  {
    bool _IsAddMode = false;

    #region Constructor
    public winNoBinding()
    {
      InitializeComponent();
    }
    #endregion

    #region Loaded Event
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      ProductManager mgr = new ProductManager();

      lstData.DataContext = mgr.GetProducts();
    }
    #endregion

    #region SelectionChanged Event
    private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      Product entity;
      entity = (Product)lstData.SelectedItem;

      txtProductId.Text = entity.ProductId.ToString();
      txtProductName.Text = entity.ProductName;
      txtPrice.Text = entity.Price.ToString();
      chkIsActive.IsChecked = entity.IsActive;
    }
    #endregion

    #region Add Click Event
    private void btnAdd_Click(object sender, RoutedEventArgs e)
    {
      // Put UI into Add Mode
      _IsAddMode = true;
      SetEditUIDisplay();

      // Create empty input fields
      txtProductId.Text = "0";
      txtProductName.Text = string.Empty;
      txtPrice.Text = "0";
      chkIsActive.IsChecked = true;
    }
    #endregion

    #region Cancel Click Event
    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      // Cancel the Edit
      SetNormalUIDisplay();

      // TODO: Write code to undo changes

      lstData.SelectedIndex = 0;
    }
    #endregion

    #region Save Click Event
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      if (_IsAddMode)
        AddData();
      else
        UpdateData();

      SetNormalUIDisplay();
    }
    #endregion

    #region AddData Method
    private void AddData()
    {
      // Save the Current Item
      ProductManager mgr = new ProductManager();
      Product entity = new Product();

      entity.ProductId = Convert.ToInt32(txtProductId.Text);
      entity.ProductName = txtProductName.Text;
      entity.Price = Convert.ToDecimal(txtPrice.Text);
      entity.IsActive = Convert.ToBoolean(chkIsActive.IsChecked);

      ObservableCollection<Product> coll = (ObservableCollection<Product>)lstData.DataContext;
      coll.Add(entity);

      // Save Data
      mgr.Insert(entity);
    }
    #endregion

    #region UpdateData Method
    private void UpdateData()
    {
      Product entity = (Product)lstData.SelectedItem;
      ProductManager mgr = new ProductManager();

      entity.ProductId = Convert.ToInt32(txtProductId.Text);
      entity.ProductName = txtProductName.Text;
      entity.Price = Convert.ToDecimal(txtPrice.Text);
      entity.IsActive = Convert.ToBoolean(chkIsActive.IsChecked);

      // Save Data
      mgr.Update(entity);
    }
    #endregion

    #region SetNormalUIDisplay Method
    private void SetNormalUIDisplay()
    {
      _IsAddMode = false;
      btnAdd.IsEnabled = true;
      btnSave.IsEnabled = false;
      btnCancel.IsEnabled = false;
    }
    #endregion

    #region SetEditUIDisplay Method
    private void SetEditUIDisplay()
    {
      btnAdd.IsEnabled = false;
      btnSave.IsEnabled = true;
      btnCancel.IsEnabled = true;
    }
    #endregion

    #region Data Has Changed Methods
    private void TextHasChanged(object sender, TextChangedEventArgs e)
    {
      // Only Change Mode if Element has Keyboard Focus
      if (((UIElement)sender).IsKeyboardFocused)
        SetEditUIDisplay();
    }

    private void CheckedHasChanged(object sender, RoutedEventArgs e)
    {
      if (((UIElement)sender).IsKeyboardFocused || ((UIElement)sender).IsMouseDirectlyOver)
        SetEditUIDisplay();
    }
    #endregion
  }
}