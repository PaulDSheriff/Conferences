﻿using System.Windows;

namespace MVVMSample1
{
  /// <summary>
  /// Interaction logic for winPerson.xaml
  /// </summary>
  public partial class winPerson : Window
  {
    PersonViewModel _ViewModel;

    public winPerson()
    {
      InitializeComponent();
      
      // Grab instance of View Model from XAML
      _ViewModel = (PersonViewModel)this.Resources["viewModel"];
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.Validate();
    }
  }
}
