﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVVMSample1
{
  public class BusinessRuleMessage
  {
    #region Constructors
    public BusinessRuleMessage()
    {
    }

    public BusinessRuleMessage(string propertyName, string message)
    {
      PropertyName = propertyName;
      Message = message;
    }
    #endregion

    #region Public Properties
    public string PropertyName { get; set; }
    public string Message { get; set; }
    #endregion
  }
}
