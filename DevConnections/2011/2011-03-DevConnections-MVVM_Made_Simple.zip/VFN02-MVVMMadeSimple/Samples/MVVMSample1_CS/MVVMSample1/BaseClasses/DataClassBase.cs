﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace MVVMSample1
{
  public class DataClassBase : CommonBase
  {
    public DataClassBase()
    {
      _BusinessRuleFailures = new BusinessRuleMessages();
    }

    private BusinessRuleMessages _BusinessRuleFailures;

    public BusinessRuleMessages BusinessRuleFailures
    {
      get { return _BusinessRuleFailures; }
      set
      {
        _BusinessRuleFailures = value;
        RaisePropertyChanged("BusinessRuleFailures");
      }
    }
  }
}
