﻿Imports System.Collections.ObjectModel 
Imports System.Windows

Public Class ProductViewModel
  Inherits ViewModelBase

#Region "Constructor"
  Public Sub New()
    ' Make sure GetProducts has great exception handling! 
    DataCollection = _DataManager.GetProducts()
  End Sub
#End Region

#Region "Private Variables"
  Private _DataManager As New ProductManager()
#End Region

#Region "DataCollection Property"
  Private mDataCollection As ObservableCollection(Of Product)

  Public Property DataCollection() As ObservableCollection(Of Product)
    Get
      Return mDataCollection
    End Get
    Set(ByVal value As ObservableCollection(Of Product))
      mDataCollection = value
      RaisePropertyChanged("DataCollection")
    End Set
  End Property
#End Region

#Region "DetailData Property"
  Private mDetailData As Product

  Public Property DetailData() As Product
    Get
      Return mDetailData
    End Get
    Set(ByVal value As Product)
      mDetailData = value
      RaisePropertyChanged("DetailData")
    End Set
  End Property
#End Region

#Region "AddRecord Method"
  Public Sub AddRecord()
    SetViewStateMode(UIStateMode.Add)

    ' Create Empty Object for UI to Display 
    DetailData = New Product()
  End Sub
#End Region

#Region "CancelEdit Method"
  Public Sub CancelEdit()

    ' TODO: Write Code to Undo Here 
    SetViewStateMode(UIStateMode.Cancel)
  End Sub
#End Region

#Region "SaveData Method"
  Public Sub SaveData()
    If IsAddMode Then
      _DataManager.Insert(DetailData)
      DataCollection.Add(DetailData)
      SetViewStateMode(UIStateMode.Normal)
    Else
      _DataManager.Update(DetailData)
      SetViewStateMode(UIStateMode.Normal)
    End If
  End Sub
#End Region

#Region "DeleteData Method"
  Public Sub DeleteData()
    _DataManager.Delete(DetailData)
    DataCollection.Remove(DetailData)
    SetViewStateMode(UIStateMode.Normal)
  End Sub
#End Region
End Class