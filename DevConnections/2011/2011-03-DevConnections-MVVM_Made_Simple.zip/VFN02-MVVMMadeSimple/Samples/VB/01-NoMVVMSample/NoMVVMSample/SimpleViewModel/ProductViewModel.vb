﻿Imports System.Collections.ObjectModel
Imports System.ComponentModel

Public Class ProductViewModel
  Implements INotifyPropertyChanged

  Private mIsAddMode As Boolean = False
  Private mDataManager As New ProductManager()

#Region "Constructor - Initialize Product Data Collection"
  Public Sub New()
    DataCollection = mDataManager.GetProducts()
  End Sub
#End Region

#Region "INotifyPropertyChanged"
  Public Event PropertyChanged As PropertyChangedEventHandler Implements INotifyPropertyChanged.PropertyChanged

  Protected Sub RaisePropertyChanged(ByVal propertyName As String)
    RaiseEvent PropertyChanged(Me, New PropertyChangedEventArgs(propertyName))
  End Sub
#End Region

#Region "Private UI Variables"
  Private _IsSaveEnabled As Boolean = False
  Private _IsCancelEnabled As Boolean = False
  Private _IsAddEnabled As Boolean = True
#End Region

#Region "UI Properties"
  Public Property IsSaveEnabled() As Boolean
    Get
      Return _IsSaveEnabled
    End Get
    Set(ByVal value As Boolean)
      If _IsSaveEnabled <> value Then
        _IsSaveEnabled = value
        RaisePropertyChanged("IsSaveEnabled")
      End If
    End Set
  End Property

  Public Property IsCancelEnabled() As Boolean
    Get
      Return _IsCancelEnabled
    End Get
    Set(ByVal value As Boolean)
      If _IsCancelEnabled <> value Then
        _IsCancelEnabled = value
        RaisePropertyChanged("IsCancelEnabled")
      End If
    End Set
  End Property

  Public Property IsAddEnabled() As Boolean
    Get
      Return _IsAddEnabled
    End Get
    Set(ByVal value As Boolean)
      If _IsAddEnabled <> value Then
        _IsAddEnabled = value
        RaisePropertyChanged("IsAddEnabled")
      End If
    End Set
  End Property

  Public Property IsAddMode() As Boolean
    Get
      Return mIsAddMode
    End Get
    Set(ByVal value As Boolean)
      If mIsAddMode <> value Then
        mIsAddMode = value
        RaisePropertyChanged("IsAddMode")
      End If
    End Set
  End Property
#End Region

#Region "DataCollection Property"
  Private mDataCollection As ObservableCollection(Of Product)

  Public Property DataCollection() As ObservableCollection(Of Product)
    Get
      Return mDataCollection
    End Get
    Set(ByVal value As ObservableCollection(Of Product))
      mDataCollection = value
      RaisePropertyChanged("DataCollection")
    End Set
  End Property
#End Region

#Region "DetailData Property"
  Private mDetailData As Product

  Public Property DetailData() As Product
    Get
      Return mDetailData
    End Get
    Set(ByVal value As Product)
      mDetailData = value
      RaisePropertyChanged("DetailData")
    End Set
  End Property
#End Region

#Region "SetNormalUIDisplay Method"
  Public Sub SetNormalUIDisplay()
    IsAddMode = False
    IsAddEnabled = True
    IsSaveEnabled = False
    IsCancelEnabled = False
  End Sub
#End Region

#Region "SetEditUIDisplay Method"
  Public Sub SetEditUIDisplay()
    IsAddEnabled = False
    IsSaveEnabled = True
    IsCancelEnabled = True
  End Sub
#End Region

#Region "AddRecord Method"
  Public Sub AddRecord()
    SetEditUIDisplay()
    IsAddMode = True

    ' Create Empty Object for UI to Display 
    DetailData = New Product()
  End Sub
#End Region

#Region "CancelEdit Method"
  Public Sub CancelEdit()

    ' TODO: Write Code to Undo Here 
    SetNormalUIDisplay()
  End Sub
#End Region

#Region "SaveData Method"
  Public Sub SaveData()
    If IsAddMode Then
      mDataManager.Insert(DetailData)
      DataCollection.Add(DetailData)
    Else
      mDataManager.Update(DetailData)
    End If
    SetNormalUIDisplay()
  End Sub
#End Region

#Region "DeleteData Method"
  Public Sub DeleteData()
    mDataManager.Delete(DetailData)
    DataCollection.Remove(DetailData)
    SetNormalUIDisplay()
  End Sub
#End Region
End Class