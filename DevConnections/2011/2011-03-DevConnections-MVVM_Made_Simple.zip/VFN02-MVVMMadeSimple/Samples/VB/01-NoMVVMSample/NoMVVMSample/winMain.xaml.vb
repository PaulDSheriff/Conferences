﻿Imports System.Windows

Partial Public Class winMain
  Inherits Window
  Public Sub New()
    InitializeComponent()
  End Sub

  Private Sub btnNoBinding_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim win As New winNoBinding()

    win.Show()
  End Sub

  Private Sub btnBasicBinding_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim win As New winBasicDataBinding()

    win.Show()
  End Sub

  Private Sub btnOtherBinding_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim win As New winMoreDataBinding()

    win.Show()
  End Sub

  Private Sub btnSimpleMVVM_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim win As New winSimpleMVVM()

    win.Show()
  End Sub
End Class