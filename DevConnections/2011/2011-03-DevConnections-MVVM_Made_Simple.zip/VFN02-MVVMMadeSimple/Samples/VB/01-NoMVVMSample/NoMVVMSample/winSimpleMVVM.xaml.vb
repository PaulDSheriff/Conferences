﻿Imports System.Windows
Imports System.Windows.Controls

Partial Public Class winSimpleMVVM
  Inherits Window

  Private mViewModel As ProductViewModel

#Region "Constructor"
  Public Sub New()
    InitializeComponent()

    ' Initialize the Product View Model Object 
    mViewModel = DirectCast(Me.FindResource("viewModel"), ProductViewModel)

    ' For some reason, the ListView is not Selected, so Select it 
    lstData.SelectedIndex = 0
  End Sub
#End Region

#Region "Add Click Event"
  Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    mViewModel.AddRecord()
  End Sub
#End Region

#Region "Cancel Click Event"
  Private Sub btnCancel_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    mViewModel.CancelEdit()

    ' TODO: Write code to undo changes 

    lstData.SelectedIndex = 0
  End Sub
#End Region

#Region "Save Click Event"
  Private Sub btnSave_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    mViewModel.SaveData()
  End Sub
#End Region

#Region "Data Has Changed Methods"
  Private Sub TextHasChanged(ByVal sender As Object, ByVal e As TextChangedEventArgs)
    ' Only Change Mode if Element has Keyboard Focus 
    If DirectCast(sender, UIElement).IsKeyboardFocused Then
      mViewModel.SetEditUIDisplay()
    End If
  End Sub

  Private Sub CheckedHasChanged(ByVal sender As Object, ByVal e As RoutedEventArgs)
    If DirectCast(sender, UIElement).IsKeyboardFocused OrElse DirectCast(sender, UIElement).IsMouseDirectlyOver Then
      mViewModel.SetEditUIDisplay()
    End If
  End Sub
#End Region
End Class