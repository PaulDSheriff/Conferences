﻿using System;
using System.Windows.Controls;

namespace SLNavigationIdeas
{
  public class MenuEventArgs : EventArgs
  {
    public MenuEventArgs()
    {
      UserControlToLoad = null;
      IsMenu = true;
    }

    public MenuEventArgs(UserControl uc)
    {
      UserControlToLoad = uc;
      IsMenu = true;
    }

    public MenuEventArgs(UserControl uc, bool isMenu)
    {
      UserControlToLoad = uc;
      IsMenu = isMenu;
    }

    public UserControl UserControlToLoad { get; set; }
    public bool IsMenu { get; set; }
    public string HeaderText { get; set; }
    public string MenuText { get; set; }
    public string ImageUri { get; set; }
  }
}
