﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace SLNavigationIdeas
{
	public partial class PopUpMenuDevTools : UserControl, IMenu
	{
		public PopUpMenuDevTools()
		{
			InitializeComponent();
		}

		#region IMenu Implementation
		public event EventHandler MenuClicked;

		public void RaiseMenuClicked(MenuEventArgs args)
		{
			EventHandler handler = this.MenuClicked;
			if (handler != null)
				handler(this, args);
		}
		#endregion

		private void LoadControl(object sender, RoutedEventArgs e)
		{
			Button item = (Button)sender;

			// Get Tag from selected item. "Tag" has the name of the control to load in it
			if (item.Tag != null)
				if (item.Tag.ToString() != string.Empty)
					LoadMenu(item.Tag.ToString());
		}

		private void LoadMenu(string controlName)
		{
			UserControl ctl = null;
			Type typ;

			// Create a Type from the controlName parameter
			typ = Type.GetType(controlName);
			// Create an instance of this control
			ctl = (UserControl)Activator.CreateInstance(typ);

			// Load another User Control and Raise Menu Clicked Event
			RaiseMenuClicked(new MenuEventArgs(ctl));
		}
	}
}
