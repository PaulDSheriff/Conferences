﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace SLNavigationIdeas
{
  public partial class PopUpMenu : UserControl
  {
    public PopUpMenu()
    {
      InitializeComponent();
      this.MouseMove += new MouseEventHandler(PopUp_MouseMove);
    }

    // Get Current Mouse Position
    Point currentMouse = new Point();
    // The Menu User Control to Load
    UserControl menuUC = null;
    // The next user Control to load
    UserControl nextControlToLoad = null;

    void PopUp_MouseMove(object sender, MouseEventArgs e)
    {
      currentMouse = e.GetPosition(this);
    }

    private void LoadMenu()
    {
      if (currentMouse != null)
      {
        Canvas.SetLeft(menuUC, currentMouse.X);
        Canvas.SetTop(menuUC, currentMouse.Y);

				CanvasArea.Children.Add(menuUC);
      }
    }

    private void btnHome_Click(object sender, RoutedEventArgs e)
    {
      // Clear the content area
      contentArea.Children.Clear();
      // Remove the Previous Menu from the Visible Display Area
      RemovePreviousMenu();
    }

		private void btnDevTools_Click(object sender, RoutedEventArgs e)
		{
			// Remove the Previous Menu from the Visible Display Area
			RemovePreviousMenu();

			// Create Instance of Popup Menu
			menuUC = new PopUpMenuDevTools();

			// Create Event Handler to MenuClicked Event
			((PopUpMenuDevTools)menuUC).MenuClicked += new EventHandler(MenuWasClicked);

			LoadMenu();
		}

    private void btnFWTools_Click(object sender, RoutedEventArgs e)
    {
      // Remove the Previous Menu from the Visible Display Area
      RemovePreviousMenu();

      // Create Instance of Popup Menu
      menuUC = new PopUpMenuFWTools();
      // Create Event Handler to MenuClicked Event
			((PopUpMenuFWTools)menuUC).MenuClicked += new EventHandler(MenuWasClicked);

      LoadMenu();
    }

    void MenuWasClicked(object sender, EventArgs e)
    {
      // We know the EventArgs are of type MenuEventArgs
      nextControlToLoad = ((MenuEventArgs)e).UserControlToLoad;

      // Remove the Previous Menu from the Visible Display Area
      RemovePreviousMenu();

      // Clear the content area
      contentArea.Children.Clear();

			if (nextControlToLoad != null)
			{
				// Load the new control
				contentArea.Children.Add(nextControlToLoad);
			}
    }

    private void RemovePreviousMenu()
    {
      if (menuUC != null)
      {
        // Remove the Menu from the Visible Display Area
        CanvasArea.Children.Remove(menuUC);

        // Clear previous menu
        menuUC = null;
      }
    }
  }
}