﻿using System;

namespace SLNavigationIdeas
{
  public interface IMenu
  {
    event EventHandler MenuClicked;
  }
}
