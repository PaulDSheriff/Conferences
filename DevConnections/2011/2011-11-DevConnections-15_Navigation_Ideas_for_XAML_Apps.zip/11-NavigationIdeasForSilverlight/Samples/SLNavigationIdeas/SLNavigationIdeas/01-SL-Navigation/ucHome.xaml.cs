﻿using System.Windows.Controls;

namespace SLNavigationIdeas
{
  public partial class ucHome : UserControl
  {
    public ucHome()
    {
      InitializeComponent();
    }
  }
}
