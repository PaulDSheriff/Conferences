﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace SLNavigationIdeas
{
  public partial class ucNavErrorWindow : ChildWindow
  {
    public ucNavErrorWindow()
    {
      InitializeComponent();
    }

    public ucNavErrorWindow(Uri uri)
    {
      InitializeComponent();
      if (uri != null)
      {
        tbMessage.Text = "Page not found: \"" + uri.ToString() + "\"";
      }
    }

    private void OKButton_Click(object sender, RoutedEventArgs e)
    {
      this.DialogResult = true;
    }

    private void CancelButton_Click(object sender, RoutedEventArgs e)
    {
      this.DialogResult = false;
    }
  }
}