﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SLNavigationIdeas
{
	public partial class ucTreeView : UserControl
	{
		public ucTreeView()
		{
			InitializeComponent();
		}

		private void TreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
		{
			TextBlock tb;

			if (menu.SelectedItem != null)
			{
				if (menu.SelectedItem is TextBlock)
				{
					tb = (TextBlock)menu.SelectedItem;

					if (tb.Tag != null)
						if (tb.Tag.ToString() != string.Empty)
							LoadMenu(tb.Tag.ToString());
				}
				else
					contentArea.Children.Clear();
			}
		}

		private void LoadMenu(string controlName)
		{
			UserControl ctl = null;
			Type typ;

			if (controlName.ToLower() == "clear")
			{
				contentArea.Children.Clear();
			}
			else
			{
				// Create a Type from the controlName parameter
				typ = Type.GetType(controlName);
				// Create an instance of this control
				ctl = (UserControl)Activator.CreateInstance(typ);
				// Clear Content Area for next control
				contentArea.Children.Clear();
				contentArea.Children.Add(ctl);
			}
		}
	}
}
