﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace SLNavigationIdeas
{
  public partial class ucMirrorImageMenu : UserControl
  {
    public ucMirrorImageMenu()
    {
      InitializeComponent();
    }

		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			this.DataContext = this;
		}

    #region ImageHeight Property
    public Double ImageHeight
    {
      get { return (Double)GetValue(ImageHeightProperty); }
      set { SetValue(ImageHeightProperty, value); }
    }

    // Using a DependencyProperty as the backing store for ImageHeight.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty ImageHeightProperty =
        DependencyProperty.Register("ImageHeight", typeof(Double), typeof(ucMirrorImageMenu), null);
    #endregion

    #region ImageWidth Property
    public Double ImageWidth
    {
      get { return (Double)GetValue(ImageWidthProperty); }
      set { SetValue(ImageWidthProperty, value); }
    }

    // Using a DependencyProperty as the backing store for ImageWidth.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty ImageWidthProperty =
        DependencyProperty.Register("ImageWidth", typeof(Double), typeof(ucMirrorImageMenu), null);
    #endregion
    
    #region ToolTip Property
    public string ToolTip
    {
      get { return (string)GetValue(ToolTipProperty); }
      set { SetValue(ToolTipProperty, value); }
    }

    // Using a DependencyProperty as the backing store for ToolTip.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty ToolTipProperty =
        DependencyProperty.Register("ToolTip", typeof(string), typeof(ucMirrorImageMenu), null);
    #endregion
    
    #region MenuName Property
    public string MenuName
    {
      get { return (string)GetValue(MenuNameProperty); }
      set { SetValue(MenuNameProperty, value); }
    }

    // Using a DependencyProperty as the backing store for MenuName.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty MenuNameProperty =
        DependencyProperty.Register("MenuName", typeof(string), typeof(ucMirrorImageMenu), null);
    #endregion

    #region ImageUri Property
    public Uri ImageUri
    {
      get { return (Uri)GetValue(ImageUriProperty); }
      set { SetValue(ImageUriProperty, value); }
    }

    // Using a DependencyProperty as the backing store for ImageUri.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty ImageUriProperty =
        DependencyProperty.Register("ImageUri", typeof(Uri), typeof(ucMirrorImageMenu), null);
    #endregion

    #region MouseLeftButtonUp Event
    private void ImageMenu_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
      RaiseClick();
    }
    #endregion

    #region Click Event Procedure
    public delegate void ClickEventHandler(object sender, ImageMenuEventArgs e);
    public event ClickEventHandler Click;
    
    protected void RaiseClick()
    {
      ImageMenuEventArgs arg = new ImageMenuEventArgs();
      arg.MenuName = MenuName;
      arg.ImageUri = ImageUri;
      arg.ToolTip = ToolTip;

      if (null != Click)
        Click(this, arg);
    }
    #endregion
  }
}
