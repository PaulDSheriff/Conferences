﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace SLNavigationIdeas
{
  public partial class ucMirrorImageMenusHardCoded : UserControl
  {
    public ucMirrorImageMenusHardCoded()
    {
      InitializeComponent();
    }

    private void ucImageMenu_Click(object sender, ImageMenuEventArgs e)
    {
			ucMirrorImageMenu menu = (ucMirrorImageMenu)sender;
			UserControl ctl;
			string control = string.Empty;
			Type typ;

			if (menu.Tag != null)
				if (menu.Tag.ToString() != string.Empty)
					control = menu.Tag.ToString();

			if (control.ToLower() == "clear" || control.Trim() == string.Empty)
				contentArea.Children.Clear();
			else
			{
				// Get the Type from the Menu.UserControlName property
				typ = Type.GetType(menu.Tag.ToString());
				// Create an instance of this control
				ctl = (UserControl)Activator.CreateInstance(typ);
				// Display the control
				contentArea.Children.Add(ctl);
			}
    }
  }
}
