﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace SLNavigationIdeas
{
  public class Menus
  {
    #region Public Properties
    public int MenuId { get; set; }
    public string MenuTitle { get; set; }
    public string MenuTip { get; set; }
    public string MenuImage { get; set; }
		public string UserControl { get; set; }
		#endregion

    public static IEnumerable<Menus> GetMenus()
    {
      IEnumerable<Menus> ret = null;
      
      string fileName;

      fileName = @"Xml/Menu.xml";

      ret = Menus.GetMenus(fileName);

      return ret;
    }

    public static IEnumerable<Menus> GetMenus(string fileName)
    {
      XElement elem = XElement.Load(fileName);

      var items = from prod in elem.Descendants("Menu")
                  select new Menus
                  {
                    MenuId = Convert.ToInt32(prod.Element("MenuId").Value),
                    MenuTitle = prod.Element("MenuTitle").Value,
                    MenuTip = prod.Element("MenuTip").Value,
                    MenuImage = prod.Element("MenuImage").Value,
										UserControl = prod.Element("UserControl").Value
                  };

      return items;
    }
  }
}
