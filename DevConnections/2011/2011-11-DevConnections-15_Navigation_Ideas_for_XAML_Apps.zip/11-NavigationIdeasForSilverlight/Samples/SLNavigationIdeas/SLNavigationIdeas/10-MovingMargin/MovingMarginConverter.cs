﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace SLNavigationIdeas
{
  public class MovingMarginConverter : IValueConverter
  {
    const int INCREMENT = 4;
    static int _CurrentIndex = -1;
    static int _CurrentOffset = 1;
    static bool _Increment = false;
    static int _TotalCount = 0;

    public object Convert(object value, Type targetType,
                          object parameter, CultureInfo culture)
    {
      ListBox lst;
      Thickness margin;
      int modValue;
      int increment;

      lst = (ListBox)value;

      // Get Increment Value from Tag
      if (lst.Tag == null)
        increment = INCREMENT;
      else
        increment = System.Convert.ToInt32(lst.Tag);

      // Get Modulus value from Parameter
      if (parameter == null)
        modValue = 3;
      else
        modValue = System.Convert.ToInt32(parameter);

      // First Time Thru
      if (_CurrentIndex == -1)
      {
        // Get total count
        _TotalCount = lst.Items.Count;

        // Set all variables to start Values
        _Increment = false;
        _CurrentIndex = 0;
        _CurrentOffset = 0;
      }

      // Create the Margin
      margin = new Thickness(4, _CurrentOffset, 4, _CurrentOffset);

      // Check to see if we need to switch from increment to decrement, or vice versa
      if (_CurrentIndex % modValue == 0)
        _Increment = !_Increment;

      // Increment current index
      _CurrentIndex++;
      // Determine whether to increment or decrement the offset
      if (_Increment)
        _CurrentOffset += increment;
      else
        _CurrentOffset -= increment;

      // Last time thru, reset _CurrentIndex variable
      if (_CurrentIndex == _TotalCount)
        _CurrentIndex = -1;

      return margin;
    }

    public object ConvertBack(object value, Type targetType,
                              object parameter, CultureInfo culture)
    {
      return System.Convert.ToString(value);
    }
  }
}
