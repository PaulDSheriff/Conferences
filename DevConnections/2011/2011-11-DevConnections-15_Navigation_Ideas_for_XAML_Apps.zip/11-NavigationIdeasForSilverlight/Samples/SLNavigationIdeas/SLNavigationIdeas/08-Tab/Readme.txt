﻿A tab control is not very easy to style
You need to extract the control template in order to style correctly

To use a two line navigation you need to figure out a way as you move from one tab to another how to automatically load the last page displayed under that tab
