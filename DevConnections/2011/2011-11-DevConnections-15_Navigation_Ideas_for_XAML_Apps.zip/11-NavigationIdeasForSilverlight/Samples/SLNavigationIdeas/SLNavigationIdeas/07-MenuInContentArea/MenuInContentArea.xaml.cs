﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace SLNavigationIdeas
{
  public partial class MenuInContentArea : UserControl
  {
    public MenuInContentArea()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      GoHome();
    }

    private void btnHome_Click(object sender, RoutedEventArgs e)
    {
      GoHome();
    }

    private void GoHome()
    {
      contentArea.Children.Clear();

      // Make 2nd Menu Invisible
      btn2ndMenu.Visibility = System.Windows.Visibility.Collapsed;
      
      // Load First Menu      
      grdTop.Visibility = System.Windows.Visibility.Visible;
      grdDevTools.Visibility = System.Windows.Visibility.Collapsed;
      grdFWTools.Visibility = System.Windows.Visibility.Collapsed;
    }
   
    private void btn2ndMenu_Click(object sender, RoutedEventArgs e)
    {
      if(btn2ndMenu.MenuText.Contains("Dev"))
      {
				btnDevTools_Click(this, e);
      }
      else if (btn2ndMenu.MenuText.Contains("Frame"))
      {
				btnFWTools_Click(this, e);
      }
    }

    private void btnDevTools_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      btn2ndMenu.Visibility = System.Windows.Visibility.Visible;
      grdTop.Visibility = System.Windows.Visibility.Collapsed;
      grdFWTools.Visibility = System.Windows.Visibility.Collapsed;
      grdDevTools.Visibility = System.Windows.Visibility.Visible;
      // Set 2nd Menu Buttons Image
      btn2ndMenu.ImageUri = btnDevTools.ImageUri;
      // Set 2nd Menu Buttons Text
			btn2ndMenu.MenuText = btnDevTools.MenuText;
    }

    private void btnFWTools_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      btn2ndMenu.Visibility = System.Windows.Visibility.Visible;
      grdTop.Visibility = System.Windows.Visibility.Collapsed;
      grdFWTools.Visibility = System.Windows.Visibility.Visible;
      grdDevTools.Visibility = System.Windows.Visibility.Collapsed;
      // Set 2nd Menu Buttons Image
      btn2ndMenu.ImageUri = btnFWTools.ImageUri;
      // Set 2nd Menu Buttons Text
			btn2ndMenu.MenuText = btnFWTools.MenuText;
    }

    private void LoadControl(object sender, RoutedEventArgs e)
    {
      TurnOffSubMenus();
			ucButtonImageLongText item = (ucButtonImageLongText)sender;

			// Get Tag from selected item. "Tag" has the name of the control to load in it
			if (item.Tag != null)
				if (item.Tag.ToString() != string.Empty)
					LoadMenu(item.Tag.ToString());
		}

		private void LoadMenu(string controlName)
		{
			UserControl ctl = null;
			Type typ;

			if (controlName.ToLower() == "clear")
			{
				contentArea.Children.Clear();
			}
			else
			{
				// Create a Type from the controlName parameter
				typ = Type.GetType(controlName);
				// Create an instance of this control
				ctl = (UserControl)Activator.CreateInstance(typ);
				// Clear Content Area for next control
				contentArea.Children.Clear();
				contentArea.Children.Add(ctl);
			}
		}

    private void TurnOffSubMenus()
    {
      grdTop.Visibility = System.Windows.Visibility.Collapsed;
      grdFWTools.Visibility = System.Windows.Visibility.Collapsed;
      grdDevTools.Visibility = System.Windows.Visibility.Collapsed;
    }
  }
}