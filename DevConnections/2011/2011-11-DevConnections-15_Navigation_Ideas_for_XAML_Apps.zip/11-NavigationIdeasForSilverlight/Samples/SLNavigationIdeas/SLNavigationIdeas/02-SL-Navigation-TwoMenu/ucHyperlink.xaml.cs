﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace SLNavigationIdeas
{
  public partial class ucHyperlink : UserControl
  {
    public ucHyperlink()
    {
      InitializeComponent();
    }

    public Uri NavigateUri
    {
      get { return theLink.NavigateUri; }
      set { theLink.NavigateUri = value; }
    }

    public string TargetName
    {
      get { return theLink.TargetName; }
      set { theLink.TargetName = value; }
    }

    public new object Content
    {
      get { return theLink.Content; }
      set { theLink.Content = value; }
    }
  }
}
