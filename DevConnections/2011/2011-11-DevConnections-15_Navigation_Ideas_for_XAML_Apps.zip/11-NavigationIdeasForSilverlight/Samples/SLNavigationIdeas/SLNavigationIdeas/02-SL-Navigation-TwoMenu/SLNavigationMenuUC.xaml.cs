﻿using System.Windows.Controls;

using System.Windows.Navigation;

namespace SLNavigationIdeas
{
  public partial class SLNavigationMenuUC : UserControl
  {
    public SLNavigationMenuUC()
    {
      InitializeComponent();
    }

    private void ContentFrame_Navigated(object sender, NavigationEventArgs e)
    {
      // Do something here after new user control has been navigated to
      // if(e.Content==null) -> this means navigating to the same page        
    }

    private void ContentFrame_NavigationFailed(object sender, NavigationFailedEventArgs e)
    {
      // Display error of which page was trying to be navigated to
      e.Handled = true;
      ucNavErrorWindow win = new ucNavErrorWindow(e.Uri);      
      win.Show();
    }
  }
}
