﻿using System;
using System.Windows.Controls;

namespace SLNavigationIdeas
{
	public partial class ucMetroSettingsList : UserControl
	{
		public ucMetroSettingsList()
		{
			InitializeComponent();
		}

		#region MetroTileClick Event Procedure
		public delegate void MetroTileClickEventHandler(object sender, TileEventArgs e);
		public event MetroTileClickEventHandler MetroTileClick;

		protected void RaiseTileClick(TileEventArgs e)
		{
			if (null != MetroTileClick)
				MetroTileClick(this, e);
		}
		#endregion

		private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			TileEventArgs arg = new TileEventArgs();
			ListBoxItem item = null;
			UserControl ctl;
			Type typ;

			// Get Menu Selected in List Box
			item = (ListBoxItem)lstMenus.SelectedItem;
			// Get the Type from the Menu.UserControlName property
			typ = Type.GetType(item.Tag.ToString());
			// Create an instance of this control
			ctl = (UserControl)Activator.CreateInstance(typ);
			// Raise the event to display control
			arg.NavigationUri = item.Tag.ToString();
			RaiseTileClick(arg);
		}
	}
}
