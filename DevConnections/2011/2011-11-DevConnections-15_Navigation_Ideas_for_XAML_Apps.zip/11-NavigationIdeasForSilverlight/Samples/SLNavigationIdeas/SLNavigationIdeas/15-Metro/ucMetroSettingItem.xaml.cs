﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace SLNavigationIdeas
{
	public partial class ucMetroSettingItem : UserControl
	{
		public ucMetroSettingItem()
		{
			InitializeComponent();

			this.DataContext = this;
		}

		#region MenuText Property
		public string MenuText
		{
			get { return (string)GetValue(MenuTextProperty); }
			set { SetValue(MenuTextProperty, value); }
		}

		// Using a DependencyProperty as the backing store for MenuText.  This enables animation, styling, binding, etc...
		public static readonly DependencyProperty MenuTextProperty =
				DependencyProperty.Register("MenuText", typeof(string), typeof(ucMetroSettingItem), null);
		#endregion

		#region ImageUri Property
		public Uri ImageUri
		{
			get { return (Uri)GetValue(ImageUriProperty); }
			set { SetValue(ImageUriProperty, value); }
		}

		// Using a DependencyProperty as the backing store for ImageUri.  This enables animation, styling, binding, etc...
		public static readonly DependencyProperty ImageUriProperty =
				DependencyProperty.Register("ImageUri", typeof(Uri), typeof(ucMetroSettingItem), null);
		#endregion

	}
}
