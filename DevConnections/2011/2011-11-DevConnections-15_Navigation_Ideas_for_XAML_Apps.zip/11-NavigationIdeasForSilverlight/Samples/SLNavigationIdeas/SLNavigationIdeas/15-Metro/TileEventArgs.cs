﻿using System;

namespace SLNavigationIdeas
{
	public class TileEventArgs : EventArgs
	{
		public TileEventArgs()
		{
		}

		public TileEventArgs(string uri)
		{
			NavigationUri = uri;
		}

		public TileEventArgs(string uri, string tileText)
		{
			NavigationUri = uri;
			TileText = tileText;
		}

		public string NavigationUri { get; set; }
		public string TileText { get; set; }
	}
}
