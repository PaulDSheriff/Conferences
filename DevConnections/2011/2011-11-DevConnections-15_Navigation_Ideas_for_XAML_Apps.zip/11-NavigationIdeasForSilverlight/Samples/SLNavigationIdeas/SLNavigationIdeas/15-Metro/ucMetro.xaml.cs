﻿using System;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Input;

namespace SLNavigationIdeas
{
	public partial class ucMetro : UserControl
	{
		public ucMetro()
		{
			InitializeComponent();
		}

		// Create Right/Left Animation Class
		private UserControlOpacityAnimation _Animation = null;
		// Stack to hold user controls to move backward thru
		private Stack<UserControl> _UserControlStack = new Stack<UserControl>();
		// "Settings" control
		private ucMetroSettingsList _SettingsList = null;

		private void UserControl_Loaded(object sender, System.Windows.RoutedEventArgs e)
		{
			// Initialize the Animation Object with the Content Area to Draw the Controls
			_Animation = new UserControlOpacityAnimation(contentArea, (UserControl)contentArea.Children[0]);
			
			// Initialize the Stack with the "Home" tiles page.
			_UserControlStack.Push((UserControl)contentArea.Children[0]);
		}

		private void ucMetroTiles_MetroTileClick(object sender, TileEventArgs e)
		{
			LoadControl(e.NavigationUri, false);
		}

		private void SettingsTileClick(object sender, TileEventArgs e)
		{
			// The Settings User Control is now going to be loaded
			LoadControl(e.NavigationUri, true);
		}

		private void NavigationMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			LoadControl(((Image)sender).Tag.ToString(), false);
		}

		private void LoadControl(string controlName, bool isSettingsControl)
		{
			UserControl ctl = null;
			Type typ;

			if (controlName.ToLower() == "back")
			{
				if (_UserControlStack.Count > 1)
				{
					// Pop last one off stack
					_UserControlStack.Pop();

					// Get the current one on the stack
					ctl = _UserControlStack.Peek();

					// Animate the Next Control
					if (!_Animation.AnimationRunning)
						_Animation.Animate(ctl);
				}
			}
			else if (controlName.ToLower() == "home")
			{
				while (_UserControlStack.Count > 1)
					_UserControlStack.Pop();

				if (!_Animation.AnimationRunning)
					_Animation.Animate(_UserControlStack.Peek());
			}
			else
			{
				// Create a Type from the controlName parameter
				typ = Type.GetType(controlName);
				// Create an instance of this control
				ctl = (UserControl)Activator.CreateInstance(typ);

				// Push control onto Stack					
				_UserControlStack.Push(ctl);

				// Check for "Settings" list
				if (isSettingsControl)
				{
					// You need to hook the event to display the content on this page
					_SettingsList = (ucMetroSettingsList)ctl;
					_SettingsList.MetroTileClick += new ucMetroSettingsList.MetroTileClickEventHandler(_SettingsList_MetroTileClick);
				}

				// Animate the Next Control
				if (!_Animation.AnimationRunning)
					_Animation.Animate(ctl);
			}
		}

		void _SettingsList_MetroTileClick(object sender, TileEventArgs e)
		{
			LoadControl(e.NavigationUri, false);
		}
	}
}