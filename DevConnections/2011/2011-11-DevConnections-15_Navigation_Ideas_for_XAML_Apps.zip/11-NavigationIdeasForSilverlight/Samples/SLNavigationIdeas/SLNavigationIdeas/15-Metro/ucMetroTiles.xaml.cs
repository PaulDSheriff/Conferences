﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace SLNavigationIdeas
{
	public partial class ucMetroTiles : UserControl
	{
		public ucMetroTiles()
		{
			InitializeComponent();
		}

		private void TileHasBeenClicked(object sender, RoutedEventArgs e)
		{
			RaiseTileClick(new TileEventArgs(((ucMetroTile)sender).Tag.ToString(), ((ucMetroTile)sender).TileText));
		}

		#region MetroTileClick Event Procedure
		public delegate void MetroTileClickEventHandler(object sender, TileEventArgs e);
		public event MetroTileClickEventHandler MetroTileClick;

		protected void RaiseTileClick(TileEventArgs e)
		{
			if (null != MetroTileClick)
				MetroTileClick(this, e);
		}
		#endregion

		#region SettingsTileClick Event Procedure
		public delegate void SettingsTileClickEventHandler(object sender, TileEventArgs e);
		public event SettingsTileClickEventHandler SettingsTileClick;

		protected void RaiseSettingsTileClick(TileEventArgs e)
		{
			if (null != SettingsTileClick)
				SettingsTileClick(this, e);
		}
		#endregion

		private void SettingsMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			RaiseSettingsTileClick(new TileEventArgs(((Border)sender).Tag.ToString(), "Settings"));
		}
	}
}