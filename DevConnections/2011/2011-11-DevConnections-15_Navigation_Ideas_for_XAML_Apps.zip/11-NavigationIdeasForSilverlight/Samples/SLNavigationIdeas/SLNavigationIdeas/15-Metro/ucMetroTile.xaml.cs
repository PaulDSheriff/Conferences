﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace SLNavigationIdeas
{
	public partial class ucMetroTile : UserControl
	{
		public ucMetroTile()
		{
			InitializeComponent();

			this.DataContext = this;
		}

		#region TileText Property
		public string TileText
		{
			get { return (string)GetValue(TileTextProperty); }
			set { SetValue(TileTextProperty, value); }
		}

		// Using a DependencyProperty as the backing store for TileText.  This enables animation, styling, binding, etc...
		public static readonly DependencyProperty TileTextProperty =
				DependencyProperty.Register("TileText", typeof(string), typeof(ucMetroTile), null);
		#endregion

		#region TileImageUri Property
		public Uri TileImageUri
		{
			get { return (Uri)GetValue(TileImageUriProperty); }
			set { SetValue(TileImageUriProperty, value); }
		}

		// Using a DependencyProperty as the backing store for TileImageUri.  This enables animation, styling, binding, etc...
		public static readonly DependencyProperty TileImageUriProperty =
				DependencyProperty.Register("TileImageUri", typeof(Uri), typeof(ucMetroTile), null);
		#endregion

		#region TileClick Event Procedure
		public delegate void TileClickEventHandler(object sender, RoutedEventArgs e);
		public event TileClickEventHandler TileClick;

		protected void RaiseTileClick(RoutedEventArgs e)
		{
			if (null != TileClick)
				TileClick(this, e);
		}
		#endregion

		private void TileMouseLeftButtonUp(object sender, System.Windows.Input.MouseButtonEventArgs e)
		{
			RaiseTileClick(e);
		}
	}
}
