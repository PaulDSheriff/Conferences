﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace SLNavigationIdeas
{
  public class UserControlOpacityAnimation : UserControlAnimation
  {
    #region Constructor
		public UserControlOpacityAnimation(Grid contentArea)
			: base(contentArea)
		{
		}
		
		public UserControlOpacityAnimation(Grid contentArea, UserControl current)
      : base(contentArea, current)
    {
    }
    #endregion

    #region Override of PrepareNew Method
    protected override void PrepareNew()
    {
      if (_NewControl != null)
      {
        DoubleAnimation animation = new DoubleAnimation();
        animation.From = 0;
        animation.To = 1;
        animation.Duration = TimeSpan.FromMilliseconds(AnimationTime);
        animation.FillBehavior = FillBehavior.Stop;

        Storyboard.SetTarget(animation, _NewControl);
        Storyboard.SetTargetProperty(animation, new PropertyPath("(UIElement.Opacity)"));

        _NewStoryBoard.Children.Clear();
        _NewStoryBoard.Children.Add(animation);
        _NewStoryBoard.Completed += new EventHandler(NewStoryBoard_Completed);

        _ContentArea.Children.Add(_NewControl);
      }
    }
    #endregion

    #region Override of PrepareCurrent Method
    protected override void PrepareCurrent()
    {
      if (_CurrentControl != null)
      {
        DoubleAnimation animation = new DoubleAnimation();
        animation.From = 1;
        animation.To = 0;
        animation.Duration = TimeSpan.FromMilliseconds(AnimationTime);
        animation.FillBehavior = FillBehavior.Stop;

        Storyboard.SetTarget(animation, _CurrentControl);
        Storyboard.SetTargetProperty(animation, new PropertyPath("(UIElement.Opacity)"));

        _CurrentStoryBoard.Children.Clear();
        _CurrentStoryBoard.Children.Add(animation);
        _CurrentStoryBoard.Completed += new EventHandler(CurrentStoryBoard_Completed);
      }
    }
    #endregion
  }
}