﻿using System.Windows;
using System.Windows.Controls;

namespace SLNavigationIdeas
{
  public partial class ucMainMenuExpand : UserControl
  {
    public ucMainMenuExpand()
    {
      InitializeComponent();
      IsArrowVisible = false;
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      // Set DataContext of UserControl to itself
      // This is needed to bind 'Text' property to the TextBlock Text property
      this.DataContext = this;
    }

    #region Text Dependency Property
    public string Text
    {
      get { return (string)GetValue(TextProperty); }
      set { SetValue(TextProperty, value); }
    }

    // Using a DependencyProperty as the backing store for Text.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty TextProperty =
        DependencyProperty.Register("Text", typeof(string), typeof(ucMainMenuExpand), null);
    #endregion

    #region IsArrowVisible Dependency Property
    public bool IsArrowVisible
    {
      get { return (bool)GetValue(IsArrowVisibleProperty); }
      set { SetValue(IsArrowVisibleProperty, value); }
    }

    // Using a DependencyProperty as the backing store for IsArrowVisible.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty IsArrowVisibleProperty =
        DependencyProperty.Register("IsArrowVisible", typeof(bool), typeof(ucMainMenuExpand), null);
    #endregion
  }
}
