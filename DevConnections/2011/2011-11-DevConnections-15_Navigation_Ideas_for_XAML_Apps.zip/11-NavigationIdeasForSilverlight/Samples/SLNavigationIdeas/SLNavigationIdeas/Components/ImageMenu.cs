﻿using System;
using System.Collections.Generic;

namespace SLNavigationIdeas
{
  public class ImageMenu : CommonBase
  {
    #region Private Variables
    private string _MenuName = string.Empty;
    private string _ToolTip = string.Empty;
    private Uri _ImageUri = null;
    private string _UserControlName = string.Empty;
    #endregion

    #region Public Properties
    public string MenuName
    {
      get { return _MenuName; }
      set
      {
        if (_MenuName != value)
        {
          _MenuName = value;
          RaisePropertyChanged("MenuName");
        }
      }
    }

    public string ToolTip
    {
      get { return _ToolTip; }
      set
      {
        if (_ToolTip != value)
        {
          _ToolTip = value;
          RaisePropertyChanged("ToolTip");
        }
      }
    }

    public Uri ImageUri
    {
      get { return _ImageUri; }
      set
      {
        if (_ImageUri != value)
        {
          _ImageUri = value;
          RaisePropertyChanged("ImageUri");
        }
      }
    }

    public string UserControlName
    {
      get { return _UserControlName; }
      set
      {
        if (_UserControlName != value)
        {
          _UserControlName = value;
          RaisePropertyChanged("UserControlName");
        }
      }
    }
    #endregion
  }
}
