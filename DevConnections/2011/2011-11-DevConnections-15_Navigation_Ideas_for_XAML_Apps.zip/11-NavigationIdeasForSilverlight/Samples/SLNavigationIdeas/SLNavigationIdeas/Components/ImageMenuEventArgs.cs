﻿using System;

namespace SLNavigationIdeas
{
  public class ImageMenuEventArgs: EventArgs
  {
    #region Public Properties
    public string MenuName { get; set; }
    public string ToolTip { get; set; }
    public Uri ImageUri { get; set; }
    public string UserControlName { get; set; }
    #endregion
  }
}
