﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace SLNavigationIdeas
{
  public class ImageMenus : List<ImageMenu>
  {
    #region GetAllMenus Method
    public List<ImageMenu> GetAllMenus()
    {
      XElement XmlObject;

      // Retrieve Data from Xml File or Isolated Storage
      XmlObject = XElement.Load("Xml/ImageMenus.xml");

      // Fill a list of Product objects
      var menus =
        from menu in XmlObject.Descendants("ImageMenu")
        orderby Convert.ToInt32(menu.Element("DisplayOrder").Value)
        select new ImageMenu
        {
          MenuName = menu.Element("MenuName").Value,
          ToolTip = menu.Element("ToolTip").Value,
          UserControlName = menu.Element("UserControlName").Value,
          ImageUri = new Uri(menu.Element("ImageUri").Value, UriKind.Relative)
        };

      return menus.ToList();
    }
    #endregion
  }
}
