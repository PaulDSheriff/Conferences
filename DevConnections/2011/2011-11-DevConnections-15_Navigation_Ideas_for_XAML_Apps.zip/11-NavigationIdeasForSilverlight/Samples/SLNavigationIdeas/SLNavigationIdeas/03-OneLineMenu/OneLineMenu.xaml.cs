﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace SLNavigationIdeas
{
  public partial class OneLineMenu : UserControl
  {
    public OneLineMenu()
    {
      InitializeComponent();
    }

    private void btnHome_Click(object sender, RoutedEventArgs e)
    {
      // Clear the content area
      contentArea.Children.Clear();

      btnDevTools.Visibility = System.Windows.Visibility.Visible;
      btnFWTools.Visibility = System.Windows.Visibility.Visible;
      spDevTools.Visibility = System.Windows.Visibility.Collapsed;
      spFWTools.Visibility = System.Windows.Visibility.Collapsed;
    }

    private void btnDevTools_Click(object sender, RoutedEventArgs e)
    {
      // Clear the content area
      contentArea.Children.Clear();

      btnFWTools.Visibility = System.Windows.Visibility.Collapsed;
      spDevTools.Visibility = System.Windows.Visibility.Visible;
			spFWTools.Visibility = System.Windows.Visibility.Collapsed;
    }

    private void btnFWTools_Click(object sender, RoutedEventArgs e)
    {
      // Clear the content area
      contentArea.Children.Clear();

      btnDevTools.Visibility = System.Windows.Visibility.Collapsed;
      spDevTools.Visibility = System.Windows.Visibility.Collapsed;
			spFWTools.Visibility = System.Windows.Visibility.Visible;
    }

    private void btnLoadControl_Click(object sender, RoutedEventArgs e)
    {
			ucButtonImageTextBottom item = (ucButtonImageTextBottom)sender;

			// Get Tag from selected item. "Tag" has the name of the control to load in it
			if (item.Tag != null)
				if (item.Tag.ToString() != string.Empty)
					LoadMenu(item.Tag.ToString());
		}

		private void LoadMenu(string controlName)
		{
			UserControl ctl = null;
			Type typ;

			if (controlName.ToLower() == "clear")
			{
				contentArea.Children.Clear();				
			}
			else
			{
				// Create a Type from the controlName parameter
				typ = Type.GetType(controlName);
				// Create an instance of this control
				ctl = (UserControl)Activator.CreateInstance(typ);
				// Clear Content Area for next control
				contentArea.Children.Clear();
				contentArea.Children.Add(ctl);
			}
		}
  }
}
