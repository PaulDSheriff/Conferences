﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace SLNavigationIdeas
{
  public partial class ucButtonImageTextBottom : UserControl
  {
    public ucButtonImageTextBottom()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      // Set DataContext of UserControl to itself
      // This is needed to bind 'Text' property to the TextBlock Text property
      this.DataContext = this;
    }

    #region ImageHeight Property
    public Double ImageHeight
    {
      get { return (Double)GetValue(ImageHeightProperty); }
      set { SetValue(ImageHeightProperty, value); }
    }

    // Using a DependencyProperty as the backing store for ImageHeight.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty ImageHeightProperty =
        DependencyProperty.Register("ImageHeight", typeof(Double), typeof(ucButtonImageTextBottom), null);
    #endregion

    #region ImageWidth Property
    public Double ImageWidth
    {
      get { return (Double)GetValue(ImageWidthProperty); }
      set { SetValue(ImageWidthProperty, value); }
    }

    // Using a DependencyProperty as the backing store for ImageWidth.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty ImageWidthProperty =
        DependencyProperty.Register("ImageWidth", typeof(Double), typeof(ucButtonImageTextBottom), null);
    #endregion

    #region ToolTip Property
    public string ToolTip
    {
      get { return (string)GetValue(ToolTipProperty); }
      set { SetValue(ToolTipProperty, value); }
    }

    // Using a DependencyProperty as the backing store for ToolTip.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty ToolTipProperty =
        DependencyProperty.Register("ToolTip", typeof(string), typeof(ucButtonImageTextBottom), null);
    #endregion

    #region MenuText Property
    public string MenuText
    {
      get { return (string)GetValue(MenuTextProperty); }
      set { SetValue(MenuTextProperty, value); }
    }

    // Using a DependencyProperty as the backing store for MenuText.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty MenuTextProperty =
        DependencyProperty.Register("MenuText", typeof(string), typeof(ucButtonImageTextBottom), null);
    #endregion

    #region ImageUri Property
    public Uri ImageUri
    {
      get { return (Uri)GetValue(ImageUriProperty); }
      set { SetValue(ImageUriProperty, value); }
    }

    // Using a DependencyProperty as the backing store for ImageUri.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty ImageUriProperty =
        DependencyProperty.Register("ImageUri", typeof(Uri), typeof(ucButtonImageTextBottom), null);
    #endregion

    #region Menu Click Event
    private void btnMenu_Click(object sender, RoutedEventArgs e)
    {
      RaiseClick(e);
    }
    #endregion

    #region Click Event Procedure
    public delegate void ClickEventHandler(object sender, RoutedEventArgs e);
    public event ClickEventHandler Click;

    protected void RaiseClick(RoutedEventArgs e)
    {
      if (null != Click)
        Click(this, e);
    }
    #endregion
  }
}
