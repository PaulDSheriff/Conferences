﻿using System;
using System.Windows.Controls;

namespace SLNavigationIdeas
{
  public partial class OutlookStyleListBox : UserControl
  {
    public OutlookStyleListBox()
    {
      InitializeComponent();
    }

    private void lstMenus_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      ListBoxItem item = (ListBoxItem)((ListBox)sender).SelectedItem;

      // Get Tag from selected item. "Tag" has the name of the control to load in it
      if (item.Tag != null)
        if (item.Tag.ToString() != string.Empty)
          LoadMenu(item.Tag.ToString());
    }

    private void LoadMenu(string controlName)
    {
      UserControl ctl = null;
      Type typ;

      // Create a Type from the controlName parameter
      typ = Type.GetType(controlName);
      // Create an instance of this control
      ctl = (UserControl)Activator.CreateInstance(typ);
      // Clear Content Area for next control
      contentArea.Children.Clear();
      if (ctl != null)
        contentArea.Children.Add(ctl);
    }
  }
}
