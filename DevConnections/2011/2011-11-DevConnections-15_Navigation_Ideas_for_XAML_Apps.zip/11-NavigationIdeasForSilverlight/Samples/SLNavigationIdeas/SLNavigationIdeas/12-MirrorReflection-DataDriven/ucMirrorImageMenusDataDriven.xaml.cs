﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace SLNavigationIdeas
{
  public partial class ucMirrorImageMenusDataDriven : UserControl
  {
    public ucMirrorImageMenusDataDriven()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      ImageMenus menus = new ImageMenus();

      // Load Menus from XML File
      lstMenus.DataContext = menus.GetAllMenus();
    }

    private void lstMenus_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
			ImageMenu menu = null;
			UserControl ctl;
			Type typ;

			// Get Menu Selected in List Box
			menu = (ImageMenu)lstMenus.SelectedItem;
			// Get the Type from the Menu.UserControlName property
			typ = Type.GetType(menu.UserControlName);
			// Create an instance of this control
			ctl = (UserControl)Activator.CreateInstance(typ);
			// Display the control
			contentArea.Children.Add(ctl);
    }
  }
}
