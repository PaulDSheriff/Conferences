﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace TimeSheetComponentsCS
{
  public class Customer
  {
    #region Constructors
    public Customer()
    {
      Name = string.Empty;
    }

    public Customer(string name)
    {
      Name = name;
    }
    #endregion

    public string Name { get; set; }

    public static string UnSelected
    {
      get { return "[Select]"; }
    }
  }

  public class Customers : List<Customer>
  {
    public Customers GetCustomers()
    {
      Customers ret = new Customers();

      try
      {
        var xElem = XElement.Load(Utilities.GetCurrentDirectory() +
                                   @"\Xml\Customer.xml");

        // Get All Customers
        var items = from item in xElem.Descendants("Customer")
                    select item;

        // Build Collection
        foreach (var item in items)
          ret.Add(new Customer(item.Element("Name").Value));
      }
      catch (Exception ex)
      {
        ret.Add(new Customer("CUSTOMER 1"));
      }

      return ret;
    }
  }
}
