using System;

namespace TimeSheetComponentsCS
{
  public class TimeSheetSample3
  {

    #region Constructor
    public TimeSheetSample3()
    {
      Resource = string.Empty;
      EntryDate = DateTime.Now;
      Customer = string.Empty;
      Hours = 1;
      Description = string.Empty;
      Messages = string.Empty;
    }
    #endregion

    #region Public Properties
    public string Resource { get;set;}
    public DateTime EntryDate { get; set; }
    public string Customer { get; set; }
    public decimal Hours { get; set; }
    public string Description { get; set; }
    public string Messages { get; set; }

    public string MessagesForWebDisplay
    {
      get { return Messages.Replace(Environment.NewLine, "<br />"); }
    }
    #endregion

    #region ValidateData Method
    //  This overload checks if the data can be converted
    //  then puts it into the private variables in this class
    //  then calls the ValidateData to check the data
    public bool ValidateData(string resource, string entryDate,
      string customer, string hours, string description)
    {
      decimal value = 0;

      Messages = string.Empty;

      if (resource != TimeSheetComponentsCS.Resource.UnSelected)
      {
        Resource = resource;
      }
      if (Utilities.IsDate(entryDate))
      {
        EntryDate = Convert.ToDateTime(entryDate);
      }
      if (customer != TimeSheetComponentsCS.Customer.UnSelected)
      {
        Customer = customer;
      }
      //  Make sure hours entered are decimal values
      if (decimal.TryParse(hours, out value) == false)
      {
        Messages += "Hours must be in decimal format." +
          Environment.NewLine;
      }
      else
      {
        Hours = value;
      }
      Description = description;

      // Now call ValidateData to check all public properties
      return ValidateData();
    }

    protected bool ValidateData()
    {
      //  User Must Enter a Resource
      if (Resource.Trim() == string.Empty)
      {
        Messages += "You must choose a Resource." +
          Environment.NewLine;
      }
      if (Utilities.IsDate(EntryDate))
      {
        //  Entry Date must not be older than 7 days
        if (EntryDate <
          (DateTime.Now.Subtract(new TimeSpan(7, 0, 0, 0))))
        {
          Messages += "Entry Date must be greater than 7 days ago" +
            Environment.NewLine;
        }
        //  Entry Date Must Be Today's Date or Less
        if (EntryDate > DateTime.Now)
        {
          Messages += "Entry Date must today's date or less" +
            Environment.NewLine;
        }
      }
      else
      {
        Messages += "Entry Date must be filled in." +
          Environment.NewLine;
      }
      //  User Must Enter a Customer
      if (Customer.Trim() == string.Empty)
      {
        Messages += "You must choose a customer." +
          Environment.NewLine;
      }
      //  Hours must be greater than 0
      if (Hours <= 0)
      {
        Messages += "Hours must be greater than zero." +
          Environment.NewLine;
      }
      //  Hours must be less than 12
      if (Hours > 12)
      {
        Messages += "Hours must be less than 12." +
          Environment.NewLine;
      }
      //  User Must Enter a Description
      if (Description.Trim() == string.Empty)
      {
        Messages += "Description must be entered." +
          Environment.NewLine;
      }
      else
      {
        //  Description length must be greater than 10 characters
        if (Description.Trim().Length < 10)
        {
          Messages += "Description entered must be greater than 10 characters." +
            Environment.NewLine;
        }
      }

      return (Messages == string.Empty);
    }
    #endregion
  }
}