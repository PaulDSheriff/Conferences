﻿using System;
using System.Web.UI;

using TimeSheetComponentsCS;

namespace TimeSheetWebCS
{
  public partial class frmSample1 : System.Web.UI.Page
  {
    #region Loading Methods
    private string _Messages = string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
      {
        ResourcesLoad();
        CustomersLoad();
        txtEntryDate.Text = DateTime.Now.ToShortDateString();
      }
    }

    private void ResourcesLoad()
    {
      Resources res = new Resources();

      ddlResource.DataTextField = "Name";
      ddlResource.DataValueField = "Name";
      ddlResource.DataSource = res.GetResources();
      ddlResource.DataBind();
    }

    private void CustomersLoad()
    {
      Customers cust = new Customers();

      ddlCustomer.DataTextField = "Name";
      ddlCustomer.DataValueField = "Name";
      ddlCustomer.DataSource = cust.GetCustomers();
      ddlCustomer.DataBind();
    }
    #endregion

    #region Saving Methods
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (ValidateData())
      {
        lblMessage.Text = "Data is Valid";
      }
      else
      {
        lblMessage.Text = _Messages.Replace(Environment.NewLine, "<br />");
      }
    }

    private bool ValidateData()
    {
      decimal value = 0;

      _Messages = string.Empty;

      //  User Must Enter a Resource
      if (ddlResource.SelectedIndex <= 0)
      {
        _Messages += "You must choose a Resource." +
          Environment.NewLine;
      }
      if (Utilities.IsDate(txtEntryDate.Text))
      {
        //  Entry Date must not be older than 7 days
        if (Convert.ToDateTime(txtEntryDate.Text) <
          (DateTime.Now.Subtract(new TimeSpan(7, 0, 0, 0))))
        {
          _Messages += "Entry Date must be greater than 7 days ago" +
            Environment.NewLine;
        }
        //  Entry Date Must Be Today's Date or Less
        if (Convert.ToDateTime(txtEntryDate.Text) > DateTime.Now)
        {
          _Messages += "Entry Date must today's date or less" +
            Environment.NewLine;
        }
      }
      else
      {
        _Messages += "Entry Date must be a valid date." + Environment.NewLine;
      }

      //  User Must Enter a Customer
      if (ddlCustomer.SelectedIndex <= 0)
      {
        _Messages += "You must choose a customer." +
          Environment.NewLine;
      }
      //  Make sure hours entered are decimal values
      if (decimal.TryParse(txtHours.Text, out value) == false)
      {
        _Messages += "Hours must be in decimal format." +
          Environment.NewLine;
      }
      else
      {
        //  Hours must be greater than 0
        if (value <= 0)
        {
          _Messages += "Hours must be greater than zero." +
            Environment.NewLine;
        }
        //  Hours must be less than 12
        if (value > 12)
        {
          _Messages += "Hours must be less than 12." +
            Environment.NewLine;
        }
      }
      //  User Must Enter a Description
      if (txtDescription.Text.Trim() == string.Empty)
      {
        _Messages += "Description must be entered." +
          Environment.NewLine;
      }
      else
      {
        //  Description length must be greater than 10 characters
        if (txtDescription.Text.Trim().Length < 10)
        {
          _Messages += "Description must be greater than 10 characters." +
             Environment.NewLine;
        }
      }

      return (_Messages == string.Empty);
    }
    #endregion
  }
}