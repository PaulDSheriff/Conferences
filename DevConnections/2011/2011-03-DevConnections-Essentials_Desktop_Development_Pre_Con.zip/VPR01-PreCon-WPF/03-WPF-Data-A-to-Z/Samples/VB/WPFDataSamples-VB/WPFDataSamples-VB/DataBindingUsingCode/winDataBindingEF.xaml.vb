﻿Imports WPFEFComponents

Partial Public Class winDataBindingEF
  Private Sub winDataBindingEF_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles MyBase.Loaded
    Dim dc As New AdventureWorksLTEntities()

    Dim items = From cust In dc.Customer _
                Order By cust.LastName _
                Select cust

    lstData.DataContext = items
  End Sub
End Class
