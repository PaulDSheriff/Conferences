﻿Partial Public Class winTextBoxToLabel

End Class
