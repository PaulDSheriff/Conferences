﻿Partial Public Class winFontBinding

End Class
