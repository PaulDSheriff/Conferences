using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPFComponents
{
partial class AdvWorksDataContext
{
  public IEnumerable<Customer> GetAllCustomers()
  {
    // Create a collection of Customers
    var items = from item in this.Customers
                orderby item.LastName
                select item;

    return items;
  }

  public IQueryable<string> GetCustomerTitles()
  {
    // Create a collection of Customers
    var items = (from item in this.Customers
                 orderby item.LastName
                 select item.Title).Distinct();

    return items;
  }

  public IEnumerable<Customer> GetCustomersByTitle(string title)
  {
    // Create a collection of Customers
    var items = from item in this.Customers
                where item.Title == title
                orderby item.LastName
                select item;

    return items;
  }
}
}
