﻿using System.Windows;

namespace WPFDataSamples
{
  /// <summary>
  /// Interaction logic for winObjectDataProviderLINQXML.xaml
  /// </summary>
  public partial class winObjectDataProviderLINQXML : Window
  {
    public winObjectDataProviderLINQXML()
    {
      InitializeComponent();
    }
  }
}
