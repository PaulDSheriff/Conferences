﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPFEFComponents
{
  public partial class Customer
  {
    public IEnumerable<Customer> GetAllCustomers()
    {
      AdventureWorksLTEntities dc= new AdventureWorksLTEntities();

      var items = from cust in dc.Customer
                  orderby cust.CompanyName
                  select cust;

      return items;
    }
  }
}
