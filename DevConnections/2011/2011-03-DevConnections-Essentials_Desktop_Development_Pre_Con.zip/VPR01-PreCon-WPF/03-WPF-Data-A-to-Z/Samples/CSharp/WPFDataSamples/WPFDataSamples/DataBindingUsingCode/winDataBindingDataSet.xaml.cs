﻿using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace WPFDataSamples
{
  /// <summary>
  /// Interaction logic for winDataBindingDataSet.xaml
  /// </summary>
  public partial class winDataBindingDataSet : Window
  {
    public winDataBindingDataSet()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      DataSet ds = new DataSet();
      SqlDataAdapter da;

      da = new SqlDataAdapter(
        "SELECT LastName FROM SalesLT.Customer ORDER BY LastName", 
        AppConfig.ConnectString);

      da.Fill(ds);

      // You must bind to a DataTable, not a DataSet
      lstData.DataContext = ds.Tables[0];
    }    
  }
}
