﻿using System.Windows;

namespace WPFDataSamples
{
  /// <summary>
  /// Interaction logic for winObjectDataProvider.xaml
  /// </summary>
  public partial class winObjectDataProviderLINQSQL : Window
  {
    public winObjectDataProviderLINQSQL()
    {
      InitializeComponent();
    }
  }
}
