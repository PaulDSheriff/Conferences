﻿using System.Windows;

namespace WPFDataSamples
{
  /// <summary>
  /// Interaction logic for App.xaml
  /// </summary>
  public partial class App : Application
  {
  }
}
