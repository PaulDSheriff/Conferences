﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Silverlight101
{
  public partial class ucMain : UserControl
  {
    public ucMain()
    {
      InitializeComponent();
    }

    #region Load User Control Method
    private void LoadUserControl(UserControl uc)
    {
      this.Content = uc;
    }
    #endregion

    private void btnSample1_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucSample1_AbsPosition());
    }

    private void btnSample2_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucSample2_Grid());
    }

    private void btnSample3_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucSample3_GridResizeMargin());
    }

    private void btnSample4_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucSample4_StackPanel());
    }

    private void btnSample5_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucSample5_Canvas());
    }

    private void btnMarginPadding_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucMarginPadding());
    }

    private void btnStyle1_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucStackPanelResource());
    }

    private void btnStyle2_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucWindowResource());
    }

    private void btnCheckBoxes_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucCheckBoxes());
    }

    private void btnImage_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucImage());
    }

    private void btnMedia_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucMedia());
    }

    private void btnPasswordBox_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucPasswordBox());
    }

    private void btnRadioButtons_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucRadioButtons());
    }

    private void btnTextBlock_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucTextBlock());
    }

    private void btnComboBox_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucComboBoxes());
    }

    private void btnListBox_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucListBox());
    }

    private void btnBorder_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucBorder());
    }

    private void btnTabs_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucTab());
    }

    private void btnScrollViewer_Click(object sender, RoutedEventArgs e)
    {
      LoadUserControl(new ucScrollViewer());
    }

  }
}
