﻿using System.Windows;
using System.Windows.Controls;

namespace Silverlight101
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private void btnMain_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new ucMain());
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Add(new ucMain());
    }
  }
}
