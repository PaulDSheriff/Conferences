public interface ITest
{
  string InformUser();
}