public class TestClass2 : ITest
{
  public string InformUser()
  {
    return "Hello from TestClass2";
  }

}