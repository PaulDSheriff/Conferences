using System.Data;

public class Users
{
  public DataTable GetAllUsers()
  {
    DataTable dt = null;

    dt = DataLayer.GetDataTable("SELECT * FROM oopUsers",
      AppConfig.ConnectString);

    return dt;
  }

  public DataTable GetUsersByFilter(UsersSearch userSearch)
  {
    string sql = string.Empty;
    string where = " WHERE ";
    DataTable dt = null;

    if (userSearch.FirstName.Trim() != string.Empty)
    {
      sql += where + " FirstName LIKE '" + userSearch.FirstName + "%'";
      where = " AND ";
    }
    if (userSearch.LastName.Trim() != string.Empty)
    {
      sql += where + " LastName LIKE '" + userSearch.LastName + "%'";
      where = " AND ";
    }
    if (userSearch.Email.Trim() != string.Empty)
    {
      sql += where + " Email LIKE '%" + userSearch.Email + "%'";
      where = " AND ";
    }

    dt = DataLayer.GetDataTable("SELECT * FROM oopUsers " + sql, 
      AppConfig.ConnectString);

    return dt;
  }
}