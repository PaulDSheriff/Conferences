Imports System.Data
Public Class Users
  Public Function GetAllUsers() As DataSet
    Dim ds As DataSet

    ds = DataLayer.GetDataSet("SELECT * FROM oopUsers", _
      AppConfig.ConnectString)

    Return ds
  End Function

  Public Function GetUsersByFilter(ByVal uSearch As UsersSearch) As DataSet
    Dim sql As String = String.Empty
    Dim where As String = " WHERE "
    Dim ds As DataSet

    If uSearch.FirstName.Trim() <> String.Empty Then
      sql &= where & " FirstName LIKE '" & uSearch.FirstName & "%'"
      where = " AND "
    End If
    If uSearch.LastName.Trim() <> String.Empty Then
      sql &= where & " LastName LIKE '" & uSearch.LastName & "%'"
      where = " AND "
    End If
    If uSearch.Email.Trim() <> String.Empty Then
      sql &= where & " Email LIKE '%" & uSearch.Email & "%'"
      where = " AND "
    End If

    ds = DataLayer.GetDataSet("SELECT * FROM oopUsers " & sql, _
     AppConfig.ConnectString)

    Return ds
  End Function
End Class