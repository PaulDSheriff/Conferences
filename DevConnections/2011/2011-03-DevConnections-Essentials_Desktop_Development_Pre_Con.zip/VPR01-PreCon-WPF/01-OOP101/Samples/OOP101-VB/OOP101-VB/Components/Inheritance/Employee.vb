Public Class Employee
  Inherits Person

  Private mSalary As Decimal

  Public Property Salary() As Decimal
    Get
      Return mSalary
    End Get
    Set(ByVal Value As Decimal)
      mSalary = Value
    End Set
  End Property
End Class
