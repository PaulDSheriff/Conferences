Public Class UsersSearch
  Private mFirstName As String = String.Empty
  Private mLastName As String = String.Empty
  Private mEmail As String = String.Empty

  Public Property FirstName() As String
    Get
      Return mFirstName
    End Get
    Set(ByVal Value As String)
      mFirstName = Value
    End Set
  End Property

  Public Property LastName() As String
    Get
      Return mLastName
    End Get
    Set(ByVal Value As String)
      mLastName = Value
    End Set
  End Property

  Public Property Email() As String
    Get
      Return mEmail
    End Get
    Set(ByVal Value As String)
      mEmail = Value
    End Set
  End Property
End Class
