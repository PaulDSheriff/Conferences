Public Class TestClass1
  Implements ITest

  Public Function InformUser() As String Implements ITest.InformUser
    Return "Hello from TestClass1"
  End Function
End Class
