﻿Imports System.Windows

Partial Public Class frmInterface1
  Inherits Window

  Private Sub btnTest1_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Test1()
  End Sub

  Private Sub Test1()
    Dim it As ITest = Nothing

    it = New TestClass1()

    lblMsg.Text = it.InformUser()
  End Sub

  Private Sub btnTest2_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Test2()
  End Sub

  Private Sub Test2()
    Dim it As ITest = Nothing

    it = New TestClass2()

    lblMsg.Text = it.InformUser()
  End Sub
End Class