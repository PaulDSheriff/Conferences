﻿Imports System.Windows

Partial Public Class frmUserSearch3
  Inherits Window

  Private Sub Window_Loaded(ByVal sender As Object, ByVal e As RoutedEventArgs)
    UserLoad()
  End Sub

  Private Sub UserLoad()
    Dim bo As New Users()

    lstUsers.DataContext = bo.GetAllUsers()
  End Sub

  Private Sub btnSearch_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    UserSearch()
  End Sub

  Private Sub UserSearch()
    Dim bo As New Users()
    Dim srch As UsersSearch

    srch = ucCriteria.GetInfo()

    lstUsers.DataContext = bo.GetUsersByFilter(srch)
  End Sub
End Class