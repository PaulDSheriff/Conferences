Public Class EventSampler2
  Public Event Before(ByVal sender As Object, ByVal e As EventSampler2EventArgs)
  Public Event ContinueProcess(ByVal sender As Object, ByVal e As EventSampler2EventArgs)
  Public Event After(ByVal sender As Object, ByVal e As EventSampler2EventArgs)

  Public TimesThru As Integer = 0

  Public Sub Process()
    Dim ev As New EventSampler2EventArgs

    ev.Message = "Before the Process"
    RaiseEvent Before(Me, ev)

    For Me.TimesThru = 1 To 10000000
      ev.TimesThru = TimesThru
      RaiseEvent ContinueProcess(Me, ev)

      If ev.Cancel Then
        Exit For
      End If
    Next

    ev.Message = "After the Process"
    RaiseEvent After(Me, ev)
  End Sub
End Class

Public Class EventSampler2EventArgs
  Inherits EventArgs

  Public Message As String = String.Empty
  Public Cancel As Boolean = False
  Public TimesThru As Integer = 0
End Class