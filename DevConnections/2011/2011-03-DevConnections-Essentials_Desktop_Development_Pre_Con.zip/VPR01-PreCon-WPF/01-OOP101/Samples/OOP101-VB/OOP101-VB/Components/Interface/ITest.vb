Public Interface ITest
  Function InformUser() As String
End Interface