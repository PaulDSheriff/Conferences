﻿Imports System
Imports System.Windows

Partial Public Class frmEventSample
  Inherits Window

#Region "Event Sample 1"
  Private mEV1 As New EventSampler1()

  Protected Sub btnSample1_Click(ByVal sender As [Object], ByVal e As RoutedEventArgs)
    AddHandler mEV1.After, AddressOf mEV1_After
    AddHandler mEV1.Before, AddressOf mEV1_Before
    mEV1.Process()
  End Sub

  Private Sub mEV1_After(ByVal Message As String)
    lblSample1.Text = Message
  End Sub

  Private Sub mEV1_Before(ByVal Message As String)
    lblSample1.Text = Message
  End Sub

#End Region

#Region "Event Sample 2"
  Private mEV2 As New EventSampler2()

  Protected Sub btnSample2_Click(ByVal sender As [Object], ByVal e As RoutedEventArgs)
    AddHandler mEV2.After, AddressOf mEV2_After
    AddHandler mEV2.ContinueProcess, AddressOf mEV2_ContinueProcess
    mEV2.Process()
  End Sub

  Private Sub mEV2_After(ByVal sender As Object, ByVal e As EventSampler2EventArgs)
    lblSample2.Text = (e.Message & " - TimesThru = ") + e.TimesThru.ToString()
  End Sub

  Private Sub mEV2_ContinueProcess(ByVal sender As Object, ByVal e As EventSampler2EventArgs)
    If e.TimesThru = 10 Then
      e.Cancel = True
    End If
  End Sub
#End Region
End Class