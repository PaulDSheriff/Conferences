﻿Imports System
Imports System.ComponentModel
Imports System.IO
Imports System.Windows
Imports System.Windows.Markup

Public Class MyWindow
  Inherits Window

  ''' <summary>
  ''' Returns a true if the Window object is in design mode, or false if in runtime mode.
  ''' </summary>
  ''' <returns>Boolean</returns>
  Public Function IsInDesignMode() As Boolean
    Return DesignerProperties.GetIsInDesignMode(Me)
  End Function

  ''' <summary>
  ''' Load and Merge a Resource Dictionary in a XAML file on disk into the current Window object
  ''' </summary>
  ''' <param name="fileName">The full path and file name of the XAML file.</param>
  Public Sub LoadSamplesResource(ByVal fileName As String)
    Dim dic As ResourceDictionary = Nothing

    If File.Exists(fileName) Then
      Using fs As New FileStream(fileName, FileMode.Open)
        dic = DirectCast(XamlReader.Load(fs), ResourceDictionary)
      End Using

      Me.Resources.MergedDictionaries.Clear()
      Me.Resources.MergedDictionaries.Add(dic)
    Else
      Throw New ApplicationException("Can't open resource file: " & fileName & " in the method WPFCommon.OpenResourceDictionary().")
    End If
  End Sub

  Public Function GetCurrentDirectory() As String
    Dim path As String = Nothing

    path = AppDomain.CurrentDomain.BaseDirectory
    If path.IndexOf("\bin") > 0 Then
      path = path.Substring(0, path.LastIndexOf("\bin"))
    End If

    Return path
  End Function
End Class