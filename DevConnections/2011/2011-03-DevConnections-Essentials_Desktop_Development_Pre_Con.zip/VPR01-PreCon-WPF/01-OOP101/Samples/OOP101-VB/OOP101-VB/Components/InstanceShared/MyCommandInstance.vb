Public Class MyCommandInstance
  Private mCommandText As String = String.Empty

  Public Property CommandText() As String
    Get
      Return mCommandText
    End Get
    Set(ByVal value As String)
      mCommandText = value
    End Set
  End Property
End Class
