﻿Imports System.Windows

Partial Public Class frmInstanceShared
  Inherits Window

  Private Sub btnInstance_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim cmd1 As New MyCommandInstance()
    Dim cmd2 As New MyCommandInstance()

    cmd1.CommandText = "SELECT * FROM Products"
    cmd2.CommandText = "SELECT * FROM Users"

    ' Look at each CommandText property
    System.Diagnostics.Debugger.Break()
  End Sub

  Private Sub btnShared_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    ' The following does not make sense
    Dim cmd1 As New MyCommandShared()
    Dim cmd2 As New MyCommandShared()
    ' cmd1.CommandText = "SELECT * FROM Products" ' Not valid

    MyCommandShared.CommandText = "SELECT * FROM Products"
    MyCommandShared.CommandText = "SELECT * FROM Users"

    ' Look at each CommandText property
    System.Diagnostics.Debugger.Break()
  End Sub
End Class