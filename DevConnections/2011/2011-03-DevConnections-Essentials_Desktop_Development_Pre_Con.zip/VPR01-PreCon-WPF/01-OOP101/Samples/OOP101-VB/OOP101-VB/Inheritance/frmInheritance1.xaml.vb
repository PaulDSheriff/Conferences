﻿Imports System
Imports System.Windows

Partial Public Class frmInheritance1
  Inherits Window

  Private Sub btnPerson_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim p As New Person()

    p.FirstName = "John"
    p.LastName = "Doe"

    ' Salary is not available
    ' p.Salary = Convert.ToDecimal(50000.0)

    lblName.Text = (p.LastName & ", ") + p.FirstName
  End Sub

  Private Sub btnEmployee_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim pe As New Employee()

    pe.FirstName = "John"
    pe.LastName = "Doe"
    pe.Salary = Convert.ToDecimal(50000.0R)

    lblName.Text = ((pe.LastName & ", ") + pe.FirstName & " - Salary: ") + pe.Salary.ToString("c")
  End Sub

  Private Sub btnPerson2_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim p As New Person2()

    p.FirstName = "John"
    p.LastName = "Doe"

    lblName.Text = p.FullName
  End Sub

  Private Sub btnEmployee2_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim pe As New Employee2()

    pe.FirstName = "John"
    pe.LastName = "Doe"
    pe.Salary = Convert.ToDecimal(50000.0R)

    lblName.Text = pe.FullName
  End Sub
End Class