Imports System.Configuration

Public Class AppConfig
  Public Shared ReadOnly Property ConnectString() As String
    Get
      Return ConfigurationManager.ConnectionStrings("Sandbox").ConnectionString
    End Get
  End Property

  Public Shared ReadOnly Property ConnectStringOleDb() As String
    Get
      Return ConfigurationManager.ConnectionStrings("SandboxOleDb").ConnectionString
    End Get
  End Property
End Class