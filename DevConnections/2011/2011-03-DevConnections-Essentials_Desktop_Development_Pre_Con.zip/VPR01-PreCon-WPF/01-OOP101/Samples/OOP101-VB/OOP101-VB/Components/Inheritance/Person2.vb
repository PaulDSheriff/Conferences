Public Class Person2
  Private mFirstName As String = String.Empty
  Private mLastName As String = String.Empty
  Private mFullName As String = String.Empty

  Public Property FirstName() As String
    Get
      Return mFirstName
    End Get
    Set(ByVal Value As String)
      mFirstName = Value
      ' Call Protected Method
      CreateFullName()
    End Set
  End Property

  Public Property LastName() As String
    Get
      Return mLastName
    End Get
    Set(ByVal Value As String)
      mLastName = Value
      ' Call Protected Method
      CreateFullName()
    End Set
  End Property

  Public Property FullName() As String
    Get
      Return mFullName
    End Get
    Set(ByVal Value As String)
      mFullName = Value
    End Set
  End Property

  Protected Overridable Sub CreateFullName()
    mFullName = mLastName & ", " & mFirstName
  End Sub
End Class
