Imports System.Data

Public Class DataLayer
  Public Shared Function GetDataSet(ByVal sql As String, _
   ByVal connectString As String) As DataSet
    Dim ds As New DataSet
    Dim da As SqlClient.SqlDataAdapter

    ' Create Data Adapter
    da = New SqlClient.SqlDataAdapter(sql, connectString)
    da.Fill(ds)

    Return ds
  End Function

  Public Shared Function GetDataTable(ByVal sql As String, ByVal connectString As String) As DataTable
    Return GetDataSet(sql, connectString).Tables(0)
  End Function
End Class