﻿using System;
using System.Windows;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Scheduler;

namespace ReminderDemo
{
  public partial class MainPage : PhoneApplicationPage
  {
    #region Constructor
    public MainPage()
    {
      InitializeComponent();
    }
    #endregion

    private void Remind_Click(object sender, RoutedEventArgs e)
    {
      Reminder r = new Reminder("Run demo!");

      r.Title = "Demo Reminder";
      r.Content = "Time to run the demo!";
      r.BeginTime = DateTime.Now.AddSeconds(5);
      r.NavigationUri = NavigationService.CurrentSource;

      // In case it was already there.
      ScheduledActionService.Remove("Run demo!");
      ScheduledActionService.Add(r);
    }
  }
}