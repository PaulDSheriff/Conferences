﻿using Microsoft.Phone.Controls;

namespace AppLifeCycle2
{
  public partial class MainPage : PhoneApplicationPage
  {
    // Constructor
    public MainPage()
    {
      InitializeComponent();
      Message.Text = App.WasTombstoned ? "Restoring..." : "Fast!";
    }
  }
}