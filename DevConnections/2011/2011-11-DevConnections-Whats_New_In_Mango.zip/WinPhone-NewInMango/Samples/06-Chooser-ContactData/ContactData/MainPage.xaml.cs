﻿using System;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Tasks;

namespace ContactData
{
  public partial class MainPage : PhoneApplicationPage
  {
    AddressChooserTask addressTask;
    EmailAddressChooserTask emailTask;
    PhoneNumberChooserTask phoneTask;
    public MainPage()
    {
      InitializeComponent();

      FindEmail.Click += (o, e) =>
      {
        emailTask = new EmailAddressChooserTask();
        emailTask.Completed += new EventHandler<EmailResult>(emailTask_Completed);
        emailTask.Show();
      };

      FindAddress.Click += (o, e) =>
      {
        addressTask = new AddressChooserTask();
        addressTask.Completed +=
            new EventHandler<AddressResult>(addressTask_Completed);
        addressTask.Show();
      };

      FindPhone.Click += (o, e) =>
      {
        phoneTask = new PhoneNumberChooserTask();
        phoneTask.Completed +=
            new EventHandler<PhoneNumberResult>(phoneTask_Completed);
        phoneTask.Show();
      };
    }

    void phoneTask_Completed(object sender, PhoneNumberResult e)
    {
      if (e.TaskResult == TaskResult.OK)
      {
        Results.Text = e.DisplayName + ": " + e.PhoneNumber;
      }
    }

    void emailTask_Completed(object sender, EmailResult e)
    {
      if (e.TaskResult == TaskResult.OK)
      {       
        Results.Text = e.DisplayName + ": " + e.Email;
      }
    }

    void addressTask_Completed(object sender, AddressResult e)
    {
      if (e.TaskResult == TaskResult.OK)
      {
        Results.Text = e.DisplayName + ": " + e.Address;       
      }
    }
  }
}