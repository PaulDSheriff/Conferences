﻿using System;
using System.Linq;
using System.Windows;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace TilesPart1
{
  public partial class MainPage : PhoneApplicationPage
  {
    #region Constructor
    public MainPage()
    {
      InitializeComponent();
    }
    #endregion

    private void Create_Click(object sender, RoutedEventArgs e)
    {
      // See if secondary tile has been setup
      ShellTile secondaryTile =
               ShellTile.ActiveTiles.FirstOrDefault(
               x => x.NavigationUri
                   .ToString()
                   .Contains("Secondary"));

      if (secondaryTile == null)
      {
        // Create new tile
        StandardTileData NewTileData = new StandardTileData
        {
          BackgroundImage =
               new Uri("Blue.jpg", UriKind.Relative),
          Title = "Secondary Tile",
          Count = 1,
          // Now create back of tile
          BackBackgroundImage =
               new Uri("Red.jpg", UriKind.Relative),
          BackTitle = "Current Weather",
          BackContent = "72 degrees, Sunny",
        };

        // Create tile with link to call page and pass in parameter
        ShellTile.Create(
            new Uri(
                "/MainPage.xaml?Secondary",
                UriKind.Relative),
                NewTileData);

      }
    }
  }
}





