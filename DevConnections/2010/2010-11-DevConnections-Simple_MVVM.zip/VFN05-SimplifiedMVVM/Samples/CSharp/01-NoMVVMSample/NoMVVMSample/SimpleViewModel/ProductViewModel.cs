﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;

namespace NoMVVMSample
{
  public class ProductViewModel : DependencyObject, INotifyPropertyChanged
  {
    bool _IsAddMode = false;
    ProductManager _DataManager = new ProductManager();

    #region Constructor - Initialize Product Data Collection
    public ProductViewModel()
    {
      DataCollection = _DataManager.GetProducts();
    }
    #endregion

    #region INotifyPropertyChanged
    public event PropertyChangedEventHandler PropertyChanged;

    protected void RaisePropertyChanged(string propertyName)
    {
      if (PropertyChanged != null)
        PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
    }
    #endregion

    #region Private UI Variables
    private bool _IsSaveEnabled = false;
    private bool _IsCancelEnabled = false;
    private bool _IsAddEnabled = true;
    #endregion

    #region UI Properties
    public bool IsSaveEnabled
    {
      get { return _IsSaveEnabled; }
      set
      {
        if (_IsSaveEnabled != value)
        {
          _IsSaveEnabled = value;
          RaisePropertyChanged("IsSaveEnabled");
        }
      }
    }

    public bool IsCancelEnabled
    {
      get { return _IsCancelEnabled; }
      set
      {
        if (_IsCancelEnabled != value)
        {
          _IsCancelEnabled = value;
          RaisePropertyChanged("IsCancelEnabled");
        }
      }
    }

    public bool IsAddEnabled
    {
      get { return _IsAddEnabled; }
      set
      {
        if (_IsAddEnabled != value)
        {
          _IsAddEnabled = value;
          RaisePropertyChanged("IsAddEnabled");
        }
      }
    }

    public bool IsAddMode
    {
      get { return _IsAddMode; }
      set
      {
        if (_IsAddMode != value)
        {
          _IsAddMode = value;
          RaisePropertyChanged("IsAddMode");
        }
      }
    }
    #endregion

    #region DataCollection Property
    public ObservableCollection<Product> DataCollection
    {
      get { return (ObservableCollection<Product>)GetValue(DataCollectionProperty); }
      set { SetValue(DataCollectionProperty, value); }
    }

    public static readonly DependencyProperty DataCollectionProperty =
        DependencyProperty.Register("DataCollection", typeof(ObservableCollection<Product>), typeof(ProductViewModel), new UIPropertyMetadata(null));
    #endregion

    #region DetailData Property
    public Product DetailData
    {
      get { return (Product)GetValue(DetailDataProperty); }
      set { SetValue(DetailDataProperty, value); }
    }

    public static readonly DependencyProperty DetailDataProperty =
        DependencyProperty.Register("DetailData", typeof(Product), typeof(ProductViewModel), new UIPropertyMetadata(null));
    #endregion

    #region SetNormalUIDisplay Method
    public void SetNormalUIDisplay()
    {
      IsAddMode = false;
      IsAddEnabled = true;
      IsSaveEnabled = false;
      IsCancelEnabled = false;
    }
    #endregion

    #region SetEditUIDisplay Method
    public void SetEditUIDisplay()
    {
      IsAddEnabled = false;
      IsSaveEnabled = true;
      IsCancelEnabled = true;
    }
    #endregion

    #region AddRecord Method
    public void AddRecord()
    {
      SetEditUIDisplay();
      IsAddMode = true;

      // Create Empty Object for UI to Display
      DetailData = new Product();
    }
    #endregion

    #region CancelEdit Method
    public void CancelEdit()
    {
      SetNormalUIDisplay();

      // TODO: Write Code to Undo Here
    }
    #endregion

    #region SaveData Method
    public void SaveData()
    {
      if (IsAddMode)
      {
        _DataManager.Insert(DetailData);
        DataCollection.Add(DetailData);
      }
      else
      {
        _DataManager.Update(DetailData);
      }
      SetNormalUIDisplay();
    }
    #endregion

    #region DeleteData Method
    public void DeleteData()
    {
      _DataManager.Delete(DetailData);
      DataCollection.Remove(DetailData);
      SetNormalUIDisplay();
    }
    #endregion
  }
}
