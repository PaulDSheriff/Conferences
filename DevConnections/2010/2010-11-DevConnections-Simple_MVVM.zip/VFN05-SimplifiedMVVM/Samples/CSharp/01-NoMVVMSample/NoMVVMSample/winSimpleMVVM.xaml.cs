﻿using System.Windows;
using System.Windows.Controls;

namespace NoMVVMSample
{
  public partial class winSimpleMVVM : Window
  {
    ProductViewModel _ViewModel;

    #region Constructor
    public winSimpleMVVM()
    {
      InitializeComponent();

      // Initialize the Product View Model Object
      _ViewModel = (ProductViewModel)this.FindResource("viewModel");

      // For some reason, the ListView is not Selected, so Select it
      lstData.SelectedIndex = 0;
    }
    #endregion

    #region Add Click Event
    private void btnAdd_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.AddRecord();
    }
    #endregion

    #region Cancel Click Event
    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.CancelEdit();

      // TODO: Write code to undo changes

      lstData.SelectedIndex = 0;
    }
    #endregion

    #region Save Click Event
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.SaveData();
    }
    #endregion

    #region Data Has Changed Methods
    private void TextHasChanged(object sender, TextChangedEventArgs e)
    {
      // Only Change Mode if Element has Keyboard Focus
      if (((UIElement)sender).IsKeyboardFocused)
        _ViewModel.SetEditUIDisplay();
    }

    private void CheckedHasChanged(object sender, RoutedEventArgs e)
    {
      if (((UIElement)sender).IsKeyboardFocused || ((UIElement)sender).IsMouseDirectlyOver)
        _ViewModel.SetEditUIDisplay();
    }
    #endregion
  }
}
