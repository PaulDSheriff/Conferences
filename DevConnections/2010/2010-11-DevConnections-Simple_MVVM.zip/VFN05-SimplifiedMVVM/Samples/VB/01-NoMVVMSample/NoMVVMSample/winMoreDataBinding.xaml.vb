﻿Imports System.Collections.ObjectModel
Imports System.ComponentModel
Imports System.Windows
Imports System.Windows.Controls

Partial Public Class winMoreDataBinding
  Inherits Window
  Implements INotifyPropertyChanged

  Private mDataManager As ProductManager
  Private mIsAddMode As Boolean = False

#Region "INotifyPropertyChanged"
  Public Event PropertyChanged As PropertyChangedEventHandler Implements INotifyPropertyChanged.PropertyChanged

  Protected Sub RaisePropertyChanged(ByVal propertyName As String)
    RaiseEvent PropertyChanged(Me, New PropertyChangedEventArgs(propertyName))
  End Sub
#End Region

#Region "Constructor"
  Public Sub New()
    InitializeComponent()
  End Sub
#End Region

#Region "Private UI Variables"
  Private _IsSaveEnabled As Boolean = False
  Private _IsCancelEnabled As Boolean = False
  Private _IsAddEnabled As Boolean = True
#End Region

#Region "UI Properties"
  Public Property IsSaveEnabled() As Boolean
    Get
      Return _IsSaveEnabled
    End Get
    Set(ByVal value As Boolean)
      If _IsSaveEnabled <> value Then
        _IsSaveEnabled = value
        RaisePropertyChanged("IsSaveEnabled")
      End If
    End Set
  End Property

  Public Property IsCancelEnabled() As Boolean
    Get
      Return _IsCancelEnabled
    End Get
    Set(ByVal value As Boolean)
      If _IsCancelEnabled <> value Then
        _IsCancelEnabled = value
        RaisePropertyChanged("IsCancelEnabled")
      End If
    End Set
  End Property

  Public Property IsAddEnabled() As Boolean
    Get
      Return _IsAddEnabled
    End Get
    Set(ByVal value As Boolean)
      If _IsAddEnabled <> value Then
        _IsAddEnabled = value
        RaisePropertyChanged("IsAddEnabled")
      End If
    End Set
  End Property
#End Region

#Region "Loaded Event"
  Private Sub Window_Loaded(ByVal sender As Object, ByVal e As RoutedEventArgs)
    mDataManager = New ProductManager()

    lstData.DataContext = mDataManager.GetProducts()
  End Sub
#End Region

#Region "Add Click Event"
  Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    ' Create blank Object and Put UI into Add Mode 
    ' Put UI into Add Mode 
    mIsAddMode = True
    SetEditUIDisplay()

    grdDetail.DataContext = New Product()
  End Sub

#End Region

#Region "Cancel Click Event"
  Private Sub btnCancel_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    ' Cancel the Edit 
    SetNormalUIDisplay()

    ' TODO: Write code to undo changes 

    lstData.SelectedIndex = 0
  End Sub
#End Region

#Region "Save Click Event"
  Private Sub btnSave_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    If mIsAddMode Then
      AddData()
    Else
      UpdateData()
    End If

    SetNormalUIDisplay()
  End Sub
#End Region

#Region "AddData Method"
  Private Sub AddData()
    ' Save the Current Item 
    Dim mgr As New ProductManager()
    Dim entity As Product = DirectCast(grdDetail.DataContext, Product)

    Dim coll As ObservableCollection(Of Product) = DirectCast(lstData.DataContext, ObservableCollection(Of Product))
    coll.Add(entity)

    ' Save the Data
    mgr.Insert(entity)
  End Sub
#End Region

#Region "UpdateData Method"
  Private Sub UpdateData()
    Dim mgr As New ProductManager()
    Dim entity As Product = DirectCast(lstData.SelectedItem, Product)

    mgr.Update(entity)
  End Sub
#End Region

#Region "SetNormalUIDisplay Method"
  Private Sub SetNormalUIDisplay()
    mIsAddMode = False
    IsAddEnabled = True
    IsSaveEnabled = False
    IsCancelEnabled = False
  End Sub
#End Region

#Region "SetEditUIDisplay Method"
  Private Sub SetEditUIDisplay()
    IsAddEnabled = False
    IsSaveEnabled = True
    IsCancelEnabled = True
  End Sub
#End Region

#Region "Data Has Changed Methods"
  Private Sub TextHasChanged(ByVal sender As Object, ByVal e As TextChangedEventArgs)
    ' Only Change Mode if Element has Keyboard Focus 
    If DirectCast(sender, UIElement).IsKeyboardFocused Then
      SetEditUIDisplay()
    End If
  End Sub

  Private Sub CheckedHasChanged(ByVal sender As Object, ByVal e As RoutedEventArgs)
    If DirectCast(sender, UIElement).IsKeyboardFocused OrElse DirectCast(sender, UIElement).IsMouseDirectlyOver Then
      SetEditUIDisplay()
    End If
  End Sub
#End Region
End Class