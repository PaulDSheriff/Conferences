﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPFDataGridComboBox
{
  public class ProductViewModel : CommonBase
  {
    private Products _ProductsCollection;
    private ProductTypes _ProductTypesCollection;

    public Products ProductsCollection
    {
      get { return _ProductsCollection; }
      set
      {
        _ProductsCollection = value;
        OnPropertyChanged("ProductsCollection");
      }
    }

    public ProductTypes ProductTypesCollection
    {
      get { return _ProductTypesCollection; }
      set
      {
        _ProductTypesCollection = value;
        OnPropertyChanged("ProductTypesCollection");
      }
    }

    public void Init()
    {
      // Create the collection of Product Types
      ProductTypes types = new ProductTypes();
      ProductTypesCollection = types.BuildCollection();

      // Create the collection of Products
      Products prods = new Products();
      ProductsCollection = prods.BuildCollection(ProductTypesCollection);
    }
  }
}
