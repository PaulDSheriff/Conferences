﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPFDataGridComboBox
{
  public class ProductType : CommonBase
  {
    public ProductType(int typeId, string desc)
    {
      ProductTypeId = typeId;
      TypeDescription = desc;
    }

    private int _ProductTypeId = 0;
    private string _TypeDescription = string.Empty;

    public int ProductTypeId
    {
      get { return _ProductTypeId; }
      set
      {
        _ProductTypeId = value;
        OnPropertyChanged("ProductTypeId");
      }
    }

    public string TypeDescription
    {
      get { return _TypeDescription; }
      set
      {
        _TypeDescription = value;
        OnPropertyChanged("TypeDescription");
      }
    }
  }
}
