﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPFDataGridComboBox
{
  public class ProductTypes : List<ProductType>
  {
    public ProductTypes BuildCollection()
    {
      this.Add(new ProductType(1, "Product"));
      this.Add(new ProductType(2, "eBook"));
      this.Add(new ProductType(3, "Video"));

      return this;
    }

    public ProductType GetType(int typeId)
    {
      return Find(t => t.ProductTypeId == typeId);
    }

    public ProductType GetType(string desc)
    {
      return Find(t => t.TypeDescription == desc);
    }
  }
}
