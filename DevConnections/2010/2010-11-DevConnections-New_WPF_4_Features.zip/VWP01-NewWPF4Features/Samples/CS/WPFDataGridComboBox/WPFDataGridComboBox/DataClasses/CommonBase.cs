﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;


namespace WPFDataGridComboBox
{
  public abstract class CommonBase : DependencyObject, INotifyPropertyChanged 
  {
    protected CommonBase()
    {
    }

    public event PropertyChangedEventHandler PropertyChanged;

    //This raises the INotifyPropertyChanged.PropertyChanged event to indicate
    //a specific property has changed value.
    /// </summary>
    /// <param name="propertyName"></param>            
    protected virtual void OnPropertyChanged(string propertyName)
    {
      PropertyChangedEventHandler handler = this.PropertyChanged;
      if (handler != null)
      {
        var e = new PropertyChangedEventArgs(propertyName);
        handler(this, e);
      }
    }
  }
}
