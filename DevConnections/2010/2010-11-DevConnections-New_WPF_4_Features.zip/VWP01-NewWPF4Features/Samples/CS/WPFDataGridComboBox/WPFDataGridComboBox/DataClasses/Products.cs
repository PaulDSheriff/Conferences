﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPFDataGridComboBox
{
  public class Products : List<Product>
  {
    public Products BuildCollection(ProductTypes types)
    {
      this.Add(new Product(1, "PDSA Framework", types.GetType("Product")));
      this.Add(new Product(2, "Haystack", types.GetType("Product")));
      this.Add(new Product(3, "Fundamentals of .NET eBook", types.GetType("eBook")));
      this.Add(new Product(4, "MVVM Made Simple", types.GetType("Video")));

      return this;
    }
  }
}
