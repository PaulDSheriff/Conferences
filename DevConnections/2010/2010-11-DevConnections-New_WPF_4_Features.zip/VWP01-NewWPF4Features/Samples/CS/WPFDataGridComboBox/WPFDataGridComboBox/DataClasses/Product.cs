﻿
namespace WPFDataGridComboBox
{
  public class Product : CommonBase
  {
    public Product(int id, string name, ProductType type)
    {
      ProductId = id;
      ProductName = name;
      TypeOfProduct = type;
    }

    private int _ProductId = 0;
    private string _ProductName = string.Empty;
    private ProductType _TypeOfProduct = null;

    public int ProductId
    {
      get { return _ProductId; }
      set
      {
        _ProductId = value;
        OnPropertyChanged("ProductId");
      }
    }

    public string ProductName
    {
      get { return _ProductName; }
      set
      {
        _ProductName = value;
        OnPropertyChanged("ProductName");
      }
    }

    public ProductType TypeOfProduct
    {
      get { return _TypeOfProduct; }
      set
      {
        _TypeOfProduct = value;
        OnPropertyChanged("TypeOfProduct");
      }
    }
  }
}
