﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFDataGrid
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private System.Data.Objects.ObjectQuery<Customer> GetCustomersQuery(AdventureWorksLTEntities adventureWorksLTEntities)
    {
      // Auto generated code

      System.Data.Objects.ObjectQuery<WPFDataGrid.Customer> customersQuery = adventureWorksLTEntities.Customers;
      // Returns an ObjectQuery.
      return customersQuery;
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {

      WPFDataGrid.AdventureWorksLTEntities adventureWorksLTEntities = new WPFDataGrid.AdventureWorksLTEntities();
      // Load data into Customers. You can modify this code as needed.
      System.Windows.Data.CollectionViewSource customersViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("customersViewSource")));
      System.Data.Objects.ObjectQuery<WPFDataGrid.Customer> customersQuery = this.GetCustomersQuery(adventureWorksLTEntities);
      customersViewSource.Source = customersQuery.Execute(System.Data.Objects.MergeOption.AppendOnly);
    }
  }
}
