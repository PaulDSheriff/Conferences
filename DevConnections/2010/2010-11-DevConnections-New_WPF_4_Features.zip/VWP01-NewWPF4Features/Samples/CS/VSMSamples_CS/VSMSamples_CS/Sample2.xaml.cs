﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace VSMSamples_CS
{
  /// <summary>
  /// Interaction logic for Sample2.xaml
  /// </summary>
  public partial class Sample2 : Window
  {
    public Sample2()
    {
      InitializeComponent();
    }

    private void rect_MouseEnter(object sender, MouseEventArgs e)
    {
      VisualStateManager.GoToElementState(rect, "MouseEnter", true);
    }

    private void rect_MouseLeave(object sender, MouseEventArgs e)
    {
      VisualStateManager.GoToElementState(rect, "MouseLeave", true);
    }
  }
}
