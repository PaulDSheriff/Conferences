﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace VSMSamples_CS
{
  /// <summary>
  /// Interaction logic for Sample4.xaml
  /// </summary>
  public partial class Sample4 : Window
  {
    public Sample4()
    {
      InitializeComponent();
    }
  }
}
