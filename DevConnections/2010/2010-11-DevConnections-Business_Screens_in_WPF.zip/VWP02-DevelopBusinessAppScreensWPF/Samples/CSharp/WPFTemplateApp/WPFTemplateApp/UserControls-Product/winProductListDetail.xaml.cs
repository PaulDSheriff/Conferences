﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFTemplateApp
{
  /// <summary>
  /// Interaction logic for winProductListDetail.xaml
  /// </summary>
  public partial class winProductListDetail : Window
  {
    public winProductListDetail()
    {
      InitializeComponent();
    }

    #region Cancel Event
    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      // Cancel the Edit
      ((ProductViewModel)this.DataContext).CancelEdit();
      this.Close();
    }
    #endregion

    #region Save Event
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      // Save the Current Item
      ((ProductViewModel)this.DataContext).SaveData();
      this.Close();
    }
    #endregion

    #region Data Has Changed Methods
    private void TextHasChanged(object sender, TextChangedEventArgs e)
    {
      // Only Change Mode if Element has Keyboard Focus
      if (((UIElement)sender).IsKeyboardFocused)
        ((ProductViewModel)this.DataContext).SetViewStateMode(UIStateMode.Edit);
    }

    private void CheckedHasChanged(object sender, RoutedEventArgs e)
    {
      if (((UIElement)sender).IsKeyboardFocused || ((UIElement)sender).IsMouseDirectlyOver)
        ((ProductViewModel)this.DataContext).SetViewStateMode(UIStateMode.Edit);
    }
    #endregion
  }
}
