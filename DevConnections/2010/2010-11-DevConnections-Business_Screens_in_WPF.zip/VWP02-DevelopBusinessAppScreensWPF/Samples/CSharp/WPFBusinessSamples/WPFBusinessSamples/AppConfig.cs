﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPFBusinessSamples
{
  public class AppConfig
  {
    protected static string GetSetting(string key)
    {
      return ConfigurationManager.AppSettings[key];
    }

    public static string ResourceFile
    {
      get { return GetSetting("ResourceFile"); }
    }
  }
}
