﻿using System.Windows;

namespace WPFBusinessSamples
{
  /// <summary>
  /// Interaction logic for winMenuOnLeft.xaml
  /// </summary>
  public partial class winMenuOnLeft : Window
  {
    public winMenuOnLeft()
    {
      InitializeComponent();
    }
  }
}
