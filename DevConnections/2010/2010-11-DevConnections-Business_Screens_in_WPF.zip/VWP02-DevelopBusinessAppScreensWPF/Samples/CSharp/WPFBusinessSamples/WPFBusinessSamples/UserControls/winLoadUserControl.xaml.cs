﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using WPFComponents;

namespace WPFBusinessSamples
{
  /// <summary>
  /// Interaction logic for winLoadUserControl.xaml
  /// </summary>
  public partial class winLoadUserControl : Window
  {
    public winLoadUserControl()
    {
      InitializeComponent();
    }

    private void btnLoad_Click(object sender, RoutedEventArgs e)
    {
      btnLoad.IsEnabled = false;

      ucAddress ucaddr = new ucAddress();
      Address addr = new Address();

      stpMain.Children.Add(ucaddr);

      ucaddr.DataContext = addr.CreateSample();
    }
  }
}
