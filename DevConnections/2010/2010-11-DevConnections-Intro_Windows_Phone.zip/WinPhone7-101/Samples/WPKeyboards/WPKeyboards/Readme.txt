﻿There are different keyboard layouts
 Default
 Text
 Number
 Chat
 TelephoneNumber

For a complete list, see the following link:
http://msdn.microsoft.com/en-us/library/system.windows.input.inputscopenamevalue(VS.95).aspx