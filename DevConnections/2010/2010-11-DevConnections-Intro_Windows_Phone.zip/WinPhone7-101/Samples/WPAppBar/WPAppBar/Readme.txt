﻿For your images...

1. Icons must be 48x48 pixels
2. Design should be white foreground 26x26 pixels
3. Background must be transparent
4. Property for icon should be...
   a. Build Action=Content
   b. Copy to Ouput Directory=Copy Always