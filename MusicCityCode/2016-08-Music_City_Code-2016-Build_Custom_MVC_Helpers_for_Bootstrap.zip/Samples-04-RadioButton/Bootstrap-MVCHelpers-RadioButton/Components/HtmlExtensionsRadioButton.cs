﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using System.Web.Routing;

namespace Bootstrap_MVCHelpers_RadioButton
{
  public static class HtmlExtensionsRadioButton
  {
    #region Bootstrap Radio Button
    /// <summary>
    /// Bootstrap Radio Button
    /// </summary>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="text">The text to display next to this radio button.</param>
    /// <param name="value">The 'value' attribute to set.</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML radio button with the appropriate type set.</returns>
    public static MvcHtmlString BootstrapRadioButtonFor<TModel, TProperty>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TProperty>> expression,
      string text,
      string value,
      object htmlAttributes = null)
    {
      return BootstrapRadioButtonFor(htmlHelper, expression, text, value, false, false, htmlAttributes);
    }

    /// <summary>
    /// Bootstrap Radio Button
    /// </summary>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="text">The text to display next to this radio button.</param>
    /// <param name="value">The 'value' attribute to set.</param>
    /// <param name="useInline">Whether or not to use 'radio-inline' for the Bootstrap class.</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML radio button with the appropriate type set.</returns>
    public static MvcHtmlString BootstrapRadioButtonFor<TModel, TProperty>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TProperty>> expression,
      string text,
      string value,
      bool useInline,
      object htmlAttributes = null)
    {
      return BootstrapRadioButtonFor(htmlHelper, expression, text, value, useInline, false, htmlAttributes);
    }

    /// <summary>
    /// Bootstrap Radio Button
    /// </summary>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="text">The text to display next to this radio button.</param>
    /// <param name="value">The 'value' attribute to set.</param>
    /// <param name="useInline">Whether or not to use 'radio-inline' for the Bootstrap class.</param>
    /// <param name="isAutoFocus">Whether or not to set the 'autofocus' attribute on this radio button.</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML radio button with the appropriate type set.</returns>
    public static MvcHtmlString BootstrapRadioButtonFor<TModel, TProperty>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TProperty>> expression,
      string text,
      string value,
      bool useInline,
      bool isAutoFocus,
      object htmlAttributes = null)
    {
      StringBuilder sb = new StringBuilder(512);
      RouteValueDictionary rvd;

      // Add additional attributes
      rvd = new RouteValueDictionary(HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

      // Add HTML 5 attributes
      if (isAutoFocus) {
        rvd.Add("autofocus", "autofocus");
      }

      // Build the Radio Button
      if (useInline) {
        sb.Append("<div class='radio-inline'>");
      }
      else {
        sb.Append("<div class='radio'>");
        sb.Append("<label>");
      }

      // Add on Radio Button
      sb.Append(InputExtensions.RadioButtonFor(htmlHelper,
                expression,
                value,
                rvd));

      sb.Append(text);
      if (useInline) {
        sb.Append("</div>");
      }
      else {
        sb.Append("</label>");
        sb.Append("</div>");
      }

      // Return an MVC HTML String
      return MvcHtmlString.Create(sb.ToString());
    }
    #endregion
  }
}