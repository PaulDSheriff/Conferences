﻿using System.Web.Mvc;
using SamplesData;

namespace Bootstrap_MVCHelpers_RadioButton.Controllers
{
  public class RadioButtonSamplesController : Controller
  {
    public ActionResult RadioButton01()
    {
      UserData model = new UserData();

      return View(model);
    }

    public ActionResult RadioButton02()
    {
      UserData model = new UserData();

      return View(model);
    }    
  }
}