﻿using System;
using System.Linq.Expressions;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using System.Web.Routing;

namespace Bootstrap_MVCHelpers_Password
{
  public static class HtmlExtensionsPassword
  {
    #region Bootstrap/HTML 5 Password Helpers
    /// <summary>
    /// Bootstrap and HTML 5 Password Helper
    /// </summary>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML input element with the appropriate type set.</returns>
    public static MvcHtmlString BootstrapPasswordFor<TModel, TValue>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TValue>> expression,
      object htmlAttributes = null)
    {
      return BootstrapPasswordFor(htmlHelper, expression,
          string.Empty, string.Empty, false, 
          false, null, htmlAttributes);
    }
        
    /// <summary>
    /// Bootstrap and HTML 5 Password Helper
    /// </summary>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="title">The HTML 5 'title' attribute to set.</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML input element with the appropriate type set.</returns>
    public static MvcHtmlString BootstrapPasswordFor<TModel, TValue>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TValue>> expression,
      string title,
      object htmlAttributes = null)
    {
      return BootstrapPasswordFor(htmlHelper, expression, title, title,
          false, false, null, htmlAttributes);
    }

    /// <summary>
    /// Bootstrap and HTML 5 Password Helper
    /// </summary>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="title">The HTML 5 'title' attribute to set.</param>
    /// <param name="isRequired">Whether or not to set the 'required' attribute on this Password.</param>
    /// <param name="isAutoFocus">Whether or not to set the 'autofocus' attribute on this Password.</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML input element with the appropriate type set.</returns>
    public static MvcHtmlString BootstrapPasswordFor<TModel, TValue>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TValue>> expression,
      string title,
      bool isRequired,
      bool isAutoFocus,
      object htmlAttributes = null)
    {
      return BootstrapPasswordFor(htmlHelper, expression,
          title, title, isRequired,
          isAutoFocus, null, htmlAttributes);
    }

    /// <summary>
    /// Bootstrap and HTML 5 Password Helper
    /// </summary>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="title">The HTML 5 'title' attribute to set.</param>
    /// <param name="placeholder">The HTML 5 'placeholder' attribute to set.</param>
    /// <param name="isRequired">Whether or not to set the 'required' attribute on this Password.</param>
    /// <param name="isAutoFocus">Whether or not to set the 'autofocus' attribute on this Password.</param>
    /// <param name="cssClass">Additional CSS class(es) to add. 'form-control' is added automatically.</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML input element with the appropriate type set.</returns>
    public static MvcHtmlString BootstrapPasswordFor<TModel, TValue>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TValue>> expression,
      string title,
      string placeholder,
      bool isRequired,
      bool isAutoFocus,
      string cssClass = "",
      object htmlAttributes = null)
    {
      RouteValueDictionary rvd;

      // Add additional attributes
      rvd = new RouteValueDictionary(HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

      // Set the 'password' type
      rvd.Add("type", "password");

      // Add HTML 5 attributes
      if (!string.IsNullOrEmpty(title)) {
        rvd.Add("title", title);
      }
      if (!string.IsNullOrEmpty(placeholder)) {
        rvd.Add("placeholder", placeholder);
      }
      if (isAutoFocus) {
        rvd.Add("autofocus", "autofocus");
      }
      if (isRequired) {
        rvd.Add("required", "required");
      }

      // Add CSS classes
      if (string.IsNullOrEmpty(cssClass)) {
        cssClass = "form-control";
      }
      else {
        cssClass = "form-control" + " " + cssClass;
      }
      rvd.Add("class", cssClass);

      // Build Password using InputExtensions
      return InputExtensions.PasswordFor(htmlHelper,
                 expression,
                 rvd);
    }
    #endregion
  }
}