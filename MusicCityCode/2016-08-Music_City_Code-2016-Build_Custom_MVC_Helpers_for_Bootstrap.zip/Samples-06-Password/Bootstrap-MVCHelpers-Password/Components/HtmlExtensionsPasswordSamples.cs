﻿using System;
using System.Linq.Expressions;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using System.Web.Routing;

namespace Bootstrap_MVCHelpers_Password
{
  public static class HtmlExtensionsPasswordSamples
  {
    public static MvcHtmlString BootstrapPasswordFor1<TModel, TValue>(
       this HtmlHelper<TModel> htmlHelper,
       Expression<Func<TModel, TValue>> expression,
       object htmlAttributes = null)
    {
      RouteValueDictionary rvd;

      // Add additional attributes
      rvd = new RouteValueDictionary(
         HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

      // Set the 'password' type
      rvd.Add("type", "password");

      // Build text box using InputExtensions
      return InputExtensions.PasswordFor(htmlHelper,
                  expression,
                  rvd);
    }
      
    public static MvcHtmlString BootstrapPasswordFor2<TModel, TValue>(
      this HtmlHelper<TModel> htmlHelper,
        Expression<Func<TModel, TValue>> expression,
        string title,
        string placeholder,
        bool isRequired,
        bool isAutoFocus,
        object htmlAttributes = null)
    {
      RouteValueDictionary rvd;

      // Add additional attributes
      rvd = new RouteValueDictionary(
          HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

      // Set the 'password' type
      rvd.Add("type", "password");

      // Add HTML 5 attributes
      if (!string.IsNullOrEmpty(title)) {
        rvd.Add("title", title);
      }
      if (!string.IsNullOrEmpty(placeholder)) {
        rvd.Add("placeholder", placeholder);
      }
      if (isAutoFocus) {
        rvd.Add("autofocus", "autofocus");
      }
      if (isRequired) {
        rvd.Add("required", "required");
      }

      // Build text box using InputExtensions
      return InputExtensions.PasswordFor(htmlHelper,
                  expression,
                  rvd);
    }
  }
}