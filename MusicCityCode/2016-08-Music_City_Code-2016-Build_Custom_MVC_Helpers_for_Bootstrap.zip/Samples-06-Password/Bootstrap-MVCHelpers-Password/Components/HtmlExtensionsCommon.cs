﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace Bootstrap_MVCHelpers_Password
{
   public static class HtmlExtensionsCommon
   {
      #region Button Types
      public enum HtmlButtonTypes
      {
         submit,
         button,
         reset
      }
      #endregion

      #region HTML 5 Input Types Enum
      public enum Html5InputTypes
      {
         text,
         color,
         date,
         datetime,
         email,
         month,
         number,
         password,
         range,
         search,
         tel,
         time,
         url,
         week
      }
      #endregion

      #region AddName Method
      public static void AddName(TagBuilder tb, string name, string id)
      {
         if (!string.IsNullOrWhiteSpace(name)) {
            // Ensure we have valid name
            name = TagBuilder.CreateSanitizedId(name);

            if (string.IsNullOrWhiteSpace(id)) {
               // Generate a valid 'id' attribute from the 'name' attribute
               tb.GenerateId(name);
            }
            else {
               // Add 'id' to HTML
               tb.MergeAttribute("id", TagBuilder.CreateSanitizedId(id));
            }

            // Add 'name' to HTML
            tb.MergeAttribute("name", name);
         }
      }
      #endregion
   }
}