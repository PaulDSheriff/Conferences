﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Bootstrap_MVCHelpers_Password
{
  public class UserData
  {
    #region Constructor
    public UserData()
      : base()
    {
      Email = string.Empty;
      Password = string.Empty;
    }
    #endregion

    #region Public Properties
    [Required(ErrorMessage = "Email is required")]
    public string Email { get; set; }
    [Required(ErrorMessage = "Password is required")]
    public string Password { get; set; }
    #endregion
  }
}
