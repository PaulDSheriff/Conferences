﻿using System.Web.Mvc;

namespace Bootstrap_MVCHelpers_Password.Controllers
{
   public class PasswordSamplesController : Controller
   {
      public ActionResult Password01()
      {
         UserData model = new UserData();

         return View(model);
      }

      public ActionResult Password02()
      {
         UserData model = new UserData();

         return View(model);
      }

      public ActionResult Password03()
      {
         UserData model = new UserData();

         return View(model);
      }
   }
}