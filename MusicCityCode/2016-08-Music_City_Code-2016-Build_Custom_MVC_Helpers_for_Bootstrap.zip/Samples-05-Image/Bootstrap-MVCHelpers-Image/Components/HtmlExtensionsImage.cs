﻿using System.Text;
using System.Web.Mvc;

namespace Bootstrap_MVCHelpers_Image
{
  public static class HtmlExtensionsImage
  {
    #region Image Element 1 - Using StringBuilder()
    public static MvcHtmlString Image1(this HtmlHelper htmlHelper,
      string src,
      string altText)
    {
      StringBuilder sb = new StringBuilder(512);

      sb.AppendFormat("<img src='{0}' alt='{1}' />", src, altText);

      return MvcHtmlString.Create(sb.ToString());
    }
    #endregion

    #region Image Element 2 - Using TagBuilder
    public static MvcHtmlString Image2(this HtmlHelper htmlHelper,
      string src,
      string altText)
    {
      TagBuilder tb = new TagBuilder("img");

      tb.MergeAttribute("src", src);
      tb.MergeAttribute("alt", altText);

      return MvcHtmlString.Create(tb.ToString(TagRenderMode.SelfClosing));
    }
    #endregion

    #region Image Element 3 - Adding Css Classes
    public static MvcHtmlString Image3(this HtmlHelper htmlHelper,
      string src,
      string altText,
      string cssClass)
    {
      TagBuilder tb = new TagBuilder("img");

      tb.AddCssClass(cssClass);
      tb.MergeAttribute("src", src);
      tb.MergeAttribute("alt", altText);

      return MvcHtmlString.Create(tb.ToString(TagRenderMode.SelfClosing));
    }
    #endregion

    #region Image Element 4 - Adding 'name', generate id
    public static MvcHtmlString Image4(
      this HtmlHelper htmlHelper,
      string src,
      string altText,
      string cssClass,
      string name)
    {
      TagBuilder tb = new TagBuilder("img");

      // Ensure we have valid name
      name = TagBuilder.CreateSanitizedId(name);

      // Generate a valid 'id' attribute from the 'name' attribute
      // Adds to the HTML automatically
      tb.GenerateId(name);

      // Add 'name' to HTML
      tb.MergeAttribute("name", name);

      tb.AddCssClass(cssClass);
      tb.MergeAttribute("src", src);
      tb.MergeAttribute("alt", altText);

      return MvcHtmlString.Create(tb.ToString(TagRenderMode.SelfClosing));
    }
    #endregion

    #region Image Helper
    /// <summary>
    /// Builds an &lt;img&gt; element
    /// </summary>
    /// <example>
    /// &lt;%= Html.Image("img1", ResolveUrl("~/Content/XBox.jpg"), "XBox Console") %&gt;
    /// </example> 
    /// <param name="htmlHelper">The helper</param>
    /// <param name="url">The URL where the image is located</param>
    /// <param name="altText">Alternate text to display</param>
    /// <returns>An &lt;img&gt; tag</returns>
    public static MvcHtmlString Image(this HtmlHelper htmlHelper,
      string url, string altText)
    {
      return Image(htmlHelper, url, altText, string.Empty, null, null);
    }

    /// <summary>
    /// Builds an &lt;img&gt; element
    /// </summary>
    /// <example>
    /// &lt;%= Html.Image("img1", ResolveUrl("~/Content/XBox.jpg"), "XBox Console") %&gt;
    /// </example>
    /// <param name="htmlHelper">The helper</param>
    /// <param name="url">The URL where the image is located</param>
    /// <param name="altText">Alternate text to display</param>
    /// <param name="cssClass">CSS class(es) to add</param>
    /// <param name="name">The 'name' attribute for this element (optional)</param>
    /// <param name="htmlAttributes">An object that sets the HTML attributes for the element (optional)</param>
    /// <returns>An HTML &lt;img&gt; tag</returns>
    public static MvcHtmlString Image(this HtmlHelper htmlHelper,
      string url,
      string altText,
      string cssClass,
      string name,
      object htmlAttributes)
    {
      // Create TagBuilder
      TagBuilder tb = new TagBuilder("img");

      // Add 'name' and 'id' attributes if present
      if (!string.IsNullOrWhiteSpace(name)) {
        // Ensure we have valid name
        name = TagBuilder.CreateSanitizedId(name);

        // Generate a valid 'id' attribute from the 'name' attribute
        tb.GenerateId(name);

        // Add 'name' to HTML
        tb.MergeAttribute("name", name);
      }

      // Add additional CSS classes
      if (!string.IsNullOrWhiteSpace(cssClass)) {
        tb.AddCssClass(cssClass);
      }

      // Add all attributes
      // NOTE: These are added to the output in sorted order
      tb.MergeAttribute("src", url);
      tb.MergeAttribute("alt", altText);

      // Add additional attributes
      tb.MergeAttributes(HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

      // Render HTML Element
      return MvcHtmlString.Create(tb.ToString(TagRenderMode.SelfClosing));
    }
    #endregion
  }
}