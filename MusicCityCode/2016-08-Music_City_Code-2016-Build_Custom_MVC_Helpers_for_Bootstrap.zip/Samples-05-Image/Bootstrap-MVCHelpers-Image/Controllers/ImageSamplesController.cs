﻿using System.Web.Mvc;

namespace Bootstrap_MVCHelpers_Image.Controllers
{
  public class ImageSamplesController : Controller
  {
    public ActionResult Image01()
    {
      return View();
    }

    public ActionResult Image02()
    {
      return View();
    }

    public ActionResult Image03()
    {
      return View();
    }

    public ActionResult Image04()
    {
      return View();
    }

    public ActionResult Image05()
    {
      return View();
    }
  }
}