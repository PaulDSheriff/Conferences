﻿using System.Web.Mvc;

namespace Bootstrap_MVCHelpers_TextBox.Controllers
{
   public class TextBoxSamplesController : Controller
   {
      public ActionResult TextBox01()
      {
         TrainingProductViewModel model = new TrainingProductViewModel();

         return View(model);
      }

      public ActionResult TextBox02()
      {
         TrainingProductViewModel model = new TrainingProductViewModel();

         return View(model);
      }

      public ActionResult TextBox03()
      {
         TrainingProductViewModel model = new TrainingProductViewModel();

         return View(model);
      }

      public ActionResult TextBox04()
      {
         TrainingProductViewModel model = new TrainingProductViewModel();

         return View(model);
      }
   }
}