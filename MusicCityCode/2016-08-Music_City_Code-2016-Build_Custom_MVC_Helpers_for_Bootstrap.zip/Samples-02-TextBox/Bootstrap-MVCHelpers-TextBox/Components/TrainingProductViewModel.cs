﻿using System;
using System.Collections.Generic;

namespace Bootstrap_MVCHelpers_TextBox
{
  public class TrainingProductViewModel
  {
    public TrainingProductViewModel()
      : base()
    {
      // Initialize other variables
      Entity = new TrainingProduct();
    }

    public TrainingProduct Entity { get; set; }
  }
}
