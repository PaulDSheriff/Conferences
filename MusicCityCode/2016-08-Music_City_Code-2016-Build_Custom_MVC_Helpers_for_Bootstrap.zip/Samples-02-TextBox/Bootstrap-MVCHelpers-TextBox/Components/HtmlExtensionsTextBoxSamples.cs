﻿using System;
using System.Linq.Expressions;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using System.Web.Routing;

namespace Bootstrap_MVCHelpers_TextBox
{
  public static class HtmlExtensionsTextBoxSamples
  {
    public static MvcHtmlString BootstrapTextBoxFor1<TModel, TValue>(
       this HtmlHelper<TModel> htmlHelper,
       Expression<Func<TModel, TValue>> expression,
       object htmlAttributes = null)
    {
      RouteValueDictionary rvd;

      // Add additional attributes
      rvd = new RouteValueDictionary(
         HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

      // Build text box using InputExtensions
      return InputExtensions.TextBoxFor(htmlHelper,
                  expression,
                  rvd);
    }

    public static MvcHtmlString BootstrapTextBoxFor2<TModel, TValue>(
       this HtmlHelper<TModel> htmlHelper,
       Expression<Func<TModel, TValue>> expression,
       HtmlExtensionsCommon.Html5InputTypes type,
       object htmlAttributes = null)
    {
      RouteValueDictionary rvd;

      // Add additional attributes
      rvd = new RouteValueDictionary(
         HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

      // Set the HTML 5 type
      rvd.Add("type", type.ToString());

      // Build text box using InputExtensions
      return InputExtensions.TextBoxFor(htmlHelper,
                  expression,
                  rvd);
    }

    public static MvcHtmlString BootstrapTextBoxFor3<TModel, TValue>(
      this HtmlHelper<TModel> htmlHelper,
        Expression<Func<TModel, TValue>> expression,
        HtmlExtensionsCommon.Html5InputTypes type,
        string title,
        string placeholder,
        bool isRequired,
        bool isAutoFocus,
        object htmlAttributes = null)
    {
      RouteValueDictionary rvd;

      // Add additional attributes
      rvd = new RouteValueDictionary(
          HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

      // Set the HTML 5 type
      rvd.Add("type", type.ToString());

      // Add HTML 5 attributes
      if (!string.IsNullOrEmpty(title)) {
        rvd.Add("title", title);
      }
      if (!string.IsNullOrEmpty(placeholder)) {
        rvd.Add("placeholder", placeholder);
      }
      if (isAutoFocus) {
        rvd.Add("autofocus", "autofocus");
      }
      if (isRequired) {
        rvd.Add("required", "required");
      }

      // Build text box using InputExtensions
      return InputExtensions.TextBoxFor(htmlHelper,
                  expression,
                  rvd);
    }
  }
}