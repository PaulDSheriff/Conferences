﻿using System;
using System.Linq.Expressions;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using System.Web.Routing;

namespace Bootstrap_MVCHelpers_CheckBox
{
  public static class HtmlExtensionsCheckBoxSamples
  {
    public static MvcHtmlString BootstrapCheckBoxFor1<TModel>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, bool>> expression,
      string text,
      object htmlAttributes = null)
    {
      StringBuilder sb = new StringBuilder(512);
      RouteValueDictionary rvd;

      // Add additional attributes
      rvd = new RouteValueDictionary(
        HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

      // Open the CheckBox tag
      sb.Append("<div class='checkbox'>");
      sb.Append("<label>");

      // Build CheckBox using InputExtensions
      sb.Append(InputExtensions.CheckBoxFor(htmlHelper,
                expression,
                rvd));

      // Add the Text
      sb.Append(text);

      // Close the CheckBox tag
      sb.Append("</label>");
      sb.Append("</div>");

      // Return an MVC HTML String
      return MvcHtmlString.Create(sb.ToString());
    }

    public static MvcHtmlString BootstrapCheckBoxFor2<TModel>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, bool>> expression,
      string text,
      string title,
      bool isAutoFocus,
      object htmlAttributes = null)
    {
      StringBuilder sb = new StringBuilder(512);
      RouteValueDictionary rvd;

      // Add additional attributes
      rvd = new RouteValueDictionary(HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

      // Add Title, or use 'Text' if null or empty
      if (string.IsNullOrWhiteSpace(title)) {
        title = text;
      }
      rvd.Add("title", title);

      // Add HTML 5 attributes
      if (isAutoFocus) {
        rvd.Add("autofocus", "autofocus");
      }

      // Open the CheckBox tag
      sb.Append("<div class='checkbox'>");
      sb.Append("<label>");

      // Build CheckBox using InputExtensions
      sb.Append(InputExtensions.CheckBoxFor(htmlHelper,
                expression,
                rvd));

      // Add the Text
      sb.Append(text);

      // Close the CheckBox tag
      sb.Append("</label>");
      sb.Append("</div>");

      // Return an MVC HTML String
      return MvcHtmlString.Create(sb.ToString());
    }

    public static MvcHtmlString BootstrapCheckBoxFor3<TModel>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, bool>> expression,
      string text,
      string title,
      bool isAutoFocus,
      bool useInline,
      object htmlAttributes = null)
    {
      StringBuilder sb = new StringBuilder(512);
      RouteValueDictionary rvd;

      // Add additional attributes
      rvd = new RouteValueDictionary(HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

      // Add Title, or use 'Text' if null or empty
      if (string.IsNullOrWhiteSpace(title)) {
        title = text;
      }
      rvd.Add("title", title);

      // Add HTML 5 attributes
      if (isAutoFocus) {
        rvd.Add("autofocus", "autofocus");
      }

      // Open the CheckBox tag
      if (useInline) {
        sb.Append("<label class='checkbox-inline'>");
      }
      else {
        sb.Append("<div class='checkbox'>");
        sb.Append("<label>");
      }

      // Build CheckBox using InputExtensions
      sb.Append(
           InputExtensions.CheckBoxFor(htmlHelper,
             expression,
             rvd));

      // Add the Text
      sb.Append(text);

      // Close the CheckBox tag
      if (useInline) {
        sb.Append("</label>");
      }
      else {
        sb.Append("</label>");
        sb.Append("</div>");
      }

      // Return an MVC HTML String
      return MvcHtmlString.Create(sb.ToString());
    }

    public static MvcHtmlString BootstrapCheckBoxFor4<TModel>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, bool>> expression,
      string text,
      string title,
      bool isAutoFocus,
      bool useInline,
      string btnClass,
      object htmlAttributes = null)
    {
      StringBuilder sb = new StringBuilder(512);
      RouteValueDictionary rvd;

      // Add additional attributes
      rvd = new RouteValueDictionary(HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

      // Add Title, or use 'Text' if null or empty
      if (string.IsNullOrWhiteSpace(title)) {
        title = text;
      }
      rvd.Add("title", title);

      // Add HTML 5 attributes
      if (isAutoFocus) {
        rvd.Add("autofocus", "autofocus");
      }

      // Open the CheckBox tag
      if (useInline) {
        sb.AppendFormat("<label class='checkbox-inline btn {0}'>", btnClass);
      }
      else {
        sb.Append("<div class='checkbox'>");
        sb.AppendFormat("<label class='btn {0}'>", btnClass);
      }

      // Build CheckBox using InputExtensions
      sb.Append(InputExtensions.CheckBoxFor(htmlHelper,
                expression,
                rvd));

      // Add the Text
      sb.Append(text);

      // Close the CheckBox tag
      if (useInline) {
        sb.Append("</label>");
      }
      else {
        sb.Append("</label>");
        sb.Append("</div>");
      }

      // Return an MVC HTML String
      return MvcHtmlString.Create(sb.ToString());
    }
  }
}