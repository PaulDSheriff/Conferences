﻿using System;
using System.Linq.Expressions;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using System.Web.Routing;

namespace Bootstrap_MVCHelpers_CheckBox
{
  public static class HtmlExtensionsCheckBox
  {
    #region Bootstrap CheckBox Helpers
    /// <summary>
    /// Bootstrap Check Box
    /// </summary>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="text">The text to display next to this check box.</param>
    /// <param name="btnClass">The Bootstrap 'btn-' class to add to this check box (optional).</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML checkbox with the appropriate type set.</returns>
    public static MvcHtmlString BootstrapCheckBoxFor<TModel>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, bool>> expression,
      string text,
      string btnClass = "",
      object htmlAttributes = null)
    {
      return BootstrapCheckBoxFor(htmlHelper, expression, text, 
                string.Empty, false, false, btnClass, htmlAttributes);
    }

    /// <summary>
    /// Bootstrap Check Box
    /// </summary>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="text">The text to display next to this check box.</param>
    /// <param name="title">The 'title' attribute to set for this check box.</param>
    /// <param name="btnClass">The Bootstrap 'btn-' class to add to this check box (optional).</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML checkbox with the appropriate type set.</returns>
    public static MvcHtmlString BootstrapCheckBoxFor<TModel>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, bool>> expression,
      string text,
      string title,
      string btnClass = "",
      object htmlAttributes = null)
    {
      return BootstrapCheckBoxFor(htmlHelper, expression, text,
                title, false, false, btnClass, htmlAttributes);
    }

    /// <summary>
    /// Bootstrap Check Box
    /// </summary>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="text">The text to display next to this check box.</param>
    /// <param name="title">The 'title' attribute to set for this check box.</param>
    /// <param name="isAutoFocus">Whether or not to set the 'autofocus' attribute on this check box.</param>
    /// <param name="useInline">Whether or not to use 'checkbox-inline' for the Bootstrap class.</param>
    /// <param name="btnClass">The Bootstrap 'btn-' class to add to this check box (optional).</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML checkbox with the appropriate type set.</returns>
    public static MvcHtmlString BootstrapCheckBoxFor<TModel>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, bool>> expression,
      string text,
      string title,
      bool isAutoFocus,
      bool useInline,
      string btnClass = "",
      object htmlAttributes = null)
    {
      StringBuilder sb = new StringBuilder(512);
      RouteValueDictionary rvd;
      string chkClass = "checkbox";

      // Add additional attributes
      rvd = new RouteValueDictionary(HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

      // Add Title, or use 'Text' if null or empty
      if (string.IsNullOrWhiteSpace(title)) {
        title = text;
      }
      rvd.Add("title", title);

      // Add HTML 5 attributes
      if (isAutoFocus) {
        rvd.Add("autofocus", "autofocus");
      }

      // Set checkbox CSS class
      if (useInline) {
        chkClass = "checkbox-inline";
      }

      // Set any 'btn' CSS class
      if (!string.IsNullOrWhiteSpace(btnClass)) {
        btnClass = " btn " + btnClass;
      }
      else {
        btnClass = string.Empty;
      }

      // Begin the CheckBox Tag(s)
      if (useInline) {
        sb.AppendFormat("<label class='{0}'>", chkClass + btnClass);
      }
      else {
        sb.AppendFormat("<div class='{0}'>", chkClass);
        if (string.IsNullOrWhiteSpace(btnClass)) {
          sb.Append("<label>");
        }
        else {
          sb.AppendFormat("<label class='{0}'>", btnClass.Trim());
        }
      }

      // Build CheckBox using InputExtensions
      sb.Append(InputExtensions.CheckBoxFor(htmlHelper,
                expression,
                rvd));

      // Add the Text
      sb.Append(text);

      // Close the CheckBox tag(s)
      if (useInline) {
        sb.Append("</label>");
      }
      else {
        sb.Append("</label>");
        sb.Append("</div>");
      }

      // Return an MVC HTML String
      return MvcHtmlString.Create(sb.ToString());
    }
    #endregion
  }
}