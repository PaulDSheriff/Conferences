﻿using System;

namespace Bootstrap_MVCHelpers_CheckBox
{
  public class ProductInfo
  {
    public bool IsActive { get; set; }
    public bool CanBeDiscounted { get; set; }
  }
}
