﻿using System.Web.Mvc;

namespace Bootstrap_MVCHelpers_CheckBox.Controllers
{
  public class CheckBoxSamplesController : Controller
  {
    public ActionResult CheckBox01()
    {
      ProductInfo model = new ProductInfo();

      model.CanBeDiscounted = true;

      return View(model);
    }

    public ActionResult CheckBox02()
    {
      ProductInfo model = new ProductInfo();

      model.IsActive = true;

      return View(model);
    }

    public ActionResult CheckBox03()
    {
      ProductInfo model = new ProductInfo();

      model.CanBeDiscounted = true;

      return View(model);
    }

    public ActionResult CheckBox04()
    {
      ProductInfo model = new ProductInfo();

      model.IsActive = true;

      return View(model);
    }

    public ActionResult CheckBox05()
    {
      ProductInfo model = new ProductInfo();

      model.CanBeDiscounted = true;

      return View(model);
    }

    public ActionResult CheckBox06()
    {
      ProductInfo model = new ProductInfo();

      model.IsActive = true;

      return View(model);
    }
  }
}