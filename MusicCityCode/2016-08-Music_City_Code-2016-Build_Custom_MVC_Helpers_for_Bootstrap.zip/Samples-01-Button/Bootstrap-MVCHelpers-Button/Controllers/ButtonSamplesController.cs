﻿using System.Web.Mvc;

namespace Bootstrap_MVCHelpers_Button.Controllers
{
  public class ButtonSamplesController : Controller
  {
    public ActionResult Button01()
    {
      return View();
    }

    public ActionResult Button02()
    {
      return View();
    }

    public ActionResult Button03()
    {
      return View();
    }

    public ActionResult Button04()
    {
      return View();
    }
     
    public ActionResult Button05()
    {
       return View();
    }
  }
}