﻿using System.Web.Mvc;

namespace Bootstrap_MVCHelpers_Button
{
   public static class HtmlExtensionsButton
   {
      #region Bootstrap/HTML 5 Submit Button Helpers
      /// <summary>
      /// Bootstrap Submit Button Helper
      /// </summary>
      /// <param name="htmlHelper">The helper</param>
      /// <param name="innerHtml">The text (or HTML) for the button</param>
      /// <returns>A HTML &lt;button&gt; element with the appropriate properties set.</returns>
      public static MvcHtmlString BootstrapButton(this HtmlHelper htmlHelper,
        string innerHtml,
        object htmlAttributes = null)
      {
         return BootstrapButton(htmlHelper, innerHtml, null, null, null, false, false, HtmlExtensionsCommon.HtmlButtonTypes.submit, htmlAttributes);
      }

      /// <summary>
      /// Bootstrap Submit Button Helper
      /// </summary>
      /// <param name="htmlHelper">The helper</param>
      /// <param name="innerHtml">The text (or HTML) for the button</param>
      /// <param name="cssClass">CSS class(es) to add</param>
      /// <returns>A HTML &lt;button&gt; element with the appropriate properties set.</returns>
      public static MvcHtmlString BootstrapButton(this HtmlHelper htmlHelper,
        string innerHtml,
       string cssClass,
        object htmlAttributes = null)
      {
         return BootstrapButton(htmlHelper, innerHtml, cssClass, null, null, false, false, HtmlExtensionsCommon.HtmlButtonTypes.submit, htmlAttributes);
      }

      /// <summary>
      /// Bootstrap Submit Button Helper
      /// </summary>
      /// <param name="htmlHelper">The helper</param>
      /// <param name="innerHtml">The text (or HTML) for the button</param>
      /// <param name="cssClass">CSS class(es) to add</param>
      /// <param name="name">The 'name' attribute for this element</param>
      /// <returns>A HTML &lt;button&gt; element with the appropriate properties set.</returns>
      public static MvcHtmlString BootstrapButton(this HtmlHelper htmlHelper,
        string innerHtml,
        string cssClass,
        string name,
        object htmlAttributes = null)
      {
         return BootstrapButton(htmlHelper, innerHtml, cssClass, name, null, false, false, HtmlExtensionsCommon.HtmlButtonTypes.submit, htmlAttributes);
      }

      /// <summary>
      /// Bootstrap Submit Button Helper
      /// </summary>
      /// <param name="htmlHelper">The helper</param>
      /// <param name="innerHtml">The text (or HTML) for the button</param>
      /// <param name="cssClass">CSS class(es) to add</param>
      /// <param name="name">The 'name' attribute for this element (optional)</param>
      /// <param name="title">The 'title' for the button</param>
      /// <param name="isFormNoValidate">Whether or not this button validates the form (default=false)</param>
      /// <param name="isAutoFocus">Whether or not this button gets the input focus (default=false)</param>
      /// <param name="buttonType">The 'type' of button. Can be 'submit' (default), 'reset', or 'button')</param>
      /// <param name="htmlAttributes">An object that sets the HTML attributes for the element (optional)</param>
      /// <returns>A HTML &lt;button&gt; element with the appropriate properties set.</returns>
      public static MvcHtmlString BootstrapButton(this HtmlHelper htmlHelper,
        string innerHtml,
        string cssClass,
        string name,
        string title,
        bool isFormNoValidate,
        bool isAutoFocus,
        HtmlExtensionsCommon.HtmlButtonTypes buttonType,
        object htmlAttributes = null)
      {
         // Create TagBuilder
         TagBuilder tb = new TagBuilder("button");

         // Set the inner html
         tb.InnerHtml = innerHtml;

         // Ensure we have a 'btn-*' class
         if (!string.IsNullOrEmpty(cssClass)) {
            if (!cssClass.Contains("btn-")) {
               cssClass = "btn-primary " + cssClass;
            }
         }
         else {
            cssClass = "btn-primary";
         }

         // Add additional CSS classes
         tb.AddCssClass(cssClass);

         // Each call to AddCssClass adds to the 
         // beginning of the 'class=' attribute
         // Add 'btn' last so it becomes the first one
         tb.AddCssClass("btn");

         // Add 'name' and 'id' attributes if present
         HtmlExtensionsCommon.AddName(tb, name, null);

         // Add HTML 5 attributes
         if (!string.IsNullOrWhiteSpace(title)) {
            tb.MergeAttribute("title", title);
         }
         if (isFormNoValidate) {
            tb.MergeAttribute("formnovalidate", "formnovalidate");
         }
         if (isAutoFocus) {
            tb.MergeAttribute("autofocus", "autofocus");
         }

         // Add type of button
         switch (buttonType) {
            case HtmlExtensionsCommon.HtmlButtonTypes.submit:
               tb.MergeAttribute("type", "submit");
               break;
            case HtmlExtensionsCommon.HtmlButtonTypes.button:
               tb.MergeAttribute("type", "button");
               break;
            case HtmlExtensionsCommon.HtmlButtonTypes.reset:
               tb.MergeAttribute("type", "reset");
               break;
         }

         // Add additional attributes
         tb.MergeAttributes(HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

         return MvcHtmlString.Create(tb.ToString());
      }
      #endregion
   }
}