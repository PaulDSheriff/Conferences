﻿using System.Web.Mvc;

namespace Bootstrap_MVCHelpers_Button
{
   public static class HtmlExtensionsButtonSamples
   {
      #region Button Sample 1
      public static MvcHtmlString BootstrapButton1(this HtmlHelper htmlHelper,
        string innerHtml)
      {
         // Create TagBuilder
         TagBuilder tb = new TagBuilder("button");

         // Add Bootstrap 'btn' classes
         tb.AddCssClass("btn-primary");
         // Add 'btn' last so it becomes the first one
         tb.AddCssClass("btn");

         // Set the inner html
         tb.InnerHtml = innerHtml;

         // Add type of button
         tb.MergeAttribute("type", "submit");

         return MvcHtmlString.Create(tb.ToString());
      }
      #endregion

      #region Button Sample 2
      public static MvcHtmlString BootstrapButton2(this HtmlHelper htmlHelper,
        string innerHtml,
        string cssClass,
        object htmlAttributes = null)
      {
         // Create TagBuilder
         TagBuilder tb = new TagBuilder("button");

         // Ensure we have a 'btn-*' class
         if (!string.IsNullOrEmpty(cssClass)) {
            if (!cssClass.Contains("btn-")) {
               cssClass = "btn-primary " + cssClass;
            }
         }
         else {
            cssClass = "btn-primary";
         }

         // Add additional CSS classes
         tb.AddCssClass(cssClass);

         // Each call to AddCssClass adds to the 
         // beginning of the 'class=' attribute
         // Add 'btn' last so it becomes the first one
         tb.AddCssClass("btn");

         // Set the inner html
         tb.InnerHtml = innerHtml;

         // Add type of button
         tb.MergeAttribute("type", "submit");

         // Add additional attributes
         tb.MergeAttributes(HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

         return MvcHtmlString.Create(tb.ToString());
      }
      #endregion

      #region Button Sample 3
      public static MvcHtmlString BootstrapButton3(this HtmlHelper htmlHelper,
        string innerHtml,
        string cssClass,
        string name,
        object htmlAttributes = null)
      {
         // Create TagBuilder
         TagBuilder tb = new TagBuilder("button");

         // Add 'name' and 'id' attributes if present
         HtmlExtensionsCommon.AddName(tb, name, null);

         // Ensure we have a 'btn' class
         if (string.IsNullOrEmpty(cssClass)) {
            cssClass = "btn-primary";
         }

         // Add additional CSS classes
         tb.AddCssClass(cssClass);

         // Each call to AddCssClass adds to the 
         // beginning of the 'class=' attribute
         // Add 'btn' last so it becomes the first one
         tb.AddCssClass("btn");

         // Set the inner html
         tb.InnerHtml = innerHtml;

         // Add type of button
         tb.MergeAttribute("type", "submit");

         // Add additional attributes
         tb.MergeAttributes(HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

         return MvcHtmlString.Create(tb.ToString());
      }
      #endregion

      #region Button Sample 4
      public static MvcHtmlString BootstrapButton4(this HtmlHelper htmlHelper,
        string innerHtml,
        string cssClass,
        string name,
        string title,
        bool isFormNoValidate = false,
        bool isAutoFocus = false,
        object htmlAttributes = null)
      {
         // Create TagBuilder
         TagBuilder tb = new TagBuilder("button");

         // Add 'name' and 'id' attributes if present
         HtmlExtensionsCommon.AddName(tb, name, null);

         // Ensure we have a 'btn-*' class
         if (!string.IsNullOrEmpty(cssClass)) {
            if (!cssClass.Contains("btn-")) {
               cssClass = "btn-primary " + cssClass;
            }
         }
         else {
            cssClass = "btn-primary";
         }

         // Add additional CSS classes
         tb.AddCssClass(cssClass);

         // Each call to AddCssClass adds to the 
         // beginning of the 'class=' attribute
         // Add 'btn' last so it becomes the first one
         tb.AddCssClass("btn");

         // Set the inner html
         tb.InnerHtml = innerHtml;

         // Add HTML 5 attributes
         if (!string.IsNullOrWhiteSpace(title)) {
            tb.MergeAttribute("title", title);
         }
         if (isFormNoValidate) {
            tb.MergeAttribute("formnovalidate", "formnovalidate");
         }
         if (isAutoFocus) {
            tb.MergeAttribute("autofocus", "autofocus");
         }

         // Add type of button
         tb.MergeAttribute("type", "submit");

         // Add additional attributes
         tb.MergeAttributes(HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

         return MvcHtmlString.Create(tb.ToString());
      }
      #endregion
   }
}