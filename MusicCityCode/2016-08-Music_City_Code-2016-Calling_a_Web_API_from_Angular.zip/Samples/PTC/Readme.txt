﻿Create the database
-------------------
To create the database and the data for this project, run the \SqlScripts\PTC.SQL in SQL Server

Files of Interest
-----------------
\Models\PTCData.edmx - Entity Framework of PTC database tables
\Deafult.html - The sample Product screen

Samples
----------------------------------------------------------------
Sample00.html - HTML structure, no angular
Sample01.html - Get all products via Web API call
Sample02.html - Add filters for date and currency
Sample03.html - Search via Web API call
Product.html - Search on client-side