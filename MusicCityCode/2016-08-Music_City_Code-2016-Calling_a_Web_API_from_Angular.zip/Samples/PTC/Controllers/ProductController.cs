﻿using PTC.Controllers;
using PTC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PTC.Controllers_Api
{
  public class ProductController : ApiController
  {
    // GET api/<controller>
    public IHttpActionResult Get() {
      IHttpActionResult ret = null;
      PTCEntities db = new PTCEntities();
      List<Product> Products;

      Products = db.Products.OrderBy(p => p.ProductName).ToList();

      if (Products.Count > 0) {
        ret = Ok(Products);
      }
      else {
        ret = NotFound();
      }

      return ret;
    }

    [HttpPost()]
    [Route("api/Product/Search")]
    public IHttpActionResult Search(
      ProductSearch search) {
      IHttpActionResult ret = null;
      PTCEntities db = new PTCEntities();
      List<Product> Products;

      // Search for Products
      // Perform Search
      Products = db.Products.Where(p =>
        (string.IsNullOrEmpty(search.ProductName) ? true :
              p.ProductName.Contains(search.ProductName))).
        OrderBy(p => p.ProductName).ToList();

      if (Products.Count > 0) {
        ret = Ok(Products);
      }
      else {
        ret = NotFound();
      }

      return ret;
    }
  }
}