﻿(function () {
  'use strict';

  angular.module('app').controller('ProductController', ProductController);

  function ProductController($http) {
    var vm = this;
    var dataService = $http;

    // Hook up public events
    vm.resetSearch = resetSearch;
    vm.search = search;

    // Create properties
    vm.products = [];
    vm.searchInput = {
      productName: ''
    };

    // Load all products
    productList();

    // ***************************************
    // Private functions
    // ***************************************
    function resetSearch() {
      vm.searchInput = {
        productName: ''
      };

      productList();
    }

    function search() {
      // Call Web API to search for a list of Products
      dataService.post("/api/Product/Search",
              vm.searchInput)
        .then(function (result) {
          vm.products = result.data;
        }, function (error) {
          handleException(error);
        });
    }

    function productList() {
      dataService.get("/api/Product")
      .then(function (result) {
        vm.products = result.data;
      },
      function (error) {
        handleException(error);
      });
    }

    function handleException(error) {
      alert(error.data.ExceptionMessage);
    }
  }
})();