﻿(function () {
  'use strict';

  angular.module('app').controller('ProductController', ProductController);

  function ProductController($http) {
    var vm = this;
    var dataService = $http;

    // Create properties
    vm.products = [];

    // Load all products
    productList();

    // ***************************************
    // Private functions
    // ***************************************
    function productList() {
      dataService.get("/api/Sample01")
      .then(function (result) {
        vm.products = result.data;
      },
      function (error) {
        handleException(error);
      });
    }

    function handleException(error) {
      alert(error.data.ExceptionMessage);
    }
  }
})();