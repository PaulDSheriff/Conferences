﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using MyClasses;
using System.IO;

namespace MyClassesTest
{
  [TestClass]
  public class FileProcessTest6
  {
    private const string FILE_NAME = @"D:\Test.txt";

    [TestInitialize()]
    public void TestInitialize()
    {
      // Create the Test.txt file.
      File.AppendAllText(FILE_NAME, "Some Text");
    }

    [TestCleanup()]
    public void TestCleanup()
    {
      // Delete Test.txt file
      if (File.Exists(FILE_NAME))
        File.Delete(FILE_NAME);
    }

    [TestMethod]
    public void FileExistsFalseWithInitCleanup()
    {
      FileProcess fp = new FileProcess();

      Assert.AreEqual(fp.FileExists(@"D:\NoFile.txt"), false);
    }

    [TestMethod]
    public void FileExistsTrueWithInitCleanup()
    {
      FileProcess fp = new FileProcess();

      // Test the Method
      Assert.AreEqual(fp.FileExists(FILE_NAME), true);
    }
  }
}
