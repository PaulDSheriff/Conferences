﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using MyClasses;
using System.IO;

namespace MyClassesTest
{
  [TestClass]
  public class FileProcessTest2
  {
    private const string FILE_NAME = @"D:\Test.txt";

    [TestMethod]
    public void FileExistsFalse()
    {
      FileProcess fp = new FileProcess();

      Assert.AreEqual(fp.FileExists(@"D:\NoFile.txt"), false);
    }

    [TestMethod]
    public void FileExistsTrue()
    {
      FileProcess fp = new FileProcess();

      // Create the Test.txt file.
      File.AppendAllText(FILE_NAME, "Some Text");

      // Test the Method
      Assert.AreEqual(fp.FileExists(FILE_NAME), true);

      // Delete the File
      File.Delete(FILE_NAME);
    }

    [TestMethod]
    public void FileExistsBadInput()
    {
      throw new AssertInconclusiveException();
    }
  }
}
