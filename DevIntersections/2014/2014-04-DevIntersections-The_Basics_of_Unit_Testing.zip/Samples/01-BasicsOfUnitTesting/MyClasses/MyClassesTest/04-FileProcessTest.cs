﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using MyClasses;
using System.IO;

namespace MyClassesTest
{
  [TestClass]
  public class FileProcessTest4
  {
    private const string FILE_NAME = @"D:\Test.txt";

    [TestMethod()]
    public void FileExistsBadInputWithException()
    {
      FileProcess fp = new FileProcess();

      try
      {
        // The following will be a successful test
        fp.FileExistsWithException(string.Empty);
      }
      catch (ArgumentNullException)
      {
        return;
      }

      Assert.Fail("Call to FileExists did not throw an ArgumentNullException as expected");
    }


    [TestMethod()]
    public void FileExistsBadInputWithExceptionAssertFail()
    {
      FileProcess fp = new FileProcess();

      try
      {
        // The following will cause the Assert.Fail() to run
        fp.FileExistsWithException(FILE_NAME);
      }
      catch (ArgumentNullException)
      {
        return;
      }

      Assert.Fail("Call to FileExists did not throw an ArgumentNullException as expected");
    }
  }
}
