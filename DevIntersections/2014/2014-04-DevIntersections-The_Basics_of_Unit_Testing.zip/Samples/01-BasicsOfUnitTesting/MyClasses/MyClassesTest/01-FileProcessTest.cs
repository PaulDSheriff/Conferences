﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using MyClasses;
using System.IO;

namespace MyClassesTest
{
  [TestClass]
  public class FileProcessTest1
  {
    [TestMethod]
    public void FileExistsFalse()
    {
      FileProcess fp = new FileProcess();

      Assert.AreEqual(fp.FileExists(@"D:\NoFile.txt"), false);
    }

    [TestMethod]
    public void FileExistsTrue()
    {
      throw new AssertInconclusiveException();
    }

    [TestMethod]
    public void FileExistsBadInput()
    {
      throw new AssertInconclusiveException();
    }
  }
}
