﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using MyClasses;
using System.IO;

namespace MyClassesTest
{
  [TestClass]
  public class FileProcessTest9
  {
    private const string FILE_NAME = @"D:\Test.txt";

    #region Initialize and Cleanup
    [TestInitialize()]
    public void TestInitialize()
    {
      // Create the Test.txt file.
      File.AppendAllText(FILE_NAME, "Some Text");
    }

    [TestCleanup()]
    public void TestCleanup()
    {
      // Delete Test.txt file
      if (File.Exists(FILE_NAME))
        File.Delete(FILE_NAME);
    }
    #endregion

    #region Normal Tests
    [TestMethod]
    [Owner("JohnK")]
    public void FileExistsFalseWithAttributes()
    {
      FileProcess fp = new FileProcess();

      Assert.AreEqual(fp.FileExists(@"D:\NoFile.txt"), false);
    }

    [TestMethod]
    [Owner("JohnK")]
    public void FileExistsTrueWithAttributes()
    {
      FileProcess fp = new FileProcess();

      Assert.AreEqual(fp.FileExists(FILE_NAME), true);
    }
    #endregion

    #region Expected Exception Test
    [TestMethod(),
      ExpectedException(typeof(System.ArgumentNullException))]
    [Owner("TimN")]
    public void FileExistsBadInputWithAttributes()
    {
      FileProcess fp = new FileProcess();

      fp.FileExistsWithException(string.Empty);
    }
    #endregion

    #region Assert.Fail Test
    [TestMethod()]
    [Owner("MichaelK")]
    public void FileExistsBadInputWithExceptionWithAttributes()
    {
      FileProcess fp = new FileProcess();

      try
      {
        // The following will be a successful test
        fp.FileExistsWithException(string.Empty);
      }
      catch (ArgumentNullException)
      {
        return;
      }

      Assert.Fail("Call to FileExists did not throw an ArgumentNullException as expected");
    }
    #endregion

    #region TestContext Test
    private TestContext testContextInstance;
    public TestContext TestContext
    {
      get { return testContextInstance; }
      set { testContextInstance = value; }
    }
    #endregion

    #region DataDriven Test
    [TestMethod()]
    [DataSource("System.Data.SqlClient",
      "Server=Localhost;Database=Sandbox;Integrated Security=SSPI",
      "FileProcessTest",
      DataAccessMethod.Sequential)]
    [Owner("MichaelK")]
    public void FileExistsFromDBWithAttributes()
    {
      FileProcess fp = new FileProcess();
      string fileName;
      bool expected;

      fileName =
        TestContext.DataRow["FileName"].ToString();
      expected =
        Convert.ToBoolean(
          TestContext.DataRow["ExpectedValue"]);

      Assert.AreEqual(expected,
        fp.FileExists(fileName),
        "File Name: " + fileName +
        " has failed it's existence test in test: FileExistsFromDB()");
    }
    #endregion

    #region DataDriven (Config) Test
    [TestMethod()]
    [DataSource("Sandbox")]
    [Owner("MichaelK")]
    public void FileExistsFromDBConfigWithAttributes()
    {
      FileProcess fp = new FileProcess();
      string fileName;
      bool expected;

      fileName =
        TestContext.DataRow["FileName"].ToString();
      expected =
        Convert.ToBoolean(
          TestContext.DataRow["ExpectedValue"]);

      Assert.AreEqual(expected,
        fp.FileExists(fileName),
        "File Name: " + fileName +
        " has failed it's existence test in test: FileExistsFromDB()");
    }
    #endregion
  }
}
