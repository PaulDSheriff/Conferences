﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using MyClasses;
using System.IO;

namespace MyClassesTest
{
  [TestClass]
  public class FileProcessTest7
  {
    private const string FILE_NAME = @"D:\Test.txt";

    #region Initialize and Cleanup
    [TestInitialize()]
    public void TestInitialize()
    {
      // Create the Test.txt file.
      File.AppendAllText(FILE_NAME, "Some Text");
    }

    [TestCleanup()]
    public void TestCleanup()
    {
      // Delete Test.txt file
      if (File.Exists(FILE_NAME))
        File.Delete(FILE_NAME);
    }
    #endregion

    #region TestContext Property
    private TestContext testContextInstance;
    public TestContext TestContext
    {
      get { return testContextInstance; }
      set { testContextInstance = value; }
    }
    #endregion

    [TestMethod()]
    [DataSource("System.Data.SqlClient",
      "Server=Localhost;Database=Sandbox;Integrated Security=SSPI",
      "FileProcessTest",
      DataAccessMethod.Sequential)]
    public void FileExistsFromDB()
    {
      FileProcess fp = new FileProcess();
      string fileName;
      bool expected;

      fileName =
        TestContext.DataRow["FileName"].ToString();
      expected =
        Convert.ToBoolean(
          TestContext.DataRow["ExpectedValue"]);

      Assert.AreEqual(expected,
        fp.FileExists(fileName),
        "File Name: " + fileName +
        " has failed it's existence test in test: FileExistsFromDB()");
    }
  }
}
