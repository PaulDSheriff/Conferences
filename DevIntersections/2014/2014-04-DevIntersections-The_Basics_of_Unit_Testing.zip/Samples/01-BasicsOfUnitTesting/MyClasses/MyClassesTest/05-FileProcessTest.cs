﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using MyClasses;
using System.IO;

namespace MyClassesTest
{
  [TestClass]
  public class FileProcessTest5
  {
    private const string FILE_NAME = @"D:\Test.txt";

    private TestContext testContextInstance;
    public TestContext TestContext
    {
      get { return testContextInstance; }
      set { testContextInstance = value; }
    }

    [TestMethod]
    public void FileExistsWithTestContext()
    {
      FileProcess fp = new FileProcess();

      TestContext.WriteLine("Creating Test.txt File");
      // Create the Test.txt file.
      File.AppendAllText(FILE_NAME, "Some Text");

      TestContext.WriteLine("Calling FileExists Test");
      Assert.AreEqual(fp.FileExists(FILE_NAME), true);

      TestContext.WriteLine("Deleting Test.txt File");
      File.Delete(FILE_NAME);
    }
  }
}
