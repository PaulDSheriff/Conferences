﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using MyClasses;
using System.IO;

namespace MyClassesTest
{
  [TestClass]
  public class FileProcessTest3
  {
    [TestMethod(),
      ExpectedException(typeof(System.ArgumentNullException))]
    public void FileExistsBadInput()
    {
      FileProcess fp = new FileProcess();

      fp.FileExistsWithException(string.Empty);
    }
  }
}
