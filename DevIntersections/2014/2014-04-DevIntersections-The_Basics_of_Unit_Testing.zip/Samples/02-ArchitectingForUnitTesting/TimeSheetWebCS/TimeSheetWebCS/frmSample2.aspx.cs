﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Web.UI;
using TimeSheetComponentsCS;

namespace TimeSheetWebCS
{
  public partial class frmSample2 : System.Web.UI.Page
  {
    private ObservableCollection<ValidationMessage> _Messages = new ObservableCollection<ValidationMessage>();
    private TimeSheetSample2 _Time2 = new TimeSheetSample2();

    #region Loading Methods
    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
      {
        ResourcesLoad();
        CustomersLoad();
        txtEntryDate.Text = DateTime.Now.ToShortDateString();
      }
    }

    private void ResourcesLoad()
    {
      Resources res = new Resources();

      ddlResource.DataTextField = "Name";
      ddlResource.DataValueField = "Name";
      ddlResource.DataSource = res.GetResources();
      ddlResource.DataBind();
    }

    private void CustomersLoad()
    {
      Customers cust = new Customers();

      ddlCustomer.DataTextField = "Name";
      ddlCustomer.DataValueField = "Name";
      ddlCustomer.DataSource = cust.GetCustomers();
      ddlCustomer.DataBind();
    }
    #endregion

    #region Saving Methods
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      lblMessage.Text = string.Empty;
      lstMessages.Items.Clear();
      if (ValidateData())
      {
        lblMessage.Text = "Data is Valid";
      }
      else
      {
        lstMessages.DataSource = _Messages;
        lstMessages.DataBind();
      }
    }

    private bool ValidateData()
    {
      decimal value = 0;

      _Messages.Clear();

      // **********************************************
      //  Move values from form into TimeSheet Class
      // **********************************************
      if (ddlResource.SelectedItem.Text == Resource.UnSelected)
      {
        _Messages.Add(new ValidationMessage("You must choose a Resource.", "Resource"));
      }
      if (!Utilities.IsDate(txtEntryDate.Text))
      {
        _Messages.Add(new ValidationMessage("Entry Date must be a valid date.", "EntryDate"));
      }
      if (ddlCustomer.SelectedItem.Text == Customer.UnSelected)
      {
        _Messages.Add(new ValidationMessage("You must choose a Customer.", "Customer"));
      }
      //  Make sure hours entered are decimal values
      if (decimal.TryParse(txtHours.Text, out value) == false)
      {
        _Messages.Add(new ValidationMessage("Hours must be in decimal format.", "Hours"));
      }

      if (_Messages.Count == 0)
      {
        _Time2.Customer = ddlCustomer.SelectedItem.Text;
        _Time2.Description = txtDescription.Text;
        _Time2.EntryDate = Convert.ToDateTime(txtEntryDate.Text);
        _Time2.Hours = Convert.ToDecimal(txtHours.Text);
        _Time2.Resource = ddlResource.SelectedItem.Text;
        _Time2.ValidateData();

        _Messages = _Time2.Messages;
      }

      return (_Messages.Count == 0);
    }
    #endregion
  }
}