﻿using System.Windows;

namespace TimeSheetWPFCS
{
  public partial class winMain : Window
  {
    public winMain()
    {
      InitializeComponent();
    }

    private void btnTime1_Click(object sender, RoutedEventArgs e)
    {
      winTimeSheetSample1 win = new winTimeSheetSample1();

      win.Show();
    }

    private void btnTime2_Click(object sender, RoutedEventArgs e)
    {
      winTimeSheetSample2 win = new winTimeSheetSample2();

      win.Show();
    }
  }
}
