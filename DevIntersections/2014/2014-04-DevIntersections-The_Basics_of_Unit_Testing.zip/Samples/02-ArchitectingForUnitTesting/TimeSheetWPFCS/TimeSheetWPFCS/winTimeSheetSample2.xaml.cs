﻿using System;
using System.Windows;

using TimeSheetComponentsCS;

namespace TimeSheetWPFCS
{
  public partial class winTimeSheetSample2 : Window
  {
    #region Constructor
    public winTimeSheetSample2()
    {
      InitializeComponent();
    }
    #endregion

    #region Windows Loaded Event and Cancel Event
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      _TimeValidator = (TimeSheetSample2)this.FindResource("time2");
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      this.Close();
    }
    #endregion

    private TimeSheetSample2 _TimeValidator;

    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      if (ValidateData())
      {
        _TimeValidator.Messages.Add(new ValidationMessage("Data is Valid", ""));
      } 
    }

    private bool ValidateData()
    {
      decimal value = 0;

      // **********************************************
      //  Check Data on Form for blank entries
      // **********************************************
      if (!Utilities.IsDate(txtEntryDate.Text))
        _TimeValidator.Messages.Add(new ValidationMessage("Entry Date is Invalid.", "EntryDate"));

      if (decimal.TryParse(txtHours.Text, out value) == false)
        _TimeValidator.Messages.Add(new ValidationMessage("Hours must be in decimal format.", "Hours"));

      return (_TimeValidator.ValidateData());
    }
  }
}