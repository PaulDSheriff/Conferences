﻿using System;

namespace TimeSheetComponentsCS
{
  public class TimeSheetData : CommonBase
  {
    #region Constructor
    public TimeSheetData() : base()
    {
      Resource = TimeSheetComponentsCS.Resource.UnSelected;
      EntryDate = DateTime.Now.ToShortDateString();
      Customer = TimeSheetComponentsCS.Customer.UnSelected;
      Hours = "1";
      Description = string.Empty;
    }
    #endregion

    #region Fields
    private string _Resource = string.Empty;
    private string _EntryDate = string.Empty;
    private string _Customer = string.Empty;
    private string _Hours = string.Empty;
    private string _Description = string.Empty;
    #endregion

    #region Public Properties
    public string Resource
    {
      get { return _Resource; }
      set
      {
        if (_Resource != value)
        {
          _Resource = value;
          RaisePropertyChanged("Resource");
        }
      }
    }

    public string EntryDate
    {
      get { return _EntryDate; }
      set
      {
        if (_EntryDate != value)
        {
          _EntryDate = value;
          RaisePropertyChanged("EntryDate");
        }
      }
    }

    public string Customer
    {
      get { return _Customer; }
      set
      {
        if (_Customer != value)
        {
          _Customer = value;
          RaisePropertyChanged("Customer");
        }
      }
    }

    public string Hours
    {
      get { return _Hours; }
      set
      {
        if (_Hours != value)
        {
          _Hours = value;
          RaisePropertyChanged("Hours");
        }
      }
    }

    public string Description
    {
      get { return _Description; }
      set
      {
        if (_Description != value)
        {
          _Description = value;
          RaisePropertyChanged("Description");
        }
      }
    }
    #endregion
  }
}
