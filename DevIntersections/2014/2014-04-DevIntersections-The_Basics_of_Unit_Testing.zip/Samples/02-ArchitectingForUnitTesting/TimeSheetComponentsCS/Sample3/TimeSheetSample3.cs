using System;

namespace TimeSheetComponentsCS
{
  public class TimeSheetSample3 : CommonBase
  {

    #region Constructor
    public TimeSheetSample3() : base()
    {
      Resource = string.Empty;
      EntryDate = DateTime.Now;
      Customer = string.Empty;
      Hours = 1;
      Description = string.Empty;
    }
    #endregion

    #region Public Properties
    public string Resource { get;set;}
    public DateTime EntryDate { get; set; }
    public string Customer { get; set; }
    public decimal Hours { get; set; }
    public string Description { get; set; }
    #endregion

    #region ValidateData Method
    //  This overload checks if the data can be converted
    //  then puts it into the private variables in this class
    //  then calls the ValidateData to check the data
    public bool ValidateData(string resource, string entryDate,
      string customer, string hours, string description)
    {
      decimal value = 0;

      Messages.Clear();

      if (resource != TimeSheetComponentsCS.Resource.UnSelected)
      {
        Resource = resource;
      }
      if (Utilities.IsDate(entryDate))
      {
        EntryDate = Convert.ToDateTime(entryDate);
      }
      if (customer != TimeSheetComponentsCS.Customer.UnSelected)
      {
        Customer = customer;
      }
      //  Make sure hours entered are decimal values
      if (decimal.TryParse(hours, out value) == false)
      {
        Messages.Add(new ValidationMessage("Hours must be in decimal format.", "Hours"));
      }
      else
      {
        Hours = value;
      }
      Description = description;

      // Now call ValidateData to check all public properties
      return ValidateData();
    }

    protected bool ValidateData()
    {
      //  User Must Enter a Resource
      if (Resource.Trim() == string.Empty)
      {
        Messages.Add(new ValidationMessage("You must choose a Resource.", "Resource"));
      }
      if (Utilities.IsDate(EntryDate))
      {
        //  Entry Date must not be older than 7 days
        if (EntryDate <
          (DateTime.Now.Subtract(new TimeSpan(7, 0, 0, 0))))
        {
          Messages.Add(new ValidationMessage("Entry Date must be greater than 7 days ago", "EntryDate"));
        }
        //  Entry Date Must Be Today's Date or Less
        if (EntryDate > DateTime.Now)
        {
          Messages.Add(new ValidationMessage("Entry Date must today's date or less", "EntryDate"));
        }
      }
      else
      {
        Messages.Add(new ValidationMessage("Entry Date must be filled in.", "EntryDate"));
      }
      //  User Must Enter a Customer
      if (Customer.Trim() == string.Empty)
      {
        Messages.Add(new ValidationMessage("You must choose a customer.", "Customer"));
      }
      //  Hours must be greater than 0
      if (Hours <= 0)
      {
        Messages.Add(new ValidationMessage("Hours must be greater than zero.", "Hours"));
      }
      //  Hours must be less than 12
      if (Hours > 12)
      {
        Messages.Add(new ValidationMessage("Hours must be less than 12.", "Hours"));
      }
      //  User Must Enter a Description
      if (Description.Trim() == string.Empty)
      {
        Messages.Add(new ValidationMessage("Description must be entered.", "Description"));
      }
      else
      {
        //  Description length must be greater than 10 characters
        if (Description.Trim().Length < 10)
        {
          Messages.Add(new ValidationMessage("Description entered must be greater than 10 characters.", "Description"));
        }
      }

      return (Messages.Count == 0);
    }
    #endregion
  }
}