﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace TimeSheetComponentsCS
{
  public abstract class CommonBase : INotifyPropertyChanged
  {
    #region Constructor
    protected CommonBase()
    {
      Messages = new ObservableCollection<ValidationMessage>();
    }
    #endregion

    #region INotifyPropertyChanged Implementation
    public event PropertyChangedEventHandler PropertyChanged;

    /// <summary>
    /// The PropertyChanged Event to raise to any UI object
    /// The event is only invoked if data binding is used
    /// </summary>
    /// <param name="propertyName">The property name that is changing</param>          
    protected virtual void RaisePropertyChanged(string propertyName)
    {
      PropertyChangedEventHandler handler = this.PropertyChanged;
      if (handler != null)
      {
        var e = new PropertyChangedEventArgs(propertyName);
        handler(this, e);
      }
    }
    #endregion

    private ObservableCollection<ValidationMessage> _Messages;
    public ObservableCollection<ValidationMessage> Messages
    {
      get { return _Messages; }
      set
      {
        _Messages = value;
        RaisePropertyChanged("Messages");
      }
    }
  }
}
