using System;
using System.Web;

namespace TimeSheetComponentsCS
{
  public class Utilities
  {
    #region IsDate Methods
    public static bool IsDate(object value)
    {
      if (value == null)
      {
        return false;
      }
      else
      {
        return IsDate(Convert.ToString(value));
      }
    }

    public static bool IsDate(string value)
    {
      DateTime dt;
      bool ret;

      ret = DateTime.TryParse(value, out dt);

      return ret;
    }
    #endregion

    #region GetCurrentDirectory Method
    public static string GetCurrentDirectory()
    {
      string ret = null;

      if (HttpContext.Current == null)
      {
        ret = Environment.CurrentDirectory;

        if (ret.EndsWith(@"\bin\Debug"))
        {
          ret = ret.Substring(0, ret.LastIndexOf(@"\bin\Debug"));
        }
      }
      else
      {
        ret = HttpContext.Current.Server.MapPath("/");
      }

      return ret;
    }
    #endregion
  }
}