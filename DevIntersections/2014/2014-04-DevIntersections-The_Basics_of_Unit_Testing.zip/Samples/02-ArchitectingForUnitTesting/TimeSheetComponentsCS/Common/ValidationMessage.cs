﻿using System;

namespace TimeSheetComponentsCS
{
  /// <summary>
  /// A class for storing validation rule failure messages
  /// </summary>
  public class ValidationMessage : CommonBase
  {
    #region Constructors
    public ValidationMessage()
    {
    }

    public ValidationMessage(string message, string propertyName)
    {
      Message = message;
      PropertyName = propertyName;
    }
    #endregion

    private string _Message = string.Empty;
    private string _PropertyName = string.Empty;

    /// <summary>
    /// Get/Set the validation message to display
    /// </summary>
    public string Message
    {
      get { return _Message; }
      set
      {
        if (_Message != value)
        {
          _Message = value;
          RaisePropertyChanged("Message");
        }
      }
    }

    /// <summary>
    /// Get/Set the property name that was invalid
    /// Can you use this to loop through controls on your UI and put a border around those properties that have failed validation
    /// </summary>
    public string PropertyName
    {
      get { return _PropertyName; }
      set
      {
        if (_PropertyName != value)
        {
          _PropertyName = value;
          RaisePropertyChanged("PropertyName");
        }
      }
    }
  }
}
