using System;

namespace TimeSheetComponentsCS
{
  public class TimeSheetSample2 : CommonBase
  {
    #region Constructor
    public TimeSheetSample2() : base()
    {
      Resource = string.Empty;
      EntryDate = DateTime.Now;
      Customer = string.Empty;
      Hours = 1;
      Description = string.Empty;
    }
    #endregion

    #region Public Properties
    public string Resource { get;set;}
    public DateTime EntryDate { get; set; }
    public string Customer { get; set; }
    public decimal Hours { get; set; }
    public string Description { get; set; }
    #endregion

    #region ValidateData Method
    public bool ValidateData()
    {
      Messages.Clear();

      //  User Must Enter a Resource
      if (Resource.Trim() == TimeSheetComponentsCS.Resource.UnSelected)
      {
        Messages.Add(new ValidationMessage("You must choose a Resource.", "Resource"));
      }
      //  Entry Date must not be older than 7 days
      if (EntryDate <
        (DateTime.Now.Subtract(new TimeSpan(7, 0, 0, 0))))
      {
        Messages.Add(new ValidationMessage("Entry Date must be greater than 7 days ago", "EntryDate"));
      }
      //  Entry Date Must Be Today's Date or Less
      if (EntryDate > DateTime.Now)
      {
        Messages.Add(new ValidationMessage("Entry Date must today's date or less", "EntryDate"));
      }
      //  User Must Enter a Customer
      if (Customer.Trim() == TimeSheetComponentsCS.Customer.UnSelected)
      {
        Messages.Add(new ValidationMessage("You must choose a customer.", "Customer"));
      }
      //  Hours must be greater than 0
      if (Hours <= 0)
      {
        Messages.Add(new ValidationMessage("Hours must be greater than zero.", "Hours"));
      }
      //  Hours must be less than 12
      if (Hours > 12)
      {
        Messages.Add(new ValidationMessage("Hours must be less than 12.", "Hours"));
      }
      //  User Must Enter a Description
      if (Description.Trim() == string.Empty)
      {
        Messages.Add(new ValidationMessage("Description must be entered.", "Description"));
      }
      else
      {
        //  Description length must be greater than 10 characters
        if (Description.Trim().Length < 10)
        {
          Messages.Add(new ValidationMessage("Description entered must be greater than 10 characters.", "Description"));
        }
      }

      return (Messages.Count == 0);
    }
    #endregion
  }
}