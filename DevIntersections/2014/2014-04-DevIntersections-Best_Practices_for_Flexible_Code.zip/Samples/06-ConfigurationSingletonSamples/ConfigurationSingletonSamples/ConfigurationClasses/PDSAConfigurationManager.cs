﻿using System;
using System.Configuration;

namespace ConfigurationSingletonSamples
{
  public class PDSAConfigurationManager
  {
    #region Instance Property
    private static PDSAConfigurationManager _Instance = null;

    /// <summary>
    /// Get/Set an Instance of the ConfigurationManager class
    /// </summary>
    public static PDSAConfigurationManager Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new PDSAConfigurationManager();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    #region Instance Property Thread Safe
    // This approach ensures that only one instance is created and only when the instance is needed. 
    // Also, the variable is declared to be volatile to ensure that assignment to the instance variable 
    // completes before the instance variable can be accessed. 
    // Lastly, this approach uses a syncRoot instance to lock on, rather than locking on the type itself, to avoid deadlocks. 
    //
    // This double-check locking approach solves the thread concurrency problems while avoiding an exclusive lock 
    // in every call to the Instance property method. 
    // It also allows you to delay instantiation until the object is first accessed.
    // In practice, an application rarely requires this type of implementation. 
    // In most cases, the static initialization approach is sufficient.

    private static volatile PDSAConfigurationManager _InstanceThreadSafe = null;
    private static object syncRoot = new Object();

    /// <summary>
    /// Get/Set a Thread-Safe Instance of the ConfigurationManager class
    /// </summary>
    public static PDSAConfigurationManager InstanceThreadSafe
    {
      get
      {
        if (_InstanceThreadSafe == null)
        {
          lock (syncRoot)
          {
            if (_InstanceThreadSafe == null)
            {
              _Instance = new PDSAConfigurationManager();
            }
          }
        }

        return _Instance;
      }
      set { _InstanceThreadSafe = value; }
    }
    #endregion

    /// <summary>
    /// Return the value for the specified key passed in
    /// </summary>
    /// <param name="key">The key to locate</param>
    /// <returns>A value</returns>
    public string GetSetting(string key)
    {
      return GetSetting(key, string.Format("Key {0} Not Found.", key));
    }

    /// <summary>
    /// Return a value for the specified key passed in
    /// </summary>
    /// <param name="key">The key to locate</param>
    /// <param name="defaultValue">The default value to return if the key is not found</param>
    /// <returns>A value</returns>
    public string GetSetting(string key, string defaultValue)
    {
      string ret = string.Empty;

      ret = ConfigurationManager.AppSettings[key];
      if (string.IsNullOrEmpty(ret))
        ret = defaultValue;

      return ret;
    }
  }
}
