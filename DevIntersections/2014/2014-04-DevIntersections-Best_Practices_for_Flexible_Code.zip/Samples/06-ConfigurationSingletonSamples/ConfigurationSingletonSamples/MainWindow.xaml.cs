﻿using System.Windows;

namespace ConfigurationSingletonSamples
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnGetValue_Click(object sender, RoutedEventArgs e)
    {
      PDSAConfigurationManager mgr = new PDSAConfigurationManager();

      tbResult.Text = mgr.GetSetting(txtKey.Text, txtDefaultValue.Text);
    }

    // Hard Coded Sample
    private void GetValue()
    {
      PDSAConfigurationManager mgr = new PDSAConfigurationManager();

      MessageBox.Show(mgr.GetSetting("DefaultStateCode", "CA"));
    }

    #region Singleton Pattern
    private void btnGetValueSingleton_Click(object sender, RoutedEventArgs e)
    {
      tbResult.Text = PDSAConfigurationManager.Instance.GetSetting(txtKey.Text, txtDefaultValue.Text);
    }

    // Hard Coded Sample
    private void GetValueSingleton()
    {
      MessageBox.Show(PDSAConfigurationManager.Instance.GetSetting("DefaultStateCode", "CA"));
    }
    #endregion
  }
}
