﻿using System;
using System.Linq;
using System.Xml.Linq;

namespace CommonLibrary
{
  /// <summary>
  /// Class for extending XML functionality
  /// </summary>
public static class XmlExtensions
{
  #region GetAs<T> Method
  /// <summary>
  /// Retrieve data from an XElement object's value and convert to a specific data type
  /// </summary>
  /// <typeparam name="T">The type to convert to</typeparam>
  /// <param name="elem">The element to get the value from</param>
  /// <param name="defaultValue">A default if the value is not found</param>
  /// <returns>A type</returns>
  public static T GetAs<T>(this XElement elem, T defaultValue = default(T))
  {
    T ret = defaultValue;

    if (elem != null && !string.IsNullOrEmpty(elem.Value))
    {
      // Cast to Return Data Type
      ret = (T)Convert.ChangeType(elem.Value, typeof(T));
    }
      
    return ret;
  }
  #endregion
}
}
