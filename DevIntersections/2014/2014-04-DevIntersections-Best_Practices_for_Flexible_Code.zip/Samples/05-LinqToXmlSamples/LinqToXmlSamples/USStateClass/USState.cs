﻿using System;

namespace LinqToXmlSamples
{
  /// <summary>
  /// This class represents a US State Code
  /// </summary>
public partial class USState
{
  /// <summary>
  /// Get/Set the two-letter abbreviation
  /// </summary>
  public string StateCode { get; set; }
  /// <summary>
  /// Get/Set the full state name
  /// </summary>
  public string StateName { get; set; }
  /// <summary>
  /// Get/Set the Capital
  /// </summary>
  public string Capital { get; set; }

  #region Override of ToString()
  public override string ToString()
  {
    return StateCode + " (" + StateName + ")";
  }
  #endregion
}
}
