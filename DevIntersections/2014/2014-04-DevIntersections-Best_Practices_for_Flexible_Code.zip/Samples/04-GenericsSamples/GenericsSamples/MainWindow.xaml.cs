﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Documents;

namespace GenericsSamples
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    #region Non-Generic Methods
    private void btnHardCodedNonGeneric_Click(object sender, RoutedEventArgs e)
    {
      HardCodedNonGenericsSample();
    }

    private void HardCodedNonGenericsSample()
    {
      object value = "1";

      int i = ConvertToInt(value, default(int));

      value = "1/1/2014";
      DateTime dt = ConvertToDateTime(value, default(DateTime));

      value = null;
      DateTime dtNull = ConvertToDateTime(value, default(DateTime));
    }

    private void btnNonGeneric_Click(object sender, RoutedEventArgs e)
    {
      lstData.DataContext = GetProductsNonGeneric();
    }

    public List<Product> GetProductsNonGeneric()
    {
      List<Product> ret = new List<Product>();
      Product entity;
      SqlDataAdapter da;
      DataTable dt = new DataTable();

      da = new SqlDataAdapter("SELECT * FROM Product",
        "Server=Localhost;Database=Sandbox;Integrated Security=Yes");

      da.Fill(dt);

      foreach (DataRow dr in dt.Rows)
      {
        entity = new Product();

        entity.ProductId = ConvertToInt(dr["ProductId"], 0);
        entity.ProductName = ConvertToString(dr["ProductName"], string.Empty);
        entity.IntroductionDate = ConvertToDateTime(dr["IntroductionDate"],
                  default(DateTime));
        entity.Cost = ConvertToDecimal(dr["Cost"],
                  default(decimal));
        entity.Price = ConvertToDecimal(dr["Price"],
                  default(decimal));
        entity.IsDiscontinued = ConvertToBoolean(dr["IsDiscontinued"],
                  default(bool));

        ret.Add(entity);
      }

      return ret;
    }

    public int ConvertToInt(object value, object defaultValue)
    {
      if (value == null || value.Equals(DBNull.Value))
        return Convert.ToInt32(defaultValue);
      else
        return Convert.ToInt32(value);
    }

    public DateTime ConvertToDateTime(object value, object defaultValue)
    {
      if (value == null || value.Equals(DBNull.Value))
        return Convert.ToDateTime(defaultValue);
      else
        return Convert.ToDateTime(value);
    }

    public string ConvertToString(object value, object defaultValue)
    {
      if (value == null || value.Equals(DBNull.Value))
        return Convert.ToString(defaultValue);
      else
        return Convert.ToString(value);
    }

    public Decimal ConvertToDecimal(object value, object defaultValue)
    {
      if (value == null || value.Equals(DBNull.Value))
        return Convert.ToDecimal(defaultValue);
      else
        return Convert.ToDecimal(value);
    }

    public bool ConvertToBoolean(object value, object defaultValue)
    {
      if (value == null || value.Equals(DBNull.Value))
        return Convert.ToBoolean(defaultValue);
      else
        return Convert.ToBoolean(value);
    }
    #endregion

    #region Generic Methods
    private void btnHardCodedGeneric_Click(object sender, RoutedEventArgs e)
    {
      HardCodedGenericsSample();
    }

    private void HardCodedGenericsSample()
    {
      object value = "1";

      int i = ConvertTo<int>(value, default(int));

      value = "1/1/2014";
      DateTime dt = ConvertTo<DateTime>(value, default(DateTime));

      value = null;
      DateTime dtNull = ConvertTo<DateTime>(value, default(DateTime));
    }

    private void btnGeneric_Click(object sender, RoutedEventArgs e)
    {
      lstData.DataContext = GetProducts();
    }

    public List<Product> GetProducts()
    {
      List<Product> ret = new List<Product>();
      Product entity;
      SqlDataAdapter da;
      DataTable dt = new DataTable();

      da = new SqlDataAdapter("SELECT * FROM Product",
        "Server=Localhost;Database=Sandbox;Integrated Security=Yes");

      da.Fill(dt);

      foreach (DataRow dr in dt.Rows)
      {
        entity = new Product();

        entity.ProductId = Convert.ToInt32(dr["ProductId"]);
        entity.ProductName = dr["ProductName"].ToString();
        entity.IntroductionDate =
                ConvertTo<DateTime>(dr["IntroductionDate"],
                  default(DateTime));
        entity.Cost =
                ConvertTo<decimal>(dr["Cost"],
                  default(decimal));
        entity.Price =
                ConvertTo<decimal>(dr["Price"],
                  default(decimal));
        entity.IsDiscontinued =
                ConvertTo<bool>(dr["IsDiscontinued"],
                  default(bool));

        ret.Add(entity);
      }

      return ret;
    }

    public T ConvertTo<T>(object value, object defaultValue)
    {
      if (value == null || value.Equals(DBNull.Value))
        return (T)Convert.ChangeType(defaultValue, typeof(T));
      else
        return (T)Convert.ChangeType(value, typeof(T));
    }
    #endregion
  }
}
