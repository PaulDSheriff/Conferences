﻿using System;

namespace GenericsSamples
{
  /// <summary>
  /// This class represents a Product
  /// </summary>
  public partial class Product
  {
    /// <summary>
    /// Get/Set the Product ID
    /// </summary>
    public int ProductId { get; set; }
    /// <summary>
    /// Get/Set the Product Name
    /// </summary>
    public string ProductName { get; set; }
    /// <summary>
    /// Get/Set the Introduction Date
    /// </summary>
    public DateTime IntroductionDate { get; set; }
    /// <summary>
    /// Get/Set the Cost
    /// </summary>
    public decimal Cost { get; set; }
    /// <summary>
    /// Get/Set the Price
    /// </summary>
    public decimal Price { get; set; }
    /// <summary>
    /// Get/Set whether or not this Product is Discontinued 
    /// </summary>
    public bool IsDiscontinued { get; set; }
  }
}
