﻿using System;
using System.Globalization;

namespace CommonLibrary
{
  /// <summary>
  /// This class contains Extension Methods for DateTime
  /// </summary>
  public static class DateExtensions
  {
    /// <summary>
    /// Returns the first day of the month for the date value passed in.
    /// </summary>
    /// <param name="value">A Date Value</param>
    /// <returns>DateTime</returns>
    public static DateTime MonthStart(this DateTime value)
    {
      DateTime dt = DateTime.MinValue;

      dt = new DateTime(value.Year, value.Month, 1, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);

      return dt;
    }

    /// <summary>
    /// Returns the last day of the month for the date value passed in.
    /// </summary>
    /// <param name="value">A Date Value</param>
    /// <returns>DateTime</returns>
    public static DateTime MonthEnd(this DateTime value)
    {
      int lastDay = 0;
      DateTime dt = DateTime.MinValue;

      lastDay = DateTime.DaysInMonth(value.Year, value.Month);

      dt = new DateTime(value.Year, value.Month, lastDay, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);

      return dt;
    }

    /// <summary>
    /// Returns a Date that is the first day of the quarter for the given date value passed in.
    /// </summary>
    /// <param name="value">A Date Value</param>
    /// <returns>DateTime</returns>
    public static DateTime QuarterStart(this DateTime value)
    {
      DateTime dt = DateTime.MinValue;

      switch (value.Month)
      {
        case 1:
        case 2:
        case 3:
          dt = new DateTime(value.Year, 1, 1, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
          break;
        case 4:
        case 5:
        case 6:
          dt = new DateTime(value.Year, 4, 1, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
          break;
        case 7:
        case 8:
        case 9:
          dt = new DateTime(value.Year, 7, 1, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
          break;
        case 10:
        case 11:
        case 12:
          dt = new DateTime(value.Year, 10, 1, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
          break;

        default:
          break;
      }

      return dt;
    }

    /// <summary>
    /// Returns a Date that is the last day of the quarter for the given date value passed in.
    /// </summary>
    /// <param name="value">A Date Value</param>
    /// <returns>DataTime</returns>
    public static DateTime QuarterEnd(this DateTime value)
    {
      DateTime dt = DateTime.MinValue;

      switch (value.Month)
      {
        case 1:
        case 2:
        case 3:
          dt = new DateTime(value.Year, 3, 31, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
          break;
        case 4:
        case 5:
        case 6:
          dt = new DateTime(value.Year, 6, 30, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
          break;
        case 7:
        case 8:
        case 9:
          dt = new DateTime(value.Year, 9, 30, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
          break;
        case 10:
        case 11:
        case 12:
          dt = new DateTime(value.Year, 12, 31, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
          break;

        default:
          break;
      }

      return dt;
    }

    /// <summary>
    /// Returns the first day of the year for the given date passed in.
    /// </summary>
    /// <param name="value">A Date Value</param>
    /// <returns>DateTime</returns>
    public static DateTime YearStart(this DateTime value)
    {
      DateTime dt = DateTime.MinValue;

      dt = new DateTime(value.Year, 1, 1, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);

      return dt;
    }

    /// <summary>
    /// Returns the last day of the year for the given date value passed in.
    /// </summary>
    /// <param name="value">DateTime</param>
    /// <returns>DateTime</returns>
    public static DateTime YearEnd(this DateTime value)
    {
      DateTime dt = DateTime.MinValue;

      dt = new DateTime(value.Year, 12, 31, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);

      return dt;
    }
  }
}
