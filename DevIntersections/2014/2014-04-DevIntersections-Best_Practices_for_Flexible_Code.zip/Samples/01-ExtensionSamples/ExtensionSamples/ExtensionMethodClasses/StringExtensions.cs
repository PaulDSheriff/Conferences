﻿using System;
using System.Text.RegularExpressions;

namespace CommonLibrary
{
  /// <summary>
  /// This class contains Extension Methods for DateTime
  /// </summary>
  public static class StringExtensions
  {
    /// <summary>
    /// Take any string and reverse all of its characters
    /// NOTE: This name is the same as another Extension method Reverse, so this one will be used.
    /// </summary>
    /// <param name="value">The string to reverse</param>
    /// <returns>A string with all characters in reverse order</returns>
    public static string Reverse(this string value)
    {
      char[] charArray = null;
      string ret = string.Empty;

      if (value != null)
      {
        charArray = value.ToCharArray();
        Array.Reverse(charArray);

        ret = new string(charArray);
      }

      return ret;
    }

    /// <summary>
    /// Convert a string to a boolean
    /// 1, -1, True, true, T, t, Yes, yes, Y, y will return 'true'
    /// 0, False, false, F, f, No, no, N, n will return 'false'
    /// </summary>
    /// <param name="value">value to convert to boolean</param>
    /// <returns>Boolean</returns>
    public static bool ToBoolean(this string value)
    {
      bool ret = false;

      switch (value.ToLower())
      {
        case "true":
        case "t":
        case "yes":
        case "y":
        case "1":
        case "-1":
          ret = true;
          break;
        case "false":
        case "f":
        case "no":
        case "n":
        case "0":
          ret = false;
          break;
        default:
          ret = false;
          break;
      }

      return ret;
    }

    /// <summary>
    /// Is the value passed in a valid email format?
    /// </summary>
    /// <param name="email">The email to check</param>
    /// <returns>True if the email is valid, otherwise false.</returns>
    public static bool IsValidEmail(this string email)
    {
      return Regex.IsMatch(email, (@"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$"));
    }


    /// <summary>
    /// Pass in a string and this method will determine if it is all lower case characters or not.
    /// </summary>
    /// <param name="value">The string to check</param>
    /// <returns>True if the string passed in is all lower case, otherwise false.</returns>
    public static bool IsAllLowerCase(this string value)
    {
      return new Regex(@"^([^A-Z])+$").IsMatch(value);
    }

    /// <summary>
    /// Pass in a string and this method will determine if it is all upper case characters or not.
    /// </summary>
    /// <param name="value">The string to check</param>
    /// <returns>True if the string passed in is all upper case, otherwise false.</returns>
    public static bool IsAllUpperCase(this string value)
    {
      return new Regex(@"^([^a-z])+$").IsMatch(value);
    }
  }
}
