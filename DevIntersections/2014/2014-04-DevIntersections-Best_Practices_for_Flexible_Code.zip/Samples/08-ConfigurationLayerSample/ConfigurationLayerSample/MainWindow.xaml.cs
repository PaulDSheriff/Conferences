﻿using System.Diagnostics;
using System.Windows;
using ConfigurationLayer;

namespace ConfigurationLayerSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnGetSetting_Click(object sender, RoutedEventArgs e)
    {
      txtValue.Text = PDSAConfigurationManager.Instance.GetSetting(txtKey.Text);
    }

    private void btnGetSettingDefault_Click(object sender, RoutedEventArgs e)
    {
      txtValue.Text = PDSAConfigurationManager.Instance.GetSetting(txtKey.Text, txtDefault.Text);
    }

    private void btnAppConfig_Click(object sender, RoutedEventArgs e)
    {
      Debug.WriteLine(AppConfig.Instance.EmpType);
      Debug.WriteLine(AppConfig.Instance.StateCode);

      Debugger.Break();
    }
  }
}
