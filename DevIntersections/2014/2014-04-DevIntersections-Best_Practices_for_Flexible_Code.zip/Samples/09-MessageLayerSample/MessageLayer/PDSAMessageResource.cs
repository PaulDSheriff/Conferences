﻿using System;
using System.Reflection;
using System.Resources;

namespace MessageLayer
{
  public class PDSAMessageResource : PDSAMessageBase
  {
    #region Constructors
    public PDSAMessageResource()
      : base()
    {
    }
    public PDSAMessageResource(string location)
      : base(location)
    {
    }
    #endregion

    public override string GetMessage(string key, string defaultMessage)
    {
      string ret = string.Empty;

      Assembly assm = Assembly.GetEntryAssembly();
      if (string.IsNullOrEmpty(BaseLocationName))
      {
        BaseLocationName = assm.GetName().Name + ".Properties.Resources";
      }

      ResourceManager resourceManager = new ResourceManager(BaseLocationName, assm);
      try
      {
        ret = resourceManager.GetString(key);
      }
      catch (Exception ex)
      {
        System.Diagnostics.Debug.Write(ex.Message);
        ret = defaultMessage;
      }

      return ret;
    }
  }
}
