﻿using System;

namespace MessageLayer
{
  public class PDSAMessageManager
  {
    #region Constructors
    public PDSAMessageManager()
    {
    }

    public PDSAMessageManager(PDSAMessageBase reader)
    {
      _MessageReader = reader;
    }
    #endregion

    #region Instance
    private static PDSAMessageManager _Instance = null;

    public static PDSAMessageManager Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new PDSAMessageManager();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    #region Message Reader Property
    private PDSAMessageBase _MessageReader = null;

    public PDSAMessageBase MessageReader
    {
      get { return _MessageReader; }
      set { _MessageReader = value; }
    }
    #endregion

    #region GetMessage Methods
    public virtual string GetMessage(string key)
    {
      if (MessageReader == null)
        return string.Empty;
      else
        return MessageReader.GetMessage(key);
    }

    public virtual string GetMessage(string key, string defaultValue)
    {
      if (MessageReader == null)
        return defaultValue;
      else
        return MessageReader.GetMessage(key, defaultValue);
    }
    #endregion
  }
}
