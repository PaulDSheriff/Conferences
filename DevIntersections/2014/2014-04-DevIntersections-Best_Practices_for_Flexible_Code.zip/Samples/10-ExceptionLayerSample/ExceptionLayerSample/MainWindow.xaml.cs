﻿using System;
using System.Collections.Specialized;
using System.Windows;

using ExceptionLayer;

namespace ExceptionLayerSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnPublish_Click(object sender, RoutedEventArgs e)
    {
      PDSAExceptionManager.Instance.Publish(new ApplicationException("This is an exception"));
    }

    private void btnPublishWithExtras_Click(object sender, RoutedEventArgs e)
    {
      NameValueCollection nvc = new NameValueCollection();
      nvc.Add("StateCode", "CA");
      nvc.Add("EmpType", "20");

      PDSAExceptionManager.Instance.Publish(new ApplicationException("This is an exception"), nvc);
    }
  }
}
