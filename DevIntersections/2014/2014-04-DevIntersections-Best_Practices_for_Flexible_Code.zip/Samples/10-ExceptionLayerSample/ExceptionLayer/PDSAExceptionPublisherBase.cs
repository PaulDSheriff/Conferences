﻿using System;
using System.Collections.Specialized;
using System.Text;

namespace ExceptionLayer
{
  public abstract class PDSAExceptionPublisherBase
  {
    #region Public Publish Methods
    public virtual void Publish(Exception ex)
    {
      Publish(ex, null);
    }

    public virtual void Publish(Exception ex, NameValueCollection additionalInfo)
    {
      ExceptionToPublish = ex;
      AdditionalInformation = additionalInfo;
      ExceptionInfo = new StringBuilder(1024);

      ExceptionInfo.AppendLine("Date/Time: " + DateTime.Now.ToString());
      ExceptionInfo.AppendLine("Exception Info");
      ExceptionInfo.AppendLine(ExceptionToPublish.ToString());
      ExceptionInfo.AppendLine();
      if (additionalInfo != null)
      {
        //  Retrieve Additional Info
        for (int index = 0; index <= additionalInfo.Count - 1; index++)
        {
          ExceptionInfo.AppendLine(additionalInfo.GetKey(index) + "=" + additionalInfo[index]);
        }
      }

      // Call Exception Publisher's Unique Publishing Method
      PublishSpecial();
    }
    #endregion

    #region Abstract PublishSpecial Method for each Publisher to Override
    protected abstract void PublishSpecial();
    #endregion

    #region Protected Properties
    protected StringBuilder ExceptionInfo { get; set; }
    protected Exception ExceptionToPublish { get; set; }
    protected NameValueCollection AdditionalInformation { get; set; }
    #endregion
  }
}
