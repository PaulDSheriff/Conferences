﻿using System;

namespace ExceptionLayer
{
  public class PDSAEmailSettings
  {
    #region Constructors
    public PDSAEmailSettings()
    {
      FromEmail = string.Empty;
      ToEmail = string.Empty;
      Subject = string.Empty;
      SMTPServer = string.Empty;
    }

     /// <summary>
    /// Create an instance of an email exception publisher
    /// </summary>
    /// <param name="from">The 'From' email address</param>
    /// <param name="to">The 'To' email address (NOTE: This can be a comma delimited list)</param>
    /// <param name="subject">The 'Subject' of the email</param>
    /// <param name="smtpServer">The SMTP Server from which to relay the emails</param>
    public PDSAEmailSettings(string from, string to, string subject, string smtpServer)
    {
      FromEmail = from;
      ToEmail = to;
      Subject = subject;
      SMTPServer = smtpServer;
    }
    #endregion

    /// <summary>
    /// Get/Set FromEmail
    /// </summary>
    public string FromEmail { get; set; }

    /// <summary>
    /// Get/Set ToEmail
    /// </summary>
    public string ToEmail { get; set; }

    /// <summary>
    /// Get/Set Subject
    /// </summary>
    public string Subject { get; set; }

    /// <summary>
    /// Get/Set SMTPServer
    /// </summary>
    public string SMTPServer { get; set; }
    
    /// <summary>
    /// Get/Set Port
    /// </summary>
    public string Port { get; set; }

    /// <summary>
    /// Get/Set UserName
    /// </summary>
    public string UserName { get; set; }

    /// <summary>
    /// Get/Set Password
    /// </summary>
    public string Password { get; set; }

    /// <summary>
    /// Get/Set UseSsl
    /// </summary>
    public bool UseSsl { get; set; }
  }
}
