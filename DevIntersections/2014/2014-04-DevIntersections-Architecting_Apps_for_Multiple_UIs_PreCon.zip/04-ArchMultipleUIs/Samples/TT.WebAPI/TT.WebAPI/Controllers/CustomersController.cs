﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using TimeTrack.EntityClasses;
using TimeTrack.Services;

namespace TT.WebAPI.Controllers
{
    public class CustomersController : ApiController
    {
      // http://Localhost:xxx/api/Customers
      public Customers GetCustomers()
      {
        CustomerServices srv = new CustomerServices();
        Customers coll;

        coll = srv.GetCustomers().DataCollection;

        return coll;
      }
    }
}
