﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using TimeTrack.EntityClasses;
using TimeTrack.ViewModels;

namespace TimeTrack.MVC.Controllers
{
  public class TimeSheetsDisplayController : Controller
  {
    static TimeSheetsDisplayViewModel _ViewModel = new TimeSheetsDisplayViewModel(false);

    /// <summary>
    /// This method is called the first time the page is loaded
    /// </summary>
    /// <returns>An ActionResult object</returns>
    public ActionResult TimeSheetsDisplay()
    {
      // Load all Customers
      _ViewModel.GetAllCustomers();
      // Create new "CustomerCollection" property on the ViewBag from the CustomerCollection property of the View Model
      ViewBag.CustomerCollection = _ViewModel.CustomerCollection;

      return View(_ViewModel);
    }

    /// <summary>
    /// This version of the Index method is called on the post-back from the Drop Down List of customers
    /// </summary>
    /// <param name="customerId">The CustomerId from the drop down list</param>
    /// <returns>An ActionResult object</returns>
    [HttpPost()]
    public ActionResult TimeSheetsDisplay(int customerId)
    {
      Customer entity = null;

      if (customerId >= 0)
      {
        // Fill in CustomerId from the customerId parameter
        entity = new Customer();
        entity.CustomerId = customerId;
        // Get all TimeSheets for this customer
        _ViewModel.GetTimeSheetsByCustomer(entity);
        // Create new "TimeSheets" property on the ViewBag
        ViewBag.TimeSheets = _ViewModel.DataCollection;
      }

      return View(_ViewModel);
    }
  }
}
