using System;
using System.ServiceModel.Activation;
using Common.Library;
using TimeTrack.DataClasses;
using TimeTrack.EntityClasses;

namespace TimeTrack.Services
{
  /// <summary>
  /// Class called by a WCF Service
	/// All methods return a "Response Class". 
	/// This allows us to do all exception handling here and not have to throw any custom exceptions
	/// You can return all error messages from here. 
	/// Those messages could be data-driven. That way if you want to change them, you only have to change them on the server
  /// </summary>
  [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
  public partial class CustomerServices : ICustomerServices
  {
    #region CreateCustomerDataObject Method
    private CustomerData CreateCustomerDataObject()
    {
      CustomerData ret = new CustomerData();

      ret.ConnectString = ret.GetConnectString("TimeTrack");

      return ret;
    }
    #endregion

    #region GetCustomer Method
    public CustomerResponse GetCustomer(Customer entity)
    {
      CustomerResponse ret = new CustomerResponse();
      CustomerData data = null;

      try
      {
        data = CreateCustomerDataObject();

        ret.DetailData = data.GetCustomer(entity);
        ret.RowsAffected = data.RowsAffected;
        ret.Status = OperationResult.Success;
        if(ret.RowsAffected == 0)
        {
          ret.Status = OperationResult.NoRecords;
          ret.FriendlyErrorMessage = "The record you were looking for was not found.";
        }
      }
      catch (Exception ex)
      {
				// Perform any exception logging here

				// Set Return Properties
        ret.ErrorMessage = ex.Message;
        ret.ErrorMessageExtended = ex.ToString();
        ret.Status = OperationResult.Exception;
      }

      return ret;
    }
    #endregion

    #region GetCustomers Method
    public CustomerResponse GetCustomers()
    { 
      CustomerResponse ret = new CustomerResponse();
      CustomerData data = null;
      
      try
      {
        data = CreateCustomerDataObject();

        ret.DataCollection = data.BuildCollection();
        ret.RowsAffected = data.RowsAffected;
        if (ret.DataCollection != null)
        {
          if (ret.DataCollection.Count > 0)
            ret.Status = OperationResult.Success;
          else
          {
            ret.Status = OperationResult.NoRecords;
            ret.FriendlyErrorMessage = "No records were found for this table.";
          }
        }
      }
      catch (Exception ex)
      {
				// Perform any exception logging here

				// Set Return Properties
				ret.ErrorMessage = ex.Message;
        ret.ErrorMessageExtended = ex.ToString();
        ret.Status = OperationResult.Exception;
      }

      return ret;
    }
    #endregion

  }
}

