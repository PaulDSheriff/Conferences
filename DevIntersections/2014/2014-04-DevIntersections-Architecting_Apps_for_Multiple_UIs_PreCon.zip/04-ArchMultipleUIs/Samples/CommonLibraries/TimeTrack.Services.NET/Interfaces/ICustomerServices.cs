using System.ServiceModel;
using System.ServiceModel.Web;

using TimeTrack.DataClasses;
using TimeTrack.EntityClasses;

namespace TimeTrack.Services
{
  [ServiceContract(Namespace = "http://TimeTrack.Services")]
  public interface ICustomerServices
  {
    [OperationContract]
    [WebInvoke(Method = "POST",
        BodyStyle = WebMessageBodyStyle.WrappedRequest,
        ResponseFormat = WebMessageFormat.Json,
        RequestFormat = WebMessageFormat.Json
      )]
    CustomerResponse GetCustomer(Customer entity);

    [OperationContract]
    [WebGet(ResponseFormat = WebMessageFormat.Json)]  
    CustomerResponse GetCustomers();
  }
}
