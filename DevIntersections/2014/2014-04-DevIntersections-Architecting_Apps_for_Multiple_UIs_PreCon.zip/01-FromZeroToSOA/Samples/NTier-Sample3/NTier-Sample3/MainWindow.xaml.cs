﻿using System.Windows;

using NTier.DataClasses;
using NTier.EntityClasses;

namespace NTier_Sample3
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window
  {
    PersonManager _Manager = null;

    public MainWindow()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      _Manager = new PersonManager(AppConfig.ConnectString);

      lstData.DataContext = _Manager.GetPersons();
      if (_Manager.Message != string.Empty)
        tbMessage.Text = _Manager.Message;
    }
    
    private void btnUpdate_Click(object sender, RoutedEventArgs e)
    {
      if (lstData.SelectedIndex >= 0)
      {
        _Manager.UpdatePerson(((Person)lstData.SelectedItem));
        if (_Manager.Message != string.Empty)
          tbMessage.Text = _Manager.Message;
      }
    }
  }
}
