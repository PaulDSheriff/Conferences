﻿using System;
using System.Windows;

using NTier.EntityClasses;
using NTier_Sample4.PersonServiceReference;

namespace NTier_Sample4
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      PersonServicesClient client = null;
      PersonResponse resp;

      try
      {
        client = new PersonServicesClient();

        resp = client.GetPersons();
        if (resp.Status == NTier.Common.OperationResult.Success)
          lstData.DataContext = resp.DataCollection;
        else
          tbMessage.Text = resp.ErrorMessage;
      }
      catch (Exception ex)
      {
        tbMessage.Text = ex.Message;
      }
    }

    private void btnUpdate_Click(object sender, RoutedEventArgs e)
    {
      PersonServicesClient client = null;
      PersonResponse resp;

      if (lstData.SelectedIndex >= 0)
      {
        try
        {
          client = new PersonServicesClient();

          resp = client.Update(((Person)lstData.SelectedItem));
          if (resp.Status == NTier.Common.OperationResult.Success)
            MessageBox.Show("Person Updated");
          else
            tbMessage.Text = resp.ErrorMessage;
        }
        catch (Exception ex)
        {
          tbMessage.Text = ex.Message;
        }
      }
    }
  }
}
