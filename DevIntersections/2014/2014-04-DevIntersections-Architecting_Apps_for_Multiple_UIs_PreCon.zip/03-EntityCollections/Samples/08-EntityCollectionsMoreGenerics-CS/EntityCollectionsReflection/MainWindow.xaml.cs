﻿using System.Windows;
using System.Reflection;
using System;
using System.Data;
using System.Data.SqlClient;

namespace EntityCollectionsReflection
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    #region Window_Loaded Event Procedure
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      DisplayRowsRead();
    }
    #endregion

    #region DisplayRowsRead Method
    private void DisplayRowsRead()
    {
      if (lstData.Items.Count > 0)
        txtRowsRead.Text = lstData.Items.Count.ToString("###,###");
      else
        txtRowsRead.Text = "0";
    }
    #endregion
    
    private void btnNewGeneric_Click(object sender, RoutedEventArgs e)
    {
      DataTable dt = new DataTable();
      SqlDataAdapter da = null;

      da = new SqlDataAdapter("SELECT * FROM Product",
                              AppSettings.Instance.ConnectString);

      da.Fill(dt);

      var query = (from dr in dt.AsEnumerable()
                   select new Product
                   {
                     ProductId = Convert.ToInt32(dr["ProductId"]),
                     ProductName = dr["ProductName"].ToString(),
                     IntroductionDate =
                       DataConvert.GetDataAs<DateTime>(dr["IntroductionDate"]),
                     Cost = DataConvert.GetDataAs<decimal>(dr["Cost"]),
                     Price = DataConvert.GetDataAs<decimal>(dr["Price"]),
                     IsDiscontinued = DataConvert.GetDataAs<bool>(dr["IsDiscontinued"])
                   });

      lstData.View = PDSAListView.CreateGridViewColumns(typeof(Product));
      lstData.DataContext = query;
    }

    private void btnDataRowExtension_Click(object sender, RoutedEventArgs e)
    {
      DataTable dt = new DataTable();
      SqlDataAdapter da = null;

      da = new SqlDataAdapter("SELECT * FROM Product",
                              AppSettings.Instance.ConnectString);

      da.Fill(dt);

      var query = (from dr in dt.AsEnumerable()
                   select new Product
                   {
                     ProductId = dr.GetDataAs<int>("ProductId"),
                     ProductName = dr["ProductName"].ToString(),
                     IntroductionDate = dr.GetDataAs<DateTime>("IntroductionDate"),
                     Cost = dr.GetDataAs<decimal>("Cost"),
                     Price = dr.GetDataAs<decimal>("Price"),
                     IsDiscontinued = dr.GetDataAs<bool>("IsDiscontinued")
                   });

      lstData.View = PDSAListView.CreateGridViewColumns(typeof(Product));
      lstData.DataContext = query;
    }

    private void btnDataTable_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr = new ProductManager();

      lstData.View = PDSAListView.CreateGridViewColumns(typeof(Product));
      lstData.DataContext = mgr.GetProductsDataTable();
      DisplayRowsRead();
    }

    private void btnDataReader_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr = new ProductManager();

      lstData.View = PDSAListView.CreateGridViewColumns(typeof(Product));
      lstData.DataContext = mgr.GetProductsDataReader();
      DisplayRowsRead();
    }

  }
}
