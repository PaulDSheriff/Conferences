﻿Imports System.Reflection

Class MainWindow

#Region "InvokeMember Method"
  Private Sub btnSetProperty1_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnSetProperty1.Click
    Dim entity As New Product()

    GetType(Product).InvokeMember("ProductName", _
       BindingFlags.SetProperty, _
         Type.DefaultBinder, entity, _
            New Object() {"A New Product"})

    MessageBox.Show(entity.ProductName)
  End Sub
#End Region

#Region "SetValue Method"
  Private Sub btnSetProperty2_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnSetProperty2.Click
    Dim entity As New Product()

    GetType(Product).GetProperty("ProductName"). _
       SetValue(entity, "A New Product", Nothing)

    MessageBox.Show(entity.ProductName)
  End Sub
#End Region
End Class