﻿Public Class DataConvert
  Public Shared Function ConvertTo(Of T As Structure)(value As Object, defaultValue As Object) As T
    If value.Equals(DBNull.Value) Then
      Return DirectCast(defaultValue, T)
    Else
      Return DirectCast(value, T)
    End If
  End Function
End Class
