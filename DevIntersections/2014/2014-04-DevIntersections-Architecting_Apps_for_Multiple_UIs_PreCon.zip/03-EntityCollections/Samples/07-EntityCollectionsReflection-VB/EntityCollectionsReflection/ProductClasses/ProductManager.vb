﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Collections.Generic

Public Class ProductManager
  Inherits ManagerBase

#Region "GetProductsDataTable Method"
  ''' <summary>
  ''' This method uses Reflection to create an entity collection using a DataTable
  ''' Your Entity class should use nullable types
  ''' </summary>
  ''' <returns>A List of Product objects</returns>
  Public Function GetProductsDataTable() As List(Of Product)
    Dim dt As New DataTable()
    Dim da As SqlDataAdapter = Nothing
    Dim ret As List(Of Product) = Nothing

    da = New SqlDataAdapter("SELECT * FROM Product", AppSettings.Instance.ConnectString)

    da.Fill(dt)

    ' Build Collection of Entity Objets using Reflection
    ret = MyBase.BuildCollection(Of Product)(GetType(Product), dt)

    Return ret
  End Function
#End Region

#Region "GetProductsDataReader Method"
  ''' <summary>
  ''' This method uses Reflection to create an entity collection using a DataReader
  ''' Your Entity class should use nullable types
  ''' </summary>
  ''' <returns>A List of Product objects</returns>
  Public Function GetProductsDataReader() As List(Of Product)
    Dim cmd As SqlCommand = Nothing
    Dim ret As List(Of Product) = Nothing

    cmd = New SqlCommand("SELECT * FROM Product")
    Using cnn = New SqlConnection(AppSettings.Instance.ConnectString)
      cmd.Connection = cnn
      cmd.Connection.Open()
      Using rdr = cmd.ExecuteReader()

        ' Build Collection of Entity Objets using Reflection
        ret = BuildCollection(Of Product)(GetType(Product), rdr)

      End Using
    End Using

    Return ret
  End Function
#End Region
End Class
