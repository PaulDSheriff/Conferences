﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace EntityCollectionsLinq
{
  public class ProductManager
  {
    #region GetProducts Method
    /// <summary>
    /// This method uses DataRow.Field&lt;T&gt;() method to retrieve data.
    /// The Field method works will nullable types.
    /// </summary>
    /// <returns>A List of Product objects</returns>
    public List<Product> GetProducts()
    {
      DataTable dt = new DataTable();
      SqlDataAdapter da = null;

      da = new SqlDataAdapter("SELECT * FROM Product",
                              AppSettings.Instance.ConnectString);

      da.Fill(dt);

      var query = 
        (from dr in dt.AsEnumerable()
          select new Product
          {
            ProductId = dr.Field<int?>("ProductId"),
            ProductName = dr.Field<string>("ProductName"),
            IntroductionDate = dr.Field<DateTime?>("IntroductionDate"),
            Cost = dr.Field<decimal?>("Cost"),
            Price = dr.Field<decimal?>("Price"),
            IsDiscontinued = dr.Field<bool?>("IsDiscontinued")
          });

      return query.ToList();
    }
    #endregion
  }
}
