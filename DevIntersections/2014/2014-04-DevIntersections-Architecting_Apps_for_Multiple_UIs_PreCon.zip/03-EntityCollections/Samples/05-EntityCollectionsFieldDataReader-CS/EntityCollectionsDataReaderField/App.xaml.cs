﻿using System.Windows;

namespace EntityCollectionsDataReaderField
{
	public partial class App : Application
	{
	}
}
