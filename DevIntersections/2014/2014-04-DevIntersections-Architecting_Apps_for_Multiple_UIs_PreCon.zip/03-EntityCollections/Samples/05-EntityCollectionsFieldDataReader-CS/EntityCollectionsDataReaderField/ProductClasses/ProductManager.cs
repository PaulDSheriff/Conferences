﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace EntityCollectionsDataReaderField
{
  public class ProductManager
  {
    #region GetProducts Method
    /// <summary>
    /// This method uses a custom extension method on a DataReader called Field to retrieve data.
    /// The Field method works will nullable types.
    /// </summary>
    /// <returns>A List of Product objects</returns>
    public List<Product> GetProducts()
    {
      SqlCommand cmd = null;
      List<Product> ret = new List<Product>();
      Product entity = null;

      cmd = new SqlCommand("SELECT * FROM Product");
      using (cmd.Connection = new SqlConnection(AppSettings.Instance.ConnectString))
      {
        cmd.Connection.Open();
        using (var rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection))
        {
          while (rdr.Read())
          {
            entity = new Product();

            entity.ProductId = rdr.Field<int?>("ProductId");
            entity.ProductName = rdr.Field<string>("ProductName");
            entity.IntroductionDate = rdr.Field<DateTime?>("IntroductionDate");
            entity.Cost = rdr.Field<decimal?>("Cost");
            entity.Price = rdr.Field<decimal?>("Price");
            entity.IsDiscontinued = rdr.Field<bool?>("IsDiscontinued");

            ret.Add(entity);
          }
        }
      }

      return ret;
    }
    #endregion
  }
}
