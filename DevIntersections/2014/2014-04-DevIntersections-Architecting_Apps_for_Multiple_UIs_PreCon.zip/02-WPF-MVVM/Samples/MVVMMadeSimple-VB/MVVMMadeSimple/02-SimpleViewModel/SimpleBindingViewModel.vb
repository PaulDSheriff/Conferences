﻿Public Class SimpleBindingViewModel
  Inherits CommonBase

  Private mIsBenefitsChecked As Boolean = True
  Private mIs401kEnabled As Boolean = True
  Private mIsHealthCareEnabled As Boolean = True

  Public Property IsBenefitsChecked() As Boolean
    Get
      Return mIsBenefitsChecked
    End Get
    Set(value As Boolean)
      If mIsBenefitsChecked <> value Then
        mIsBenefitsChecked = value
        Is401kEnabled = value
        IsHealthCareEnabled = value
        RaisePropertyChanged("IsBenefitsChecked")
      End If
    End Set
  End Property

  Public Property Is401kEnabled() As Boolean
    Get
      Return mIs401kEnabled
    End Get
    Set(value As Boolean)
      If mIs401kEnabled <> value Then
        mIs401kEnabled = value
        RaisePropertyChanged("Is401kEnabled")
      End If
    End Set
  End Property

  Public Property IsHealthCareEnabled() As Boolean
    Get
      Return mIsHealthCareEnabled
    End Get
    Set(value As Boolean)
      If mIsHealthCareEnabled <> value Then
        mIsHealthCareEnabled = value
        RaisePropertyChanged("IsHealthCareEnabled")
      End If
    End Set
  End Property
End Class
