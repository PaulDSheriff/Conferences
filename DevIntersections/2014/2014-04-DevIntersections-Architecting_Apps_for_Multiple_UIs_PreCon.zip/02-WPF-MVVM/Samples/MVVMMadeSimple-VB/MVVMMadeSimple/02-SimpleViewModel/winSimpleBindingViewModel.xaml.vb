﻿Public Class winSimpleBindingViewModel

End Class
