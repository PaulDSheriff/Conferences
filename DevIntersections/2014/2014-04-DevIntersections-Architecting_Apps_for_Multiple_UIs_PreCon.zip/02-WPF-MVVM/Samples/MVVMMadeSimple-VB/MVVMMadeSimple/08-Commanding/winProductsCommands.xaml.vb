﻿Public Class winProductsCommands
  Private mViewModel As ProductViewModelCommand

#Region "Constructor"
  Public Sub New()
    InitializeComponent()

    ' Initialize the Product View Model Object
    mViewModel = DirectCast(Me.Resources("viewModel"), ProductViewModelCommand)
  End Sub
#End Region

#Region "Loaded Event"
  Private Sub UserControl_Loaded(sender As Object, e As RoutedEventArgs)
    ' Load Products
    mViewModel.LoadAll()
  End Sub
#End Region

#Region "Edit Click Event"
  Private Sub btnEdit_Click(sender As Object, e As RoutedEventArgs)
    ' Get Data Context from Button
    ' So you can update the List Box SelectedValue
    mViewModel.DetailData = DirectCast(DirectCast(sender, Button).DataContext, Product)
    mViewModel.SetEditUIDisplay()
  End Sub
#End Region
End Class
