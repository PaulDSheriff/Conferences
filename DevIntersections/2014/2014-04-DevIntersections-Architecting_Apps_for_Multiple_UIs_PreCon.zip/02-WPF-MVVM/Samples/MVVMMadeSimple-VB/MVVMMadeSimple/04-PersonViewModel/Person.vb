﻿Public Class Person
  Inherits DataClassBase

#Region "Constructor"
  Public Sub New()
    FirstName = String.Empty
    LastName = String.Empty
    BirthDate = DateTime.Now.AddYears(-20)
  End Sub
#End Region

#Region "Private Variables"
  Private mFirstName As String
  Private mLastName As String
  Private mBirthDate As DateTime
#End Region

#Region "Public Properties"
  Public Property FirstName() As String
    Get
      Return mFirstName
    End Get
    Set(value As String)
      mFirstName = value
      RaisePropertyChanged("FirstName")
    End Set
  End Property

  Public Property LastName() As String
    Get
      Return mLastName
    End Get
    Set(value As String)
      mLastName = value
      RaisePropertyChanged("LastName")
    End Set
  End Property

  Public Property BirthDate() As DateTime
    Get
      Return mBirthDate
    End Get
    Set(value As DateTime)
      mBirthDate = value
      RaisePropertyChanged("BirthDate")
    End Set
  End Property
#End Region

#Region "Validate Method"
  ''' <summary>
  ''' Validate Business Rules
  ''' </summary>
  ''' <returns>True if all rules pass, False otherwise</returns>
  Public Function Validate() As Boolean
    ' Clear Business Rule Failure Collection
    BusinessRuleFailures.Clear()

    If FirstName.Trim() = String.Empty Then
      BusinessRuleFailures.Add(New BusinessRuleMessage("FirstName", "First Name Must Be Filled In."))
    ElseIf FirstName.Trim().Length < 2 Then
      BusinessRuleFailures.Add(New BusinessRuleMessage("FirstName", "First Name Must Be More Than 1 Character."))
    End If

    If LastName.Trim() = String.Empty Then
      BusinessRuleFailures.Add(New BusinessRuleMessage("LastName", "Last Name Must Be Filled In."))
    ElseIf LastName.Trim().Length < 2 Then
      BusinessRuleFailures.Add(New BusinessRuleMessage("LastName", "Last Name Must Be More Than 1 Character."))
    End If

    ' Check Birth Date, assume no one is older than 110 years old!
    If BirthDate < DateTime.Now.AddYears(-110) Then
      BusinessRuleFailures.Add(New BusinessRuleMessage("BirthDate", "Birth Date Must Be Greater Than " & DateTime.Now.AddYears(-110).ToShortDateString()))
    End If

    Return (BusinessRuleFailures.Count = 0)
  End Function
#End Region
End Class
