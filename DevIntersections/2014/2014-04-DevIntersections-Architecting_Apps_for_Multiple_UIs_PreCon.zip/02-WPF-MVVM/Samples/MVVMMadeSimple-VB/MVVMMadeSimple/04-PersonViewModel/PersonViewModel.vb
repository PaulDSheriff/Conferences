﻿Public Class PersonViewModel
  Inherits ViewModelBase

#Region "Constructor"
  Public Sub New()
    PersonData = New Person()
  End Sub
#End Region

#Region "Private Variables"
  Private mPersonData As Person
#End Region

#Region "Public Properties"
  Public Property PersonData() As Person
    Get
      Return mPersonData
    End Get
    Set(value As Person)
      mPersonData = value
      RaisePropertyChanged("PersonData")
    End Set
  End Property
#End Region

#Region "Validate Method"
  Public Function Validate() As Boolean
    IsMessageVisible = False
    MessageToDisplay = String.Empty

    If PersonData.Validate() = False Then
      IsMessageVisible = True
      MessageToDisplay = PersonData.BusinessRuleFailures.ToString()
    End If

    Return Not IsMessageVisible
  End Function
#End Region
End Class