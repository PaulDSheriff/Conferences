﻿Public Class winPersonSample
  Private mViewModel As PersonViewModel

  Public Sub New()

    ' This call is required by the designer.
    InitializeComponent()

    ' Grab instance of View Model from XAML
    mViewModel = DirectCast(Me.Resources("viewModel"), PersonViewModel)
  End Sub

  Private Sub Button_Click(sender As Object, e As RoutedEventArgs)
    mViewModel.Validate()
  End Sub
End Class
