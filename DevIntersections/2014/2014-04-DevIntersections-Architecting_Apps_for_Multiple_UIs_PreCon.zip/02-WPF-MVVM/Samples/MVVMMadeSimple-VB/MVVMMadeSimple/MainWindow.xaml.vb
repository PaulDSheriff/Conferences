﻿Class MainWindow 

  Private Sub btnSimpleBinding_Click(sender As Object, e As RoutedEventArgs) Handles btnSimpleBinding.Click
    Dim win As New winSimpleBinding

    win.Show()
  End Sub

  Private Sub btnSimpleBindingViewModel_Click(sender As Object, e As RoutedEventArgs) Handles btnSimpleBindingViewModel.Click
    Dim win As New winSimpleBindingViewModel

    win.Show()
  End Sub

  Private Sub btnSearch_Click(sender As Object, e As RoutedEventArgs) Handles btnSearch.Click
    Dim win As New winSearchSample

    win.Show()
  End Sub

  Private Sub btnPerson_Click(sender As Object, e As RoutedEventArgs) Handles btnPerson.Click
    Dim win As New winPersonSample

    win.Show()
  End Sub

  Private Sub btnSimpleViewModelList_Click(sender As Object, e As RoutedEventArgs) Handles btnSimpleViewModelList.Click
    Dim win As New winListOnly

    win.Show()
  End Sub

  Private Sub btnSimpleViewModel_Click(sender As Object, e As RoutedEventArgs) Handles btnSimpleViewModel.Click
    Dim win As New winSimpleMVVM

    win.Show()
  End Sub

  Private Sub btnSimpleBaseClass_Click(sender As Object, e As RoutedEventArgs) Handles btnSimpleBaseClass.Click
    Dim win As New winProducts

    win.Show()
  End Sub

  Private Sub btnCommanding_Click(sender As Object, e As RoutedEventArgs) Handles btnCommanding.Click
    Dim win As New winProductsCommands

    win.Show()
  End Sub
End Class
