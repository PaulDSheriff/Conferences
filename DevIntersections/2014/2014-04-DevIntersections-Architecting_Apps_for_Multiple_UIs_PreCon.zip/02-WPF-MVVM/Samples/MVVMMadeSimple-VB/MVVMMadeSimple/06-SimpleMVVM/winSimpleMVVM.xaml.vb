﻿Public Class winSimpleMVVM
  Private mViewModel As ProductViewModelSimple

  Public Sub New()
    InitializeComponent()

    ' Initialize the Product View Model Object
    mViewModel = DirectCast(Me.Resources("viewModel"), ProductViewModelSimple)
  End Sub

#Region "Edit Click Event"
  Private Sub btnEdit_Click(sender As Object, e As RoutedEventArgs)
    ' Get Data Context from Button
    ' So you can update the List Box SelectedValue
    mViewModel.DetailData = DirectCast(DirectCast(sender, Button).DataContext, Product)
    mViewModel.SetEditUIDisplay()
  End Sub
#End Region

#Region "Add Click Event"
  Private Sub btnAdd_Click(sender As Object, e As RoutedEventArgs)
    mViewModel.AddRecord()
  End Sub
#End Region

#Region "Cancel Click Event"
  Private Sub btnCancel_Click(sender As Object, e As RoutedEventArgs)
    mViewModel.CancelEdit()

    ' TODO: Write code to undo changes
  End Sub
#End Region

#Region "Save Click Event"
  Private Sub btnSave_Click(sender As Object, e As RoutedEventArgs)
    mViewModel.SaveData()
  End Sub
#End Region
End Class
