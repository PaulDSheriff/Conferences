﻿Imports System.Collections.ObjectModel

Public Class ProductViewModelSimple
  Inherits ViewModelBase

#Region "Constructor"
  Public Sub New()
    LoadAll()
  End Sub
#End Region

#Region "Private UI Variables"
  Private mIsAddMode As Boolean = False
  Private mIsSaveEnabled As Boolean = False
  Private mIsCancelEnabled As Boolean = False
  Private mIsAddEnabled As Boolean = True
  Private mIsListEnabled As Boolean = True
  Private mIsDetailEnabled As Boolean = False
  Private mSelectedListIndex As Integer = -1
  Private mMessage As String = String.Empty

  Private mDataCollection As ObservableCollection(Of Product)
  Private mDetailData As Product
#End Region

#Region "UI Properties"
  Public Property IsSaveEnabled() As Boolean
    Get
      Return mIsSaveEnabled
    End Get
    Set(value As Boolean)
      If mIsSaveEnabled <> value Then
        mIsSaveEnabled = value
        RaisePropertyChanged("IsSaveEnabled")
      End If
    End Set
  End Property

  Public Property IsCancelEnabled() As Boolean
    Get
      Return mIsCancelEnabled
    End Get
    Set(value As Boolean)
      If mIsCancelEnabled <> value Then
        mIsCancelEnabled = value
        RaisePropertyChanged("IsCancelEnabled")
      End If
    End Set
  End Property

  Public Property IsAddEnabled() As Boolean
    Get
      Return mIsAddEnabled
    End Get
    Set(value As Boolean)
      If mIsAddEnabled <> value Then
        mIsAddEnabled = value
        RaisePropertyChanged("IsAddEnabled")
      End If
    End Set
  End Property

  Public Property IsListEnabled() As Boolean
    Get
      Return mIsListEnabled
    End Get
    Set(value As Boolean)
      If mIsListEnabled <> value Then
        mIsListEnabled = value
        RaisePropertyChanged("IsListEnabled")
      End If
    End Set
  End Property

  Public Property SelectedListIndex() As Integer
    Get
      Return mSelectedListIndex
    End Get
    Set(value As Integer)
      If mSelectedListIndex <> value Then
        mSelectedListIndex = value
        RaisePropertyChanged("SelectedListIndex")
      End If
    End Set
  End Property

  Public Property IsDetailEnabled() As Boolean
    Get
      Return mIsDetailEnabled
    End Get
    Set(value As Boolean)
      If mIsDetailEnabled <> value Then
        mIsDetailEnabled = value
        RaisePropertyChanged("IsDetailEnabled")
      End If
    End Set
  End Property

  Public Property IsAddMode() As Boolean
    Get
      Return mIsAddMode
    End Get
    Set(value As Boolean)
      If mIsAddMode <> value Then
        mIsAddMode = value
        RaisePropertyChanged("IsAddMode")
      End If
    End Set
  End Property

  Public Property Message() As String
    Get
      Return mMessage
    End Get
    Set(value As String)
      If mMessage <> value Then
        mMessage = value
        RaisePropertyChanged("Message")
      End If
    End Set
  End Property
#End Region

#Region "DataCollection Property"
  Public Property DataCollection() As ObservableCollection(Of Product)
    Get
      Return mDataCollection
    End Get
    Set(value As ObservableCollection(Of Product))
      mDataCollection = value
      RaisePropertyChanged("DataCollection")
    End Set
  End Property
#End Region

#Region "DetailData Property"
  Public Property DetailData() As Product
    Get
      Return mDetailData
    End Get
    Set(value As Product)
      mDetailData = value
      RaisePropertyChanged("DetailData")
    End Set
  End Property
#End Region

#Region "SetNormalUIDisplay Method"
  Public Sub SetNormalUIDisplay()
    IsAddMode = False
    IsAddEnabled = True
    IsSaveEnabled = False
    IsCancelEnabled = False
    IsListEnabled = True
    IsDetailEnabled = False
  End Sub
#End Region

#Region "SetEditUIDisplay Method"
  Public Sub SetEditUIDisplay()
    IsAddEnabled = False
    IsSaveEnabled = True
    IsCancelEnabled = True
    IsListEnabled = False
    IsDetailEnabled = True
    Message = String.Empty
  End Sub
#End Region

#Region "LoadAll Method"
  Public Sub LoadAll()
    Try
      Dim mgr As New ProductManager()
      
      DataCollection = New ObservableCollection(Of Product)(mgr.GetProducts())
      SelectedListIndex = 0

    Catch
      ' Ignore exception in design time
    End Try
  End Sub
#End Region

#Region "AddRecord Method"
  Public Sub AddRecord()
    SetEditUIDisplay()
    IsAddMode = True

    ' Create Empty Object for UI to Display
    DetailData = New Product()
    DetailData.IntroductionDate = DateTime.Now
    DetailData.IsDiscontinued = False
  End Sub
#End Region

#Region "CancelEdit Method"
  Public Sub CancelEdit()
    SetNormalUIDisplay()

    IsAddMode = False
    Message = String.Empty

    ' TODO: Write Code to Undo Here
  End Sub
#End Region

#Region "SaveData Method"
  Public Sub SaveData()
    If IsAddMode Then
      InsertData()
    Else
      UpdateData()
    End If

    SetNormalUIDisplay()
  End Sub
#End Region

#Region "Insert Data"
  Public Sub InsertData()
    Dim mgr As New ProductManager()
    Dim resp As ProductResponse

    ' Insert Product
    resp = mgr.Insert(DetailData)
    If resp.Status = OperationResult.Exception Then
      Message = resp.ErrorMessage
    Else
      DataCollection.Add(DetailData)
      Message = "Insert Successful"
    End If
  End Sub
#End Region

#Region "Update Data"
  Public Sub UpdateData()
    Dim mgr As New ProductManager()
    Dim resp As ProductResponse

    ' Update Product
    resp = mgr.Update(DetailData)
    If resp.Status = OperationResult.Exception Then
      Message = resp.ErrorMessage
    Else
      Message = "Update Successful"
    End If
  End Sub
#End Region
End Class