﻿Imports System.Collections.ObjectModel

Public Class ProductViewModel
  Inherits ViewModelAddEditDeleteBase

  Public Sub New()
    LoadAll()
  End Sub

#Region "Private UI Variables"
  Private _DataCollection As ObservableCollection(Of Product)
  Private _DetailData As Product
#End Region

#Region "DataCollection Property"
  Public Property DataCollection() As ObservableCollection(Of Product)
    Get
      Return _DataCollection
    End Get
    Set(value As ObservableCollection(Of Product))
      _DataCollection = value
      RaisePropertyChanged("DataCollection")
    End Set
  End Property
#End Region

#Region "DetailData Property"
  Public Property DetailData() As Product
    Get
      Return _DetailData
    End Get
    Set(value As Product)
      _DetailData = value
      RaisePropertyChanged("DetailData")
    End Set
  End Property
#End Region

#Region "LoadAll Method"
  Public Sub LoadAll()
    Try
      Dim mgr As New ProductManager()

      DataCollection = New ObservableCollection(Of Product)(mgr.GetProducts())
      SelectedListIndex = 0

    Catch
      ' Ignore exception in design time
    End Try
  End Sub
#End Region

#Region "AddRecord Method"
  Public Sub AddRecord()
    SetEditUIDisplay()
    IsAddMode = True

    ' Create Empty Object for UI to Display
    DetailData = New Product()
    DetailData.IntroductionDate = DateTime.Now
    DetailData.IsDiscontinued = False
  End Sub
#End Region

#Region "CancelEdit Method"
  Public Sub CancelEdit()
    SetNormalUIDisplay()

    IsAddMode = False
    Message = String.Empty

    ' TODO: Write Code to Undo Here
  End Sub
#End Region

#Region "SaveData Method"
  Public Sub SaveData()
    If IsAddMode Then
      InsertData()
    Else
      UpdateData()
    End If

    SetNormalUIDisplay()
  End Sub
#End Region

#Region "Insert Data"
  Public Sub InsertData()
    Dim mgr As New ProductManager()
    Dim resp As ProductResponse

    ' Insert Product
    resp = mgr.Insert(DetailData)
    If resp.Status = OperationResult.Exception Then
      Message = resp.ErrorMessage
    Else
      DataCollection.Add(DetailData)
      Message = "Insert Successful"
    End If
  End Sub
#End Region

#Region "Update Data"
  Public Sub UpdateData()
    Dim mgr As New ProductManager()
    Dim resp As ProductResponse

    ' Update Product
    resp = mgr.Update(DetailData)
    If resp.Status = OperationResult.Exception Then
      Message = resp.ErrorMessage
    Else
      Message = "Update Successful"
    End If
  End Sub
#End Region
End Class
