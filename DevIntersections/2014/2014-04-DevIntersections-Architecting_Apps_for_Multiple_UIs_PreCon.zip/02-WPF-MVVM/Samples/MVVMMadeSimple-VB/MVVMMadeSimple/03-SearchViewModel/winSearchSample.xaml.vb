﻿Public Class winSearchSample
  Private mViewModel As SearchViewModel

  Public Sub New()
    ' This call is required by the designer.
    InitializeComponent()

    ' Grab instance of View Model from XAML
    mViewModel = DirectCast(Me.Resources("viewModel"), SearchViewModel)
  End Sub

  Private Sub Button_Click(sender As Object, e As RoutedEventArgs)
    mViewModel.Search()
  End Sub
End Class
