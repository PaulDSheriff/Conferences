﻿Public Class winSimpleBinding

End Class
