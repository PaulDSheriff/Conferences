﻿Public Class winListOnly
  Public Sub New()

    ' This call is required by the designer.
    InitializeComponent()
  End Sub
End Class
