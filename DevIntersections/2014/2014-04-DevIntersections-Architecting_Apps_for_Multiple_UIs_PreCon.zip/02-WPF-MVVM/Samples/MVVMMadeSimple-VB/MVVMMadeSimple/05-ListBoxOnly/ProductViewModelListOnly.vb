﻿Imports System.Collections.ObjectModel

Public Class ProductViewModelListOnly
  Inherits ViewModelBase

  Public Sub New()
    LoadAll()
  End Sub

#Region "DataCollection Property"
  Private mDataCollection As ObservableCollection(Of Product)

  Public Property DataCollection() As ObservableCollection(Of Product)
    Get
      Return mDataCollection
    End Get
    Set(value As ObservableCollection(Of Product))
      mDataCollection = value
      RaisePropertyChanged("DataCollection")
    End Set
  End Property
#End Region

#Region "LoadAll Method"
  Public Sub LoadAll()
    Dim mgr As ProductManager = Nothing

    Try
      mgr = New ProductManager()

      DataCollection = New ObservableCollection(Of Product)(mgr.GetProducts())

    Catch
      ' Create Mock Data
      DataCollection = New ObservableCollection(Of Product)(mgr.CreateMockData())

    End Try
  End Sub
#End Region
End Class