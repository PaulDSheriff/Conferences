﻿Imports System.Configuration

Public Class AppConfig

  Private Shared mInstance As AppConfig = Nothing

  Public Shared Property Instance As AppConfig
    Get
      If mInstance Is Nothing Then
        mInstance = New AppConfig
      End If

      Return mInstance
    End Get
    Set(value As AppConfig)
      mInstance = value
    End Set
  End Property

  Public ReadOnly Property ConnectString() As String
    Get
      Return ConfigurationManager.ConnectionStrings("Sandbox").ConnectionString
    End Get
  End Property
End Class
