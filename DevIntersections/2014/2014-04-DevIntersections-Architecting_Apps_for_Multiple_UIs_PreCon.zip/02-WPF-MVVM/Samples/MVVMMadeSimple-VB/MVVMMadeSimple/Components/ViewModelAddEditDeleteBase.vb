﻿Public Class ViewModelAddEditDeleteBase
  Inherits ViewModelBase

#Region "Private UI Variables"
  Private mIsAddMode As Boolean = False
  Private mIsSaveEnabled As Boolean = False
  Private mIsCancelEnabled As Boolean = False
  Private mIsAddEnabled As Boolean = True
  Private mIsListEnabled As Boolean = True
  Private mIsDetailEnabled As Boolean = False
  Private mSelectedListIndex As Integer = -1
  Private mMessage As String = String.Empty
#End Region

#Region "UI Properties"
  Public Property IsSaveEnabled() As Boolean
    Get
      Return mIsSaveEnabled
    End Get
    Set(value As Boolean)
      If mIsSaveEnabled <> value Then
        mIsSaveEnabled = value
        RaisePropertyChanged("IsSaveEnabled")
      End If
    End Set
  End Property

  Public Property IsCancelEnabled() As Boolean
    Get
      Return mIsCancelEnabled
    End Get
    Set(value As Boolean)
      If mIsCancelEnabled <> value Then
        mIsCancelEnabled = value
        RaisePropertyChanged("IsCancelEnabled")
      End If
    End Set
  End Property

  Public Property IsAddEnabled() As Boolean
    Get
      Return mIsAddEnabled
    End Get
    Set(value As Boolean)
      If mIsAddEnabled <> value Then
        mIsAddEnabled = value
        RaisePropertyChanged("IsAddEnabled")
      End If
    End Set
  End Property

  Public Property IsListEnabled() As Boolean
    Get
      Return mIsListEnabled
    End Get
    Set(value As Boolean)
      If mIsListEnabled <> value Then
        mIsListEnabled = value
        RaisePropertyChanged("IsListEnabled")
      End If
    End Set
  End Property

  Public Property SelectedListIndex() As Integer
    Get
      Return mSelectedListIndex
    End Get
    Set(value As Integer)
      If mSelectedListIndex <> value Then
        mSelectedListIndex = value
        RaisePropertyChanged("SelectedListIndex")
      End If
    End Set
  End Property

  Public Property IsDetailEnabled() As Boolean
    Get
      Return mIsDetailEnabled
    End Get
    Set(value As Boolean)
      If mIsDetailEnabled <> value Then
        mIsDetailEnabled = value
        RaisePropertyChanged("IsDetailEnabled")
      End If
    End Set
  End Property

  Public Property IsAddMode() As Boolean
    Get
      Return mIsAddMode
    End Get
    Set(value As Boolean)
      If mIsAddMode <> value Then
        mIsAddMode = value
        RaisePropertyChanged("IsAddMode")
      End If
    End Set
  End Property

  Public Property Message() As String
    Get
      Return mMessage
    End Get
    Set(value As String)
      If mMessage <> value Then
        mMessage = value
        RaisePropertyChanged("Message")
      End If
    End Set
  End Property
#End Region

#Region "SetNormalUIDisplay Method"
  Public Sub SetNormalUIDisplay()
    IsAddMode = False
    IsAddEnabled = True
    IsSaveEnabled = False
    IsCancelEnabled = False
    IsListEnabled = True
    IsDetailEnabled = False
  End Sub
#End Region

#Region "SetEditUIDisplay Method"
  Public Sub SetEditUIDisplay()
    IsAddEnabled = False
    IsSaveEnabled = True
    IsCancelEnabled = True
    IsListEnabled = False
    IsDetailEnabled = True
    Message = String.Empty
  End Sub
#End Region
End Class