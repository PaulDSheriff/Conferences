﻿Public Class ViewModelBase
  Inherits CommonBase

  Private mMessageToDisplay As String = String.Empty
  Private mIsMessageVisible As Boolean = False

  Public Property MessageToDisplay() As String
    Get
      Return mMessageToDisplay
    End Get
    Set(value As String)
      mMessageToDisplay = value
      RaisePropertyChanged("MessageToDisplay")
    End Set
  End Property

  Public Property IsMessageVisible() As Boolean
    Get
      Return mIsMessageVisible
    End Get
    Set(value As Boolean)
      mIsMessageVisible = value
      RaisePropertyChanged("IsMessageVisible")
    End Set
  End Property
End Class