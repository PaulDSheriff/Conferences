﻿Public Class DataClassBase
  Inherits CommonBase

  Public Sub New()
    mBusinessRuleFailures = New BusinessRuleMessages()
  End Sub

  Private mBusinessRuleFailures As BusinessRuleMessages

  Public Property BusinessRuleFailures() As BusinessRuleMessages
    Get
      Return mBusinessRuleFailures
    End Get
    Set(value As BusinessRuleMessages)
      mBusinessRuleFailures = value
      RaisePropertyChanged("BusinessRuleFailures")
    End Set
  End Property
End Class
