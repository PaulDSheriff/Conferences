﻿Public Class Product
  Inherits CommonBase

  Private mProductName As String = String.Empty
  Private mIsDiscontinued As Boolean = False
  Private mIntroductionDate As DateTime = DateTime.Now
  Private mProductId As Integer = 0
  Private mCost As Decimal = 0
  Private mPrice As Decimal = 0

  ''' <summary>
  ''' Get/Set ProductName
  ''' </summary>
  Public Property ProductName() As String
    Get
      Return mProductName
    End Get
    Set(ByVal Value As String)
      If mProductName <> Value Then
        mProductName = Value
        RaisePropertyChanged("ProductName")
      End If
    End Set
  End Property

  ''' <summary>
  ''' Get/Set IsDiscontinued
  ''' </summary>
  Public Property IsDiscontinued() As Boolean
    Get
      Return mIsDiscontinued
    End Get
    Set(ByVal Value As Boolean)
      If mIsDiscontinued <> Value Then
        mIsDiscontinued = Value
        RaisePropertyChanged("IsDiscontinued")
      End If
    End Set
  End Property

  ''' <summary>
  ''' Get/Set IntroductionDate
  ''' </summary>
  Public Property IntroductionDate() As DateTime
    Get
      Return mIntroductionDate
    End Get
    Set(ByVal Value As DateTime)
      If mIntroductionDate <> Value Then
        mIntroductionDate = Value
        RaisePropertyChanged("IntroductionDate")
      End If
    End Set
  End Property

  ''' <summary>
  ''' Get/Set ProductId
  ''' </summary>
  Public Property ProductId() As Integer
    Get
      Return mProductId
    End Get
    Set(ByVal Value As Integer)
      If mProductId <> Value Then
        mProductId = Value
        RaisePropertyChanged("ProductId")
      End If
    End Set
  End Property

  ''' <summary>
  ''' Get/Set Cost
  ''' </summary>
  Public Property Cost() As Decimal
    Get
      Return mCost
    End Get
    Set(ByVal Value As Decimal)
      If mCost <> Value Then
        mCost = Value
        RaisePropertyChanged("Cost")
      End If
    End Set
  End Property

  ''' <summary>
  ''' Get/Set Price
  ''' </summary>
  Public Property Price() As Decimal
    Get
      Return mPrice
    End Get
    Set(ByVal Value As Decimal)
      If mPrice <> Value Then
        mPrice = Value
        RaisePropertyChanged("Price")
      End If
    End Set
  End Property
End Class
