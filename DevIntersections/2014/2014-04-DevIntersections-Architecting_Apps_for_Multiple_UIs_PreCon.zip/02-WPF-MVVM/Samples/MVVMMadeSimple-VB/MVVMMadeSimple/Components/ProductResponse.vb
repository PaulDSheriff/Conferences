﻿Public Class ProductResponse
  Inherits ResponseBase

  Private mDetailData As Product
  Private mDataCollection As List(Of Product)

  Public Property DetailData() As Product
    Get
      Return mDetailData
    End Get
    Set(value As Product)
      mDetailData = value
    End Set
  End Property

  Public Property DataCollection() As List(Of Product)
    Get
      Return mDataCollection
    End Get
    Set(value As List(Of Product))
      mDataCollection = value
    End Set
  End Property
End Class