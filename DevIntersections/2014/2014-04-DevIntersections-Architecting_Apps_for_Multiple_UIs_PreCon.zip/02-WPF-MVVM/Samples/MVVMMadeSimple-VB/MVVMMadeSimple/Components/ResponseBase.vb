﻿Public Enum OperationResult
  Unknown
  Success
  Exception
  Failure
End Enum

Public Class ResponseBase
  Public Sub New()
    Status = OperationResult.Unknown
    FriendlyErrorMessage = String.Empty
    ErrorMessage = String.Empty
  End Sub

  Private mStatus As OperationResult
  Private mFriendlyErrorMessage As String
  Private mErrorMessage As String

  Public Property Status() As OperationResult
    Get
      Return mStatus
    End Get
    Set(value As OperationResult)
      mStatus = value
    End Set
  End Property

  Public Property FriendlyErrorMessage() As String
    Get
      Return mFriendlyErrorMessage
    End Get
    Set(value As String)
      mFriendlyErrorMessage = value
    End Set
  End Property

  Public Property ErrorMessage() As String
    Get
      Return mErrorMessage
    End Get
    Set(value As String)
      mErrorMessage = value
    End Set
  End Property
End Class
