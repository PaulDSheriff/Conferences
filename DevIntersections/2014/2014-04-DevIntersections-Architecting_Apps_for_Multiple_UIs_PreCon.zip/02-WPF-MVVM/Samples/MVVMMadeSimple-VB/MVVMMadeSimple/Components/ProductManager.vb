﻿Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Data

Public Class ProductManager
  Public Function GetProducts() As List(Of Product)
    Dim cmd As SqlCommand = Nothing
    Dim ret As New List(Of Product)()
    Dim entity As Product = Nothing

    cmd = New SqlCommand("SELECT * FROM Product")
    Using cnn As SqlConnection = New SqlConnection(AppConfig.Instance.ConnectString)
      cmd.Connection = cnn
      cmd.Connection.Open()
      Using rdr As SqlDataReader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While rdr.Read()
          entity = New Product()

          entity.ProductId = Convert.ToInt32(rdr("ProductId"))
          entity.ProductName = rdr("ProductName").ToString()
          entity.IntroductionDate = Convert.ToDateTime(rdr("IntroductionDate"))
          entity.Cost = Convert.ToDecimal(rdr("Cost"))
          entity.Price = Convert.ToDecimal(rdr("Price"))
          entity.IsDiscontinued = Convert.ToBoolean(rdr("IsDiscontinued"))

          ret.Add(entity)
        End While
      End Using
    End Using

    Return ret
  End Function

  Public Function CreateMockData() As List(Of Product)
    Dim ret As New List(Of Product)()
    Dim entity As Product

    entity = New Product()
    entity.ProductId = 1
    entity.ProductName = "Product 1 - MOCK"
    entity.IntroductionDate = DateTime.Now
    entity.Cost = 100
    entity.Price = 200
    entity.IsDiscontinued = False
    ret.Add(entity)

    entity = New Product()
    entity.ProductId = 2
    entity.ProductName = "Product 2 - MOCK"
    entity.IntroductionDate = DateTime.Now.AddDays(-1)
    entity.Cost = 200
    entity.Price = 400
    entity.IsDiscontinued = False
    ret.Add(entity)

    entity = New Product()
    entity.ProductId = 3
    entity.ProductName = "Product 3 - MOCK"
    entity.IntroductionDate = DateTime.Now
    entity.Cost = 300
    entity.Price = 600
    entity.IsDiscontinued = False
    ret.Add(entity)

    Return ret
  End Function

#Region "Update Method"
  Public Function Update(prod As Product) As ProductResponse
    Dim sql As String = String.Empty
    Dim cmd As SqlCommand = Nothing
    Dim cnn As SqlConnection = Nothing
    Dim parm As SqlParameter = Nothing
    Dim ret As New ProductResponse()

    ret.Status = OperationResult.Unknown
    sql = "UPDATE Product "
    sql += " SET "
    sql += " ProductName = @ProductName, "
    sql += " IntroductionDate = @IntroductionDate, "
    sql += " Cost = @Cost, "
    sql += " Price = @Price, "
    sql += " IsDiscontinued = @IsDiscontinued "
    sql += " WHERE ProductId = @ProductId "
    Try
      cnn = New SqlConnection(AppConfig.Instance.ConnectString)
      cmd = New SqlCommand(sql, cnn)
      parm = New SqlParameter("@ProductName", prod.ProductName)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@IntroductionDate", prod.IntroductionDate)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@Cost", prod.Cost)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@Price", prod.Price)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@IsDiscontinued", prod.IsDiscontinued)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@ProductId", prod.ProductId)
      cmd.Parameters.Add(parm)

      cnn.Open()

      cmd.ExecuteNonQuery()
      ret.Status = OperationResult.Success
      ret.FriendlyErrorMessage = "Update was Successful"
    Catch ex As Exception
      ' Publish exception here
      ret.Status = OperationResult.Exception
      ret.ErrorMessage = ex.Message
      ret.FriendlyErrorMessage = "The Update to the Product Table did not Work."
    Finally
      If cnn IsNot Nothing And cnn.State = ConnectionState.Open Then
        cnn.Close()
      End If
    End Try

    Return ret
  End Function
#End Region

#Region "Insert Method"
  Public Function Insert(prod As Product) As ProductResponse
    Dim sql As String = String.Empty
    Dim cmd As SqlCommand = Nothing
    Dim cnn As SqlConnection = Nothing
    Dim parm As SqlParameter = Nothing
    Dim ret As New ProductResponse()

    ret.Status = OperationResult.Unknown
    sql = "INSERT INTO Product(ProductName, "
    sql += " IntroductionDate, Cost, Price, IsDiscontinued)"
    sql += " VALUES(@ProductName, @IntroductionDate, "
    sql += " @Cost, @Price, @IsDiscontinued)"
    Try
      cnn = New SqlConnection(AppConfig.Instance.ConnectString)
      cmd = New SqlCommand(sql, cnn)
      parm = New SqlParameter("@ProductName", prod.ProductName)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@IntroductionDate", prod.IntroductionDate)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@Cost", prod.Cost)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@Price", prod.Price)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@IsDiscontinued", prod.IsDiscontinued)
      cmd.Parameters.Add(parm)

      cnn.Open()

      cmd.ExecuteNonQuery()

      ' Retrieve Product ID
      cmd.Parameters.Clear()
      cmd.CommandText = "SELECT @@IDENTITY"
      prod.ProductId = Convert.ToInt32(cmd.ExecuteScalar())

      ret.Status = OperationResult.Success
      ret.FriendlyErrorMessage = "Insert was Successful"
      ' Return entity class so the IDENTITY value can be retrieved
      ret.DetailData = prod
    Catch ex As Exception
      ' Publish exception here
      ret.Status = OperationResult.Exception
      ret.ErrorMessage = ex.Message
      ret.FriendlyErrorMessage = "The Insert to the Product Table did not Work."
    Finally
      If cnn IsNot Nothing And cnn.State = ConnectionState.Open Then
        cnn.Close()
      End If
    End Try

    Return ret
  End Function
#End Region

#Region "Delete Method"
  Public Function Delete(productId As Integer) As ProductResponse
    Dim sql As String = String.Empty
    Dim cmd As SqlCommand = Nothing
    Dim cnn As SqlConnection = Nothing
    Dim parm As SqlParameter = Nothing
    Dim ret As New ProductResponse()

    ret.Status = OperationResult.Unknown
    sql = "DELETE FROM Product "
    sql += " WHERE ProductId = @ProductId "
    Try
      cnn = New SqlConnection(AppConfig.Instance.ConnectString)
      cmd = New SqlCommand(sql, cnn)
      parm = New SqlParameter("@ProductId", productId)
      cmd.Parameters.Add(parm)

      cnn.Open()

      cmd.ExecuteNonQuery()
      ret.Status = OperationResult.Success
      ret.FriendlyErrorMessage = "Delete was Successful"
    Catch ex As Exception
      ' Publish exception here
      ret.Status = OperationResult.Exception
      ret.ErrorMessage = ex.Message
      ret.FriendlyErrorMessage = "The Delete to the Product Table did not Work."
    Finally
      If cnn IsNot Nothing And cnn.State = ConnectionState.Open Then
        cnn.Close()
      End If
    End Try

    Return ret
  End Function
#End Region

End Class
