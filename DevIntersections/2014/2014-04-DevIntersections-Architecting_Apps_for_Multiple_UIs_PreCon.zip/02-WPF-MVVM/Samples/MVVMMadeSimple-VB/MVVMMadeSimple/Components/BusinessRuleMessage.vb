﻿Public Class BusinessRuleMessage
#Region "Constructors"
  Public Sub New()
  End Sub

  Public Sub New(name As String, msg As String)
    PropertyName = name
    Message = msg
  End Sub
#End Region

#Region "Private Properties"
  Private mPropertyName As String
  Private mMessage As String
#End Region

#Region "Public Properties"
  Public Property PropertyName() As String
    Get
      Return mPropertyName
    End Get
    Set(value As String)
      mPropertyName = Value
    End Set
  End Property

  Public Property Message() As String
    Get
      Return mMessage
    End Get
    Set(value As String)
      mMessage = value
    End Set
  End Property
#End Region
End Class