﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Library;

namespace MVVMMadeSimple
{
  public class SimpleBindingViewModel : CommonBase
  {
    private bool mIsBenefitsChecked = true;
    private bool mIs401kEnabled = true;
    private bool mIsHealthCareEnabled = true;

    public bool IsBenefitsChecked
    {
      get { return mIsBenefitsChecked; }
      set
      {
        if (mIsBenefitsChecked != value)
        {
          mIsBenefitsChecked = value;
          Is401kEnabled = value;
          IsHealthCareEnabled = value;
          RaisePropertyChanged("IsBenefitsChecked");
        }
      }
    }

    public bool Is401kEnabled
    {
      get { return mIs401kEnabled; }
      set
      {
        if (mIs401kEnabled != value)
        {
          mIs401kEnabled = value;
          RaisePropertyChanged("Is401kEnabled");
        }
      }
    }

    public bool IsHealthCareEnabled
    {
      get { return mIsHealthCareEnabled; }
      set
      {
        if (mIsHealthCareEnabled != value)
        {
          mIsHealthCareEnabled = value;
          RaisePropertyChanged("IsHealthCareEnabled");
        }
      }
    }
  }
}
