﻿To run this sample you will have to create a Product table using the Product.sql file
