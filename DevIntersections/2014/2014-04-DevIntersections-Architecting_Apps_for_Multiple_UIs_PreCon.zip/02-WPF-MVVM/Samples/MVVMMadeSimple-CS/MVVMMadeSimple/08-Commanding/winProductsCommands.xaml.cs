﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MVVMMadeSimple
{
  public partial class winProductsCommands : Window
  {
    public winProductsCommands()
    {
      InitializeComponent();

      _ViewModel = (ProductViewModelCommand)this.Resources["viewModel"];
    }

    ProductViewModelCommand _ViewModel = null;
    #region Loaded Event
    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      // Load Products
      _ViewModel.LoadAll();
    }
    #endregion

    #region Edit Click Event
    private void btnEdit_Click(object sender, RoutedEventArgs e)
    {
      // Get Data Context from Button
      // So you can update the List Box SelectedValue
      _ViewModel.DetailData = (Product)((Button)sender).DataContext;
      _ViewModel.SetEditUIDisplay();
    }
    #endregion
  }
}
