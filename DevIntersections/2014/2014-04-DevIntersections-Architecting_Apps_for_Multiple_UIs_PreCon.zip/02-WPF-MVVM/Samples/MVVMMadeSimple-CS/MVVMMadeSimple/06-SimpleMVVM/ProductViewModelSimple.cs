﻿using System;
using System.Collections.ObjectModel;
using Common.Library;

namespace MVVMMadeSimple
{
  public class ProductViewModelSimple : ViewModelBase
  {
    #region "Constructor"
    public ProductViewModelSimple()
    {
      LoadAll();
    }
    #endregion

    #region "Private UI Variables"
    private bool mIsAddMode = false;
    private bool mIsSaveEnabled = false;
    private bool mIsCancelEnabled = false;
    private bool mIsAddEnabled = true;
    private bool mIsListEnabled = true;
    private bool mIsDetailEnabled = false;
    private int mSelectedListIndex = -1;

    private string mMessage = string.Empty;
    private ObservableCollection<Product> mDataCollection;
    #endregion
    private Product mDetailData;

    #region "UI Properties"
    public bool IsSaveEnabled
    {
      get { return mIsSaveEnabled; }
      set
      {
        if (mIsSaveEnabled != value)
        {
          mIsSaveEnabled = value;
          RaisePropertyChanged("IsSaveEnabled");
        }
      }
    }

    public bool IsCancelEnabled
    {
      get { return mIsCancelEnabled; }
      set
      {
        if (mIsCancelEnabled != value)
        {
          mIsCancelEnabled = value;
          RaisePropertyChanged("IsCancelEnabled");
        }
      }
    }

    public bool IsAddEnabled
    {
      get { return mIsAddEnabled; }
      set
      {
        if (mIsAddEnabled != value)
        {
          mIsAddEnabled = value;
          RaisePropertyChanged("IsAddEnabled");
        }
      }
    }

    public bool IsListEnabled
    {
      get { return mIsListEnabled; }
      set
      {
        if (mIsListEnabled != value)
        {
          mIsListEnabled = value;
          RaisePropertyChanged("IsListEnabled");
        }
      }
    }

    public int SelectedListIndex
    {
      get { return mSelectedListIndex; }
      set
      {
        if (mSelectedListIndex != value)
        {
          mSelectedListIndex = value;
          RaisePropertyChanged("SelectedListIndex");
        }
      }
    }

    public bool IsDetailEnabled
    {
      get { return mIsDetailEnabled; }
      set
      {
        if (mIsDetailEnabled != value)
        {
          mIsDetailEnabled = value;
          RaisePropertyChanged("IsDetailEnabled");
        }
      }
    }

    public bool IsAddMode
    {
      get { return mIsAddMode; }
      set
      {
        if (mIsAddMode != value)
        {
          mIsAddMode = value;
          RaisePropertyChanged("IsAddMode");
        }
      }
    }

    public string Message
    {
      get { return mMessage; }
      set
      {
        if (mMessage != value)
        {
          mMessage = value;
          RaisePropertyChanged("Message");
        }
      }
    }
    #endregion

    #region "DataCollection Property"
    public ObservableCollection<Product> DataCollection
    {
      get { return mDataCollection; }
      set
      {
        mDataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region "DetailData Property"
    public Product DetailData
    {
      get { return mDetailData; }
      set
      {
        mDetailData = value;
        RaisePropertyChanged("DetailData");
      }
    }
    #endregion

    #region "SetNormalUIDisplay Method"
    public void SetNormalUIDisplay()
    {
      IsAddMode = false;
      IsAddEnabled = true;
      IsSaveEnabled = false;
      IsCancelEnabled = false;
      IsListEnabled = true;
      IsDetailEnabled = false;
    }
    #endregion

    #region "SetEditUIDisplay Method"
    public void SetEditUIDisplay()
    {
      IsAddEnabled = false;
      IsSaveEnabled = true;
      IsCancelEnabled = true;
      IsListEnabled = false;
      IsDetailEnabled = true;
      Message = string.Empty;
    }
    #endregion

    #region "LoadAll Method"
    public void LoadAll()
    {
      try
      {
        ProductManager mgr = new ProductManager();

        DataCollection = new ObservableCollection<Product>(mgr.GetProducts());
        SelectedListIndex = 0;

      }
      catch
      {
        // Ignore exception in design time
      }
    }
    #endregion

    #region "AddRecord Method"
    public void AddRecord()
    {
      SetEditUIDisplay();
      IsAddMode = true;

      // Create Empty Object for UI to Display
      DetailData = new Product();
      DetailData.IntroductionDate = DateTime.Now;
      DetailData.IsDiscontinued = false;
    }
    #endregion

    #region "CancelEdit Method"
    public void CancelEdit()
    {
      SetNormalUIDisplay();

      IsAddMode = false;
      Message = string.Empty;

      // TODO: Write Code to Undo Here
    }
    #endregion

    #region "SaveData Method"
    public void SaveData()
    {
      if (IsAddMode)
      {
        InsertData();
      }
      else
      {
        UpdateData();
      }

      SetNormalUIDisplay();
    }
    #endregion

    #region "Insert Data"
    public void InsertData()
    {
      ProductManager mgr = new ProductManager();
      ProductResponse resp = default(ProductResponse);

      // Insert Product
      resp = mgr.Insert(DetailData);
      if (resp.Status == OperationResult.Exception)
      {
        Message = resp.ErrorMessage;
      }
      else
      {
        DataCollection.Add(DetailData);
        Message = "Insert Successful";
      }
    }
    #endregion

    #region "Update Data"
    public void UpdateData()
    {
      ProductManager mgr = new ProductManager();
      ProductResponse resp = default(ProductResponse);

      // Update Product
      resp = mgr.Update(DetailData);
      if (resp.Status == OperationResult.Exception)
      {
        Message = resp.ErrorMessage;
      }
      else
      {
        Message = "Update Successful";
      }
    }
    #endregion
  }
}
