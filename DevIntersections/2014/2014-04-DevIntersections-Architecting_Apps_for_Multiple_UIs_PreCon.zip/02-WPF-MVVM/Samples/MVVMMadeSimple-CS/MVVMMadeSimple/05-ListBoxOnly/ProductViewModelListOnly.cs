﻿using System.Collections.ObjectModel;
using Common.Library;

namespace MVVMMadeSimple
{
  public class ProductViewModelListOnly : ViewModelBase
  {
    public ProductViewModelListOnly()
    {
      LoadAll();
    }

    #region DataCollection Property
    private ObservableCollection<Product> _DataCollection;

    public ObservableCollection<Product> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region LoadAll Method
    public void LoadAll()
    {
      ProductManager mgr = null;

      try
      {
        mgr = new ProductManager();
                
        DataCollection = new ObservableCollection<Product>(mgr.GetProducts());
      }
      catch
      {
        // Create Mock Data
        DataCollection = new ObservableCollection<Product>(mgr.CreateMockData());
      }
    }
    #endregion
  }
}
