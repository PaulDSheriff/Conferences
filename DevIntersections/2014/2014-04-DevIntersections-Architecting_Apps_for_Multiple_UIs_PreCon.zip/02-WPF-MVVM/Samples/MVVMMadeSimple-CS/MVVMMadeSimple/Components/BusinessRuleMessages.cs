﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Common.Library
{
  public class BusinessRuleMessages : List<BusinessRuleMessage>
  {
    #region ToString method
    public override string ToString()
    {
      StringBuilder sb = new StringBuilder(1024);

      foreach (BusinessRuleMessage item in this)
      {
        sb.Append(item.Message + Environment.NewLine);
      }

      return sb.ToString();
    }
    #endregion
  }
}
