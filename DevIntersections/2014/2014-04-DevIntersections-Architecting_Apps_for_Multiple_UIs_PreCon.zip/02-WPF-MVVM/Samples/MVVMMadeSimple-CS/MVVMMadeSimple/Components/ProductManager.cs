﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;

namespace MVVMMadeSimple
{
  public class ProductManager
  {
    #region GetProducts Method
    public List<Product> GetProducts()
    {
      List<Product> ret = new List<Product>();
      string sql = string.Empty;
      SqlCommand cmd = null;
      SqlConnection cnn = null;
      SqlDataAdapter da = null;
      DataSet ds = new DataSet();

      sql = "SELECT * ";
      sql += " FROM Product ";
      sql += " ORDER BY ProductName ";
      try
      {
        cnn = new SqlConnection(AppConfig.Instance.ConnectString);
        cmd = new SqlCommand(sql, cnn);
        cnn.Open();

        da = new SqlDataAdapter(cmd);

        da.Fill(ds);
                
        if (ds.Tables.Count > 0)
        {
          if (ds.Tables[0].Rows.Count > 0)
          {
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
              Product prod = new Product();

              prod.ProductId = Convert.ToInt32(dr["ProductId"]);
              prod.ProductName = Convert.ToString(dr["ProductName"]);
              prod.IntroductionDate = Convert.ToDateTime(dr["IntroductionDate"]);
              prod.Cost = Convert.ToDecimal(dr["Cost"]);
              prod.Price = Convert.ToDecimal(dr["Price"]);
              prod.IsDiscontinued = Convert.ToBoolean(dr["IsDiscontinued"]);

              ret.Add(prod);
            }
          }
          else
          {
            // Put some error handling here
          }
        }
      }
      catch (Exception ex)
      {
        // Put some error handling here
      }
      finally
      {
        if (cnn != null &
             cnn.State == ConnectionState.Open)
          cnn.Close();
      }

      return ret;
    }
    #endregion

    #region CreateMockData Method
    public List<Product> CreateMockData()
    {
      List<Product> ret = new List<Product>();
      Product entity = default(Product);

      entity = new Product();
      entity.ProductId = 1;
      entity.ProductName = "Product 1 - MOCK";
      entity.IntroductionDate = DateTime.Now;
      entity.Cost = 100;
      entity.Price = 200;
      entity.IsDiscontinued = false;
      ret.Add(entity);

      entity = new Product();
      entity.ProductId = 2;
      entity.ProductName = "Product 2 - MOCK";
      entity.IntroductionDate = DateTime.Now.AddDays(-1);
      entity.Cost = 200;
      entity.Price = 400;
      entity.IsDiscontinued = false;
      ret.Add(entity);

      entity = new Product();
      entity.ProductId = 3;
      entity.ProductName = "Product 3 - MOCK";
      entity.IntroductionDate = DateTime.Now;
      entity.Cost = 300;
      entity.Price = 600;
      entity.IsDiscontinued = false;
      ret.Add(entity);

      return ret;
    }
    #endregion
    
    #region Update Method
    public ProductResponse Update(Product prod)
    {
      string sql = string.Empty;
      SqlCommand cmd = null;
      SqlConnection cnn = null;
      SqlParameter parm = null;
      ProductResponse ret = new ProductResponse();

      ret.Status = OperationResult.Unknown;
      sql = "UPDATE Product ";
      sql += " SET ";
      sql += " ProductName = @ProductName, ";
      sql += " IntroductionDate = @IntroductionDate, ";
      sql += " Cost = @Cost, ";
      sql += " Price = @Price, ";
      sql += " IsDiscontinued = @IsDiscontinued ";
      sql += " WHERE ProductId = @ProductId ";
      try
      {
        cnn = new SqlConnection(AppConfig.Instance.ConnectString);
        cmd = new SqlCommand(sql, cnn);
        parm = new SqlParameter("@ProductName",
          prod.ProductName);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@IntroductionDate",
          prod.IntroductionDate);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@Cost",
          prod.Cost);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@Price",
          prod.Price);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@IsDiscontinued",
          prod.IsDiscontinued);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@ProductId",
          prod.ProductId);
        cmd.Parameters.Add(parm);

        cnn.Open();

        cmd.ExecuteNonQuery();
        ret.Status = OperationResult.Success;
        ret.FriendlyErrorMessage = "Update was Successful";
      }
      catch (Exception ex)
      {
        // Publish exception here
        ret.Status = OperationResult.Exception;
        ret.ErrorMessage = ex.Message;
        ret.FriendlyErrorMessage = "The Update to the Product Table did not Work.";
      }
      finally
      {
        if (cnn != null &
             cnn.State == ConnectionState.Open)
          cnn.Close();
      }

      return ret;
    }
    #endregion

    #region Insert Method
    public ProductResponse Insert(Product prod)
    {
      string sql = string.Empty;
      SqlCommand cmd = null;
      SqlConnection cnn = null;
      SqlParameter parm = null;
      ProductResponse ret = new ProductResponse();

      ret.Status = OperationResult.Unknown;
      sql = "INSERT INTO Product(ProductName, ";
      sql += " IntroductionDate, Cost, Price, IsDiscontinued)";
      sql += " VALUES(@ProductName, @IntroductionDate, ";
      sql += " @Cost, @Price, @IsDiscontinued)";
      try
      {
        cnn = new SqlConnection(AppConfig.Instance.ConnectString);
        cmd = new SqlCommand(sql, cnn);
        parm = new SqlParameter("@ProductName",
          prod.ProductName);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@IntroductionDate",
          prod.IntroductionDate);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@Cost",
          prod.Cost);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@Price",
          prod.Price);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@IsDiscontinued",
          prod.IsDiscontinued);
        cmd.Parameters.Add(parm);

        cnn.Open();

        cmd.ExecuteNonQuery();

        // Retrieve Product ID
        cmd.Parameters.Clear();
        cmd.CommandText = "SELECT @@IDENTITY";
        prod.ProductId = Convert.ToInt32(cmd.ExecuteScalar());

        ret.Status = OperationResult.Success;
        ret.FriendlyErrorMessage = "Insert was Successful";
        // Return entity class so the IDENTITY value can be retrieved
        ret.DetailData = prod;
      }
      catch (Exception ex)
      {
        // Publish exception here
        ret.Status = OperationResult.Exception;
        ret.ErrorMessage = ex.Message;
        ret.FriendlyErrorMessage = "The Insert to the Product Table did not Work.";
      }
      finally
      {
        if (cnn != null &
             cnn.State == ConnectionState.Open)
          cnn.Close();
      }

      return ret;
    }
    #endregion

    #region Delete Method
    public ProductResponse Delete(int productId)
    {
      string sql = string.Empty;
      SqlCommand cmd = null;
      SqlConnection cnn = null;
      SqlParameter parm = null;
      ProductResponse ret = new ProductResponse();

      ret.Status = OperationResult.Unknown;
      sql = "DELETE FROM Product ";
      sql += " WHERE ProductId = @ProductId ";
      try
      {
        cnn = new SqlConnection(AppConfig.Instance.ConnectString);
        cmd = new SqlCommand(sql, cnn);
        parm = new SqlParameter("@ProductId",
          productId);
        cmd.Parameters.Add(parm);

        cnn.Open();

        cmd.ExecuteNonQuery();
        ret.Status = OperationResult.Success;
        ret.FriendlyErrorMessage = "Delete was Successful";
      }
      catch (Exception ex)
      {
        // Publish exception here
        ret.Status = OperationResult.Exception;
        ret.ErrorMessage = ex.Message;
        ret.FriendlyErrorMessage = "The Delete to the Product Table did not Work.";
      }
      finally
      {
        if (cnn != null &
             cnn.State == ConnectionState.Open)
          cnn.Close();
      }

      return ret;
    }
    #endregion
  }
}
