﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVMMadeSimple
{
  public class AppConfig
  {
    private static AppConfig mInstance = null;
    public static AppConfig Instance
    {
      get
      {
        if (mInstance == null)
        {
          mInstance = new AppConfig();
        }

        return mInstance;
      }
      set { mInstance = value; }
    }

    public string ConnectString
    {
      get { return ConfigurationManager.ConnectionStrings["Sandbox"].ConnectionString; }
    }
  }

}
