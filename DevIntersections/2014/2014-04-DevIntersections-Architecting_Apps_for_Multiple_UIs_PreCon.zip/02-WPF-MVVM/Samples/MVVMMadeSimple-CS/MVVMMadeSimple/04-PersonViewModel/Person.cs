﻿using System;
using Common.Library;

namespace MVVMMadeSimple
{
  public class Person : DataClassBase
  {
    #region Constructor
    public Person()
    {
      FirstName = string.Empty;
      LastName = string.Empty;
      BirthDate = DateTime.Now.AddYears(-20);
    }
    #endregion

    #region Private Variables
    private string _FirstName;
    private string _LastName;
    private DateTime _BirthDate;
    #endregion

    #region Public Properties
    public string FirstName
    {
      get { return _FirstName; }
      set
      {
        _FirstName = value;
        RaisePropertyChanged("FirstName");
      }
    }

    public string LastName
    {
      get { return _LastName; }
      set
      {
        _LastName = value;
        RaisePropertyChanged("LastName");
      }
    }

    public DateTime BirthDate
    {
      get { return _BirthDate; }
      set
      {
        _BirthDate = value;
        RaisePropertyChanged("BirthDate");
      }
    }
    #endregion

    #region Validate Method
    /// <summary>
    /// Validate Business Rules
    /// </summary>
    /// <returns>True if all rules pass, False otherwise</returns>
    public bool Validate()
    {
      // Clear Business Rule Failure Collection
      BusinessRuleFailures.Clear();

      if (FirstName.Trim() == string.Empty)
        BusinessRuleFailures.Add(new BusinessRuleMessage("FirstName", "First Name Must Be Filled In."));
      else if (FirstName.Trim().Length < 2)
        BusinessRuleFailures.Add(new BusinessRuleMessage("FirstName", "First Name Must Be More Than 1 Character."));

      if (LastName.Trim() == string.Empty)
        BusinessRuleFailures.Add(new BusinessRuleMessage("LastName", "Last Name Must Be Filled In."));
      else if (LastName.Trim().Length < 2)
        BusinessRuleFailures.Add(new BusinessRuleMessage("LastName", "Last Name Must Be More Than 1 Character."));

      // Check Birth Date, assume no one is older than 110 years old!
      if (BirthDate < DateTime.Now.AddYears(-110))
        BusinessRuleFailures.Add(new BusinessRuleMessage("BirthDate", "Birth Date Must Be Greater Than " + DateTime.Now.AddYears(-110).ToShortDateString()));

      return (BusinessRuleFailures.Count == 0);
    }
    #endregion
  }
}
