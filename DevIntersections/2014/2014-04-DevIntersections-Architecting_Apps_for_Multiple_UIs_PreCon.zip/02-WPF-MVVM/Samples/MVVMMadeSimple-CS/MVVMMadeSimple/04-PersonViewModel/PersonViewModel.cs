﻿using Common.Library;

namespace MVVMMadeSimple
{
  public class PersonViewModel : ViewModelBase
  {
    #region Constructor
    public PersonViewModel()
    {
      PersonData = new Person();
    }
    #endregion

    #region Private Variables
    private Person _PersonData;
    #endregion

    #region Public Properties
    public Person PersonData
    {
      get { return _PersonData; }
      set
      {
        _PersonData = value;
        RaisePropertyChanged("PersonData");
      }
    }
    #endregion

    #region Validate Method
    public bool Validate()
    {
      IsMessageVisible = false;
      MessageToDisplay = string.Empty;

      if (PersonData.Validate() == false)
      {
        IsMessageVisible = true;
        MessageToDisplay = PersonData.BusinessRuleFailures.ToString();
      }

      return !IsMessageVisible;
    }
    #endregion
  }
}