﻿using System;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Xml.Linq;

namespace PDSA.MessageLayer
{
  public enum MessageStorageLocation
  {
    Resource,
    Xml
  }

  /// <summary>
  /// Class to retrieve messages from a data store
  /// This class uses the Singleton pattern
  /// </summary>
  public class MessageManager
  {
    #region Instance Property
    private static MessageManager _Instance = null;

    /// <summary>
    /// Get/Set an Instance of the PDSAMessage class
    /// </summary>
    public static MessageManager Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new MessageManager();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    #region Location Properties
    /// <summary>
    /// Get/Set the location from where to retrieve messages
    /// </summary>
    public MessageStorageLocation StorageLocation { get; set; }
    /// <summary>
    /// Get/Set the actual storage location for the messages
    /// </summary>
    public string Location { get; set; }
    #endregion

    #region GetMessage Methods
    /// <summary>
    /// Return a message for the specified key passed in
    /// </summary>
    /// <param name="key">The identifier of the messages</param>
    /// <returns>A message</returns>
    public string GetMessage(string key)
    {
      return GetMessage(key, string.Format("Resource {0} Not Found.", key));
    }

    /// <summary>
    /// Return a message for the specified key passed in
    /// </summary>
    /// <param name="key">The identifier of the messages</param>
    /// <param name="defaultMessage">The default message to return if the identifier is not found</param>
    /// <returns>A message</returns>
    public string GetMessage(string key, string defaultMessage)
    {
      return GetMessage(key, defaultMessage, StorageLocation);
    }

    /// <summary>
    /// Return a message for the specified key passed in
    /// </summary>
    /// <param name="key">The identifier of the messages</param>
    /// <param name="defaultMessage">The default message to return if the identifier is not found</param>
    /// <param name="storageLocation">Where the messages are located</param>
    /// <returns>A message</returns>
    public string GetMessage(string key, string defaultMessage, MessageStorageLocation storageLocation)
    {
      return GetMessage(key, defaultMessage, storageLocation, Location);
    }

    /// <summary>
    /// Return a message for the specified key passed in
    /// </summary>
    /// <param name="key">The identifier of the messages</param>
    /// <param name="defaultMessage">The default message to return if the identifier is not found</param>
    /// <param name="storageLocation">Where the messages are located</param>
    /// <param name="location">The actual storage location where to get messages</param>
    /// <returns>A message</returns>
    public string GetMessage(string key, string defaultMessage, MessageStorageLocation storageLocation, string location)
    {
      string ret = string.Empty;

      StorageLocation = storageLocation;
      Location = location;

      switch (StorageLocation)
      {
        case MessageStorageLocation.Resource:
          ret = GetMessageFromResource(key, defaultMessage);
          break;

        case MessageStorageLocation.Xml:
          if (string.IsNullOrEmpty(Location))
          {
            throw new ArgumentNullException("The Location property must be filled in.");
          }
          else
          {
            ret = GetMessageFromXmlFile(key, defaultMessage);
          }
          break;
        default:
          throw new ArgumentNullException("The StorageLocation property must be filled in.");

      }

      return ret;
    }
    #endregion

    #region GetMessageFromResource Method
    protected virtual string GetMessageFromResource(string key, string defaultMessage)
    {
      string ret = defaultMessage;

      Assembly assm = Assembly.GetEntryAssembly();
      if (string.IsNullOrEmpty(Location))
      {
        Location = assm.GetName().Name + ".Properties.Resources";
      }

      ResourceManager resourceManager = new ResourceManager(Location, assm);
      try
      {
        ret = resourceManager.GetString(key);
        if(string.IsNullOrEmpty(ret))
        {
          ret = defaultMessage;
        }
      }
      catch (Exception ex)
      {
        System.Diagnostics.Debug.Write(ex.Message);
      }

      return ret;
    }
    #endregion

    #region GetMessageFromXmlFile Method
    protected virtual string GetMessageFromXmlFile(string key, string defaultMessage)
    {
      string ret = defaultMessage;

      XElement doc = XElement.Load(Location);

      XElement elem = (from node in doc.Elements("Message")
                       where node.Element("Key").Value == key
                       select node).SingleOrDefault();

      if (elem != null)
        ret = elem.Element("Value").Value;

      return ret;
    }
    #endregion
  }
}
