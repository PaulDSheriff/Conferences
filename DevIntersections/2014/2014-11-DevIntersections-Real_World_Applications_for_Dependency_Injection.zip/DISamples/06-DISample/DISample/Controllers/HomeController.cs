﻿using System.Web.Mvc;
using DISample.Models;

namespace DISample.Controllers
{
  public class HomeController : Controller
  {
    public ActionResult Index()
    {
      return View();
    }

    public ActionResult ConfigurationSample()
    {
      DISetting model = new DISetting();

      return View(model);
    }

    [HttpPost]
    public ActionResult ConfigurationSample(DISetting model)
    {

      System.Diagnostics.Debugger.Break();

      return View(model);
    }

    public ActionResult MessageSample()
    {
      return View();
    }

    public ActionResult ExceptionSample()
    {
      return View();
    }
  }
}