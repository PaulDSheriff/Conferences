﻿using System.Web.Mvc;
using DISample.Models;
using PDSA.MessageLayer;

namespace DISample.Controllers
{
  public class MessageController : Controller
  {
    public ActionResult MessageSample()
    {
      DISetting model = new DISetting();

      model.Key = "Key1";
      model.DefaultValue = "Message not found";

      return View(model);
    }

    [HttpPost]
    public ActionResult MessageSample(DISetting model, string Command)
    {
      switch (Command)
      {
        case "Get Message":
          model.Setting = PDSAMessageManager.Instance.GetMessage(model.Key);
          break;

        case "Get Message with Default":
          model.Setting = PDSAMessageManager.Instance.GetMessage(model.Key, model.DefaultValue);
          break;

        default:
          break;
      }

      // Must clear to rebind
      ModelState.Clear();

      return View(model);
    }
  }
}