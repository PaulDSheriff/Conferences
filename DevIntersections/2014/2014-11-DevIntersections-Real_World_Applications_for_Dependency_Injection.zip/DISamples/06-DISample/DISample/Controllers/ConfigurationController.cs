﻿using System.Web.Mvc;
using DISample.Models;
using PDSA.ConfigurationLayer;

namespace DISample.Controllers
{
  public class ConfigurationController : Controller
  {
    public ActionResult ConfigurationSample()
    {
      DISetting model = new DISetting();

      return View(model);
    }

    [HttpPost]
    public ActionResult ConfigurationSample(DISetting model, string Command)
    {
      switch (Command)
      {
        case "Get Setting":
          model.Setting = PDSAConfigurationManager.Instance.GetSetting(model.Key);
          break;

        case "Get Setting with Default":
          model.Setting = PDSAConfigurationManager.Instance.GetSetting(model.Key, model.DefaultValue);
          break;

        default:
          break;
      }

      // Must clear to rebind
      ModelState.Clear();

      return View(model);
    }
  }
}