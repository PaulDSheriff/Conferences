﻿using System;
using System.Collections.Specialized;
using System.Web.Mvc;
using PDSA.ExceptionLayer;

namespace DISample.Controllers
{
  public class ExceptionController : Controller
  {
    public ActionResult ExceptionSample()
    {
      return View();
    }

    [HttpPost]
    public ActionResult ExceptionSample(string Command)
    {
      switch (Command)
      {
        case "Publish Exception":
          PDSAExceptionManager.Instance.Publish(
            new ApplicationException("This is an exception"));

          break;

        case "Publish Exception with Extras":
          NameValueCollection nvc = new NameValueCollection();
          nvc.Add("DefaultStateCode", "CA");
          nvc.Add("EmpType", "20");

          PDSAExceptionManager.Instance.Publish(
            new ApplicationException("This is an exception"), nvc);
          break;

        default:
          break;
      }

      System.Diagnostics.Debugger.Break();

      return View();
    }
  }
}