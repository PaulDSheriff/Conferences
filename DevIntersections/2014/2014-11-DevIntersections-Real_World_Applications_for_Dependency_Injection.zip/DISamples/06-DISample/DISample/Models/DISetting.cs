﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DISample.Models
{
  public class DISetting
  {
    public DISetting()
    {
      Key = "DefaultStateCode";
      DefaultValue = "n/a";
      Setting = string.Empty;
    }

    public string Key { get; set; }
    public string DefaultValue { get; set; }
    public string Setting { get; set; }
  }
}