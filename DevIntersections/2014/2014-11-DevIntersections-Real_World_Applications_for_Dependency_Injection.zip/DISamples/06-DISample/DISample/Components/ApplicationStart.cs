﻿using PDSA.Common;
using PDSA.ConfigurationLayer;
using PDSA.ExceptionLayer;
using PDSA.MessageLayer;

namespace DISample
{
  public class ApplicationStart
  {
    #region Instance Property
    private static ApplicationStart _Instance = null;

    public static ApplicationStart Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new ApplicationStart();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    // Class to read standard framework settings
    private PDSAConfigurationApplicationSettings _Settings = new PDSAConfigurationApplicationSettings();

    public void Initialize()
    {
      // Load all Configuration Settings from Web.Config
      _Settings.LoadStandardSettings();

      // Initialize Configuration Manager
      InitializeConfigurationManager();

      // Initialize Message Manager
      InitializeMessageManager();

      // Initialize Exception Manager
      InitializeExceptionManager();
    }

    #region InitializeConfigurationManager Method
    protected void InitializeConfigurationManager()
    {
      switch (_Settings.ConfigurationSource)
      {
        case "Config":
          //*********************************************************************
          // Create Configuration Manager and use the Configuration File Provider
          //*********************************************************************
          PDSAConfigurationManager.Instance =
           new PDSAConfigurationManager(
             new PDSAConfigurationConfig(string.Empty));
          break;

        case "Registry":
          //**************************************************************
          // Create Configuration Manager and use the Registry Provider
          //**************************************************************
          PDSAConfigurationManager.Instance =
           new PDSAConfigurationManager(
            new PDSAConfigurationRegistry(_Settings.ConfigurationLocation));
          break;

        case "Xml":
          //**************************************************************
          // Create Configuration Manager and use the Xml Provider
          //**************************************************************
          PDSAConfigurationManager.Instance =
            new PDSAConfigurationManager(
              new PDSAConfigurationXml(
                PDSAFileCommon.GetCurrentDirectory() + _Settings.ConfigurationLocation));
          break;

        default:
          break;
      }
    }
    #endregion

    #region InitializeMessageManager Method
    protected void InitializeMessageManager()
    {
      switch (_Settings.MessageSource)
      {
        case "Resource":
          if (string.IsNullOrEmpty(_Settings.MessageLocation))
          {
            //**************************************************************
            // Create Message Manager and Default to 'Resource' Provider
            // The resources will come from the current project
            //**************************************************************
            PDSAMessageManager.Instance =
              new PDSAMessageManager(new PDSAMessageResource());
          }
          else
          {
            //**************************************************************
            // Create Message Manager and Pass in Resource Name
            //**************************************************************
            PDSAMessageManager.Instance =
              new PDSAMessageManager(
                new PDSAMessageResource(_Settings.MessageLocation));
          }
          break;

        case "Xml":
          //**************************************************************
          // Create Message Manager and Default to 'XML' Provider
          //**************************************************************
          PDSAMessageManager.Instance =
            new PDSAMessageManager(
              new PDSAMessageXml(_Settings.MessageLocation));

          break;

        default:
          break;
      }
    }
    #endregion

    #region InitializeExceptionManager Method
    protected void InitializeExceptionManager()
    {
      if (_Settings.UseExceptionFilePublisher)
      {
        //**************************************************************
        // Create Exception Manager and Add 'File' Publisher
        //**************************************************************
        PDSAExceptionManager.Instance.Publishers.Add(
          new PDSAExceptionToFile(_Settings.ExceptionFileName));
      }

      if (_Settings.UseExceptionEmailPublisher)
      {
        //**************************************************************
        // Create Exception Manager and Add 'Email' Publisher
        //**************************************************************
        PDSAEmailSettings settings = new PDSAEmailSettings();
        settings.FromEmail = _Settings.ExceptionEmailFrom;
        settings.ToEmail = _Settings.ExceptionEmailTo;
        settings.Subject = _Settings.ExceptionEmailSubject;
        PDSAExceptionManager.Instance.Publishers.Add(
          new PDSAExceptionToEMail(settings));
      }

      if(_Settings.UseExceptionEventLogPublisher)
      {
        PDSAExceptionManager.Instance.Publishers.Add(
         new PDSAExceptionToEventLog(_Settings.ExceptionEventLog));
      }

      if(_Settings.UseExceptionTablePublisher)
      {
        // TODO: Write publisher for database publishing
      }
    }
    #endregion
  }
}
