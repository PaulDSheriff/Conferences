﻿using System;
using System.Security.Principal;
using System.Text.RegularExpressions;

namespace PDSA.Common
{
  public class PDSAString
  {
    #region ExpandSpecialFolders Method
    /// <summary>
    /// This method will accept any path with the following special tokens in that path. These tokens will be expanded into their appropriate full paths.
    /// <para>[AppPath] = The folder where the application is installed</para>
    /// <para>     Example: C:\Program Files\YourAppName</para>
    /// <para>[MyDocuments] = Generate under your "My Documents" folder</para>
    /// <para>     Example: C:\Users\[YourLoginName]\Documents</para>
    /// <para>[ConfigFile] = The .Config file for the current .EXE file</para>
    /// <para>     Example: C:\MyApp\MyApp.exe.config</para>
    /// <para>[ProgramFiles] = The folder where your programs are installed</para>
    /// <para>     Example: C:\Program Files (x86)</para>
    /// <para>NOTE: None of the above tokens has a trailing backslash, so you need to add one if required.</para>
    /// </summary>
    /// <param name="folderName">The folder name with the special token in it</param>
    /// <returns>The full special folder name</returns>
    public static string ExpandSpecialFolders(string folderName)
    {
      if (folderName == null)
        folderName = string.Empty;
      else
      {
        if (folderName.Trim() == string.Empty)
        {
          folderName = PDSAFileCommon.GetCurrentDirectory();
        }
        if (folderName.Contains("[AppPath]"))
        {
          folderName = folderName.Replace("[AppPath]", PDSAFileCommon.GetCurrentDirectory());
        }
      }

      return folderName;
    }
    #endregion
  }
}
