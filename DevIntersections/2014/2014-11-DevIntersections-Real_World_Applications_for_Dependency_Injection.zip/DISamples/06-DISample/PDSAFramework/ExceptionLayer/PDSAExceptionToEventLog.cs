using System;
using System.Diagnostics;
using System.IO;

namespace PDSA.ExceptionLayer
{
  /// <summary>
  /// "Injector" class for publishing to email
  /// </summary>
  public class PDSAExceptionToEventLog : PDSAExceptionPublisherBase
  {
    #region Constructors
    public PDSAExceptionToEventLog(string logName)
      : base()
    {
      _LogName = logName;
      Init();
    }

    public PDSAExceptionToEventLog(string logName, bool isActive)
      : base()
    {
      _LogName = logName;
      Init();
    }
    #endregion

    #region Init Method
    protected void Init()
    {
      if (string.IsNullOrEmpty(_LogName))
      {
        _LogName = "Application";
      }
    }
    #endregion

    #region Private Variables
    private string _LogName = "Application";
    #endregion

    #region PublishSpecial Method
    protected override void PublishSpecial()
    {
      EventLog el = null;

      try
      {
        //  Write to EventLog Here
        el = new EventLog();

        // Set Application name as the Event Source
        el.Source = _LogName;

        el.WriteEntry(ExceptionInfo.ToString(), EventLogEntryType.Error);
      }
      catch (Exception ex)
      {
        //throw new ApplicationException("Error in PDSAExceptionToEventLog", ex);
      }
    }
    #endregion
  }
}