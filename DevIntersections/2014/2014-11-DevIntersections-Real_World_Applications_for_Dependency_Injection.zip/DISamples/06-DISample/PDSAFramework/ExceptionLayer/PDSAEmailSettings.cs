﻿using System;

namespace PDSA.ExceptionLayer
{
  public class PDSAEmailSettings
  {
    #region Constructors
    public PDSAEmailSettings()
    {
      FromEmail = string.Empty;
      ToEmail = string.Empty;
      Subject = string.Empty;
    }

    /// <summary>
    /// Create an instance of an email exception publisher
    /// </summary>
    /// <param name="from">The 'From' email address</param>
    /// <param name="to">The 'To' email address (NOTE: This can be a comma delimited list)</param>
    /// <param name="subject">The 'Subject' of the email</param>
    public PDSAEmailSettings(string from, string to, string subject)
    {
      FromEmail = from;
      ToEmail = to;
      Subject = subject;
    }
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set From Email
    /// </summary>
    public string FromEmail { get; set; }

    /// <summary>
    /// Get/Set To Email
    /// </summary>
    public string ToEmail { get; set; }

    /// <summary>
    /// Get/Set Subject
    /// </summary>
    public string Subject { get; set; }
    #endregion
  }
}
