﻿using System;
using System.Reflection;
using System.Resources;

namespace PDSA.MessageLayer
{
  /// <summary>
  /// "Injector" class for reading from resource file
  /// </summary>
  public class PDSAMessageResource : PDSAMessageBase
  {
    #region Constructors
    public PDSAMessageResource()
      : base()
    {
    }
    public PDSAMessageResource(string location)
      : base(location)
    {
    }
    #endregion

    public override string GetMessage(string key, string defaultMessage)
    {
      string ret = defaultMessage;

      Assembly assm = Assembly.GetEntryAssembly();
      if (string.IsNullOrEmpty(Location))
      {
        Location = assm.GetName().Name + ".Properties.Resources";
      }

      ResourceManager resourceManager = new ResourceManager(Location, assm);
      try
      {
        ret = resourceManager.GetString(key);
        if(string.IsNullOrEmpty(ret))
        {
          ret = defaultMessage;
        }
      }
      catch (Exception ex)
      {
        System.Diagnostics.Debug.Write(ex.Message);
      }

      return ret;
    }
  }
}
