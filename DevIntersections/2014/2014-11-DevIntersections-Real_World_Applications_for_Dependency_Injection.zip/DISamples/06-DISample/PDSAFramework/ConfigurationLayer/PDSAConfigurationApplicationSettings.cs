﻿using System;
using PDSA.Common;
using PDSA.ConfigurationLayer;

namespace PDSA.ConfigurationLayer
{
  /// <summary>
  /// This class reads all of the standard PDSA settings for any application
  /// </summary>
  public class PDSAConfigurationApplicationSettings
  {
    #region Constructor
    public PDSAConfigurationApplicationSettings()
      : base()
    {
      Init();
    }
    #endregion

    #region Init Method
    public virtual void Init()
    {
      UseExceptionFilePublisher = false;
      UseExceptionEventLogPublisher = true;
      UseExceptionEmailPublisher = false;
      UseExceptionTablePublisher = false;
      ExceptionFileName = @"[AppPath]\Exception.log";
      ExceptionEventLog = "Application";
      ExceptionEmailFromDisplayName = string.Empty;
      ExceptionEmailFrom = string.Empty;
      ExceptionEmailTo = string.Empty;
      ExceptionEmailSubject = string.Empty;
    }
    #endregion

    #region Standard Public Properties
    /// <summary>
    /// Get/Set the location of the global configuration settings for this application
    /// </summary>
    public string ConfigurationSource { get; set; }
    /// <summary>
    /// Get/Set the file location of the configuration settings for this application
    /// </summary>
    public string ConfigurationLocation { get; set; }

    /// <summary>
    /// Get/Set the location of the messages for this application
    /// </summary>
    public string MessageSource { get; set; }
    /// <summary>
    /// Get/Set the file location of the messages for this application
    /// </summary>
    public string MessageLocation { get; set; }

    /// <summary>
    /// Get/Set whether or not to use the File Exception Publisher
    /// </summary>
    public bool UseExceptionFilePublisher { get; set; }

    /// <summary>
    /// Get/Set whether or not to use the Event Log Exception Publisher
    /// </summary>
    public bool UseExceptionEventLogPublisher { get; set; }

    /// <summary>
    /// Get/Set whether or not to use the Email Exception Publisher
    /// </summary>
    public bool UseExceptionEmailPublisher { get; set; }

    /// <summary>
    /// Get/Set whether or not to use the Table Exception Publisher
    /// </summary>
    public bool UseExceptionTablePublisher { get; set; }

    /// <summary>
    /// Get/Set the file name to write exceptions to
    /// </summary>
    public string ExceptionFileName { get; set; }

    /// <summary>
    /// Get/Set the log to write exceptions to
    /// </summary>
    public string ExceptionEventLog { get; set; }

    /// <summary>
    /// Get/Set Display name for emailing exception
    /// </summary>
    public string ExceptionEmailFromDisplayName { get; set; }

    /// <summary>
    /// Get/Set ToEmail
    /// </summary>
    public string ExceptionEmailTo { get; set; }

    /// <summary>
    /// Get/Set the email from address
    /// </summary>
    public string ExceptionEmailFrom { get; set; }

    /// <summary>
    /// Get/Set Subject
    /// </summary>
    public string ExceptionEmailSubject { get; set; }
    #endregion

    #region Standard Settings Load Method
    public virtual void LoadStandardSettings()
    {
      // Use Configuration Reader
      PDSAConfigurationManager.Instance = 
        new PDSAConfigurationManager(new PDSAConfigurationConfig(string.Empty));

      // Exception Manager Information
      UseExceptionFilePublisher = Convert.ToBoolean(PDSAConfigurationManager.Instance.ConfigurationReader.GetSetting("UseExceptionFilePublisher"));
      UseExceptionEventLogPublisher = Convert.ToBoolean(PDSAConfigurationManager.Instance.ConfigurationReader.GetSetting("UseExceptionEventLogPublisher"));
      UseExceptionEmailPublisher = Convert.ToBoolean(PDSAConfigurationManager.Instance.ConfigurationReader.GetSetting("UseExceptionEmailPublisher"));
      UseExceptionTablePublisher = Convert.ToBoolean(PDSAConfigurationManager.Instance.ConfigurationReader.GetSetting("UseExceptionTablePublisher"));

      ExceptionFileName = PDSAString.ExpandSpecialFolders(PDSAConfigurationManager.Instance.GetSetting("ExceptionFileName"));
      ExceptionEmailFromDisplayName = PDSAConfigurationManager.Instance.GetSetting("ExceptionEmailFromDisplayName");
      ExceptionEmailTo = PDSAConfigurationManager.Instance.GetSetting("ExceptionEmailTo");
      ExceptionEmailFrom = PDSAConfigurationManager.Instance.GetSetting("ExceptionEmailFrom");
      ExceptionEmailSubject = PDSAConfigurationManager.Instance.GetSetting("ExceptionEmailSubject");
      ExceptionEventLog = PDSAConfigurationManager.Instance.GetSetting("ExceptionEventLog");

      ConfigurationSource = PDSAConfigurationManager.Instance.GetSetting("ConfigurationSource");
      ConfigurationLocation = PDSAString.ExpandSpecialFolders(PDSAConfigurationManager.Instance.GetSetting("ConfigurationLocation"));

      MessageSource = PDSAConfigurationManager.Instance.GetSetting("MessageSource");
      MessageLocation = PDSAString.ExpandSpecialFolders(PDSAConfigurationManager.Instance.GetSetting("MessageLocation"));
    }
    #endregion
  }
}
