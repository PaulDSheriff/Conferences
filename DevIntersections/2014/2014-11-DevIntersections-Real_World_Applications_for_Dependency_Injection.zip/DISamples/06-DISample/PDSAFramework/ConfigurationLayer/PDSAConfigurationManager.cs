using System;
namespace PDSA.ConfigurationLayer
{
  /// <summary>
  /// "Dependent" class
  /// </summary>
  public class PDSAConfigurationManager
  {
    #region Constructors
    public PDSAConfigurationManager()
    {
    }

    public PDSAConfigurationManager(PDSAConfigurationBase reader)
    {
      _ConfigReader = reader;
    }
    #endregion

    #region Instance
    private static PDSAConfigurationManager _Instance = null;

    public static PDSAConfigurationManager Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new PDSAConfigurationManager();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    #region Configuration Reader Property
    private PDSAConfigurationBase _ConfigReader = null;

    public PDSAConfigurationBase ConfigurationReader
    {
      get { return _ConfigReader; }
      set { _ConfigReader = value; }
    }
    #endregion

    #region GetSetting Methods
    public virtual string GetSetting(string key)
    {
      if (ConfigurationReader == null)
        return string.Empty;
      else
        return ConfigurationReader.GetSetting(key);
    }

    public virtual string GetSetting(string key, string defaultValue)
    {
      if (ConfigurationReader == null)
        return defaultValue;
      else
        return ConfigurationReader.GetSetting(key, defaultValue);
    }
    #endregion
  }
}