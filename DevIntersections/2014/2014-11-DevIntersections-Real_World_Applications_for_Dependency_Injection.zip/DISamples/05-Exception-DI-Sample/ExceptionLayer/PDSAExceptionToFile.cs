using System;
using System.IO;

namespace PDSA.ExceptionLayer
{
  /// <summary>
  /// "Injector" class for publishing to a file
  /// </summary>
  public class PDSAExceptionToFile : PDSAExceptionPublisherBase
  {
    #region Constructors
    public PDSAExceptionToFile(string fileName)
    {
      _FileName = fileName;
    }
    #endregion

    #region Private Variables
    private string _FileName = string.Empty;
    #endregion

    #region PublishSpecial Method
    protected override void PublishSpecial()
    {
      if (string.IsNullOrEmpty(_FileName))
      {
        _FileName = Environment.CurrentDirectory + @"\" + Environment.UserName + "-Error.log";
      }

      try
      {
        //  Write to File Here
        File.AppendAllText(_FileName, ExceptionInfo.ToString());
      }
      catch (Exception ex)
      {
        throw new ApplicationException("Error in PDSAExceptionToFile publisher", ex);
      }
    }
    #endregion
  }
}