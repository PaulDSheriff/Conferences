using System;
using System.Collections.Generic;
using System.Collections.Specialized;

namespace PDSA.ExceptionLayer
{
  /// <summary>
  /// "Dependent" class
  /// </summary>
  public class PDSAExceptionManager
  {
    #region Constructors
    public PDSAExceptionManager()
    {      
    }
    #endregion

    #region Instance property
    private static PDSAExceptionManager _Instance = null;

    public static PDSAExceptionManager Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new PDSAExceptionManager();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    #region Publishers Collection Property
    private List<PDSAExceptionPublisherBase> _Publishers = 
      new List<PDSAExceptionPublisherBase>();

    public List<PDSAExceptionPublisherBase> Publishers
    {
      get { return _Publishers; }
      set { _Publishers = value; }
    }
    #endregion

    #region Publish Methods
    public virtual void Publish(Exception ex)
    {
      Publish(ex, null);
    }

    public virtual void Publish(Exception ex, NameValueCollection AdditionalInfo)
    {
      foreach (PDSAExceptionPublisherBase item in Publishers)
      {
        item.Publish(ex, AdditionalInfo);
      }
    }
    #endregion
  }
}