﻿using PDSA.ExceptionLayer;
using PDSA.Common;

namespace ExceptionLayerSample
{
  public class ApplicationStart
  {
    #region Instance Property
    private static ApplicationStart _Instance = null;

    public static ApplicationStart Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new ApplicationStart();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    public void Initialize()
    {
      // Initialize Exception Manager
      InitializeExceptionManager();
    }

    protected void InitializeExceptionManager()
    {
      //**************************************************************
      // Create Exception Manager and Add 'File' Publisher
      //**************************************************************
      PDSAExceptionManager.Instance.Publishers.Add(
        new PDSAExceptionToFile(PDSAFileCommon.GetCurrentDirectory() + 
                                 @"\Exceptions.txt"));

      //**************************************************************
      // Create Exception Manager and Add 'Email' Publisher
      //**************************************************************
      PDSAEmailSettings settings = new PDSAEmailSettings();
      settings.FromEmail = "PSheriff@pdsa.com";
      settings.ToEmail = "PSheriff@pdsa.com";
      settings.Subject = "Exception from the Exception Layer Samples";
      PDSAExceptionManager.Instance.Publishers.Add(
        new PDSAExceptionToEMail(settings));
    }
  }
}
