using Microsoft.Win32;

namespace PDSA.ConfigurationLayer
{
  /// <summary>
  /// "Injector" class for reading Registry
  /// </summary>
  public class PDSAConfigurationRegistry : PDSAConfigurationBase
  {
    #region Constructors  
    public PDSAConfigurationRegistry(string location)
      : base(location)
    {
    }
    #endregion

    #region GetSetting Method
    public override string GetSetting(string key, string defaultValue)
    {
      RegistryKey rk = null;
      string ret = defaultValue;

      rk = Registry.LocalMachine.OpenSubKey(base.Location, true);

      if (rk != null)
      {
        ret = rk.GetValue(key, defaultValue).ToString();
        rk.Close();
        rk.Dispose();
      }

      return ret;
    }
    #endregion
  }
}