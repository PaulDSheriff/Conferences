using System.Configuration;

namespace PDSA.ConfigurationLayer
{
  /// <summary>
  /// "Injector" class for reading .Config files
  /// </summary>
  public class PDSAConfigurationConfig : PDSAConfigurationBase
  {
    #region Constructor
    public PDSAConfigurationConfig(string location)
      : base(location)
    {
    }
    #endregion

    #region GetSetting Method
    public override string GetSetting(string key, string defaultValue)
    {
      string ret;

      ret = ConfigurationManager.AppSettings[key];
      if (ret == null)
        ret = defaultValue;

      return ret;
    }
    #endregion
  }
}