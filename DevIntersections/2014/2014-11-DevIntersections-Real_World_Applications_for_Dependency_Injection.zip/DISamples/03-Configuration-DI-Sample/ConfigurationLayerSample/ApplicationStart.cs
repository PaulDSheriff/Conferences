﻿
using PDSA.Common;
using PDSA.ConfigurationLayer;

namespace ConfigurationLayerSample
{
  public class ApplicationStart
  {
    #region Instance Property
    private static ApplicationStart _Instance = null;

    public static ApplicationStart Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new ApplicationStart();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    public void Initialize()
    {
      // Initialize Configuration Manager
      InitializeConfigurationManager();
    }

    protected void InitializeConfigurationManager()
    {
      //**************************************************************
      // Create Configuration Manager and use the Xml Provider
      //**************************************************************
      PDSAConfigurationManager.Instance = 
        new PDSAConfigurationManager(
          new PDSAConfigurationXml(
            PDSAFileCommon.GetCurrentDirectory() + @"\Settings.xml"));

      //**************************************************************
      // Create Configuration Manager and use the Registry Provider
      //**************************************************************
      // PDSAConfigurationManager.Instance = 
      //  new PDSAConfigurationManager(
      //   new PDSAConfigurationRegistry(@"Software\MyApp"));

      //*********************************************************************
      // Create Configuration Manager and use the Configuration File Provider
      //*********************************************************************
      // PDSAConfigurationManager.Instance = 
      //  new PDSAConfigurationManager(
      //    new PDSAConfigurationConfig(string.Empty));
    }
  }
}
