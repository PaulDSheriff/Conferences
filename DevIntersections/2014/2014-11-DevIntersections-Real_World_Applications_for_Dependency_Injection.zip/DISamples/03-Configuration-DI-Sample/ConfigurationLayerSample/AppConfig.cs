﻿using System;

using PDSA.ConfigurationLayer;

namespace ConfigurationLayerSample
{
  public class AppConfig
  {
    #region Instance Property
    private static AppConfig _Instance = null;

    public static AppConfig Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new AppConfig();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    public int EmpType
    {
      get { return Convert.ToInt32(PDSAConfigurationManager.Instance.GetSetting("EmpType")); }
    }

    public string DefaultStateCode
    {
      get { return PDSAConfigurationManager.Instance.GetSetting("DefaultStateCode"); }
    }
  }
}
