﻿using System;
using System.Configuration;
using System.Xml;
using Microsoft.Win32;

namespace PDSA.ConfigurationLayer
{
  public enum PDSAConfigurationStorageLocation
  {
    ConfigFile,
    Registry,
    Xml
  }

  public class PDSAConfigurationManager
  {
    #region Instance Property
    private static PDSAConfigurationManager _Instance = null;

    /// <summary>
    /// Get/Set an Instance of the ConfigurationManager class
    /// </summary>
    public static PDSAConfigurationManager Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new PDSAConfigurationManager();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    #region Location Properties
    /// <summary>
    /// Get/Set the location from where to retrieve configration settings
    /// </summary>
    public PDSAConfigurationStorageLocation StorageLocation { get; set; }
    /// <summary>
    /// Get/Set the actual storage location for the configuration settings
    /// </summary>
    public string Location { get; set; }
    #endregion

    #region GetSetting Methods
    /// <summary>
    /// Return the value for the specified key passed in
    /// </summary>
    /// <param name="key">The key to locate</param>
    /// <returns>A value</returns>
    public string GetSetting(string key)
    {
      return GetSetting(key, string.Format("Key {0} Not Found.", key));
    }

    /// <summary>
    /// Return a value for the specified key passed in
    /// </summary>
    /// <param name="key">The key to locate</param>
    /// <param name="defaultValue">The default value to return if the key is not found</param>
    /// <returns>A value</returns>
    public string GetSetting(string key, string defaultValue)
    {
      return GetSetting(key, defaultValue, StorageLocation);
    }

    /// <summary>
    /// Return a value for the specified key passed in
    /// </summary>
    /// <param name="key">The key to locate</param>
    /// <param name="defaultValue">The default value to return if the key is not found</param>
    /// <param name="storageLocation">Where the config settings are located</param>
    /// <returns>A value</returns>
    public string GetSetting(string key, string defaultValue, PDSAConfigurationStorageLocation storageLocation)
    {
      return GetSetting(key, defaultValue, storageLocation, Location);
    }

    /// <summary>
    /// Return a value for the specified key passed in
    /// </summary>
    /// <param name="key">The key to locate</param>
    /// <param name="defaultValue">The default value to return if the key is not found</param>
    /// <param name="storageLocation">Where the config settings are located</param>
    /// <param name="location">The actual storage location for the config settings</param>
    /// <returns>A value</returns>
    public string GetSetting(string key, string defaultValue, PDSAConfigurationStorageLocation storageLocation, string location)
    {
      string ret = string.Empty;

      StorageLocation = storageLocation;
      Location = location;

      switch (StorageLocation)
      {
        case PDSAConfigurationStorageLocation.ConfigFile:
          ret = GetSettingFromConfigFile(key, defaultValue);
          break;
        case PDSAConfigurationStorageLocation.Registry:
          if(string.IsNullOrEmpty(Location))
          {
            throw new ArgumentNullException("The Location property must be filled in.");
          }
          else
          {
            ret = GetSettingFromRegistry(key, defaultValue);
          }
          break;
        case PDSAConfigurationStorageLocation.Xml:
          if (string.IsNullOrEmpty(Location))
          {
            throw new ArgumentNullException("The Location property must be filled in.");
          }
          else
          {
            ret = GetSettingFromXmlFile(key, defaultValue);
          }
          break;
        default:
          throw new ArgumentNullException("The StorageLocation property must be filled in.");
          
      }
     
      return ret;
    }
    #endregion

    #region GetSettingsFromConfigFile Method
    protected virtual string GetSettingFromConfigFile(string key, string defaultValue)
    {
      string ret = string.Empty;

      ret = ConfigurationManager.AppSettings[key];
      if (string.IsNullOrEmpty(ret))
        ret = defaultValue;

      return ret;
    }
    #endregion

    #region GetSettingFromRegistry Method
    protected virtual string GetSettingFromRegistry(string key, string defaultValue)
    {
      RegistryKey rk = null;
      string ret = string.Empty;

      rk = Registry.CurrentUser.OpenSubKey(Location, true);

      if (rk == null)
      {
        ret = defaultValue;
      }
      else
      {
        ret = rk.GetValue(key, defaultValue).ToString();
        rk.Close();
        rk.Dispose();
      }

      return ret;
    }
    #endregion
    
    #region GetSettingsFromXmlFile Method
    protected virtual string GetSettingFromXmlFile(string key, string defaultValue)
    {
      XmlDocument xd = null;
      XmlNode xn = null;
      string xPathQuery = null;
      string ret = string.Empty;

      xd = new XmlDocument();
      xd.Load(Location);

      xPathQuery = string.Format("/appSettings/add[@key='{0}']", key);

      xn = xd.SelectSingleNode(xPathQuery);

      if (xn == null)
      {
        ret = defaultValue;
      }
      else
      {
        ret = xn.Attributes["value"].Value;
      }

      return ret;
    }
    #endregion
  }
}
