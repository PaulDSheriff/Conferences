﻿using System;
using System.Linq;
using System.Xml.Linq;

namespace PDSA.MessageLayer
{
  /// <summary>
  /// "Injector" class for reading from XML files
  /// </summary>
  public class PDSAMessageXml : PDSAMessageBase
  {
    #region Constructors
    public PDSAMessageXml()
      : base()
    {
    }

    public PDSAMessageXml(string location)
      : base(location)
    {
    }
    #endregion

    public override string GetMessage(string key, string defaultMessage)
    {
      string ret = defaultMessage;

      XElement doc = XElement.Load(Location);

      XElement elem = (from node in doc.Elements("Message")
                       where node.Element("Key").Value == key
                       select node).SingleOrDefault();

      if (elem != null)
        ret = elem.Element("Value").Value;

      return ret;
    }
  }
}
