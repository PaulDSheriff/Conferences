﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace ConsoleClient
{
   public class Product
   {
      public int ProductId { get; set; }
      public string ProductName { get; set; }
   }

   class Program
   {
      static string ApiHostUrl
      {
         get
         {
            return ConfigurationManager.AppSettings["ApiHostUrl"];
         }
      }

      static string ApiPath
      {
         get
         {
            return ConfigurationManager.AppSettings["ApiPath"];
         }
      }

      static void Main(string[] args)
      {
         // Debugger.Break();

         Console.WriteLine("Getting products from {0}/{1}.", ApiHostUrl, ApiPath);
         Console.WriteLine();

         // Run client code in an async method
         // in order to be able to use async calls

         RunAsAsync().Wait();

         Console.WriteLine();
         Console.WriteLine("Press any key to exit.");
         Console.ReadLine();
      }

      /// <summary>
      /// 
      /// </summary>
      /// <returns></returns>
      static async Task RunAsAsync()
      {
         HttpClient client;
         HttpResponseMessage response;
         List<Product> products;

         // Create the client
         client = new HttpClient();
         client.BaseAddress = new Uri(ApiHostUrl);

         // Call "get" method
         response = await client.GetAsync(ApiPath);

         // Verify success
         if (response.IsSuccessStatusCode)
         {
            products = await response.Content.ReadAsAsync<List<Product>>();

            products.ForEach(p => 
               Console.WriteLine("Product # {0}, {1}", 
                  p.ProductId, p.ProductName));
         }
      }
   }
}
