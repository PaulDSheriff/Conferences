﻿using FeaturesSampleProject.Controllers;

using System.Web.Http;
using System.Web.Http.ExceptionHandling;

namespace FeaturesSampleProject
{
   /// <summary>
   /// WebApiConfig is used by convention as the class that is responsible for
   /// registration of Web API behavior.
   /// </summary>
   public static class WebApiConfig
   {
      /// <summary>
      /// Register Web API-specific configuration
      /// </summary>
      /// <param name="config">Instance of HttpConfiguration, configuration of HttpServer</param>
      public static void Register(HttpConfiguration config)
      {
         // Maps Web API routes defined using Route attribute
         config.MapHttpAttributeRoutes();

         // Map the default route, e.g., /api/product/1
         config.Routes.MapHttpRoute(
             name: "DefaultApi",
             routeTemplate: "api/{controller}/{id}",
             defaults: new { id = RouteParameter.Optional }
         );

         #region Sample05 - Security

         // var auth = new AuthenticationConfiguration();

         #endregion

         #region Sample07 - Custom Route

         // Create a custom route for /api/-96/29/100 that routes to 
         // Sample02Controller method GetStoresNearCoordinates
         config.Routes.MapHttpRoute(
            "ProductGeoSearchApi",
            "api/{latitude}/{longitude}/{radius}",
            defaults: new { controller = "Sample07", action = "GetStoresNearCoordinates"}
         );

         #endregion

         #region Sample08 - Custom Formatter

         // Add the custom media formatter 
         config.Formatters.Add(new Sample08_MediaFormatter());

         #endregion

         #region Sample09 - Message Handling

         // Add the custom logging handler
         
         // config.MessageHandlers.Add(new LoggingHandler());

         #endregion

         #region Sample10 - Exception Handling

         // Uncomment this to start using the ExceptionMessageHandler approach

         config.Services.Replace(typeof(IExceptionHandler), new ExceptionMessageHandler());

         #endregion
      }
   }
}
