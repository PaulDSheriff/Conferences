﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace FeaturesSampleProject
{
   public class WebApiApplication : System.Web.HttpApplication
   {
      protected void Application_Start()
      {
         // Register areas (such as "HelpPage")
         AreaRegistration.RegisterAllAreas();

         // Ensure the global configuration is valid and then 
         // call the WebApiConfig register method
         GlobalConfiguration.Configure(WebApiConfig.Register);

         // Register global filters
         FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);

         // Register MVC routes
         RouteConfig.RegisterRoutes(RouteTable.Routes);

         // Register MVC bundles
         BundleConfig.RegisterBundles(BundleTable.Bundles);
      }
   }
}
