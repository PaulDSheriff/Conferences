﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

namespace FeaturesSampleProject.Models.DataAccess
{
   /// <summary>
   /// An overly simplistic data layer class.  
   /// You could use any approach you wish -- EF, NHibernate, etc.
   /// </summary>
   public class ProductData
   {
      public Product Retrieve(int productId)
      {
         Product result = null;

         DataSet ds = DataLayer.GetDataSet(
            string.Format(" SELECT ProductId, ProductName, Price, Cost, IsActive FROM dbo.Product WHERE ProductId = {0} ", productId),
            this.ConnectionString);

         result = this.CreateProduct(ds.Tables[0].Rows[0]);

         return result;
      }

      public void Insert(Product product)
      {
         string sql = string.Format(" INSERT INTO dbo.Product (ProductName, Price, Cost, IsActive) VALUES ('{0}', {1}, {2}, {3}) ",
            product.ProductName, product.Price, product.Cost, product.IsActive ?? false ? 1 : 0);

         DataLayer.ExecuteSQL(sql, this.ConnectionString);
      }

      public void Update(Product product)
      {
         string sql = string.Format(" UPDATE dbo.Product SET ProductName = '{0}', Price = {1}, Cost = {2}, IsActive = {3} WHERE ProductId = {4} ",
            product.ProductName, product.Price, product.Cost, product.IsActive ?? false ? 1 : 0, product.ProductId);

         DataLayer.ExecuteSQL(sql, this.ConnectionString);
      }

      public void Delete(int id)
      {
         string sql = string.Format(" DELETE dbo.Product WHERE ProductId = {0} ", id);

         DataLayer.ExecuteSQL(sql, this.ConnectionString);
      }

      public DataSet GetDataSet()
      {
         return DataLayer.GetDataSet(" SELECT ProductId, ProductName, Price, Cost, IsActive FROM dbo.Product ", this.ConnectionString);
      }

      public string ConnectionString
      {
         get { return ConfigurationManager.ConnectionStrings["SampleData"].ConnectionString; }
      }

      public ProductCollection GetAllProducts()
      {
         ProductCollection products = new ProductCollection();

         DataSet ds = this.GetDataSet();
         DataTable dt = ds.Tables[0];

         foreach (DataRow row in dt.Rows)
         {
            products.Add(this.CreateProduct(row));
         }

         return products;
      }

      private Product CreateProduct(DataRow row)
      {
         return
            new Product
            {
               ProductId = Convert.ToInt32(row["ProductId"]),
               ProductName = row["ProductName"].ToString(),
               Price = Convert.ToDecimal(row["Price"]),
               Cost = Convert.ToDecimal(row["Cost"]),
               IsActive = Convert.ToBoolean(row["IsActive"])
            };
      }

   }
}