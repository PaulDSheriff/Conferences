using System.Data;
using System.Data.SqlClient;

namespace FeaturesSampleProject.Models.DataAccess
{
   internal class DataProvider
   {
      // The following methods currently only handle SQL Server
      // However, these could be put into a Case statement to choose
      // which data provider to use based on the ConnectionString.
      // Or could even be created late bound.

      public static IDbConnection CreateConnection()
      {
         SqlConnection cnn = new SqlConnection();

         return cnn;
      }

      public static IDbCommand CreateCommand()
      {
         SqlCommand cmd = new SqlCommand();

         return cmd;
      }

      public static IDataParameter CreateParameter()
      {
         SqlParameter param = new SqlParameter();

         return param;
      }

      public static IDbDataAdapter CreateDataAdapter()
      {
         SqlDataAdapter da = new SqlDataAdapter();

         return da;
      }
   }
}