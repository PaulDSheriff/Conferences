﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FeaturesSampleProject.Controllers
{
   public class HomeController : Controller
   {
      public ActionResult Index()
      {
         ViewBag.Title = "Home Page";

         return View();
      }

      public ActionResult Sample05_Authenticate()
      {
         return View();
      }

      public ActionResult Sample06_jQueryClient()
      {
         return View();
      }

      /*
      
      Sample01 - New Project
      Sample02 - Data Access
      Sample03 - Validation
      Sample04 - Exceptions
      Sample05 - Security
      Sample06 - Clients
      Sample07 - Routing
      Sample08 - Media Type
      Sample09 - Message Handling
      Sample10 - Managing State
      
      */
   }
}
