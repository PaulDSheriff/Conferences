﻿using FeaturesSampleProject.Models;
using System;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.ExceptionHandling;
using System.Web.Http.Filters;
using System.Web.Http.Results;

namespace FeaturesSampleProject.Controllers
{
   #region Sample Exception Class

   /// <summary>
   /// Simple custom exception
   /// </summary>
   public class CustomException : Exception
   {
      public CustomException(string message) : base(message) { }
   }

   #endregion

   #region Sample Exception Filter

   /// <summary>
   /// Custom attribute to use as a filter on controller methods
   /// </summary>
   public class HandleExceptionAttribute : ExceptionFilterAttribute
   {
      public override void OnException(HttpActionExecutedContext ctx)
      {
         Debugger.Break();

         var info = new ErrorInfo
         {
            FriendlyMessage = "Ooops, an error occurred.  Please contact support!",
            RequestedUrl = ctx.Request.RequestUri.ToString(),
            SystemMessage = ctx.Exception.Message
         };

         var response = ctx.Request.CreateResponse(HttpStatusCode.InternalServerError, info);
         ctx.Response = response;
      }
   }

   #endregion

   #region Sample Exception Message Handler

   /// <summary>
   /// Sample message exception handler
   /// (Replace default in config.Services)
   /// </summary>
   public class ExceptionMessageHandler : ExceptionHandler
   {
      public override void Handle(ExceptionHandlerContext ctx)
      {
         Debugger.Break();

         var info = new ErrorInfo
         {
            FriendlyMessage = "Ooops, an error occurred.  Please contact support!",
            RequestedUrl = ctx.Request.RequestUri.ToString(),
            SystemMessage = ctx.Exception.Message
         };

         var response = ctx.Request.CreateResponse(HttpStatusCode.InternalServerError, info);
         ctx.Result = new ResponseMessageResult(response);
      }
   }

   #endregion

   /// <summary>
   /// Demonstrates handling exceptions
   /// </summary>
   public class Sample04Controller : ApiController
   {
      /// <summary>
      /// Unhandled exception
      /// </summary>
      /// <returns></returns>
      public IHttpActionResult Get()
      {
         Debugger.Break();

         HttpResponseMessage result = new HttpResponseMessage
         {
            Content = new StringContent("Response Message")
         };

         throw new CustomException("Exception Message");
      }

      /// <summary>
      /// Handle the exception locally
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      public IHttpActionResult Get(int id)
      {
         HttpResponseMessage result = null;

         Debugger.Break();

         try
         {
            result = new HttpResponseMessage
            {
               Content = new StringContent(string.Format("Response Message ID {0}", id)),
               StatusCode = HttpStatusCode.OK
            };

            this.DoSomethingBad();
         }
         catch (Exception ex)
         {
            result = new HttpResponseMessage
            {
               Content = new StringContent(ex.Message),
               StatusCode = HttpStatusCode.InternalServerError
            };

            throw new HttpResponseException(result);
         }

         return ResponseMessage(result);
      }

      /// <summary>
      /// Handle the exception with a custom filter
      /// </summary>
      /// <param name="filter"></param>
      [HandleException]
      [Route("api/exception/{filter}")]
      public IHttpActionResult GetByFilter(string filter)
      {
         Debugger.Break();
         
         this.DoSomethingBad();

         return Ok();
      }

      private void DoSomethingBad()
      {
         throw new CustomException("Exception Message");
      }
   }
}
