﻿using FeaturesSampleProject.Models;

using System.Diagnostics;
using System.Web.Http;

namespace FeaturesSampleProject.Controllers
{
   /// <summary>
   /// Demonstrates model validation
   /// </summary>
   public class Sample03Controller : ApiController
   {
      /// <summary>
      /// Default model validation
      /// </summary>
      /// <param name="product"></param>
      [HttpPost]
      [Route("api/validate/model")]
      public void Save(SimpleProduct product)
      {
         Debugger.Break();

         if (ModelState.IsValid)
         {
            // Continue processing
         }
      }

      /// <summary>
      /// Validation for class using data annotation 
      /// attributes.
      /// </summary>
      /// <param name="product"></param>
      [HttpPost]
      [Route("api/validate/attributes")]
      public void Save(Product product)
      {
         Debugger.Break();

         if (ModelState.IsValid)
         {
            // Continue processing
         }
      }
   }
}
