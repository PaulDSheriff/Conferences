﻿using FeaturesSampleProject.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Http;

namespace FeaturesSampleProject.Controllers
{
   /// <summary>
   /// Demonstrates handling state
   /// </summary>
   public class Sample10Controller : ApiController
   {
      /// <summary>
      /// Get a response with a cookie
      /// </summary>
      /// <returns></returns>
      public IHttpActionResult Get()
      {
         CookieHeaderValue cookie;
         HttpResponseMessage result;
         List<CookieHeaderValue> cookies;

         Debugger.Break();

         result = new HttpResponseMessage(HttpStatusCode.OK);
         cookie = new CookieHeaderValue("token", "12345");
         cookie.Expires = DateTimeOffset.Now.AddMinutes(20);
         cookie.Domain = this.Request.RequestUri.Host;
         cookie.Path = "/";

         cookies = new List<CookieHeaderValue>();
         cookies.Add(cookie);
         result.Headers.AddCookies(cookies);

         result.Content = new StringContent("Hello Cookies!");

         return ResponseMessage(result);
      }

      /// <summary>
      /// Post a product and check the cookie
      /// </summary>
      /// <param name="product"></param>
      /// <returns></returns>
      [HttpPost]
      public IHttpActionResult Post(Product product)
      {
         Debugger.Break();

         // Cookie is present on the post request
         var cookie = this.Request.Headers.GetCookies().FirstOrDefault();

         if (cookie != null)
         {
            string token = cookie["token"].Value;
         }

         return Ok();
      }
   }
}
