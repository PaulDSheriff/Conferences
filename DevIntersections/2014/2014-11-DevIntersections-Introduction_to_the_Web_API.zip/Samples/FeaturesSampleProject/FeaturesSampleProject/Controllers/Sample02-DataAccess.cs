﻿using FeaturesSampleProject.Models;

using System.Collections.Generic;
using System.Diagnostics;
using System.Web.Http;

namespace FeaturesSampleProject.Controllers
{
   #region Basic Controller
 
   /// <summary>
   /// Demonstrates basic 'CRUD' operations
   /// </summary>
   public class Sample02Controller : ApiController
   {
      ProductManager _manager;

      public Sample02Controller()
      {
         _manager = new ProductManager();
      }

      // GET api/sample08
      public IEnumerable<Product> Get()
      {
         Debugger.Break();

         return _manager.GetProducts();
      }

      // GET api/sample08/5
      public Product Get(int id)
      {
         Debugger.Break();

         return _manager.GetProduct(id);
      }

      // POST api/sample08
      public void Post(Product product)
      {
         Debugger.Break();

         _manager.Insert(product);
      }

      // PUT api/sample08/8
      public void Put(int id, Product product)
      {
         Debugger.Break();

         _manager.Update(product);
      }

      // DELETE api/sample08/5
      public void Delete(int id)
      {
         Debugger.Break();

         _manager.Delete(id);
      }
   }

   #endregion

   #region Advanced Controller

   /// <summary>
   /// Demonstrates 'CRUD' operations
   /// </summary>
   public class ProductController : ApiController
   {
      // Using a business layer class as 
      // a simple repository.  You can easily use
      // Entity Framework or an ORM such as NHibernate

      ProductManager _manager;

      public ProductController()
      {
         _manager = new ProductManager();
      }

      // GET api/product
      public IHttpActionResult Get()
      {
         IHttpActionResult result;

         Debugger.Break();

         List<Product> products = _manager.GetProducts();

         if (products == null)
         {
            result = this.NotFound();
         }
         else
         {
            result = this.Ok<List<Product>>(products);
         }

         return result;
      }

      // GET api/product/5
      public IHttpActionResult Get(int id)
      {
         IHttpActionResult result;

         Debugger.Break();

         Product product = _manager.GetProduct(id);

         if (product == null)
         {
            result = this.NotFound();
         }
         else
         {
            result = this.Ok<Product>(product);
         }

         return result;
      }

      // POST api/product
      public IHttpActionResult Post(Product product)
      {
         Debugger.Break();

         _manager.Insert(product);

         return Ok();
      }

      // PUT api/product/5
      public IHttpActionResult Put(int id, Product product)
      {
         Debugger.Break();

         // You might want to lookup the id and if it does not 
         // exist, return NotFound

         _manager.Update(product);

         return Ok();
      }

      // DELETE api/product/5
      public IHttpActionResult Delete(int id)
      {
         Debugger.Break();

         // You might want to lookup the id and if it does not 
         // exist, return NotFound

         _manager.Delete(id);

         return this.Ok();
      }
   }

   #endregion
}
