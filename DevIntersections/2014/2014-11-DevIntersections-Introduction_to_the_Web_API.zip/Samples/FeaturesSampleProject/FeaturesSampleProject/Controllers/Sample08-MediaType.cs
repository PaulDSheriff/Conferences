﻿using FeaturesSampleProject.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Http;

namespace FeaturesSampleProject.Controllers
{
   #region Sample Media Type Formatter

   /// <summary>
   /// Demonstrates writing RetailStore to CSV
   /// </summary>
   public class Sample08_MediaFormatter : MediaTypeFormatter
   {
      /// <summary>
      /// Add text/csv to the supported media types for this formatter
      /// </summary>
      public Sample08_MediaFormatter()
      {
         this.SupportedMediaTypes.Add(new MediaTypeHeaderValue("text/csv"));

         this.MediaTypeMappings.Add(new QueryStringMapping("type", "csv", 
            new MediaTypeHeaderValue("text/csv")));
      }

      /// <summary>
      /// Indicate we are not supporting reading this type
      /// </summary>
      /// <param name="type"></param>
      /// <returns></returns>
      public override bool CanReadType(Type type)
      {
         return false;
      }

      /// <summary>
      /// Check the result type and verify it can be
      /// handled.
      /// </summary>
      /// <param name="type"></param>
      /// <returns></returns>
      public override bool CanWriteType(Type type)
      {
         bool result = false;

         if (type == typeof(RetailStore))
         {
            result = true;
         }
         else
         {
            result = typeof(IEnumerable<RetailStore>).IsAssignableFrom(type);
         }

         return result;
      }

      // Stream writer instance
      private StreamWriter _writer;

      /// <summary>
      /// Write a single item to the stream as CSV
      /// </summary>
      /// <param name="store"></param>
      private void Write(RetailStore store)
      {
         _writer.WriteLine("{0},{1},{2},{3},{4},{5}", store.BusinessName.Delimit(),
            store.StreetAddress.Delimit(), store.UnitAddress.Delimit(), store.City.Delimit(),
            store.StateProvince.Delimit(), store.PostalCode.Delimit());
      }

      /// <summary>
      /// Write the collection or item to CSV
      /// </summary>
      /// <param name="type"></param>
      /// <param name="value"></param>
      /// <param name="writeStream"></param>
      /// <param name="content"></param>
      /// <param name="transportContext"></param>
      private void WriteToStream(Type type, object value, Stream writeStream,
         HttpContent content, TransportContext transportContext)
      {
         RetailStore store;
         IEnumerable<RetailStore> stores;

         _writer = new StreamWriter(writeStream);
         stores = value as IEnumerable<RetailStore>;

         if (stores != null)
         {
            foreach (RetailStore item in stores)
            {
               this.Write(item);
            }
         }
         else
         {
            store = value as RetailStore;

            if (store == null)
            {
               throw new ArgumentException(string.Format("Cannot serialize {0} type.", 
                  value.GetType()), "value");
            }
            else
            {
               this.Write(store);
            }
         }

         _writer.Flush();
      }

      /// <summary>
      /// Implement WriteToStreamAsync in order to provide custom formatted output.
      /// </summary>
      /// <param name="type"></param>
      /// <param name="value"></param>
      /// <param name="writeStream"></param>
      /// <param name="content"></param>
      /// <param name="transportContext"></param>
      /// <returns></returns>
      public override Task WriteToStreamAsync(Type type, object value, Stream writeStream, 
         HttpContent content, TransportContext transportContext)
      {
         Debugger.Break();

         return Task.Factory.StartNew(() =>
         {
            this.WriteToStream(type, value, writeStream, content, transportContext);
         });
      }
   }

   #region Extension Methods

   public static class ObjectExtensions
   {
      private static char[] _chars = new char[] { ',', '\n', '\r', '"' };

      public static string Delimit(this object obj)
      {
         string result;

         if (obj == null)
         {
            result = string.Empty;
         }
         else
         {
            string value = obj.ToString();

            if (value.IndexOfAny(_chars) > -1)
            {
               result = string.Format("\"{0}\"", value.Replace("\"", "\"\""));
            }
            else
            {
               result = value;
            }
         }

         return result;
      }
   }

   #endregion

   #endregion

   /// <summary>
   /// Supports demonstration of custom media type
   /// </summary>
   public class Sample08Controller : ApiController
   {
      /// <summary>
      /// Called via route defined in WebApiConfig.cs
      /// </summary>
      /// <param name="latitude"></param>
      /// <param name="longitude"></param>
      /// <param name="radius"></param>
      /// <returns></returns>
      public List<RetailStore> Get()
      {
         Debugger.Break();

         List<RetailStore> result = new List<RetailStore>();

         result.Add(new RetailStore 
         { 
            BusinessName = "May Company",
            StreetAddress = "195 W Esplanade Dr.",
            UnitAddress = "Suite 1",
            City = "Oxnard",
            StateProvince = "California",
            PostalCode = "93036"
         });

         result.Add(new RetailStore
         {
            BusinessName = "The Broadway",
            StreetAddress = "3301 E Main St.",
            UnitAddress = "Suite A",
            City = "Ventura",
            StateProvince = "California",
            PostalCode = "93003"
         });

         return result;
      }
   }
}