﻿using System;
using System.Web.UI;
using System.Security.Principal;

namespace FifteenThings.Website.Secure
{
   #region Principal Object

   public class CustomPrincipal : IPrincipal
   {
      public bool HasPermission(string perm)
      {
         return false;
      }

      public IIdentity Identity
      {
         get { throw new NotImplementedException(); }
      }

      public bool IsInRole(string role)
      {
         throw new NotImplementedException();
      }
   }

   #endregion

   public partial class Default : System.Web.UI.Page
   {
      protected override void OnInit(EventArgs e)
      {
         base.OnInit(e);

         CustomPrincipal principal = (CustomPrincipal)Page.User;
         
         if (!principal.HasPermission("SecurePage"))
         {
            Response.Redirect("~/Public/AccessDenied.aspx");
         }

      }

      protected void Page_Load(object sender, EventArgs e)
      {
         // Nothing to see here
      }
   }
}