﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FifteenThings.BusinessLayer
{
   class Sample12_Strings
   {
      public void Example01()
      {
         string message;
         Employee employee;

         employee = 
            new Employee 
               { FirstName = "John", 
                 Title = "Sr. Software Engineer",
                 CompanyName = "PDSA, Inc." };

         message =
            string.Format(
               "Hello, my name is {0} and I am a {1} with {2}",
                employee.FirstName,
                employee.Title,
                employee.CompanyName);
      }

      public void Example02()
      {
         StringBuilder sb = new StringBuilder(1024);
         Employee employee;
          
         employee = 
            new Employee 
               { FirstName = "John", 
                 Title = "Sr. Software Engineer",
                 CompanyName = "PDSA, Inc." };
         
         sb = new StringBuilder(1024);
         sb.AppendFormat("Name:{0}, Title: {1}/n", employee.FirstName, employee.Title);
         sb.AppendFormat("{0}/n", string.Empty.PadLeft(80, '-'));

         // return sb.ToString()
      }

      
   }

   #region Supporting Classes

   public class ResourceManager
   {
      public string GetResource(string key)
      {
         string result = string.Empty;

         // Go get the resource from storage and then cache
         // it so you don't have to get it again

         return result;
      }
   }

   public class Employee
   {
      public string FirstName { get; set; }
      public string Title { get; set; }
      public string CompanyName { get; set; }
   }

   #endregion
}
