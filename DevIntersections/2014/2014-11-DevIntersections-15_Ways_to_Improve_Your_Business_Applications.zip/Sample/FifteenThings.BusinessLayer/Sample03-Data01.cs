﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FifteenThings.BusinessLayer
{
   public class Sample03_Data01
   {
      public void ProcessCustomers()
      {
         CustomerManager manager;

         manager = new CustomerManager();
         CustomerCollection customers = manager.GetCustomers(customerType:1);

         foreach (Customer customer in customers)
         {
            // Do something
         }
      }
   }

   #region Supporting Classes

   public class Customer
   {
      public string CompanyName { get; set; }

      public decimal CreditLimit { get; set; }
   }

   public class CustomerCollection : List<Customer>
   {
      public decimal GetCustomerBalances()
      {
         decimal result = 500;

         foreach (var c in this)
         {
            result = result + c.CreditLimit;
         }

         // this.ForEach()

         return result;
      }
   }

   public class CustomerManager
   {
      public CustomerCollection GetCustomers(int customerType)
      {
         CustomerCollection result = new CustomerCollection();

         // Get the customers out of storage where CustomerType = customerType 

         // Convert whatever you get back (data reader, table, dataset) to a 
         // custom collection and then return the result

         // Many tools, such as PDSA's Haystack Code Generator for .NET,
         // will do this for you.

         return result;
      }

      internal void Save(Customer customer)
      {
         throw new NotImplementedException();
      }
   }

   #endregion
}
