﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Principal;

namespace FifteenThings.BusinessLayer
{
   public class Sample01_Security
   {

      public void DoSomething()
      {
         CustomPrincipal prin = new CustomPrincipal();

         if (prin.HasPermission("CustomerEntryForm"))
         {
            // Allow access to form
         }
      }

      public AuthResult Authenticate(string userName, string password)
      {
         AuthResult result = AuthResult.Invalid;

         UserManager manager = new UserManager();
         User user = manager.GetUser(userName);

         // Hash the value entered and then compare to the value retrieved

         if (user.Password.Equals(HashManager.GetHash(password, user.UserId.ToString())))
         {
            result = AuthResult.Valid;
         }

         return result;
      }
   }

   #region Supporting Classes

   public enum AuthResult
   {
      Valid,
      Invalid
   }

   public class User
   {
      public int UserId { get; set; }
      public string Password { get; set; }
      public string SocialSecurityNumber { get; set; }
   }

   public class UserManager
   {
      public User GetUser(string userName)
      {
         User result = new User();

         // 'ITRW' -- Get user from the database

         return result;
      }

      public void Save(User user)
      {
         user.SocialSecurityNumber = CryptoManager.Encrypt(user.SocialSecurityNumber);

         // now store the user data in the database
      }

      public List<string> GetRoles(int userId)
      {
         List<string> result = new List<string>();

         // Get the list of roles for this user from the roles store

         return result;
      }

      public List<string> GetPermissions(List<string> roles)
      {
         List<string> result = new List<string>();

         // Get the list of permissions for these roles from the permissions store

         return result;
      }
   }

   /// <summary>
   /// Hypothetical encryption manager to encapsulate your crypto algorithm
   /// </summary>
   public class CryptoManager
   {
      public static string Encrypt(string value)
      {
         string result = string.Empty;

         // Use a crypto algorithm such as Triple DES to encrypt the value
         // and then return the result

         // Remember to store the key and initialization vector in a config file,
         // registry or protected storage -- not in the code!

         return result;
      }
   }

   /// <summary>
   /// Hypothetical hash manager to encapsulate your hash algorithm
   /// </summary>
   public class HashManager
   {
      public static string GetHash(string value, string salt)
      {
         string result = string.Empty;

         // Use a hash algorithm such as SHA256 to hash the value
         // and then return the hashed result

         return result;
      }
   }

   /// <summary>
   /// 
   /// </summary>
   public class CustomPrincipal : IPrincipal
   {
      private List<string> _roles;
      private List<string> _permissions;
      private IIdentity _identity;

      public CustomPrincipal()
      {

      }

      public CustomPrincipal(IIdentity identity, List<string> roles, List<string> permissions)
      {
         _identity = identity;
         _roles = roles;
         _permissions = permissions;
      }

      #region IPrincipal Members

      public IIdentity Identity
      {
         get { return _identity; }
      }

      public bool IsInRole(string role)
      {
         return _roles.Contains(role);
      }

      public bool HasPermission(string permission)
      {
         return _permissions.Contains(permission);
      }

      #endregion
   }


   #endregion
}
