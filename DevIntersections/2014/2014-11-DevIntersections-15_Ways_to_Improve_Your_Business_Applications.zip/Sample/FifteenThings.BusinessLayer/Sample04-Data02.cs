﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace FifteenThings.BusinessLayer
{
   #region Repository Approach

   public interface ICustomerRepository
   {
      Customer Find(int id);

   }

   public class CustomerRepo : ICustomerRepository
   {

      public Customer Find(int id)
      {
         // Write code to get EF/ORM customer entity and return it

         // Of course, don't do this...
         return new Customer();
      }
   }

   #endregion

   public class Sample04_Data02
   {
      public void GetData()
      {
         IDataReader reader = null;

         try
         {
            reader = DataLayer.GetDataReader(" SELECT * FROM Product ", "Server=localhost;Database=PDSASamples;Integrated Security=true;");

            // DataSet ds = DataLayer.GetDataSet("");
         }
         catch (Exception)
         {
            throw;
         }
         finally 
         {
            if (reader != null)
            {
               if (! reader.IsClosed)
               {
                  reader.Close();
               }
            }
         }
      }
   }

   #region Supporting Classes

   public class DataLayer
   {
      public static DataSet GetDataSet(string sql, string connectString)
      {
         DataSet ds = new DataSet();
         IDbDataAdapter da;
         da = CreateDataAdapter(sql, connectString);
         da.Fill(ds);
         return ds;
      }

      public static DataTable GetDataTable(string sql, string connectString)
      {
         DataSet ds = new DataSet();
         DataTable dt = null;
         ds = GetDataSet(sql, connectString);
         if (ds.Tables.Count > 0)
            dt = ds.Tables[0];
         return dt;
      }

      public static IDataReader GetDataReader(string sql, string connectString)
      {
         IDataReader dr;
         IDbCommand cmd = null;

         try
         {
            // Create Command with Connection Object
            cmd = CreateCommand(sql, connectString);

            // Create the DataReader
            dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
         }
         catch
         {
            // If there is an exception, close the connection
            if (cmd.Connection.State != ConnectionState.Closed)
            {
               cmd.Connection.Close();
               cmd.Connection.Dispose();
            }

            // Dispose of the Command
            cmd.Dispose();

            // Rethrow the exception
            throw;
         }

         return dr;
      }

      public static Object ExecuteScalar(string sql, string connectString)
      {
         IDbCommand cmd = null;
         Object value = null;

         try
         {
            // Create Command with Connection Object
            cmd = CreateCommand(sql, connectString);

            // Execute sql
            value = cmd.ExecuteScalar();
         }
         catch
         {
            throw;
         }

         finally
         {
            // Close the connection
            if (cmd.Connection.State == ConnectionState.Open)
               cmd.Connection.Close();

            // Dispose of the Objects
            cmd.Connection.Dispose();
            cmd.Dispose();
         }

         return value;
      }

      public static int ExecuteSQL(IDbCommand cmd, bool DisposeOfCommand)
      {
         int intRows = 0;
         bool boolOpen = false;

         try
         {
            // Open the Connection
            if (cmd.Connection.State != ConnectionState.Open)
            {
               cmd.Connection.Open();
            }
            else
            {
               boolOpen = !DisposeOfCommand;
            }

            // Execute sql
            intRows = cmd.ExecuteNonQuery();
         }
         catch
         {
            throw;
         }
         finally
         {
            if (!boolOpen)
            {
               // Close the connection
               if (cmd.Connection.State == ConnectionState.Open)
               {
                  cmd.Connection.Close();
               }
               // Dispose of the Objects
               cmd.Connection.Dispose();
            }
            if (DisposeOfCommand)
               cmd.Dispose();
         }

         return intRows;
      }

      public static int ExecuteSQL(IDbCommand cmd)
      {
         return ExecuteSQL(cmd, false);
      }

      public static int ExecuteSQL(string sql, string connectString)
      {

         IDbCommand cmd = null;
         int intRows;

         cmd = CreateCommand(sql, connectString);

         // Execute sql
         intRows = ExecuteSQL(cmd, true);

         return intRows;
      }

      public static IDbConnection CreateConnection(string connectString)
      {
         IDbConnection cnn;

         cnn = DataProvider.CreateConnection();
         cnn.ConnectionString = connectString;

         return cnn;
      }

      public static IDbCommand CreateCommand(string sql)
      {
         IDbCommand cmd;

         cmd = DataProvider.CreateCommand();

         cmd.CommandText = sql;

         return cmd;
      }

      public static IDbCommand CreateCommand(string sql, string connectString)
      {
         return CreateCommand(sql, connectString, true);
      }

      public static IDbCommand CreateCommand(string sql, string connectString, bool OpenConnection)
      {
         IDbCommand cmd;

         cmd = CreateCommand(sql);

         cmd.Connection = CreateConnection(connectString);
         if (OpenConnection)
         {
            cmd.Connection.Open();
         }

         return cmd;
      }

      public static IDataParameter CreateParameter(string ParameterName)
      {
         IDataParameter param;

         param = DataProvider.CreateParameter();
         param.ParameterName = ParameterName;

         return param;
      }

      public static IDataParameter CreateParameter(string ParameterName, DbType DataType)
      {
         IDataParameter param;

         param = DataProvider.CreateParameter();
         param.DbType = DataType;
         param.ParameterName = ParameterName;

         return param;
      }

      public static IDataParameter CreateParameter(string ParameterName, DbType DataType, Object Value)
      {
         IDataParameter param;

         param = DataProvider.CreateParameter();
         param.DbType = DataType;
         param.Value = Value;
         param.ParameterName = ParameterName;

         return param;
      }

      public static IDbDataAdapter CreateDataAdapter(string sql, string connectString)
      {
         IDbDataAdapter da;

         da = DataProvider.CreateDataAdapter();
         da.SelectCommand = CreateCommand(sql, connectString, false);

         return da;
      }
   }

   public class DataProvider
   {
      #region SQL Server Methods

      public static IDbConnection CreateConnection()
      {
         SqlConnection cnn = new SqlConnection();

         return cnn;
      }

      public static IDbCommand CreateCommand()
      {
         SqlCommand cmd = new SqlCommand();

         return cmd;
      }

      public static IDataParameter CreateParameter()
      {
         SqlParameter param = new SqlParameter();

         return param;
      }

      public static IDbDataAdapter CreateDataAdapter()
      {
         SqlDataAdapter da = new SqlDataAdapter();

         return da;
      }

      #endregion
   }

   #endregion
}
