﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics;

namespace FifteenThings.BusinessLayer
{
   #region Sample Customer Class

   public class CustomerWithValidation
   {
      [Required]
      public decimal? CreditLimit { get; set; }
   }

   #endregion

   public class Sample16_Validation
   {
      public void Save(CustomerWithValidation customer)
      {
         ValidationContext ctx;

         try
         {
            ctx = new ValidationContext(customer);
            Validator.ValidateObject(customer, ctx);
         }
         catch (ValidationException ex)
         {
            Debug.WriteLine(ex.ValidationResult.ErrorMessage);
         }
      }
   }
}
