﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FifteenThings.Tests
{
   [TestClass]
   public class TestSomething
   {
      [TestMethod]
      public void given_when_then()
      {

      }
   }
}
