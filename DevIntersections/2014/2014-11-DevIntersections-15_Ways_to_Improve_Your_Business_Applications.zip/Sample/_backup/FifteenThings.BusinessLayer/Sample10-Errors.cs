﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FifteenThings.BusinessLayer
{
   public class Sample10_Errors
   {
      ExampleTenViewModel _viewModel;

      public Sample10_Errors()
      {
         _viewModel = new ExampleTenViewModel();
      }

      public void MakeBelieveUserInterface()
      {
         try
         {

         }
         catch (Exception ex)
         {
            string message = ex.Message;


            throw;
         }

         _viewModel.DoSomethingDangerous();

         if (_viewModel.HasErrors)
         {
            this.Show(_viewModel.UserFriendlyMessage);
         }
      }

      private void Show(string message)
      {
         // Display the message
      }
   }

   public class ExampleTenViewModel
   {
      public void DoSomethingDangerous()
      {
         int i;
         int j;
         double result;

         try
         {
            i = 1;
            j = 0;
            result = i / j;
         }
         catch (Exception ex)
         {
            ExceptionManager.Publish(ex);
            this.HasErrors = true;
            this.UserFriendlyMessage = "An error occurred while trying to do something dangerous.";
            this.TechnicalMessage = ex.Message;
         }
      }

      public bool HasErrors { get; set; }
      public string UserFriendlyMessage { get; set; }
      public string TechnicalMessage { get; set; }
   }

   #region Supporting Classes

   public class ExceptionManager
   {
      static LogProvider Logger { get; set; }

      public static void Publish(Exception ex)
      {
         Logger.Log(ExceptionFormatter.FormatForLog(ex));
      }
   }

   public class ExceptionFormatter
   {
      public static string FormatForLog(Exception ex)
      {
         string result = string.Empty;

         // Build the string representation of 
         // the exception properties and inner exceptions.

         return result;
      }
   }

   public class LogProvider
   {
      public void Log(string message)
      {
         // Write the message to your favorite log target
      }
   }

   #endregion

}
