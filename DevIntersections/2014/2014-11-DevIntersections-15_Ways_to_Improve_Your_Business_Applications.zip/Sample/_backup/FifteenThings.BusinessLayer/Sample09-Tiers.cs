﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FifteenThings.BusinessLayer
{
   class Sample09_Tiers
   {
      private InvoiceViewModel _viewModel;

      public Sample09_Tiers()
      {
         _viewModel = new InvoiceViewModel();
      }

      public void MakeBelieveUserInterface()
      {
         _viewModel.HandleSaveButtonClick();
      }
   }

   /// <summary>
   /// View model layer knows nothing about data layer
   /// </summary>
   public class InvoiceViewModel
   {
      public Invoice Invoice { get; set; }

      public void HandleSaveButtonClick()
      {
         InvoiceManager manager;

         manager = new InvoiceManager();
         manager.Save(this.Invoice);
      }
   }

   /// <summary>
   /// Entity class representing an invoice
   /// </summary>
   public class Invoice
   {
      public int InvoiceId { get; set; }
      public int InvoiceType { get; set; }
   }

   /// <summary>
   /// Business layer only 'knows' about data layer
   /// </summary>
   public class InvoiceManager
   {
      public void Save(Invoice invoice)
      {
         InvoiceData data;

         data = new InvoiceData();
         data.Insert(invoice);
      }
   }

   /// <summary>
   /// Data layer only 'knows' about entity
   /// </summary>
   public class InvoiceData
   {
      public void Insert(Invoice invoice)
      {
         // Use SQL code or ORM features here ONLY
      }
   }
}
