﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;

namespace FifteenThings.BusinessLayer
{
   public class Sample07_Settings
   {
      public void WriteFile()
      {
         string fileName = string.Empty;
         string content = string.Empty;

         fileName = Path.Combine(AppSettings.OutputPath,
            string.Format("{0}.{1}", Guid.NewGuid(), "txt"));

         File.WriteAllText(fileName, content);
      }
   }

   #region Supporting Classes

   public class AppSettings
   {
      private static string _outputPath = string.Empty;

      public static string OutputPath
      {
         get
         {
            _outputPath = ConfigProvider.GetValue("OutputPath");
            return _outputPath;
         }
      }
   }

   public class ConfigProvider
   {
      internal static string GetValue(string name)
      {
         // check cache, else get from configuration

         // could have multiple sources available: file, .config, db, etc.

         return ConfigurationManager.AppSettings[name];
      }
   }


   #endregion
}
