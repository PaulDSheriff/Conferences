﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FifteenThings.BusinessLayer
{
   class Sample11_Reinvent
   {
      // Do not re-invent the wheel.

      // Use standard .NET components when possible.

      // Use commercial off the shelf when necessary.

      // Write your own custom components as a last resort.
   }
}
