﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FifteenThings.BusinessLayer
{
   public class Sample06_Code
   {

      // Use basic functional decomposition to create readable,
      // maintainable code.

      public void ProcessInvoices()
      {
         BillingManager manager;
         BillableActivityCollection activity;

         manager = new BillingManager();
         activity = manager.GetBillableActivity();
         foreach (BillableActivity item in activity)
         {
            switch (item.ActivityType)
            {
               case BillableActivity.Types.Invoice:
                  manager.CreateInvoice(item);
                  break;
               case BillableActivity.Types.CreditMemo:
                  manager.CreateCreditMemo(item);
                  break;
               case BillableActivity.Types.DebitMemo:
                  manager.CreateDebitMemo(item);
                  break;
               case BillableActivity.Types.WriteOff:
                  manager.CreateWriteOff(item);
                  break;
            }
         }
      }
   }

   #region Supporting Classes

   public class BillingManager
   {
      internal BillableActivityCollection GetBillableActivity()
      {
         throw new NotImplementedException();
      }

      internal void CreateInvoice(BillableActivity item)
      {
         throw new NotImplementedException();
      }

      internal void CreateCreditMemo(BillableActivity item)
      {
         throw new NotImplementedException();
      }

      internal void CreateDebitMemo(BillableActivity item)
      {
         throw new NotImplementedException();
      }

      internal void CreateWriteOff(BillableActivity item)
      {
         throw new NotImplementedException();
      }
   }

   public class BillableActivity
   {
      public class Types
      {
         public const int Invoice = 1;
         public const int CreditMemo = 2;
         public const int DebitMemo = 3;
         public const int WriteOff = 4;
      }

      public int ActivityType { get; set; }
   }

   public class BillableActivityCollection : List<BillableActivity>
   {
   }

   #endregion
}
