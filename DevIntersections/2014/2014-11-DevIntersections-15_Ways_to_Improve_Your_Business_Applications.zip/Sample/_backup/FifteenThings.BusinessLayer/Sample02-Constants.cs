﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FifteenThings.BusinessLayer
{
   public class Sample02_Constants
   {
      const int PRODUCT_TYPE_NEW_PRODUCT = 1;

      /// <summary>
      /// At a minimum, used a named constant
      /// </summary>
      public void DoSomething()
      {
         ProductManager manager;

         manager = new ProductManager();
         Product prod = manager.GetProduct(1);

         if (prod.ProductType == PRODUCT_TYPE_NEW_PRODUCT)
         {
            // Do something else...
         }
      }

      /// <summary>
      /// Better yet, encapsulate it so you can use it everywhere
      /// </summary>
      public void DoSomethingElse()
      {
         ProductManager manager;

         manager = new ProductManager();
         Product prod = manager.GetProduct(1);

         if (prod.ProductType == Product.ProductTypeTwo)
         {
            // Do something else...
         }
      }
   }

   #region Supporting Classes

   public class Product
   {
      const int PRODUCT_TYPE_ONE = 1;

      public int ProductType { get; set; }

      public static int ProductTypeOne { get { return PRODUCT_TYPE_ONE; } }

      /// <summary>
      /// Event better yet, get it out of storage 
      /// so you can change it later if necessary
      /// </summary>
      public static int ProductTypeTwo
      {
         get
         {
            ValueManager manager = new ValueManager();
            return manager.GetValue("PRODUCT_TYPE_TWO");
         }
      }
   }

   public class ProductManager
   {
      public Product GetProduct(int productId)
      {
         Product result = new Product();

         return result;
      }
   }

   public class ValueManager
   {
      public int GetValue(string name)
      {
         int result = -1;

         // get the expected value from storage and then 
         // cache it so you do not have to go get it again

         return result;
      }
   }
   #endregion
}
