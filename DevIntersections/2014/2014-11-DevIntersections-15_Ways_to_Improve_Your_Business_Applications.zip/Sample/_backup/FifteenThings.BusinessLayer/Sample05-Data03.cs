﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace FifteenThings.BusinessLayer
{
   public class Sample05_Data03
   {
      public void SaveOrder()
      {
         Order order;
         OrderData data;

         order = new Order();
         order.Items.Add(new OrderItem());
         data = new OrderData();

         data.Insert(order);
      }
   }

   #region Black Boxes

   public class OrderData
   {
      public void Insert(Order order)
      {
         IDataParameter parm = DataLayer.CreateParameter("@OrderId");

         // Go ahead and call DbContext
      }
   }

   public class OrderItemData
   {
      public void SaveItems(List<OrderItem> itemList)
      {
      }
   }

   #endregion

   #region Supporting Classes

   public class Order
   {
      public Order()
      {
         this.Items = new List<OrderItem>();
      }

      public int OrderId { get; set; }
      public List<OrderItem> Items { get; set; }
   }

   public class OrderItem
   {
      public int ProductId { get; set; }
      public int Quantity { get; set; }
      public double Price { get; set; }
   }

   #endregion
}
