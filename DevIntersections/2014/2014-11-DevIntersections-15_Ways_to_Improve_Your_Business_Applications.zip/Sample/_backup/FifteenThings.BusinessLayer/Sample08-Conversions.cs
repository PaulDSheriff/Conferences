﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FifteenThings.BusinessLayer
{
   public class Sample08_Conversions
   {
      public void SaveData(string customerName, string creditLimit)
      {
         // Values are coming from somewhere -- i.e., the UI

         Customer customer;
         CustomerManager manager;

         decimal limit = decimal.MinusOne;

         if (!decimal.TryParse(creditLimit, out limit))
         {
            throw new CustomerValidationException(
               "'{0}' is not a valid value for credit limit.");
         }

         customer = new Customer();
         customer.CompanyName = customerName;
         customer.CreditLimit = limit;
         
         manager = new CustomerManager();
         manager.Save(customer);
      }
   }

   #region Supporting Classes

   public class CustomerValidationException : Exception
   {
      public CustomerValidationException(string message) : base(message) {}
   }

   #endregion
}
