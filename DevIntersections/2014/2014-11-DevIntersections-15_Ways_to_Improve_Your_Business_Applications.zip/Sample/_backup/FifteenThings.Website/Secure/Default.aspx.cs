﻿using System;
using System.Web.UI;
using FifteenThings.BusinessLayer;

namespace FifteenThings.Website.Secure
{
   public partial class Default : System.Web.UI.Page
   {
      protected override void OnInit(EventArgs e)
      {
         base.OnInit(e);

         CustomPrincipal principal = (CustomPrincipal)Page.User;

         
         if (!principal.HasPermission("SecurePage"))
         {
            Response.Redirect("~/Public/AccessDenied.aspx");
         }

      }

      protected void Page_Load(object sender, EventArgs e)
      {
         // Nothing to see here
      }
   }
}