﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using FifteenThings.BusinessLayer;

namespace FifteenThings.Website
{
   public class Global : System.Web.HttpApplication
   {
      void Application_Start(object sender, EventArgs e)
      {
         // Code that runs on application startup

      }

      void Application_End(object sender, EventArgs e)
      {
         //  Code that runs on application shutdown

      }

      void Application_Error(object sender, EventArgs e)
      {
         // Code that runs when an unhandled error occurs

      }

      void Application_AuthenticateRequest(object sender, EventArgs e)
      {
         User user;
         List<string> roles;
         List<string> permissions;
         UserManager manager;
         string userName;
            
         if (HttpContext.Current.User != null)
         {
            if (HttpContext.Current.User.Identity.IsAuthenticated)
            {
               userName = HttpContext.Current.User.Identity.Name;
               manager = new UserManager();
               user = manager.GetUser(userName);
               roles = manager.GetRoles(user.UserId);
               permissions = manager.GetPermissions(roles);

               CustomPrincipal principal =
                  new CustomPrincipal(HttpContext.Current.User.Identity,
                     roles, permissions);

               HttpContext.Current.User = principal;
            }
         }
      }

      void Session_Start(object sender, EventArgs e)
      {
         // Code that runs when a new session is started

      }

      void Session_End(object sender, EventArgs e)
      {
         // Code that runs when a session ends. 
         // Note: The Session_End event is raised only when the sessionstate mode
         // is set to InProc in the Web.config file. If session mode is set to StateServer 
         // or SQLServer, the event is not raised.

      }

   }
}
