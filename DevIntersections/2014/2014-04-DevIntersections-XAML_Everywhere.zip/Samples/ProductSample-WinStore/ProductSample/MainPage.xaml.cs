﻿using PDSA.MessageBroker;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace ProductSample
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();

            // Initialize the Message Broker Events
            (Application.Current as App).MessageBroker.MessageReceived +=
             new MessageReceivedEventHandler(MessageBroker_MessageReceived);
        }

        void MessageBroker_MessageReceived(object sender, PDSAMessageBrokerEventArgs e)
        {
          switch (e.MessageName)
          {
            case "ProductList":
              ContentPanel.Children.Clear();
              ContentPanel.Children.Add(new ProductList());
              break;

            case "ProductDetail":
              ProductDetail uc = new ProductDetail();
              // Set DataContext to the Product object
              uc.DataContext = e.Message.MessageBody;

              ContentPanel.Children.Clear();
              ContentPanel.Children.Add(uc);
              break;
          }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
          ContentPanel.Children.Add(new ProductList());
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.  The Parameter
        /// property is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }
    }
}
