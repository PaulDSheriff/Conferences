﻿using PDSA.MessageBroker;
using ProductViewModels;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

// The User Control item template is documented at http://go.microsoft.com/fwlink/?LinkId=234236

namespace ProductSample
{
  public sealed partial class ProductList : UserControl
  {
    private ProductViewModel _ViewModel;

    public ProductList()
    {
      this.InitializeComponent();

      _ViewModel = (ProductViewModel)this.Resources["viewModel"];
    }

    private void btnEdit_Click(object sender, RoutedEventArgs e)
    {
      // Set the current Record
      lstData.SelectedItem = ((Button)sender).DataContext;

      PDSAMessageBrokerMessage arg = new PDSAMessageBrokerMessage();

      arg.MessageName = "ProductDetail";
      arg.MessageBody = lstData.SelectedItem;

      // Send message
      (Application.Current as App).MessageBroker.SendMessage(arg);
    }
  }
}
