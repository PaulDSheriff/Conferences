﻿namespace ProductEntity
{
  public class Product : Common.Library.CommonBase
  {
    #region Private Variables
    private int _ProductId = 0;
    private string _ProductName = string.Empty;
    private string _ProductType = string.Empty;
    private decimal _Price = 0;
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set ProductId
    /// </summary>
    public int ProductId
    {
      get { return _ProductId; }
      set
      {
        if (_ProductId != value)
        {
          _ProductId = value;
          RaisePropertyChanged("ProductId");
        }
      }
    }

    /// <summary>
    /// Get/Set ProductName
    /// </summary>
    public string ProductName
    {
      get { return _ProductName; }
      set
      {
        if (_ProductName != value)
        {
          _ProductName = value;
          RaisePropertyChanged("ProductName");
        }
      }
    }

    /// <summary>
    /// Get/Set ProductType
    /// </summary>
    public string ProductType
    {
      get { return _ProductType; }
      set
      {
        if (_ProductType != value)
        {
          _ProductType = value;
          RaisePropertyChanged("ProductType");
        }
      }
    }

    /// <summary>
    /// Get/Set Price
    /// </summary>
    public decimal Price
    {
      get { return _Price; }
      set
      {
        if (_Price != value)
        {
          _Price = value;
          RaisePropertyChanged("Price");
        }
      }
    }
    #endregion

    #region Override of ToString
    public override string ToString()
    {
      return ProductName;
    }
    #endregion
  }
}
