﻿using System.Windows;

namespace FirstSamples
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnSample1_Click(object sender, RoutedEventArgs e)
    {
      Sample1_AbsPosition win = new Sample1_AbsPosition();

      win.Show();
    }

    private void btnSample2_Click(object sender, RoutedEventArgs e)
    {
      Sample2_Grid win = new Sample2_Grid();

      win.Show();
    }

    private void btnSample3_Click(object sender, RoutedEventArgs e)
    {
      Sample3_GridResizeMargin win = new Sample3_GridResizeMargin();

      win.Show();
    }

    private void btnSample4_Click(object sender, RoutedEventArgs e)
    {
      Sample4_StackPanel win = new Sample4_StackPanel();

      win.Show();
    }

    private void btnSample5_Click(object sender, RoutedEventArgs e)
    {
      Sample5_Canvas win = new Sample5_Canvas();

      win.Show();
    }
       
    private void btnSample6_Click(object sender, RoutedEventArgs e)
    {
      Sample6_MarginPadding win = new Sample6_MarginPadding();

      win.Show();
    }
  }
}
