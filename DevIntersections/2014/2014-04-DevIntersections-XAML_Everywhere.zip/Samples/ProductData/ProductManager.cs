﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using ProductEntity;

namespace ProductData
{
    public class ProductManager
    {
      public List<Product> GetProducts()
      {
        List<Product> ret;

        XElement elem = XElement.Parse(CreateProductXml());

        var items = from prod in elem.Descendants("Product")
                    select new Product
                    {
                      ProductId = Convert.ToInt32(prod.Element("ProductId").Value),
                      ProductName = prod.Element("ProductName").Value,
                      ProductType = prod.Element("ProductType").Value,
                      Price = Convert.ToDecimal(prod.Element("Price").Value)
                    };

        ret = new List<Product>(items);

        return ret;
      }

      #region CreateProductXml Method
      private string CreateProductXml()
      {
        StringBuilder sb = new StringBuilder(2844);

        sb.Append("<?xml version=\"1.0\" standalone=\"yes\"?>");
        sb.Append(@"<Products>");
        sb.Append(@"  <Product>");
        sb.Append(@"    <ProductId>1</ProductId>");
        sb.Append(@"    <ProductName>Haystack Code Generator for .NET</ProductName>");
        sb.Append(@"    <Price>799</Price>");
        sb.Append(@"    <ProductType>Product</ProductType>");
        sb.Append(@"  </Product>");
        sb.Append(@"  <Product>");
        sb.Append(@"    <ProductId>2</ProductId>");
        sb.Append(@"    <ProductName>PDSA .NET Productivity Framework V5.0</ProductName>");
        sb.Append(@"    <Price>2500</Price>");
        sb.Append(@"    <ProductType>Product</ProductType>");
        sb.Append(@"  </Product>");
        sb.Append(@"  <Product>");
        sb.Append(@"    <ProductId>3</ProductId>");
        sb.Append(@"    <ProductName>Architecting ASP.NET Applications eBook</ProductName>");
        sb.Append(@"    <Price>20</Price>");
        sb.Append(@"    <ProductType>Book</ProductType>");
        sb.Append(@"  </Product>");
        sb.Append(@"  <Product>");
        sb.Append(@"    <ProductId>4</ProductId>");
        sb.Append(@"    <ProductName>Fundamentals of N-Tier eBook</ProductName>");
        sb.Append(@"    <Price>20</Price>");
        sb.Append(@"    <ProductType>Book</ProductType>");
        sb.Append(@"  </Product>");
        sb.Append(@"  <Product>");
        sb.Append(@"    <ProductId>5</ProductId>");
        sb.Append(@"    <ProductName>Security for ASP.NET Developers eBook</ProductName>");
        sb.Append(@"    <Price>20</Price>");
        sb.Append(@"    <ProductType>Book</ProductType>");
        sb.Append(@"  </Product>");
        sb.Append(@"  <Product>");
        sb.Append(@"    <ProductId>6</ProductId>");
        sb.Append(@"    <ProductName>VB.NET Fundamentals eBook</ProductName>");
        sb.Append(@"    <Price>10</Price>");
        sb.Append(@"    <ProductType>Book</ProductType>");
        sb.Append(@"  </Product>");
        sb.Append(@"  <Product>");
        sb.Append(@"    <ProductId>7</ProductId>");
        sb.Append(@"    <ProductName>Fundamentals of SQL Server 2008</ProductName>");
        sb.Append(@"    <Price>12</Price>");
        sb.Append(@"    <ProductType>Book</ProductType>");
        sb.Append(@"  </Product>");
        sb.Append(@"  <Product>");
        sb.Append(@"    <ProductId>8</ProductId>");
        sb.Append(@"    <ProductName>Architecting ASP.NET eBook</ProductName>");
        sb.Append(@"    <Price>20</Price>");
        sb.Append(@"    <ProductType>Book</ProductType>");
        sb.Append(@"  </Product>");
        sb.Append(@"  <Product>");
        sb.Append(@"    <ProductId>9</ProductId>");
        sb.Append(@"    <ProductName>Silverlight XAML for the Complete Novice - Part 1</ProductName>");
        sb.Append(@"    <Price>20</Price>");
        sb.Append(@"    <ProductType>Video</ProductType>");
        sb.Append(@"  </Product>");
        sb.Append(@"  <Product>");
        sb.Append(@"    <ProductId>10</ProductId>");
        sb.Append(@"    <ProductName>Silverlight XAML for the Complete Novice - Part 2</ProductName>");
        sb.Append(@"    <Price>20</Price>");
        sb.Append(@"    <ProductType>Video</ProductType>");
        sb.Append(@"  </Product>");
        sb.Append(@"  <Product>");
        sb.Append(@"    <ProductId>11</ProductId>");
        sb.Append(@"    <ProductName>Silverlight MVVM Made Easy</ProductName>");
        sb.Append(@"    <Price>20</Price>");
        sb.Append(@"    <ProductType>Video</ProductType>");
        sb.Append(@"  </Product>");
        sb.Append(@"  <Product>");
        sb.Append(@"    <ProductId>12</ProductId>");
        sb.Append(@"    <ProductName>PDSA .NET Performance Audit</ProductName>");
        sb.Append(@"    <Price>2500</Price>");
        sb.Append(@"    <ProductType>Service</ProductType>");
        sb.Append(@"  </Product>");
        sb.Append(@"  <Product>");
        sb.Append(@"    <ProductId>13</ProductId>");
        sb.Append(@"    <ProductName>PDSA .NET Security Audit</ProductName>");
        sb.Append(@"    <Price>3000</Price>");
        sb.Append(@"    <ProductType>Service</ProductType>");
        sb.Append(@"  </Product>");
        sb.Append(@"  <Product>");
        sb.Append(@"    <ProductId>14</ProductId>");
        sb.Append(@"    <ProductName>PDSA .NET SQL Server Audit</ProductName>");
        sb.Append(@"    <Price>2500</Price>");
        sb.Append(@"    <ProductType>Service</ProductType>");
        sb.Append(@"  </Product>");
        sb.Append(@"  <Product>");
        sb.Append(@"    <ProductId>15</ProductId>");
        sb.Append(@"    <ProductName>Introduction To Windows Phone Development</ProductName>");
        sb.Append(@"    <Price>20</Price>");
        sb.Append(@"    <ProductType>Video</ProductType>");
        sb.Append(@"  </Product>");
        sb.Append(@"</Products>");

        return sb.ToString();
      }
      #endregion
    }
}
