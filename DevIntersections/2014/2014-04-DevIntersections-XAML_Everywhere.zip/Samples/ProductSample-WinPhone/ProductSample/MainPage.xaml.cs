﻿using System.Windows;
using Microsoft.Phone.Controls;
using PDSA.MessageBroker;

namespace ProductSample
{
  public partial class MainPage : PhoneApplicationPage
  {
    // Constructor
    public MainPage()
    {
      InitializeComponent();

      // Initialize the Message Broker Events
      (Application.Current as App).MessageBroker.MessageReceived +=
       new MessageReceivedEventHandler(MessageBroker_MessageReceived);
    }

    void MessageBroker_MessageReceived(object sender, PDSAMessageBrokerEventArgs e)
    {
      switch (e.MessageName)
      {
        case "ProductList":
          PageTitle.Text = "Product List";

          ContentPanel.Children.Clear();
          ContentPanel.Children.Add(new ProductList());
          break;

        case "ProductDetail":
          PageTitle.Text = "Product";

          ProductDetail uc = new ProductDetail();
          // Set DataContext to the Product object
          uc.DataContext = e.Message.MessageBody;

          ContentPanel.Children.Clear();
          ContentPanel.Children.Add(uc);
          break;

      }
    }

    private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
    {
      ContentPanel.Children.Add(new ProductList());
    }
  }
}