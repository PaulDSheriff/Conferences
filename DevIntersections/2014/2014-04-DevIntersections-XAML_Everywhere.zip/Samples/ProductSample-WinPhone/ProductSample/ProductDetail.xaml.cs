﻿using System.Windows;
using System.Windows.Controls;
using PDSA.MessageBroker;

namespace ProductSample
{
  public partial class ProductDetail : UserControl
  {
    public ProductDetail()
    {
      InitializeComponent();
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      PDSAMessageBrokerMessage arg = new PDSAMessageBrokerMessage();

      arg.MessageName = "ProductList";
      
      // Send message
      (Application.Current as App).MessageBroker.SendMessage(arg);
    }
  }
}
