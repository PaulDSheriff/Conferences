﻿using System.Windows;

namespace StylesSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnSample1_Click(object sender, RoutedEventArgs e)
    {
      Sample1_HardCodedStyles win = new Sample1_HardCodedStyles();

      win.Show();
    }

    private void btnSample2_Click(object sender, RoutedEventArgs e)
    {
      Sample2_StackPanelResources win = new Sample2_StackPanelResources();

      win.Show();
    }

    private void btnSample3_Click(object sender, RoutedEventArgs e)
    {
      Sample3_WindowResources win = new Sample3_WindowResources();

      win.Show();
    }
  }
}
