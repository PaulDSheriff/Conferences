﻿Make sure you use Mode="TwoWay" in the SelectedValue

Need to install Microsoft.Bcl.Async using NuGet