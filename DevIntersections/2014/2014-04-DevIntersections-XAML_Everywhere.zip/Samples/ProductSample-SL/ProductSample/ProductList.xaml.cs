﻿using System.Windows;
using System.Windows.Controls;
using PDSA.MessageBroker;
using ProductViewModels;

namespace ProductSample
{
  public partial class ProductList : UserControl
  {
    private ProductViewModel _ViewModel;

    #region Constructor

    #endregion

    public ProductList()
    {
      InitializeComponent();

      _ViewModel = (ProductViewModel)this.Resources["viewModel"];
    }

    private void btnEdit_Click(object sender, RoutedEventArgs e)
    {
      // Set the current Record
      lstData.SelectedItem = ((Button)sender).DataContext;

      PDSAMessageBrokerMessage arg = new PDSAMessageBrokerMessage();

      arg.MessageName = "ProductDetail";
      arg.MessageBody = lstData.SelectedItem;

      // Send message
      (Application.Current as App).MessageBroker.SendMessage(arg);
    }
  }
}
