﻿using System.Collections.Generic;
using ProductData;
using ProductEntity;

namespace ProductServiceHost
{
  public class ProductService : IProductService
  {
    public List<Product> GetProducts()
    {
      ProductManager mgr = new ProductManager();

      return mgr.GetProducts();
    }
  }
}
