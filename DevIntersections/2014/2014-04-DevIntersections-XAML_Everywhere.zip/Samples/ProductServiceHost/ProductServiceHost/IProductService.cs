﻿using System.Collections.Generic;
using System.ServiceModel;
using ProductEntity;

namespace ProductServiceHost
{
  [ServiceContract]
  public interface IProductService
  {
    [OperationContract]
    List<Product> GetProducts();
  }
}
