﻿using System;

namespace FriendlyUrls
{
  public partial class Default : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnProducts_Click(object sender, EventArgs e)
    {
      Response.RedirectToRoute("GetProduct", new {ProductId = 33});      
    }

    protected void btnCustomers_Click(object sender, EventArgs e)
    {
      Response.Redirect("Customers");
    }
  }
}