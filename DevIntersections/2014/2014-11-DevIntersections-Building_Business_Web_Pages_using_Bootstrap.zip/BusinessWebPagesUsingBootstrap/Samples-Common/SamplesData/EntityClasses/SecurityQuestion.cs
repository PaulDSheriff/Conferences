﻿
namespace SamplesData
{
  public class SecurityQuestion
  {
     public string Description { get; set; }
  }
}