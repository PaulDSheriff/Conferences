﻿using System.Collections.Generic;

namespace SamplesData
{
  public class CreditCardType
  {
    public string Value { get; set; }
    public string Name { get; set; }
    public int SecurityCodeLength { get; set; }
  }
}
