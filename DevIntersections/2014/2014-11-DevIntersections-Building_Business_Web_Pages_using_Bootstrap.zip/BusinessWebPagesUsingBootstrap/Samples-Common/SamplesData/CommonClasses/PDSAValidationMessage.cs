﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SamplesData
{
  /// <summary>
  /// A class for storing validation rule failure messages
  /// </summary>
  public class PDSAValidationMessage
  {
    #region Constructors
    public PDSAValidationMessage()
    {
    }

    public PDSAValidationMessage(string propertyName, string message)
    {
      PropertyName = propertyName;
      Message = message;
    }
    #endregion

    /// <summary>
    /// Get/Set the validation message to display
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// Get/Set the property name that was invalid
		/// Can you use this to loop through controls on your UI and put a border around those properties that have failed validation
    /// </summary>
    public string PropertyName { get; set; }
  }
}
