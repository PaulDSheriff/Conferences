﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SamplesData
{
  /// <summary>
  /// Collection class of validation messages
  /// </summary>
  public class PDSAValidationMessages : List<PDSAValidationMessage>
  {
    #region ToString method
    public override string ToString()
    {      
      return ToString(Environment.NewLine);
    }

    public string ToString(string delimiter)
    {
      StringBuilder sb = new StringBuilder(1024);

      foreach (PDSAValidationMessage item in this)
      {
        sb.Append(item.Message + delimiter);
      }

      return sb.ToString();
    }
    #endregion
  }
}
