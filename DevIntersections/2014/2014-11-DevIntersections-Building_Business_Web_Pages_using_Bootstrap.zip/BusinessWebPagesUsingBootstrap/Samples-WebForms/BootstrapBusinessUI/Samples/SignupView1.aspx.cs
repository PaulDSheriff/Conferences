﻿using System;
using SamplesData;

namespace BootstrapBusinessUI.Samples
{
  public partial class SignupView1 : System.Web.UI.Page
  {
    protected void btnRegister_Click(object sender, EventArgs e)
    {
      UserData entity = new UserData();

      if (Page.IsValid)
      {
        entity.FirstName = First.Text;
        entity.LastName = Last.Text;
        entity.Email = Email.Text;
        entity.Password = Password.Text;
        entity.IsAgreeToTermsChecked = true;

        System.Diagnostics.Debugger.Break();
      }
    }
  }
}