﻿using System;
using System.Web.UI;
using SamplesData;

namespace BootstrapBusinessUI.Samples
{
  public partial class CreditCardView1 : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
      {
        hdnFileName.Value = Server.MapPath("~/Xml/CreditCardTypes.xml");
      }
    }

    protected void Save_Click(object sender, EventArgs e)
    {
      CreditCard entity = new CreditCard();

      if (Page.IsValid)
      {
        entity.CreditCardType = CreditCardTypes.SelectedValue;
        entity.NameOnCard = NameOnCard.Text;
        entity.CreditCardNumber = CreditCardNumber.Text;
        entity.SecurityCode = SecurityCode.Text;
        entity.ExpMonth = Convert.ToInt32(Months.SelectedValue);
        entity.ExpYear = Convert.ToInt32(Years.SelectedValue);

        System.Diagnostics.Debugger.Break();
      }
    }

    protected void Cancel_Click(object sender, EventArgs e)
    {
      Response.Redirect("Home.aspx");
    }
  }
}