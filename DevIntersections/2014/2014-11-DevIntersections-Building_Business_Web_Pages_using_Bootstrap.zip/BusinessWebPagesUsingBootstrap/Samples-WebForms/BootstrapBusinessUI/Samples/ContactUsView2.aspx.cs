﻿using System;
using System.Web.UI;
using SamplesData;

namespace BootstrapBusinessUI.Samples
{
  public partial class ContactUsView2 : System.Web.UI.Page
  {
    private const string URL_START = "http://www.";

    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
      {
        Url.Text = URL_START;
      }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      ContactUs entity = new ContactUs();

      if (Page.IsValid)
      {
        entity.Name = Name.Text;
        entity.Email = Email.Text;
        if (Url.Text.Trim() != URL_START)
          entity.Url = Url.Text;
        entity.Message = Msg.Text;

        System.Diagnostics.Debugger.Break();
      }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
      Response.Redirect("Home.aspx");
    }
  }
}