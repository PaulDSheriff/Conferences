﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using System.Web.Mvc;

namespace BootstrapBusinessUI
{
  public static class HtmlExtensions
  {
    public enum Html5InputTypes
    {
      text,
      color,
      date,
      datetime,
      email,
      month,
      number,
      password,
      range,
      search,
      tel,
      time,
      url,
      week
    }

    #region Submit Button Helpers
    /// <summary>
    /// Submit button helper
    /// </summary>
    /// <param name="helper">The helper</param>
    /// <param name="buttonText">The text for the button</param>
    /// <returns>String</returns>
    public static MvcHtmlString SubmitButton(this HtmlHelper helper,
      string buttonText)
    {
      return SubmitButton(helper, buttonText, null, false, null);
    }

    /// <summary>
    /// Submit button helper
    /// </summary>
    /// <param name="helper">The helper</param>
    /// <param name="buttonText">The text for the button</param>
    /// <param name="id">The id for the button</param>
    /// <returns>String</returns>
    public static MvcHtmlString SubmitButton(this HtmlHelper helper, 
      string buttonText, string id)
    {
      return SubmitButton(helper, buttonText, id, false, null);
    }

    /// <summary>
    /// Submit button helper
    /// </summary>
    /// <param name="helper">The helper</param>
    /// <param name="buttonText">The text for the button</param>
    /// <param name="id">The id for the button</param>
    /// <param name="isDisabled">Set to true if you want the button disabled</param>
    /// <returns>String</returns>
    public static MvcHtmlString SubmitButton(this HtmlHelper helper,
      string buttonText, string id, bool isDisabled)
    {
      return SubmitButton(helper, buttonText, id, isDisabled, null);
    }

    /// <summary>
    /// Submit button helper
    /// </summary>
    /// <param name="helper">The helper</param>
    /// <param name="buttonText">The text for the button</param>
    /// <param name="id">The id for the button</param>
    /// <param name="isDisabled">Set to true if you want the button disabled</param>
    /// <returns>String</returns>
    public static MvcHtmlString SubmitButton(this HtmlHelper helper,
      string buttonText, string id, bool isDisabled, string btnClass)
    {
      string str = string.Empty;
      string disable = string.Empty;

      if (string.IsNullOrEmpty(id))
        id = buttonText;
      if (string.IsNullOrEmpty(btnClass))
        btnClass = "btn-primary";

      // Ensure ID is a valid identifier
      id = id.Replace(" ", "").Replace("-", "_");

      str = "<input type='submit' class='btn {3}{1}' title='{0}' value='{0}' id='{2}' />";
      if (isDisabled)
        disable = " disabled";

      str = string.Format(str, buttonText, disable, id, btnClass);
      str = str.Replace("'", "\"");
    
      return new MvcHtmlString(str);
    }
    #endregion

    #region TextBox for HTML 5 Helpers
    public static MvcHtmlString TextBox5For<TModel, TValue>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TValue>> expression)
    {
      return TextBox5For(htmlHelper, expression, Html5InputTypes.text, string.Empty, string.Empty, false, false);
    }

    public static MvcHtmlString TextBox5For<TModel, TValue>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TValue>> expression,
      Html5InputTypes type)
    {
      return TextBox5For(htmlHelper, expression, type, string.Empty, string.Empty, false, false);
    }
    
    public static MvcHtmlString TextBox5For<TModel, TValue>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TValue>> expression,
      string title)
    {
      return TextBox5For(htmlHelper, expression, Html5InputTypes.text, title, title, false, false);
    }

    public static MvcHtmlString TextBox5For<TModel, TValue>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TValue>> expression,
      Html5InputTypes type,
      string title)
    {
      return TextBox5For(htmlHelper, expression, type, title, title, false, false);
    }

    public static MvcHtmlString TextBox5For<TModel, TValue>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TValue>> expression,
      string title,
      bool isRequired,
      bool isAutoFocus)
    {
      return TextBox5For(htmlHelper, expression, Html5InputTypes.text, title, title, isRequired, isAutoFocus);
    }

    public static MvcHtmlString TextBox5For<TModel, TValue>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TValue>> expression,
      Html5InputTypes type,
      string title,
      string placeholder,
      bool isRequired,
      bool isAutoFocus)
    {
      MvcHtmlString html = default(MvcHtmlString);
      Dictionary<string, object> attr = new Dictionary<string, object>();

      attr.Add("type", type.ToString());
      attr.Add("class", "form-control");
      if (!string.IsNullOrEmpty(title))
      {
        attr.Add("placeholder", placeholder);
      }
      if (!string.IsNullOrEmpty(placeholder))
      {
        attr.Add("title", title);
      }
      if (isAutoFocus)
      {
        attr.Add("autofocus", "autofocus");
      }
      if (isRequired)
      {
        attr.Add("required", "required");
      }

      html = System.Web.Mvc.Html.InputExtensions.TextBoxFor(htmlHelper,
      expression, attr);

      return html;
    }
    #endregion
  }
}