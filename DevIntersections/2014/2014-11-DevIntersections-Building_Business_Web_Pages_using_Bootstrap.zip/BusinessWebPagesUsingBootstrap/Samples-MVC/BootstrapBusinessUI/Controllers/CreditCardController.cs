﻿using System.Web.Mvc;
using System.Collections.Generic;
using SamplesData;

namespace BootstrapBusinessUI.Controllers
{
  public class CreditCardController : Controller
  {
    public ActionResult CreditCard1()
    {
      CreditCardViewModel vm = null;

      vm = CreateCreditCardViewModel();

      return View(vm);
    }

    private CreditCardViewModel CreateCreditCardViewModel()
    {
      CreditCardViewModel vm = new CreditCardViewModel();

      InitViewModel(vm);

      return vm;
    }

    private void InitViewModel(CreditCardViewModel vm)
    {
      vm.LoadCreditCardTypes(Server.MapPath("~/Xml/CreditCardTypes.xml"));
    }

    [HttpPost]
    public ActionResult CreditCard1(CreditCardViewModel vm)
    {
      bool ret = vm.Validate();

      if (ret)
      {
        return RedirectToAction("Index", "Home");
      }
      else
      {
        InitViewModel(vm);
        return View(vm);
      }
    }
    
    public ActionResult CreditCard2()
    {
      CreditCardViewModel vm = null;

      vm = CreateCreditCardViewModel();

      return View(vm);
    }

    [HttpPost]
    public ActionResult CreditCard2(CreditCardViewModel vm)
    {
      bool ret = vm.Validate();

      if (ret)
      {
        return RedirectToAction("Index", "Home");
      }
      else
      {
        InitViewModel(vm); 
        return View(vm);
      }
    }
  }
}