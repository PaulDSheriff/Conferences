﻿using System.Web.Mvc;
using System.Collections.Generic;
using SamplesData;

namespace BootstrapBusinessUI.Controllers
{
  public class MemberProfileController : Controller
  {
    public ActionResult MemberProfile1()
    {
      MemberProfileViewModel vm = null;

      vm = CreateMemberViewModel();

      return View(vm);
    }

    private MemberProfileViewModel CreateMemberViewModel()
    {
      MemberProfileViewModel vm = new MemberProfileViewModel();

      InitViewModel(vm);

      return vm;
    }

    private void InitViewModel(MemberProfileViewModel vm)
    {
      vm.LoadStates(Server.MapPath("~/Xml/USStates.xml"));
      vm.LoadQuestions(Server.MapPath("~/Xml/SecurityQuestions.xml"));
    }

    [HttpPost]
    public ActionResult MemberProfile1(MemberProfileViewModel vm)
    {
      bool ret = vm.Validate();

      if (ret)
      {
        return RedirectToAction("Index", "Home");
      }
      else
      {
        InitViewModel(vm); 
        return View(vm);
      }
    }
    
    public ActionResult MemberProfile2Inline()
    {
      MemberProfileViewModel vm = null;

      vm = CreateMemberViewModel();

      return View(vm);
    }

    [HttpPost]
    public ActionResult MemberProfile2Inline(MemberProfileViewModel vm)
    {
      bool ret = vm.Validate();

      if (ret)
      {
        return RedirectToAction("Index", "Home");
      }
      else
      {
        InitViewModel(vm);
        return View(vm);
      }
    }

    public ActionResult MemberProfile3Tabs()
    {
      MemberProfileViewModel vm = null;

      vm = CreateMemberViewModel();

      return View(vm);
    }

    [HttpPost]
    public ActionResult MemberProfile3Tabs(MemberProfileViewModel vm)
    {
      bool ret = vm.Validate();

      if (ret)
      {
        return RedirectToAction("Index", "Home");
      }
      else
      {
        InitViewModel(vm);
        return View(vm);
      }
    }
  }
}