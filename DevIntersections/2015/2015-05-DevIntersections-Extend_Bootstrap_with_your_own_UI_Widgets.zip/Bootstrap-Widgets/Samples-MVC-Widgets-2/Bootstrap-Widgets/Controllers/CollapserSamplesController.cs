﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Bootstrap_Widgets.Controllers
{
  public class CollapserSamplesController : Controller
  {
    public ActionResult CollapserSample01()
    {
      return View();
    }
    public ActionResult CollapserSample02()
    {
      return View();
    }
    public ActionResult CollapserSample03()
    {
      return View();
    }
    public ActionResult CollapserSample04()
    {
      return View();
    }
  }
}