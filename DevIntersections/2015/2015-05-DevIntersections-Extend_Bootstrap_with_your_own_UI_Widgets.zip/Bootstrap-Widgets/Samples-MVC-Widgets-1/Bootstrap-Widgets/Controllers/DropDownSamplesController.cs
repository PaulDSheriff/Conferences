﻿using System.Web.Mvc;
using SamplesData;

namespace Bootstrap_Widgets.Controllers
{
  public class DropDownSamplesController : Controller
  {
    public ActionResult DropDown01()
    {
      MusicGenre entity = new MusicGenre();

      return View(entity);
    }

    public ActionResult DropDown02()
    {
      MusicGenre entity = new MusicGenre();

      //entity.Genre = "Rock";

      return View(entity);
    }

    [HttpPost]
    public ActionResult DropDown02(MusicGenre entity)
    {
      System.Diagnostics.Debugger.Break();

      return View(entity);
    }

    public ActionResult DropDown03()
    {
      MusicGenre entity = new MusicGenre();

      return View(entity);
    }

    [HttpPost]
    public ActionResult DropDown03(MusicGenre entity)
    {
      System.Diagnostics.Debugger.Break();

      ModelState.Clear();

      return View(entity);
    }

    public ActionResult DropDown04()
    {
      MusicGenre entity = new MusicGenre();

      ModelState.Clear();

      return View(entity);
    }

    [HttpPost]
    public ActionResult DropDown04(MusicGenre entity)
    {
      System.Diagnostics.Debugger.Break();

      ModelState.Clear();

      return View(entity);
    }

    public ActionResult DropDown05()
    {
      MusicGenreViewModel vm = new MusicGenreViewModel();

      //vm.SelectedGenre = "Rock";
      //vm.SelectedId = 3;

      return View(vm);
    }

    [HttpPost]
    public ActionResult DropDown05(MusicGenreViewModel vm)
    {
      System.Diagnostics.Debugger.Break();

      ModelState.Clear();

      return View(vm);
    }
  }
}