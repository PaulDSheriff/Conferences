﻿using System.Windows;
using System.Windows.Controls;
using ProductDataClasses;

namespace WPF_DataManager
{
  public partial class MainWindow : Window
  {
    private ProductViewModel _ViewModel;

    public MainWindow()
    {
      InitializeComponent();

      _ViewModel = (ProductViewModel)this.Resources["viewModel"];
    }
    
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      _ViewModel.LoadAll();
    }

    private void btnEdit_Click(object sender, RoutedEventArgs e)
    {
      // Display the current Record
      // Clicking on the Edit button does not change the 
      // Selected Item of the list box, so we need to do that
      lstData.SelectedItem = ((Button)sender).DataContext;

      _ViewModel.EditData();
    }

    private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      // Clone current record in case we edit and need to cancel
      _ViewModel.CloneCurrent();
    }

    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      // Display the current Record
      // Clicking on the Delete button does not change the 
      // Selected Item of the list box, so we need to do that
      lstData.SelectedItem = ((Button)sender).DataContext;

      if (MessageBox.Show("Delete This Product?", "Delete?", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
        _ViewModel.Delete();
    }

    private void btnAdd_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.AddData();
    }

    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.Save();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.CancelEdit();
    }

    private void TextHasChanged(object sender, TextChangedEventArgs e)
    {
      // Only Change Mode if Element has Keyboard Focus
      if (((UIElement)sender).IsKeyboardFocused)
        if (!_ViewModel.IsSaveEnabled)
          _ViewModel.SetUIState(XML.Library.EditUIState.Edit);
    }
  }
}
