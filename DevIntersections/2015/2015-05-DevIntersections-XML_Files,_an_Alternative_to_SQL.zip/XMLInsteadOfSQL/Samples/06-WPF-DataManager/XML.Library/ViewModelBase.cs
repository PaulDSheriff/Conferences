﻿using Common.Library;

namespace XML.Library
{
	public enum EditUIState
	{
		Normal,
		Edit,
		Exception,
		ValidationFailed
	}

  public class ViewModelBase : CommonBase
  {
		public ViewModelBase()
		{
			SetUIState(EditUIState.Normal);
			TotalRecords = 0;
			SelectedIndex = 0;
			MessageToDisplay = string.Empty;
			LastExceptionMessage = string.Empty;
		}

    #region Private Variables
    private string _MessageToDisplay = string.Empty;
    private bool _IsMessageVisible = false;
    private bool _IsAddMode = false;
		private bool _IsListEnabled;
		private bool _ExceptionOccurred;
		private bool _ValidationFailed;
		private bool _IsAddEnabled;
		private bool _IsSaveEnabled;
		private bool _IsCancelEnabled;
		private bool _IsDetailAreaEnabled;
		private string _LastExceptionMessage;
		private string _ValidationRuleMessages;
		private int _SelectedIndex;
		private int _TotalRecords;
    #endregion

    #region Public Properties
    public string MessageToDisplay 
    {
      get { return _MessageToDisplay; }
      set
      {
        _MessageToDisplay = value;
        RaisePropertyChanged("MessageToDisplay");
      }
    }

    public bool IsMessageVisible
    {
      get { return _IsMessageVisible; }
      set
      {
        _IsMessageVisible = value;
        RaisePropertyChanged("IsMessageVisible");
      }
    }

    public bool IsAddMode
    {
      get { return _IsAddMode; }
      set
      {
        _IsAddMode = value;
        RaisePropertyChanged("IsAddMode");
      }
    }

		public bool IsListEnabled
		{
			get { return _IsListEnabled; }
			set
			{
				if (_IsListEnabled != value)
				{
					_IsListEnabled = value;
					RaisePropertyChanged("IsListEnabled");
				}
			}
		}

		public bool ExceptionOccurred
		{
			get { return _ExceptionOccurred; }
			set
			{
				if (_ExceptionOccurred != value)
				{
					_ExceptionOccurred = value;
					RaisePropertyChanged("ExceptionOccurred");
				}
			}
		}

		public bool ValidationFailed
		{
			get { return _ValidationFailed; }
			set
			{
				if (_ValidationFailed != value)
				{
					_ValidationFailed = value;
					RaisePropertyChanged("ValidationFailed");
				}
			}
		}

		public bool IsAddEnabled
		{
			get { return _IsAddEnabled; }
			set
			{
				if (_IsAddEnabled != value)
				{
					_IsAddEnabled = value;
					RaisePropertyChanged("IsAddEnabled");
				}
			}
		}

		public bool IsSaveEnabled
		{
			get { return _IsSaveEnabled; }
			set
			{
				if (_IsSaveEnabled != value)
				{
					_IsSaveEnabled = value;
					RaisePropertyChanged("IsSaveEnabled");
				}
			}
		}

		public bool IsCancelEnabled
		{
			get { return _IsCancelEnabled; }
			set
			{
				if (_IsCancelEnabled != value)
				{
					_IsCancelEnabled = value;
					RaisePropertyChanged("IsCancelEnabled");
				}
			}
		}

		public string LastExceptionMessage
		{
			get { return _LastExceptionMessage; }
			set
			{
				if (_LastExceptionMessage != value)
				{
					_LastExceptionMessage = value;
					RaisePropertyChanged("LastExceptionMessage");
				}
			}
		}

		public string ValidationRuleMessages
		{
			get { return _ValidationRuleMessages; }
			set
			{
				if (_ValidationRuleMessages != value)
				{
					_ValidationRuleMessages = value;
					RaisePropertyChanged("ValidationRuleMessages");
				}
			}
		}

		public int TotalRecords
		{
			get { return _TotalRecords; }
			set
			{
				if (_TotalRecords != value)
				{
					_TotalRecords = value;
					RaisePropertyChanged("TotalRecords");
				}
			}
		}

		public bool IsDetailAreaEnabled
		{
			get { return _IsDetailAreaEnabled; }
			set
			{
				if (_IsDetailAreaEnabled != value)
				{
					_IsDetailAreaEnabled = value;
					RaisePropertyChanged("IsDetailAreaEnabled");
				}
			}
		}

		public int SelectedIndex
		{
			get { return _SelectedIndex; }
			set
			{
				if (_SelectedIndex != value)
				{
					_SelectedIndex = value;
					RaisePropertyChanged("SelectedIndex");
				}
			}
		}
		#endregion

		public void SetUIState(EditUIState state)
		{
			switch (state)
			{
				case EditUIState.Normal:
					IsAddMode = false;
					IsListEnabled = true;
					ExceptionOccurred = false;
					ValidationFailed = false;
#if SILVERLIGHT
					IsDetailAreaEnabled = false;
#else
					IsDetailAreaEnabled = true;
#endif
					IsAddEnabled = true;
					IsSaveEnabled = false;
					IsCancelEnabled = false;
					
					break;

				case EditUIState.Edit:
					IsListEnabled = false;
					ExceptionOccurred = false;
					ValidationFailed = false;
					IsDetailAreaEnabled = true;
					IsAddEnabled = false;
					IsSaveEnabled = true;
					IsCancelEnabled = true;
					
					break;

				case EditUIState.Exception:
					IsListEnabled = false;
					ExceptionOccurred = true;
					ValidationFailed = false;
					IsDetailAreaEnabled = false;
					IsAddEnabled = false;
					IsSaveEnabled = false;
					IsCancelEnabled = false;

					break;

				case EditUIState.ValidationFailed:
					ValidationFailed = true;
					
					break;
			}
		}
  }
}
