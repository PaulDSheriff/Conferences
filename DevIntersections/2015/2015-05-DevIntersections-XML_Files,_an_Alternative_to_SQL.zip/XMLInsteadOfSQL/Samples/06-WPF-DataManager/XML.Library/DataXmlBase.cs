﻿using System;
using System.Linq;
using System.Xml.Linq;
using Common.Library;

namespace XML.Library
{
  public class DataXmlBase : CommonBase
  {
    #region Constructors    
    public DataXmlBase(string storageKey, string parentNodeName)
    {
      StorageKeyName = storageKey;
      ParentNodeName = parentNodeName;
    }
    #endregion

    #region Public Properties
    public string ParentNodeName { get; set; }
    public string StorageKeyName { get; set; }
    #endregion

    #region XmlObject Property (XElement object)
    private XElement _XmlObject = null;

    public XElement XmlObject
    {
      get { return _XmlObject; }
      set
      {
        _XmlObject = value;
        RaisePropertyChanged("XmlObject");
      }
    }
    #endregion

    #region Delete Method
    public virtual bool Delete(int id, string keyName)
    {
      // Find a specific element
      var elem = 
        (from node in XmlObject.Elements(ParentNodeName)
         where node.Attribute(keyName).Value == id.ToString()
         select node).SingleOrDefault();

      // Delete the element
      elem.Remove();

      // Save the file
      Save(XmlObject);

      return true;
    }
    #endregion

    #region DeleteLocalStorage Method
    public virtual void DeleteLocalStorage()
    {
      LocalXmlAppStorage.Remove(StorageKeyName);
    }
    #endregion

    #region Save Methods
    public void Save(XElement xmlToWrite)
    {
      if (xmlToWrite != null)
      {
        LocalXmlAppStorage.Save(StorageKeyName, xmlToWrite.ToString());
      }
    }

    public void Save()
    {
      Save(XmlObject);
    }
    #endregion

    #region BuildCollection Methods
    public virtual void BuildCollection(XElement xmlObject)
    {
      XmlObject = xmlObject;
    }

    public virtual void BuildCollection()
    {
    }
    #endregion
  }
}