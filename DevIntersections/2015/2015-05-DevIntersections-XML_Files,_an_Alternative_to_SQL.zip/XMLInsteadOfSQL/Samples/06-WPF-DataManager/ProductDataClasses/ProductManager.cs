﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Xml.Linq;
using Common.Library;
using XML.Library;

namespace ProductDataClasses
{
  public class ProductManager : DataXmlBase
  {
    public const string STORAGE_KEY = "Product.xml";
    public const string PARENT_NODE_NAME = "Product";
    public const string KEY_FIELD = "ProductId";

    #region Constructors
    public ProductManager()
      : base(STORAGE_KEY, PARENT_NODE_NAME)
    {
    }
    #endregion

    #region DataCollection Property
    private ObservableCollection<Product> _DataCollection =
             new ObservableCollection<Product>();

    public ObservableCollection<Product> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region BuildCollection Methods
    public override void BuildCollection(XElement xmlObject)
    {
      base.BuildCollection(xmlObject);

      BuildCollection();
    }

    public override void BuildCollection()
    {
      // Fill a list of Product objects
      IEnumerable<Product> nodes =
        from node in XmlObject.Elements(ParentNodeName)
        orderby node.Attribute("ProductName").Value
        select new Product
        {
          ProductId = node.Attribute("ProductId").GetAs<int>(),
          ProductName = node.Attribute("ProductName").GetAs<string>(),
          IntroductionDate = node.Attribute("IntroductionDate").
                                GetAs<DateTime>(default(DateTime)),
          Cost = node.Attribute("Cost").GetAs<decimal>(),
          Price = node.Attribute("Price").GetAs<decimal>(),
          IsDiscontinued = node.Attribute("IsDiscontinued").GetAs<bool>(),
          LastUpdated = node.Attribute("LastUpdated").GetAs<DateTime>()
        };

      // Assign to public property
      DataCollection = new ObservableCollection<Product>(nodes);
    }
    #endregion

    #region Insert Method
    public bool Insert(Product entity)
    {
      // Create new Product element
      XElement prod =
        new XElement(ParentNodeName,
          new XAttribute("ProductId", entity.ProductId),
          new XAttribute("ProductName", entity.ProductName),
          new XAttribute("IntroductionDate", entity.IntroductionDate),
          new XAttribute("Cost", entity.Cost),
          new XAttribute("Price", entity.Price),
          new XAttribute("IsDiscontinued", entity.IsDiscontinued),
          new XAttribute("LastUpdated", entity.LastUpdated)
          );

      // Add to element collection
      XmlObject.Add(prod);

      // Save the file
      base.Save(XmlObject);

      return true;
    }
    #endregion

    #region Update Method
    public bool Update(Product entity)
    {
      // Find the product element
      XElement prod =
        (from node in XmlObject.Elements(ParentNodeName)
         where node.Attribute(KEY_FIELD).Value == entity.ProductId.ToString()
         select node).SingleOrDefault();

      // Update the data
      prod.Attribute("ProductName").Value = entity.ProductName;
      prod.Attribute("IntroductionDate").Value = entity.IntroductionDate.ToString();
      prod.Attribute("Cost").Value = entity.Cost.ToString();
      prod.Attribute("Price").Value = entity.Price.ToString();
      prod.Attribute("IsDiscontinued").Value = entity.IsDiscontinued.ToString();
      prod.Attribute("LastUpdated").Value = entity.LastUpdated.ToString();

      // Save the file
      base.Save(XmlObject);

      return true;
    }
    #endregion

    #region Delete Method
    public bool Delete(Product entity)
    {
      // Find the product element
      XElement prod =
        (from node in XmlObject.Elements(ParentNodeName)
         where node.Attribute(KEY_FIELD).Value == entity.ProductId.ToString()
         select node).SingleOrDefault();

      if (prod != null)
      {
        // Delete the element
        prod.Remove();

        // Save the file
        base.Save(XmlObject);

        return true;
      }
      else
        return false;
    }
    #endregion

    #region GetNextProductId Method
    public int GetNextProductId()
    {
      return XmlObject.GetNextId(KEY_FIELD, PARENT_NODE_NAME);
    }
    #endregion

    #region GetLastUpdateDate Method
    public DateTime GetLastUpdateDate()
    {
      return XmlObject.GetLastUpdateDate("LastUpdated", PARENT_NODE_NAME);
    }
    #endregion
  }
}