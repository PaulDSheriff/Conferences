﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace XmlStorageService
{
  public class ProductService : IProductService
  {
    public string GetProductXml()
    {
      string ret = string.Empty;
      SqlDataAdapter da;
      DataSet ds = new DataSet();

      da = new SqlDataAdapter("SELECT * FROM Product",
        ConfigurationManager.ConnectionStrings["Sandbox"].
          ConnectionString);

      da.Fill(ds);

      // Create Attribute based XML
      foreach (DataColumn item in ds.Tables[0].Columns)
        item.ColumnMapping = MappingType.Attribute;

      ds.DataSetName = "Products";
      ds.Tables[0].TableName = "Product";
      ret = ds.GetXml();

      return ret;
    }
  }
}
