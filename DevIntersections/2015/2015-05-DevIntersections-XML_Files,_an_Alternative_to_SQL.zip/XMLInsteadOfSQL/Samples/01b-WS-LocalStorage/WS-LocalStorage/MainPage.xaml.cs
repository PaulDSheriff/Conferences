﻿using System;
using System.Linq;
using System.Xml.Linq;
using Windows.Storage;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace WS_LocalStorage
{
  public sealed partial class MainPage : Page
  {
    #region Constructor and OnNavigatedTo
    public MainPage()
    {
      this.InitializeComponent();
    }

    /// <summary>
    /// Invoked when this page is about to be displayed in a Frame.
    /// </summary>
    /// <param name="e">Event data that describes how this page was reached.  The Parameter
    /// property is typically used to configure the page.</param>
    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
    }
    #endregion

    const string STORAGE_KEY = "ProductData";

    private async void btnReadProject_Click(object sender, RoutedEventArgs e)
    {
      XElement elem = null;
      
      // Read file from local project
      elem = XElement.Load( @"Xml/Product.xml");
          
      // Save data to local storage
      ApplicationData.Current.LocalSettings.Values[STORAGE_KEY] = elem.ToString();

      MessageDialog dialog;
      dialog = new MessageDialog("XML Written to Application Storage");
      await dialog.ShowAsync();
    }

    private async void btnReadUserStorage_Click(object sender, RoutedEventArgs e)
    {
      XElement elem;

      // See if local storage contains the data      
      if (ApplicationData.Current.LocalSettings.Values.ContainsKey(STORAGE_KEY))
      {
        // Read XML from local storage
        elem = 
          XElement.Parse(
            ApplicationData.Current.LocalSettings.Values[STORAGE_KEY].ToString());

        // Create a list of Product objects using LINQ to XML
        var products =
          from prod in elem.Elements("Product")
          orderby prod.Attribute("ProductName").Value
          select new Product
          {
            ProductId = 
                Convert.ToInt32(prod.Attribute("ProductId").Value),
            ProductName = 
                prod.Attribute("ProductName").Value,
            IntroductionDate = 
                Convert.ToDateTime(prod.Attribute("IntroductionDate").Value),
            Cost = Convert.ToDecimal(prod.Attribute("Cost").Value),
            Price = Convert.ToDecimal(prod.Attribute("Price").Value),
            IsDiscontinued = 
                Convert.ToBoolean(prod.Attribute("IsDiscontinued").Value),
            LastUpdated = 
                Convert.ToDateTime(prod.Attribute("LastUpdated").Value)
          };

        lstData.DataContext = products;
      }
      else
      {
        MessageDialog dialog;
        dialog = new MessageDialog("XML File does not exist in Application Storage!");
        await dialog.ShowAsync();
      }
    }

    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      // Delete From Application Storage
      ApplicationData.Current.LocalSettings.Values.Remove(STORAGE_KEY);

      lstData.DataContext = null;
    }
  }
}
