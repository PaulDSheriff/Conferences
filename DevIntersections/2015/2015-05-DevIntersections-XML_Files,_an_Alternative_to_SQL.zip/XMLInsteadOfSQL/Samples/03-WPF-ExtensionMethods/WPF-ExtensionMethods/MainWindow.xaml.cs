﻿using System;
using System.Linq;
using System.Windows;
using System.Xml.Linq;
using Common.Library;

namespace WPF_ExtensionMethods
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    XElement _Elements = null;
    const string STORAGE_KEY = "Product.xml";

    private void btnGetAs_Click(object sender, RoutedEventArgs e)
    {
      // Read file from local project
      _Elements = XElement.Load(
        FileCommon.GetCurrentDirectory()
        + @"\Xml\" + STORAGE_KEY);

      // Create a list of Product objects using LINQ to XML
      // Note the use of the extension methods
      var products =
        from prod in _Elements.Elements("Product")
        orderby prod.Attribute("ProductName").Value
        select new Product
        {
          ProductId = prod.Attribute("ProductId").GetAs<int>(),
          ProductName = prod.Attribute("ProductName").GetAs<string>(),
          IntroductionDate = prod.Attribute("IntroductionDate").GetAs<DateTime>(),
          Cost = prod.Attribute("Cost").GetAs<decimal>(),
          Price = prod.Attribute("Price").GetAs<decimal>(),
          IsDiscontinued = prod.Attribute("IsDiscontinued").GetAs<bool>(),
          LastUpdated = prod.Attribute("LastUpdated").GetAs<DateTime>()
        };

      lstData.DataContext = products;
    }

    private void btnGetLastUpdateDate_Click(object sender, RoutedEventArgs e)
    {
      // Note the user of the extension method
      MessageBox.Show(_Elements.GetLastUpdateDate("LastUpdated", "Product").ToString());
    }

    private void btnGetNextId_Click(object sender, RoutedEventArgs e)
    {
      // Note the user of the extension method
      MessageBox.Show(_Elements.GetNextId("ProductId", "Product").ToString());
    }

    private void btnGetCount_Click(object sender, RoutedEventArgs e)
    {
      // Note the user of the extension method
      MessageBox.Show(_Elements.GetCount("Product").ToString());
    }
  }
}
