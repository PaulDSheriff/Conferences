﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using Common.Library;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using WS_XmlFromServer.ProductServiceReference;

namespace WS_XmlFromServer
{
  public sealed partial class MainPage : Page
  {
    #region Constructor and OnNavigateTo
    public MainPage()
    {
      this.InitializeComponent();
    }

    /// <summary>
    /// Invoked when this page is about to be displayed in a Frame.
    /// </summary>
    /// <param name="e">Event data that describes how this page was reached.  The Parameter
    /// property is typically used to configure the page.</param>
    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
    }
    #endregion

    ProductServiceClient _Client = new ProductServiceClient();
    XElement _Elements = null;
    const string STORAGE_KEY = "Product.xml";

    #region Get Xml From Server
    private async void btnRead_Click(object sender, RoutedEventArgs e)
    {
      // Call Async method on server
      string result = await _Client.GetProductXmlAsync();

      IEnumerable<Product> products;

      // Load products from XML passed back from WCF Service
      products = LoadProducts(result);

      // Close WCF Connection
      await _Client.CloseAsync();

      lstData.DataContext = products;
      btnSave.IsEnabled = true;
    }

    private IEnumerable<Product> LoadProducts(string xml)
    {
      _Elements = XElement.Parse(xml);
      
      // Create a list of Product objects from XElement object
      IEnumerable<Product> products =
        from prod in _Elements.Elements("Product")
        orderby prod.Attribute("ProductName").Value
        select new Product
        {
          ProductId = prod.Attribute("ProductId").GetAs<int>(),
          ProductName = prod.Attribute("ProductName").GetAs<string>(),
          IntroductionDate = prod.Attribute("IntroductionDate").GetAs<DateTime>(),
          Cost = prod.Attribute("Cost").GetAs<decimal>(),
          Price = prod.Attribute("Price").GetAs<decimal>(),
          IsDiscontinued = prod.Attribute("IsDiscontinued").GetAs<bool>(),
          LastUpdated = prod.Attribute("LastUpdated").GetAs<DateTime>()
        };

      return products;
    }
    #endregion
    
    #region Save Methods
    private async void btnSave_Click(object sender, RoutedEventArgs e)
    {
      LocalXmlAppStorage.Save(STORAGE_KEY, _Elements.ToString());
      
      MessageDialog dialog;
      dialog = new MessageDialog("Product Data Saved");
      await dialog.ShowAsync();
    }
    #endregion

    private async void btnReadLocal_Click(object sender, RoutedEventArgs e)
    {
      if (LocalXmlAppStorage.ContainsKey(STORAGE_KEY))
      {
        // NOTE: You should use await and GetFromFile so as not to block the UI thread
        string xml = await LocalXmlAppStorage.GetFromFile(STORAGE_KEY);

        lstData.DataContext = LoadProducts(xml);
      }
      else
      {
        MessageDialog dialog;
        dialog = new MessageDialog("XML does NOT exist in Application Storage");
        await dialog.ShowAsync();
      }
    }

    private void btnClear_Click(object sender, RoutedEventArgs e)
    {
      lstData.DataContext = new List<Product>();
    }
  }
}
