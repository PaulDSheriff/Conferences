﻿Read XML From Server
---------------------------------------
When adding service reference make sure you generate async operations
