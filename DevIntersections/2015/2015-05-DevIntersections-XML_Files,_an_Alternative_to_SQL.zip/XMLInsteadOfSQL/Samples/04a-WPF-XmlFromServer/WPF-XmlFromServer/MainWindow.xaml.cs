﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Xml.Linq;
using Common.Library;
using WPF_XmlFromServer.ProductServiceReference;

namespace WPF_XmlFromServer
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    ProductServiceClient _Client = new ProductServiceClient();
    XElement _Elements = null;
    const string STORAGE_KEY = "Product.xml";

    #region Get Xml From Server
    private void btnRead_Click(object sender, RoutedEventArgs e)
    {
      // Create new instance
      _Client = new ProductServiceClient();

      // Hook up callback
      _Client.GetProductXmlCompleted += _Client_GetProductXmlCompleted;
      // Call Async method on server
      _Client.GetProductXmlAsync();
    }

    void _Client_GetProductXmlCompleted(object sender, GetProductXmlCompletedEventArgs e)
    {
      IEnumerable<Product> products;

      // Load products from XML passed back from WCF Service
      products = LoadProducts(e.Result);

      // Close WCF Connection
      _Client.Close();

      lstData.DataContext = products;
      btnSave.IsEnabled = true;
    }

    private IEnumerable<Product> LoadProducts(string xml)
    {
      _Elements = XElement.Parse(xml);

      // Create a list of Product objects from XElement object
      IEnumerable<Product> products =
        from prod in _Elements.Elements("Product")
        orderby prod.Attribute("ProductName").Value
        select new Product
        {
          ProductId = prod.Attribute("ProductId").GetAs<int>(),
          ProductName = prod.Attribute("ProductName").GetAs<string>(),
          IntroductionDate = prod.Attribute("IntroductionDate").GetAs<DateTime>(),
          Cost = prod.Attribute("Cost").GetAs<decimal>(),
          Price = prod.Attribute("Price").GetAs<decimal>(),
          IsDiscontinued = prod.Attribute("IsDiscontinued").GetAs<bool>(),
          LastUpdated = prod.Attribute("LastUpdated").GetAs<DateTime>()
        };

      return products;
    }
    #endregion

    #region Save Methods
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      SaveProducts();
    }

    private void SaveProducts()
    {
      // Save to local storage
      LocalXmlAppStorage.Save(STORAGE_KEY, _Elements.ToString());

      MessageBox.Show("XML Saved to Local Storage");
    }
    #endregion

    private void btnReadLocal_Click(object sender, RoutedEventArgs e)
    {
      IEnumerable<Product> products;

      if(LocalXmlAppStorage.Exists(STORAGE_KEY))
      {
        // Load products from XML passed back from WCF Service
        products = LoadProducts(LocalXmlAppStorage.Get(STORAGE_KEY));

        lstData.DataContext = products;
      }
    }

    private void btnClear_Click(object sender, RoutedEventArgs e)
    {
      lstData.DataContext = new List<Product>();
    }
  }
}
