﻿using System;
using Common.Library;

namespace WS_CacheLocal
{
  public class Product : CommonBase
  {
    #region Private Variables
    private int _ProductId = 0;
    private string _ProductName = string.Empty;
    private DateTime _IntroductionDate = DateTime.Now;
    private decimal _Cost = 0;
    private decimal _Price = 0;
    private bool _IsDiscontinued = false;
    private DateTime _LastUpdated = DateTime.Now;
    #endregion

    #region Public Properties
    public int ProductId
    {
      get { return _ProductId; }
      set
      {
        _ProductId = value;
        RaisePropertyChanged("ProductId");
      }
    }

    public string ProductName
    {
      get { return _ProductName; }
      set
      {
          _ProductName = value;
          RaisePropertyChanged("ProductName");
      }
    }

    public DateTime IntroductionDate
    {
      get { return _IntroductionDate; }
      set
      {
          _IntroductionDate = value;
          RaisePropertyChanged("IntroductionDate");
      }
    }

    public decimal Cost
    {
      get { return _Cost; }
      set
      {
          _Cost = value;
          RaisePropertyChanged("Cost");
      }
    }

    public decimal Price
    {
      get { return _Price; }
      set
      {
          _Price = value;
          RaisePropertyChanged("Price");
      }
    }

    public bool IsDiscontinued
    {
      get { return _IsDiscontinued; }
      set
      {
        _IsDiscontinued = value;
        RaisePropertyChanged("IsDiscontinued");
      }
    }

    public DateTime LastUpdated
    {
      get { return _LastUpdated; }
      set
      {
          _LastUpdated = value;
          RaisePropertyChanged("LastUpdated");
      }
    }
    #endregion

    #region ToString Override
    public override string ToString()
    {
      return ProductName;
    }
    #endregion
  }
}
