﻿using System;
using System.Linq;
using System.Xml.Linq;
using Common.Library;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace WS_CacheLocal
{
  public sealed partial class MainPage : Page
  {
    #region Constructor and OnNavigatedTo
    public MainPage()
    {
      this.InitializeComponent();
    }

    /// <summary>
    /// Invoked when this page is about to be displayed in a Frame.
    /// </summary>
    /// <param name="e">Event data that describes how this page was reached.  The Parameter
    /// property is typically used to configure the page.</param>
    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
    }
    #endregion

    XElement _Elements = null;
    const string STORAGE_KEY = "Product.xml";

    private async void btnReadProject_Click(object sender, RoutedEventArgs e)
    {
      // Read file from local project
      _Elements = XElement.Load(@"Xml/" + STORAGE_KEY);

      LocalXmlAppStorage.Save(STORAGE_KEY, _Elements.ToString());

      MessageDialog dialog;
      dialog = new MessageDialog("XML Written to Application Storage");
      await dialog.ShowAsync();
    }

    private async void btnReadUserStorage_Click(object sender, RoutedEventArgs e)
    {
      if (LocalXmlAppStorage.ContainsKey(STORAGE_KEY))
      {
        lstData.DataContext = 
          XElement.Parse(LocalXmlAppStorage.Get(STORAGE_KEY));

        // Create a list of Product objects from XElement object
        var products =
          from prod in _Elements.Elements("Product")
          orderby prod.Attribute("ProductName").Value
          select new Product
          {
            ProductId = Convert.ToInt32(prod.Attribute("ProductId").Value),
            ProductName = prod.Attribute("ProductName").Value,
            IntroductionDate = Convert.ToDateTime(prod.Attribute("IntroductionDate").Value),
            Cost = Convert.ToDecimal(prod.Attribute("Cost").Value),
            Price = Convert.ToDecimal(prod.Attribute("Price").Value),
            IsDiscontinued = Convert.ToBoolean(prod.Attribute("IsDiscontinued").Value),
            LastUpdated = Convert.ToDateTime(prod.Attribute("LastUpdated").Value)
          };

        lstData.DataContext = products;
      }
      else
      {
        MessageDialog dialog;
        dialog = new MessageDialog("XML File does not exist in Application Storage!");

        await dialog.ShowAsync();
      }
    }

    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      // Delete From Application Storage
      LocalXmlAppStorage.Remove(STORAGE_KEY);

      lstData.DataContext = null;
    }
  }
}