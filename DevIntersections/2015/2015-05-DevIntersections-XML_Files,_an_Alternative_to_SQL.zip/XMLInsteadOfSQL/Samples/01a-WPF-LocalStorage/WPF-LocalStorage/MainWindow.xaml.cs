﻿using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Xml.Linq;

namespace WPF_LocalStorage
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnReadProject_Click(object sender, RoutedEventArgs e)
    {
      string path;
      XElement elem = null;
      string fileName = string.Empty;

      // Get File Name from Local Project
      fileName = FileCommon.GetCurrentDirectory()
        + @"\Xml\Product.xml";

      // Read file from local project
      elem = XElement.Load(fileName);

      // Create path to Local User Storage
      path = FileCommon.GetUserAppDataPath();

      // Create new file name to store into AppDataPath
      fileName = path + @"\Product.xml";

      // Make sure the directory exists
      if (!Directory.Exists(path))
        Directory.CreateDirectory(path);

      // Write file
      File.WriteAllText(fileName, elem.ToString());

      MessageBox.Show("File Written: " + fileName);
    }

    private void btnReadUserStorage_Click(object sender, RoutedEventArgs e)
    {
      XElement elem = null;
      string fileName = string.Empty;

      // Build file name from local storage
      fileName = FileCommon.GetUserAppDataPath() + @"\Product.xml";

      // Make sure file exists
      if (File.Exists(fileName))
      {
        // Read file from local storage
        elem = XElement.Load(fileName);

        // Create a list of Product objects using LINQ to XML
        var products =
          from prod in elem.Elements("Product")
          orderby prod.Attribute("ProductName").Value
          select new Product
          {
            ProductId = Convert.ToInt32(prod.Attribute("ProductId").Value),
            ProductName = prod.Attribute("ProductName").Value,
            IntroductionDate = Convert.ToDateTime(prod.Attribute("IntroductionDate").Value),
            Cost = Convert.ToDecimal(prod.Attribute("Cost").Value),
            Price = Convert.ToDecimal(prod.Attribute("Price").Value),
            IsDiscontinued = Convert.ToBoolean(prod.Attribute("IsDiscontinued").Value),
            LastUpdated = Convert.ToDateTime(prod.Attribute("LastUpdated").Value)
          };

        lstData.DataContext = products;
      }
      else
        MessageBox.Show("File: " + fileName + " does not exist!");
    }

    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      string _FileName = string.Empty;
      
      // Build file name from local storage
      _FileName = FileCommon.GetUserAppDataPath() + @"\Product.xml";

      // Make sure file exists
      if (File.Exists(_FileName))
      {
        // Delete file from local storage
        File.Delete(_FileName);

        lstData.DataContext = null;

        MessageBox.Show("Local File Deleted");
      }
    }
  }
}
