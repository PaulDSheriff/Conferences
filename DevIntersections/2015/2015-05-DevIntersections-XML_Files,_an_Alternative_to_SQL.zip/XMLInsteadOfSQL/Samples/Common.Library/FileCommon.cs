﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;

namespace Common.Library
{
	public class FileCommon
	{
#if !WINDOWS_PHONE && !NETFX_CORE
		/// <summary>
		/// Get your user's roaming profile directory 
		/// This folder allows you to store information for your program in a custom 
		/// folder specifically for your program. The format of this directory looks like this:
		/// C:\Users\YOUR NAME\AppData\Roaming\COMPANY NAME\APPLICATION NAME\APPLICATION VERSION
		/// 
		/// For example, on a Windows 7/8 64-bit system, this folder might look like this for an application named 'MyApplication'
		/// C:\Users\Paul\AppData\Roaming\PDSA, Inc.\MyApplication\1.0.0.0
		/// </summary>
		/// <returns>A User Data Path</returns>
		public static string GetUserAppDataPath()
		{
			string path = string.Empty;
			Assembly assm;
			Type at;
			object[] r;

			// Get the .EXE assembly
			assm = Assembly.GetEntryAssembly();
			// Get a 'Type' of the AssemblyCompanyAttribute
			at = typeof(AssemblyCompanyAttribute);
			// Get a collection of custom attributes from the .EXE assembly
			r = assm.GetCustomAttributes(at, false);
			// Get the Company Attribute
			AssemblyCompanyAttribute ct =
										((AssemblyCompanyAttribute)(r[0]));
			// Build the User App Data Path
			path = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
			path += @"\" + ct.Company;
			path += @"\" + assm.GetName().Name;
			path += @"\" + assm.GetName().Version.ToString();

			return path;
		}

		/// <summary>
		/// Gets the current directory in which your application is running
		/// If you are running in VS.NET it will remove the \bin folder from the path.
		/// </summary>
		/// <returns>The current directory</returns>
		public static string GetCurrentDirectory()
		{
			string ret = (from assembly in
											AppDomain.CurrentDomain.GetAssemblies()
										where assembly.CodeBase.EndsWith(".exe")
										select Path.GetDirectoryName(
										assembly.CodeBase.Replace("file:///", ""))).FirstOrDefault();

			if (ret.IndexOf(@"\bin") > 0)
				ret = ret.Substring(0, ret.LastIndexOf(@"\bin"));

			return ret;
		}
#endif
	}
}