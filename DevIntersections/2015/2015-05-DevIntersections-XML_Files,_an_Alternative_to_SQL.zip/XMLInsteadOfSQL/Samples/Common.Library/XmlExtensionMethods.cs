﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Xml.Linq;

namespace Common.Library
{
  public static class XmlExtensionMethods
  {
    #region GetAs Method
    public static T GetAs<T>(this XAttribute attr, T defaultValue = default(T))
    {
      T ret = defaultValue;

      if (attr != null && !string.IsNullOrEmpty(attr.Value))
      {
        // Cast to Return Data Type 
        // NOTE: ChangeType does NOT work with Nullable Types
        ret = (T)Convert.ChangeType(attr.Value, typeof(T));
      }

      return ret;
    }
    #endregion

    #region GetLastUpdateDate Method
    public static DateTime GetLastUpdateDate(this XElement elem, string attrName, string parentNodeName)
    {
      // Get the Largest LastDate Updated Node
      DateTime maxDate =
        (from node in elem.Elements(parentNodeName)
         select node.Attribute(attrName).GetAs<DateTime>()).Max();

      return maxDate;
    }
    #endregion

    #region GetNextId
    public static int GetNextId(this XElement elem, string attrName, string parentNodeName)
    {
      // Get The last id
      var MaxID = (from node in elem.Elements(parentNodeName)
                   select node.Attribute(attrName).GetAs<int>()).Max();

      return MaxID + 1;
    }
    #endregion

    #region GetCount Method
    public static int GetCount(this XElement elem, string parentNodeName)
    {
      // Get The last Date Updated
      int count = (from node in elem.Elements(parentNodeName)
                   select node).Count();

      return count;
    }
    #endregion
  }
}
