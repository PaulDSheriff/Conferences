﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

#if !NETFX_CORE
using System.IO;
#endif

#if NETFX_CORE
using Windows.Storage;
#endif

namespace Common.Library
{
  public class LocalXmlAppStorage
  {
    #region Get Method
    public static string Get(string key)
    {
      return GetFromStorage(key);
    }

    #region Windows Store GetFromStorage Method
#if NETFX_CORE
    protected static string GetFromStorage(string key)
    {
      string value = string.Empty;

      if (ApplicationData.Current.LocalSettings.Values.ContainsKey(key))
        value = ApplicationData.Current.LocalSettings.Values[key].ToString();
      else
        value = GetFromFile(key).Result;

      return value;
    }

    public async static Task<string> GetFromFile(string key)
    {
      string value = string.Empty;

      // Get Name of local storage folder
      StorageFolder storageFolder =
          Windows.Storage.ApplicationData.Current.LocalFolder;
      // Open file from local storage
      StorageFile sampleFile =
          await storageFolder.GetFileAsync(key);

      // Get XML from file
      value = await Windows.Storage.FileIO.ReadTextAsync(sampleFile);

      return value;
    }
#endif
    #endregion

    #region Normal .NET GetFromStorage Method
#if !NETFX_CORE
    protected static string GetFromStorage(string key)
    {
      string value = string.Empty;
      string file = string.Empty;

      // NOTE: 'key' should be a valid file name
      file = FileCommon.GetUserAppDataPath() + @"\" + key;

      if (File.Exists(file))
      {
        value = File.ReadAllText(file);
      }

      return value;
    }
#endif
    #endregion
    #endregion

    #region Save Method
    public static void Save(string key, string xml)
    {
      SaveToStorage(key, xml);
    }

    #region Windows Store SaveToStorage Method
#if NETFX_CORE
    protected static void SaveToStorage(string key, string xml)
    {
      // Remove old data
      Remove(key);

      // NOTE: You could exceed the limit of the local settings area
      try
      {
        ApplicationData.Current.LocalSettings.Values[key] = xml;
      }
      catch
      {
        // If you exceed the limit, save to a file
        SaveToFile(key, xml);
      }
    }

    protected async static void SaveToFile(string key, string xml)
    {
      // Get Name of local storage folder
      StorageFolder folder =
          Windows.Storage.ApplicationData.Current.LocalFolder;
      // Create new file in local storage folder
      StorageFile sampleFile =
          await folder.CreateFileAsync(key, CreationCollisionOption.ReplaceExisting);

      // Write contents to the file
      await Windows.Storage.FileIO.WriteTextAsync(sampleFile, xml);
    }
#endif
    #endregion

    #region Normal .NET SaveToStorage Method
#if !NETFX_CORE
    protected static void SaveToStorage(string key, string xml)
    {
      string file = string.Empty;

      // NOTE: 'key' should be a valid file name
      file = FileCommon.GetUserAppDataPath() + @"\" + key;

      if (File.Exists(file))
        File.Delete(file);

      if(!Directory.Exists(FileCommon.GetUserAppDataPath()))
        Directory.CreateDirectory(FileCommon.GetUserAppDataPath());

      File.WriteAllText(file, xml);
    }
#endif
    #endregion
    #endregion

    #region Remove Method
    public static bool Remove(string key)
    {
      return RemoveKey(key);
    }

    #region Windows Store RemoveKey Method
#if NETFX_CORE
    protected static bool RemoveKey(string key)
    {
      bool ret = false;

      if (Exists(key))
      {
        ApplicationData.Current.LocalSettings.Values.Remove(key);
      }

      return ret;
    }
#endif
    #endregion

    #region Normal .NET RemoveKey Method
#if !NETFX_CORE
    protected static bool RemoveKey(string key)
    {
      bool ret = false;
      string file = string.Empty;

      // NOTE: 'key' should be a valid file name
      file = FileCommon.GetUserAppDataPath() + @"\" + key;

      if (File.Exists(file))
      {
        File.Delete(file);
        ret = true;
      }

      return ret;
    }
#endif
    #endregion
    #endregion

    #region Exists/Contains/ContainsKey Methods
    public static bool Exists(string key)
    {
      return KeyExists(key);
    }

    public static bool Contains(string key)
    {
      return Exists(key);
    }

    public static bool ContainsKey(string key)
    {
      return Exists(key);
    }

    #region Windows Store KeyExists Method
#if NETFX_CORE
    protected static bool KeyExists(string key)
    {
      bool ret = false;

      ret = ApplicationData.Current.LocalSettings.Values.ContainsKey(key);
      if (!ret)
      {
        // See if local file exists
        ret = FileExists(key).Result;
      }

      return ret;
    }

    protected async static Task<bool> FileExists(string key)
    {
      bool ret = false;

      // See if local file exists
      // Get Name of local storage folder
      StorageFolder folder =
          Windows.Storage.ApplicationData.Current.LocalFolder;
      try
      {
        // See if file exists
        StorageFile sampleFile =
            await folder.GetFileAsync(key);
        ret = true;
      }
      catch
      {
        ret = false;
      }

      return ret;
    }
#endif
    #endregion

    #region Normal .NET KeyExists Method
#if !NETFX_CORE
    protected static bool KeyExists(string key)
    {
      bool ret = false;
      string file = string.Empty;

      // NOTE: 'key' should be a valid file name
      file = FileCommon.GetUserAppDataPath() + @"\" + key;

      ret = File.Exists(file);

      return ret;
    }
#endif
    #endregion
    #endregion
  }
}
