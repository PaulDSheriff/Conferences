﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Xml.Linq;
using Common.Library;
using WPF_DetectChanges.ProductServiceReference;

namespace WPF_DetectChanges
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnClear_Click(object sender, RoutedEventArgs e)
    {
      lstData.DataContext = new List<Product>();
    }

    ProductServiceClient _Client = null;
    XElement _Elements = null; 
    const string STORAGE_KEY = "Product.xml";

    private void btnRead_Click(object sender, RoutedEventArgs e)
    {
      // Minimum date in SQL Server
      DateTime lastUpdated = Convert.ToDateTime("1753-01-01");  
      int rows = int.MinValue;
      string xml = string.Empty;

      _Client = new ProductServiceClient();
      if (LocalXmlAppStorage.Exists(STORAGE_KEY))
      {
        // Load local data
        _Elements = XElement.Parse(LocalXmlAppStorage.Get(STORAGE_KEY));

        // Get largest last update date
        lastUpdated = _Elements.GetLastUpdateDate("IntroductionDate", "Product");
        // Get total rows in XML
        rows = _Elements.GetCount("Product");
      }

      // Hook up Completed Event Handler
      _Client.GetXmlIfChangedCompleted += _Client_GetXmlIfChangedCompleted;

      // Check to see if we need to retrieve updated data from server
      _Client.GetXmlIfChangedAsync(lastUpdated, rows);
    }

    void _Client_GetXmlIfChangedCompleted(object sender, GetXmlIfChangedCompletedEventArgs e)
    {
      // e.Result will be empty if data has NOT changed
      if (!string.IsNullOrEmpty(e.Result))
      {
        txtMessages.Text = "Retrieved XML from Server.";

        // Data has changed, so parse and save locally
        _Elements = XElement.Parse(e.Result);

        // Save to local storage for next time
        LocalXmlAppStorage.Save(STORAGE_KEY, _Elements.ToString());
      }
      else
        txtMessages.Text = "Retrieved XML from Local Data Store.";
      
      // Create a list of Product objects from XElement object
      IEnumerable<Product> products =
        from prod in _Elements.Elements("Product")
        orderby prod.Attribute("ProductName").Value
        select new Product
        {
          ProductId = prod.Attribute("ProductId").GetAs<int>(),
          ProductName = prod.Attribute("ProductName").GetAs<string>(),
          IntroductionDate = prod.Attribute("IntroductionDate").GetAs<DateTime>(),
          Cost = prod.Attribute("Cost").GetAs<decimal>(),
          Price = prod.Attribute("Price").GetAs<decimal>(),
          IsDiscontinued = prod.Attribute("IsDiscontinued").GetAs<bool>(),
          LastUpdated = prod.Attribute("LastUpdated").GetAs<DateTime>()
        };
      
      lstData.DataContext = products;
    }

    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      // Delete from Local Storage
      LocalXmlAppStorage.Remove(STORAGE_KEY);
    }
  }
}
