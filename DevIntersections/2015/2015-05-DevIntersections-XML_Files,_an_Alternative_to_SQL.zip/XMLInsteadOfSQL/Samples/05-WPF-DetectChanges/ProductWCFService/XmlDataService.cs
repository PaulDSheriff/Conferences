﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace ProductWCFService
{
  public class XmlDataService
  {
    public static string GetXmlFromTable(string tableName, string rootName, string parentNodeName)
    {
      string ret = string.Empty;
      string sql = string.Empty;
      SqlDataAdapter da;
      DataSet ds = new DataSet();

      sql = "SELECT * FROM " + tableName;

      da = new SqlDataAdapter(sql,
        ConfigurationManager.ConnectionStrings["Sandbox"].ConnectionString);

      da.Fill(ds);

      // Create Attribute based XML
      foreach (DataColumn item in ds.Tables[0].Columns)
        item.ColumnMapping = MappingType.Attribute;

      ds.DataSetName = rootName;
      ds.Tables[0].TableName = parentNodeName;
      ret = ds.GetXml();

      return ret;
    }

    public static bool HasDataChanged(string tableName, string fieldName,
      DateTime lastUpdated, int rows)
    {
      bool ret = false;
      string sql = string.Empty;
      SqlCommand cmd = null;
      int count = 0;

      // This will check for any INSERTs or UPDATEs
      sql = "SELECT Count(*) FROM " + tableName;
      sql += " WHERE Convert(char(19), " + fieldName +
        ", 121) > Convert(char(19),Cast('" +
        Convert.ToDateTime(lastUpdated).ToString("yyyy-MM-dd HH:mm:ss tt") + "' as datetime), 121)";

      cmd = new SqlCommand();
      cmd.CommandText = sql;
      cmd.CommandType = CommandType.Text;
      cmd.Connection = new SqlConnection(
        ConfigurationManager.ConnectionStrings["Sandbox"].ConnectionString);
      cmd.Connection.Open();
      count = Convert.ToInt32(cmd.ExecuteScalar());

      if (count == 0)
      {
        // This will check for any DELETEs
        cmd.CommandText = "SELECT Count(*) FROM " + tableName;
        count = Convert.ToInt32(cmd.ExecuteScalar());

        // If these are different, at least one row has been deleted
        ret = (count != rows);
      }
      else
        ret = true;

      cmd.Connection.Close();
      cmd.Connection.Dispose();
      cmd.Dispose();

      return ret;
    }
  }
}