﻿using System;

namespace ProductWCFService
{
  public class ProductService : IProductService
  {
    public string GetXml()
    {
      return XmlDataService.GetXmlFromTable(tableName: "Product", rootName: "Products", parentNodeName: "Product");
    }

    public string GetXmlIfChanged(DateTime lastUpdated, int rows)
    {
      string ret = string.Empty;

      if (XmlDataService.HasDataChanged(tableName: "Product", fieldName: "IntroductionDate", lastUpdated: lastUpdated, rows: rows))
        ret = GetXml();

      return ret;
    }
  }
}
