﻿using System;
using System.ServiceModel;

namespace ProductWCFService
{
  [ServiceContract]
  public interface IProductService
  {
    [OperationContract]
    string GetXml();

    [OperationContract]
    string GetXmlIfChanged(DateTime lastUpdated, int rows);
  }
}
