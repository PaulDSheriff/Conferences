﻿using System;
using System.Linq;
using System.Windows;
using System.Xml.Linq;
using Common.Library;

namespace WPF_CacheLocal
{
  public partial class MainWindow : Window
  {
    #region Constructor
    public MainWindow()
    {
      InitializeComponent();
    }
    #endregion

    const string STORAGE_KEY = "Product.xml";

    private void btnReadProject_Click(object sender, RoutedEventArgs e)
    {
      XElement elem = null;

      // Read file from local project
      elem = XElement.Load(
        FileCommon.GetCurrentDirectory()
        + @"\Xml\" + STORAGE_KEY);

      // Save to Local XML Storage
      LocalXmlAppStorage.Save(STORAGE_KEY, elem.ToString());

      MessageBox.Show("XML Saved to Local Storage");
    }

    private void btnReadUserStorage_Click(object sender, RoutedEventArgs e)
    {
      XElement elem = null;

      if (LocalXmlAppStorage.Exists(STORAGE_KEY))
      {
        // Read file from local storage
        elem = XElement.Parse(
          LocalXmlAppStorage.Get(STORAGE_KEY));

        // Create a list of Product objects from XElement object
        var products =
          from prod in elem.Elements("Product")
          orderby prod.Attribute("ProductName").Value
          select new Product
          {
            ProductId = Convert.ToInt32(prod.Attribute("ProductId").Value),
            ProductName = prod.Attribute("ProductName").Value,
            IntroductionDate = Convert.ToDateTime(prod.Attribute("IntroductionDate").Value),
            Cost = Convert.ToDecimal(prod.Attribute("Cost").Value),
            Price = Convert.ToDecimal(prod.Attribute("Price").Value),
            IsDiscontinued = Convert.ToBoolean(prod.Attribute("IsDiscontinued").Value),
            LastUpdated = Convert.ToDateTime(prod.Attribute("LastUpdated").Value)
          };

        lstData.DataContext = products;
      }
      else
        MessageBox.Show("Local Storage Key: " + STORAGE_KEY + " does not exist!");
    }

    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      if (LocalXmlAppStorage.Exists(STORAGE_KEY))
      {
        LocalXmlAppStorage.Remove(STORAGE_KEY);

        lstData.DataContext = null;

        MessageBox.Show("Local Storage Key: " + STORAGE_KEY + " Deleted");
      }
      else
        MessageBox.Show("Local Storage Key: " + STORAGE_KEY + " does not exist!");
    }
  }
}
