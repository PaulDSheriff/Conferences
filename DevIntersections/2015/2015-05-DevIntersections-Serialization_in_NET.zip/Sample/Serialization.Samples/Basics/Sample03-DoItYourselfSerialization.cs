﻿using System;
using System.IO;
using System.Diagnostics;
using System.Reflection;

namespace Serialization.Samples
{
   #region Do-It-Yourself Formatter

   /// <summary>
   /// Use reflection to inspect the properties of 
   /// a class and then add name/value pairs to a stream
   /// </summary>
   public partial class DIYFormatter
   {
      // If you were to really implement your own,
      // you would implement the IFormatter interface.

      public void Serialize(Stream stream, object graph)
      {
         Debugger.Break();

         Type t = graph.GetType();

         foreach (MemberInfo info in t.GetMembers())
         {
            string item = string.Empty;

            if (info.MemberType == MemberTypes.Property)
            {
               PropertyInfo prop = (PropertyInfo)info;
               item = string.Format("{0}={1}|", info.Name, prop.GetValue(graph));
            }
            else if (info.MemberType == MemberTypes.Field)
            {
               FieldInfo field = (FieldInfo)info;
               item = string.Format("{0}={1}|", info.Name, field.GetValue(graph));
            }

            foreach (byte b in System.Text.Encoding.UTF8.GetBytes(item))
            {
                stream.WriteByte(b);
            }            
         }
      }
   }

   #endregion

   /// <summary>
   /// Demonstrates what you would have to do if you were going
   /// to write your own serializer
   /// </summary>
   public class Sample03 : ISample
   {
      public void RunDemo()
      {
         CustomerB customer = new CustomerB
         {
            CustomerNumber = 1,
            CustomerName = "PDSA, Inc.",
            CustomerType = 2
         };

         Stream stream = Utility.CreateFileStream("Sample03.bin");
         DIYFormatter formatter = new DIYFormatter();
         formatter.Serialize(stream, customer);
         stream.Close();
      }
   }
}
