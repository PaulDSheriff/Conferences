﻿
namespace Serialization.Samples
{
   public class CustomerA
   {
      public CustomerA()
      {
      }

      public CustomerA(string name, int id)
      {
         // do nothing, just a sample
      }

      public int CustomerNumber { get; set; }
      public string CustomerName { get; set; }
      public int CustomerType { get; set; }
   }
}
