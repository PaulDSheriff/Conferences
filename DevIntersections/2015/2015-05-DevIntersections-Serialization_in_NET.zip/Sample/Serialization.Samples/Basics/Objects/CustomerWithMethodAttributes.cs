﻿using System.Runtime.Serialization;

namespace Serialization.Samples
{
   public class CustomerF
   {
      public int CustomerNumber { get; set; }
      public string CustomerName { get; set; }
      public int CustomerType { get; set; }

      [OnSerializing()]
      internal void OnSerializing(StreamingContext context)
      {

      }

      [OnSerialized()]
      internal void OnSerialized(StreamingContext context)
      {

      }

      [OnDeserializing()]
      internal void OnDeserializing(StreamingContext context)
      {
         
      }

      [OnDeserialized()]
      internal void OnDeserialized(StreamingContext context)
      {
         
      }

   }
}
