﻿using System;

namespace Serialization.Samples
{
   [Serializable]
   public class CustomerB
   {
      public int CustomerNumber { get; set; }
      public string CustomerName { get; set; }
      public int CustomerType { get; set; }
   }
}
