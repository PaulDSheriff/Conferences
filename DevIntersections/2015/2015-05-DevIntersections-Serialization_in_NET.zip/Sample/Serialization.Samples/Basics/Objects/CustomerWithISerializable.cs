﻿using System;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace Serialization.Samples
{
   [Serializable]
   public class CustomerD : ISerializable
   {
      public int CustomerNumber { get; set; }
      public string CustomerName { get; set; }
      public int CustomerType { get; set; }

      #region Constructors

      public CustomerD() { }

      public CustomerD(SerializationInfo info, StreamingContext context)
      {
         Debugger.Break();

         this.CustomerNumber = info.GetInt32("id");
         this.CustomerName = info.GetString("name");
         this.CustomerType = info.GetInt32("type");
      }

      #endregion

      public void GetObjectData(SerializationInfo info, StreamingContext context)
      {
         Debugger.Break();

         info.AddValue("id", this.CustomerNumber);
         info.AddValue("name", this.CustomerName);
         info.AddValue("type", this.CustomerType);
      }
   }
}
