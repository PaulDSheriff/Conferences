﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Serialization.Samples
{
   [Serializable]
   public class CustomerC
   {
      public int CustomerNumber { get; set; }

      public string CustomerName { get; set; }
      public int CustomerType { get; set; }

      // Only fields (a.k.a member variables) can be marked 
      // with the NonSerialized attribute.
      [NonSerialized]
      public int CustomerStatus;

      // To prevent serialization of a property, mark
      // its backing field with the NonSerialized attribute.
      [NonSerialized]
      private double _creditLimit;

      public double CreditLimit
      {
         get { return _creditLimit;  }
         set { _creditLimit = value; }
      }
   }
}
