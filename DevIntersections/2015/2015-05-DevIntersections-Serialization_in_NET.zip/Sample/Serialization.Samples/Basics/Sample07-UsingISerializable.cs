﻿using System;
using System.Diagnostics;

namespace Serialization.Samples
{
   /// <summary>
   /// Demonstrates serializing a class that implements the 
   /// ISerializable interface.
   /// </summary>
   public class Sample07 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();

         CustomerD customer = new CustomerD
         {
            CustomerNumber = 1,
            CustomerName = "PDSA, Inc.",
            CustomerType = 2,
         };

         try
         {
            // Moved the stream and formatter to a utility class
            Utility.SerializeToFile(customer, "Sample07.bin");
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
