﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Serialization.Samples
{
   /// <summary>
   /// De-serialize an object serialized using custom
   /// member information
   /// </summary>
   public class Sample08 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();

         try
         {
            // Moved the stream and formatter to a utility class
            CustomerD customer = (CustomerD)Utility.DeserializeFromFile("Sample07.bin");
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
