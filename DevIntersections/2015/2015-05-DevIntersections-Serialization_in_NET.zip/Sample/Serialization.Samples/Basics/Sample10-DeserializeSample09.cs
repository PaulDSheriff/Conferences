﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Serialization.Samples
{
   #region Customer Serialization Surrogate

   public class CustomerDeserializationSurrogate : ISerializationSurrogate
   {
      public void GetObjectData(object obj, SerializationInfo info, StreamingContext context)
      {
         // Used with serialization
      }

      public object SetObjectData(object obj, SerializationInfo info, StreamingContext context, ISurrogateSelector selector)
      {
         if (!(obj is CustomerD))
         {
            throw new ArgumentException("CustomerSerializationSurrogate only handles type CustomerD", "obj");
         }

         CustomerD customer = (CustomerD)obj;
         //info.AddValue("name", customer.CustomerName);

         customer.CustomerNumber = info.GetInt32("id");
         customer.CustomerName = info.GetString("name");
         customer.CustomerType = info.GetInt32("type");

         return customer;
      }
   }

   #endregion

   /// <summary>
   /// De-serialize an object serialized using custom
   /// member information
   /// </summary>
   public class Sample10 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();

         CustomerD customer = new CustomerD
         {
            CustomerNumber = 1,
            CustomerName = "PDSA, Inc.",
            CustomerType = 2,
         };

         try
         {
            // Create an instance of a surrogate selector
            SurrogateSelector selector = new SurrogateSelector();

            // Add our custom surrogate for CustomerD to the selector
            selector.AddSurrogate(typeof(CustomerD),
               new StreamingContext(StreamingContextStates.All),
               new CustomerDeserializationSurrogate());

            // Pass the selector to our utility class
            Utility.DeserializeFromFile("Sample09.bin", selector);
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
