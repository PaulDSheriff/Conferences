﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace Serialization.Samples
{
   #region Do-It-Yourself Deserialization

   public partial class DIYFormatter
   {
      // If you were to really implement your own,
      // you would implement the IFormatter interface.

      public object Deserialize(Stream stream)
      {
         Debugger.Break();

         // In reality, the assembly and type name
         // would be stored in the file; in this
         // case, we know what type we serialized

         CustomerB result = new CustomerB();

         StringBuilder sb = new StringBuilder(1024);
         using (StreamReader sr = new StreamReader(stream, Encoding.UTF8))
         {
            string line;
            while ((line = sr.ReadLine()) != null)
            {
               sb.Append(line);
            }
         }

         string[] values = sb.ToString().Split("|".ToCharArray());
         foreach (string item in values)
         {
            string[] kvp = item.Split("=".ToCharArray());
            if (kvp.Length > 0)
            {
               switch (kvp[0])
               {
                  case "CustomerName":
                     result.CustomerName = kvp[1];
                     break;
                  case "CustomerNumber":
                     result.CustomerNumber = Convert.ToInt32(kvp[1]);
                     break;
                  case "CustomerType":
                     result.CustomerType = Convert.ToInt32(kvp[1]);
                     break;
               }
            }
         }

         return result;
      }
   }

   #endregion

   /// <summary>
   /// Deserialize the class serialized using do-it-yourself
   /// serialization.
   /// </summary>
   public class Sample04 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();

         Stream stream = Utility.ReadFileStream("Sample03.bin");
         DIYFormatter formatter = new DIYFormatter();
         CustomerB customer = (CustomerB)formatter.Deserialize(stream);
         stream.Close();

         Debug.WriteLine(customer.CustomerName);
      }
   }
}
