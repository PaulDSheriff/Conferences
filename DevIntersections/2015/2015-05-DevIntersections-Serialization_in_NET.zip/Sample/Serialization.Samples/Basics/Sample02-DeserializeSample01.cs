﻿using System;
using System.IO;
using System.Diagnostics;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Serialization.Samples
{
   /// <summary>
   /// Deserialize the class serialized in Sample 1.
   /// </summary>
   public class Sample02 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();

         // Need a stream that contains something to be deserialized and a formatter

         try
         {
            // Get a stream
            Stream stream = Utility.ReadFileStream("Sample01.bin");

            // Create a formatter
            IFormatter formatter = new BinaryFormatter();

            // Use the formatter to deserialize your object
            CustomerB customer = (CustomerB)formatter.Deserialize(stream);

            // Remember to close the stream
            stream.Close();

            Debug.WriteLine(customer.CustomerName);
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
