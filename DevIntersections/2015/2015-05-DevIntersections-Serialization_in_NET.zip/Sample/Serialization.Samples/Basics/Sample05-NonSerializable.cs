﻿using System;
using System.IO;
using System.Diagnostics;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Serialization.Samples
{
   /// <summary>
   /// Demonstrates using the NonSerialized attribute to 
   /// prevent serialization of fields in a class.
   /// </summary>
   public class Sample05 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();

         CustomerC customer = new CustomerC
         {
            CustomerNumber = 1,
            CustomerName = "PDSA, Inc.",
            CustomerType = 2,
            CustomerStatus = 1,
            CreditLimit = 10000.00
         };

         try
         {
            Stream stream = Utility.CreateFileStream("Sample05.bin");
            IFormatter formatter = new BinaryFormatter();
            formatter.Serialize(stream, customer);
            stream.Close();
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
