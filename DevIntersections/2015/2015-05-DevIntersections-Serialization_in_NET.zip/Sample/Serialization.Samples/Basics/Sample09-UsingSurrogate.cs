﻿using System;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace Serialization.Samples
{
   #region Customer Serialization Surrogate

   public class CustomerSerializationSurrogate : ISerializationSurrogate
   {
      public void GetObjectData(object obj, SerializationInfo info, StreamingContext context)
      {
         Debugger.Break();

         if (!(obj is CustomerD))
         {
            throw new ArgumentException("CustomerSerializationSurrogate only handles type CustomerD", "obj");
         }

         CustomerD customer = (CustomerD)obj;
         info.AddValue("id", customer.CustomerNumber);
         info.AddValue("name", customer.CustomerName);
         info.AddValue("type", customer.CustomerType);
      }

      public object SetObjectData(object obj, SerializationInfo info, StreamingContext context, ISurrogateSelector selector)
      {
         // Used with deserialization
         return null;
      }
   }

   #endregion

   /// <summary>
   /// Demonstrates serializing a class that acts as 
   /// a surrogate for another class during serialization.
   /// </summary>
   public class Sample09 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();

         CustomerD customer = new CustomerD
         {
            CustomerNumber = 1,
            CustomerName = "PDSA, Inc.",
            CustomerType = 2,
         };

         try
         {
            // Create an instance of a surrogate selector
            SurrogateSelector selector = new SurrogateSelector();

            // Add our custom surrogate for CustomerD to the selector
            selector.AddSurrogate(typeof(CustomerD),
               new StreamingContext(StreamingContextStates.All),
               new CustomerSerializationSurrogate());

            // Pass the selector to our utility class
            Utility.SerializeToFile(customer, "Sample09.bin", selector);
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
