﻿using System;
using System.IO;
using System.Diagnostics;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Serialization.Samples
{
   public class Sample06 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();

         try
         {
            Stream stream = Utility.ReadFileStream("Sample05.bin");
            IFormatter formatter = new BinaryFormatter();
            CustomerC customer = (CustomerC)formatter.Deserialize(stream);
            stream.Close();

            Debug.WriteLine(customer.CreditLimit);
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
