﻿using System;
using System.IO;
using System.Diagnostics;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Serialization.Samples
{
   /// <summary>
   /// Demonstrates the simplest case for serializing a class.
   /// </summary>
   public class Sample01 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();

         // Need an object to be serialized, a stream and a formatter

         // First, what happens if you try to serialize
         // just a 'regular' class?
         CustomerA customer = new CustomerA
         {
            CustomerNumber = 1,
            CustomerName = "PDSA, Inc.",
            CustomerType = 2
         };

         #region Another Class

         // So, at a minimum, you must have a class
         // decorated with the [Serializable] attribute.

         //CustomerB customer = new CustomerB
         //{
         //   CustomerNumber = 1,
         //   CustomerName = "PDSA, Inc.",
         //   CustomerType = 2
         //};

         #endregion

         try
         {
            // Create a stream
            Stream stream = Utility.CreateFileStream("Sample01.bin");

            // Create a formatter
            IFormatter formatter = new BinaryFormatter();
            
            // Use the formatter to serialize your object
            formatter.Serialize(stream, customer);
            
            // Don't forget to close the stream!
            stream.Close();
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
