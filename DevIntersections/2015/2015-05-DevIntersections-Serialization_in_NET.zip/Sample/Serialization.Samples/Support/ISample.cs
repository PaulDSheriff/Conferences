﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Serialization.Samples
{
   /// <summary>
   /// Interface for all sample classes
   /// </summary>
   public interface ISample
   {
      void RunDemo();
   }
}
