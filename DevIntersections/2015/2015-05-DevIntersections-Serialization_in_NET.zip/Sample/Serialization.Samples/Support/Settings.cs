﻿
namespace Serialization.Samples
{
   public class Settings
   {
      public static string OutputPath
      {
         get
         {
            // Really... put this in a config file
            return @"D:\Talks\SerializationInDotNet\Sample\Serialization.Output";
         }
      }
   }
}
