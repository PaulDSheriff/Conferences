﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;

namespace Serialization.Samples
{
   public class Utility
   {
      #region Get file name with path

      public static string GetFileName(string fileName)
      {
         string result = string.Empty;

         result = System.IO.Path.Combine(Settings.OutputPath, fileName);

         return result;
      }

      #endregion

      #region Create file stream

      public static Stream CreateFileStream(string fileName)
      {
         return File.Open(Utility.GetFileName(fileName), FileMode.Create);
      }

      #endregion

      #region Read file stream

      public static Stream ReadFileStream(string fileName)
      {
         return File.OpenRead(Utility.GetFileName(fileName));
      }

      #endregion
      
      public static void SerializeToFile(object graph, string fileName)
      {
         Stream stream = Utility.CreateFileStream(fileName);
         IFormatter formatter = new BinaryFormatter();
         formatter.Serialize(stream, graph);
         stream.Close();
      }

      internal static void SerializeToFile(object graph, string fileName, SurrogateSelector selector)
      {
         Stream stream = Utility.CreateFileStream(fileName);
         IFormatter formatter = new BinaryFormatter();

         // Assign the surrogate selector (which holds 
         // a collection of surrogates) to the formatter's
         // SurrogateSelector property.

         formatter.SurrogateSelector = selector;
         
         formatter.Serialize(stream, graph);
         stream.Close();
      }

      public static object DeserializeFromFile(string fileName)
      {
         object result;
         
         Stream stream = Utility.ReadFileStream(fileName);
         IFormatter formatter = new BinaryFormatter();
         result = formatter.Deserialize(stream);
         stream.Close();

         return result;
      }

      public static object DeserializeFromFile(string fileName, SurrogateSelector selector)
      {
         object result;

         Stream stream = Utility.ReadFileStream(fileName);
         IFormatter formatter = new BinaryFormatter();

         // Assign the surrogate selector (which holds 
         // a collection of surrogates) to the formatter's
         // SurrogateSelector property.

         formatter.SurrogateSelector = selector;

         result = formatter.Deserialize(stream);
         stream.Close();

         return result;        
      }

      public static void SerializeToXMLFile(Object graph, Type type, string fileName)
      {
         XmlSerializer serializer = new XmlSerializer(type);
         Stream stream = Utility.CreateFileStream(fileName);
         serializer.Serialize(stream, graph);
         stream.Close();
      }

      public static void SerializeToXMLFile(Object graph, Type type, string fileName, XmlAttributeOverrides overrides)
      {
         XmlSerializer serializer = new XmlSerializer(type, overrides);
         Stream stream = Utility.CreateFileStream(fileName);
         serializer.Serialize(stream, graph);
         stream.Close();
      }

      public static object DeserializeFromXMLFile(Type type, string fileName)
      {
         object result;

         XmlSerializer serializer = new XmlSerializer(type);
         Stream stream = Utility.ReadFileStream(fileName);
         result = serializer.Deserialize(stream);
         stream.Close();

         return result;
      }

      public static object DeserializeFromXMLFile(Type type, string fileName, XmlAttributeOverrides overrides)
      {
         object result;

         XmlSerializer serializer = new XmlSerializer(type, overrides);
         Stream stream = Utility.ReadFileStream(fileName);
         result = serializer.Deserialize(stream);
         stream.Close();

         return result;
      }
   }
}
