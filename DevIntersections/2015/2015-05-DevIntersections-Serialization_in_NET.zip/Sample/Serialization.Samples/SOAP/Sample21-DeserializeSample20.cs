﻿using System;
using System.IO;
using System.Diagnostics;
using System.Xml.Serialization;

namespace Serialization.Samples
{
   /// <summary>
   /// Deserialize the SOAP created in sample 19
   /// </summary>
   public class Sample21 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();
         
         try
         {
            SoapReflectionImporter importer = new SoapReflectionImporter();
            XmlTypeMapping mapping = importer.ImportTypeMapping(typeof(CustomerA));
            XmlSerializer serializer = new XmlSerializer(mapping);
            Stream stream = Utility.ReadFileStream("Sample19.xml");

            CustomerA customer = (CustomerA)serializer.Deserialize(stream);

            stream.Close();
            Debug.WriteLine(customer.CustomerName);
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
