﻿using System;
using System.IO;
using System.Diagnostics;
using System.Xml.Serialization;
using System.Collections.Generic;

namespace Serialization.Samples
{
   /// <summary>
   /// Demonstrates serializing an object using
   /// SOAP encoded format
   /// </summary>
   /// <remarks>
   /// You may recall that serialization had something called a SoapFormatter.
   /// Here is what it says in MSDN:
   /// 
   ///   "Beginning with the .NET Framework 2.0, this class is obsolete. 
   ///   Use BinaryFormatter instead."
   /// </remarks>
   public class Sample20 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();

         CustomerA customer = null;

         // Class does not have any attributes 
         // controlling element names
         customer = new CustomerA
         {
            CustomerNumber = 1,
            CustomerName = "PDSA, Inc.",
            CustomerType = 2,
         };

         try
         {
            // Create a soap reflection importer
            // ...a what?
            // MSDN: Generates mappings to SOAP-encoded messages 
            // from .NET Framework types or Web service method information
            SoapReflectionImporter importer = new SoapReflectionImporter();

            // Use the importer to create a type mapping for our type
            // (essentially a container for the SOAP type mapping)
            XmlTypeMapping mapping = importer.ImportTypeMapping(typeof(CustomerA));

            // Create a serializer using the mapping
            XmlSerializer serializer = new XmlSerializer(mapping);

            // Create a stream
            Stream stream = Utility.CreateFileStream("Sample19.xml");

            // Call serialize
            serializer.Serialize(stream, customer);

            // Close the stream
            stream.Close();
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
