﻿using System;
using System.IO;
using System.Diagnostics;
using System.Xml.Serialization;
using System.Collections.Generic;

namespace Serialization.Samples
{
   #region Customer class

   public class CustomerWithSoapAttributes
   {
      [SoapAttribute("Id")]
      public int CustomerNumber { get; set; }

      [SoapElement("Name")]
      public string CustomerName { get; set; }

      [SoapIgnore]
      public int CustomerType { get; set; }
   }

   #endregion

   /// <summary>
   /// Demonstrates serializing an object using
   /// SOAP encoded format with attributes
   /// </summary>
   public class Sample22 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();

         // Class does not have any attributes 
         // controlling element names
         CustomerWithSoapAttributes customer = new CustomerWithSoapAttributes
         {
            CustomerNumber = 1,
            CustomerName = "PDSA, Inc.",
            CustomerType = 2,
         };

         try
         {
            SoapReflectionImporter importer = new SoapReflectionImporter();
            XmlTypeMapping mapping = importer.ImportTypeMapping(
               typeof(CustomerWithSoapAttributes));
            XmlSerializer serializer = new XmlSerializer(mapping);
            Stream stream = Utility.CreateFileStream("Sample21.xml");
            serializer.Serialize(stream, customer);
            stream.Close();
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
