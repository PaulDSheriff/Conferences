﻿using System;
using System.IO;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace Serialization.Samples
{
   #region Customer class

   [DataContract]
   public class CustomerWithDataContract
   {
      [DataMember]
      public int CustomerNumber { get; set; }

      [DataMember]
      public string CustomerName { get; set; }

      [IgnoreDataMember]
      public int CustomerType { get; set; }
   }

   #endregion

   /// <summary>
   /// Demonstrates serializing an object 
   /// marked with data contract attributes
   /// using data contract serializer
   /// </summary>
   public class Sample23 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();

         CustomerWithDataContract customer = new CustomerWithDataContract
         {
            CustomerNumber = 1,
            CustomerName = "PDSA, Inc.",
            CustomerType = 2,
         };

         try
         {
            // Create a serializer 
            DataContractSerializer serializer = 
               new DataContractSerializer(typeof(CustomerWithDataContract));

            // Could also use the NetDataContractSerializer which emits the full
            // .NET framework assembly and type names in the XML output

            // Create a stream
            Stream stream = Utility.CreateFileStream("Sample22.xml");

            // Call serialize
            serializer.WriteObject(stream, customer);

            // Close the stream
            stream.Close();
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
