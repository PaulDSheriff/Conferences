﻿using System;
using System.IO;
using System.Diagnostics;
using System.Xml.Serialization;
using System.Collections.Generic;

namespace Serialization.Samples
{
   #region Customer With Attributes

   [XmlRoot("Customer")]
   public class CustomerE
   {
      [XmlElement(ElementName = "Id")]
      public int CustomerNumber { get; set; }
      
      [XmlElement(ElementName = "Name")]
      public string CustomerName { get; set; }

      [XmlElement(ElementName = "Type")]
      public int CustomerType { get; set; }

      [XmlArray("Staff")]
      [XmlArrayItem("Employee")]
      public string[] Employees { get; set; }

      [XmlIgnore]
      public string Address { get; set; }
   }

   #endregion

   /// <summary>
   /// Demonstrates serializing a class set up
   /// with attributes controlling serialization
   /// </summary>
   public class Sample15 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();

         CustomerE customer = new CustomerE
         {
            CustomerNumber = 1,
            CustomerName = "PDSA, Inc.",
            CustomerType = 2,
            Employees = new string[] { "Paul", "Jim", "John" },
            Address = "17852 17th Street, Suite 205, Tustin, CA 92780"
         };

         try
         {
            Utility.SerializeToXMLFile(customer, 
               typeof(CustomerE), "Sample15.xml");
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
