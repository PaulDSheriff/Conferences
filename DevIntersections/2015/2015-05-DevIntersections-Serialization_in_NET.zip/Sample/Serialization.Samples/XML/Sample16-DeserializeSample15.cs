﻿using System;
using System.IO;
using System.Diagnostics;
using System.Xml.Serialization;

namespace Serialization.Samples
{
   /// <summary>
   /// Deserialize the XML created in sample 15
   /// </summary>
   public class Sample16 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();
         
         try
         {
            CustomerE customer = 
               (CustomerE)Utility.DeserializeFromXMLFile(
                  typeof(CustomerE), "Sample15.xml");

            Debug.WriteLine(customer.Employees[0]);
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
