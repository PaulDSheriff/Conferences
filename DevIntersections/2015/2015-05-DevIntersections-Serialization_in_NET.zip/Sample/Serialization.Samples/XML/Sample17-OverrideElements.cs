﻿using System;
using System.IO;
using System.Diagnostics;
using System.Xml.Serialization;
using System.Collections.Generic;

namespace Serialization.Samples
{
   /// <summary>
   /// Demonstrates overriding an element name
   /// when serializing an existing class
   /// </summary>
   public class Sample17 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();

         CustomerA customer = null;

         // Class does not have any attributes 
         // controlling element names
         customer = new CustomerA
         {
            CustomerNumber = 1,
            CustomerName = "PDSA, Inc.",
            CustomerType = 2,
         };

         try
         {
            // Create an element attribute
            XmlElementAttribute attrib =
               new XmlElementAttribute { ElementName = "Name" };
            
            // Create an attributes instance and add our element
            XmlAttributes collection = new XmlAttributes();
            collection.XmlElements.Add(attrib);

            // Create an overrides instance and add our attributes
            XmlAttributeOverrides overrides = new XmlAttributeOverrides();
            overrides.Add(typeof(CustomerA), "CustomerName", collection);
            
            Utility.SerializeToXMLFile(customer, 
               typeof(CustomerA), "Sample17.xml", overrides);
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
