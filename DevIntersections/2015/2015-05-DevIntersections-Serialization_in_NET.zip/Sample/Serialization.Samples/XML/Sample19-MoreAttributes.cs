﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Serialization.Samples
{
   public class Sample19 : ISample
   {

      public void RunDemo()
      {
         Debugger.Break();

         CustomerWithRuntimeAttributes customer = new CustomerWithRuntimeAttributes
         {
            CustomerNumber = 1,
            CustomerName = "PDSA, Inc.",
            CustomerType = 2,
            LanguageCode = LanguageCodeType.enUS
         };

         try
         {
            // Create a serializer
            XmlSerializer serializer = new XmlSerializer(typeof(CustomerWithRuntimeAttributes));

            // Create a stream
            Stream stream = Utility.CreateFileStream("Sample19.xml");

            // Call serialize
            serializer.Serialize(stream, customer);

            // Close the stream
            stream.Close();
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
