﻿using System;
using System.IO;
using System.Diagnostics;
using System.Xml.Serialization;

namespace Serialization.Samples
{
   /// <summary>
   /// Deserialize the XML created in sample 17
   /// </summary>
   public class Sample18 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();
         
         try
         {
            // Create the same override
            XmlElementAttribute attrib = new XmlElementAttribute { ElementName = "Name" };
            XmlAttributes collection = new XmlAttributes();
            collection.XmlElements.Add(attrib);
            XmlAttributeOverrides overrides = new XmlAttributeOverrides();
            overrides.Add(typeof(CustomerA), "CustomerName", collection);

            CustomerA customer = (CustomerA)Utility.DeserializeFromXMLFile(
               typeof(CustomerA), "Sample17.xml", overrides);

            Debug.WriteLine(customer.CustomerName);
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
