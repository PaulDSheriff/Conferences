﻿using System;
using System.IO;
using System.Diagnostics;
using System.Xml.Serialization;

namespace Serialization.Samples
{
   /// <summary>
   /// Deserialize the basic XML created in sample 11
   /// </summary>
   public class Sample12 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();
         
         try
         {
            // Create a serializer
            XmlSerializer serializer = new XmlSerializer(typeof(CustomerA));

            // Open a stream
            Stream stream = Utility.ReadFileStream("Sample11.xml");

            // Call deserialize
            CustomerA customer = (CustomerA)serializer.Deserialize(stream);

            // Close the stream
            stream.Close();

            Debug.WriteLine(customer.CustomerName);
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
