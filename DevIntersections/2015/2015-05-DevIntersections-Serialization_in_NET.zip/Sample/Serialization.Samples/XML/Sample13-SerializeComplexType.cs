﻿using System;
using System.IO;
using System.Diagnostics;
using System.Xml.Serialization;
using System.Collections.Generic;

namespace Serialization.Samples
{
   #region Sample Customer Classes

   public class Address
   {
      public string StreetAddress { get; set; }
      public string UnitOrSuite { get; set; }
      public string City { get; set; }
      public string StateOrProvince { get; set; }
      public string ZipOrPostalCode { get; set; }
   }

   public class Contact
   {
      public string Name { get; set; }
      public string Telephone { get; set; }
   }

   public class Invoice
   {
      public double Amount { get; set; }
   }

   public class InvoiceCollection : List<Invoice>
   {
   }

   public class ComplexCustomer
   {
      public ComplexCustomer()
      {
         this.Contacts = new Contact[2];
         this.Invoices = new InvoiceCollection();
         this.Address = new Address();
      }

      public int CustomerNumber { get; set; }
      public string CustomerName { get; set; }
      public int CustomerType { get; set; }
      public Address Address { get; set; }
      public Contact[] Contacts { get; set; }
      public InvoiceCollection Invoices { get; set; }
   }

   #endregion

   /// <summary>
   /// Demonstrates serializing a complex object with
   /// properties of other types, arrays and collections
   /// </summary>
   public class Sample13 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();

         ComplexCustomer customer = CreateCustomer();

         try
         {
            XmlSerializer serializer = new XmlSerializer(typeof(ComplexCustomer));
            Stream stream = Utility.CreateFileStream("Sample13.xml");
            serializer.Serialize(stream, customer);
            stream.Close();
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }

      #region Create Customer Method

      private ComplexCustomer CreateCustomer()
      {
         ComplexCustomer customer = new ComplexCustomer();

         customer.CustomerNumber = 1;
         customer.CustomerName = "PDSA, Inc.";
         customer.CustomerType = 2;

         customer.Invoices.Add(new Invoice { Amount = 1000 });
         customer.Invoices.Add(new Invoice { Amount = 2000 });

         customer.Address.StreetAddress = "17852 17th Street";
         customer.Address.UnitOrSuite = "Suite 205";
         customer.Address.City = "Tustin";
         customer.Address.StateOrProvince = "CA";
         customer.Address.ZipOrPostalCode = "90242";

         customer.Contacts[0] = new Contact { Name = "Paul", Telephone = "714.734.9792" };
         customer.Contacts[1] = new Contact { Name = "John", Telephone = "714.734.9792" };

         return customer;
      }

      #endregion

   }
}
