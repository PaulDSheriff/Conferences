﻿using System;
using System.IO;
using System.Diagnostics;
using System.Xml.Serialization;

namespace Serialization.Samples
{
   /// <summary>
   /// Deserialize the complex XML created in sample 13
   /// </summary>
   public class Sample14 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();
         
         try
         {
            XmlSerializer serializer = new XmlSerializer(typeof(ComplexCustomer));
            Stream stream = Utility.ReadFileStream("Sample13.xml");
            ComplexCustomer customer = (ComplexCustomer)serializer.Deserialize(stream);
            stream.Close();

            Debug.WriteLine(customer.Contacts[0].Name);
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
