﻿using System;
using System.IO;
using System.Diagnostics;
using System.Xml.Serialization;

namespace Serialization.Samples
{
   /// <summary>
   /// Serialize a class as XML
   /// </summary>
   /// <remarks>
   /// Note -- mention IXmlSerializable as well
   /// </remarks>
   public class Sample11 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();

        // CustomerA customer = null;

         // customer = new CustomerA("PDSA, Inc.", 1);

         CustomerA customer = new CustomerA
         {
            CustomerNumber = 1,
            CustomerName = "PDSA, Inc.",
            CustomerType = 2
         };

         try
         {
            // Create a serializer
            XmlSerializer serializer = new XmlSerializer(typeof(CustomerA));

            // Create a stream
            Stream stream = Utility.CreateFileStream("Sample11.xml");

            // Call serialize
            serializer.Serialize(stream, customer);

            // Close the stream
            stream.Close();
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
