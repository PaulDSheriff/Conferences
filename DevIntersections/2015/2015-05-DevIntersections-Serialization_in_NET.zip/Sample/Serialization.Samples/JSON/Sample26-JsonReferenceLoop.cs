﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Serialization.Samples
{
   #region Complex Class

   public class CustomerG
   {
      public string CustomerName { get; set; }
      public decimal CreditLimit { get; set; }

      // Option 2:
      //[JsonIgnore]
      public CustomerInvoice Invoice { get; set; }

      // Option 3:
      //[OnSerializing]
      //public void DoSomething(StreamingContext ctx)
      //{
      //   Debugger.Break();
      //}
   }

   public class CustomerInvoice
   {
      public CustomerInvoice(CustomerG customer)
      {
         this.BillTo = customer;
         this.LineItems = new InvoiceLineItemCollection();
         customer.Invoice = this;
      }
      
      public CustomerG BillTo { get; set; }

      public InvoiceLineItemCollection LineItems { get; set; }
   }

   public class InvoiceLineItem
   {

   }

   public class InvoiceLineItemCollection : List<InvoiceLineItem>
   {

   }

   #endregion

   /// <summary>
   /// 
   /// </summary>
   public class Sample26 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();

         CustomerG customer = new CustomerG
         {
            CustomerName = "PDSA, Inc.",
            CreditLimit = 999999.99M
         };

         CustomerInvoice invoice = new CustomerInvoice(customer);         

         // Create a stream
         Stream stream = Utility.CreateFileStream("Sample26.txt");
         StreamWriter writer = new StreamWriter(stream);

         // Create a JsonTextWriter to output to the stream
         using (JsonWriter jw = new JsonTextWriter(writer))
         {
            jw.Formatting = Formatting.Indented;

            JsonSerializer serializer = new JsonSerializer();
            // Option 1:
            // serializer.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
            serializer.Serialize(jw, invoice);
         }
      }
   }
}
