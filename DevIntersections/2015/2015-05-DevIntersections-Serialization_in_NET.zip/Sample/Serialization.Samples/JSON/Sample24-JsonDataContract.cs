﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.Serialization.Json;

namespace Serialization.Samples
{
   /// <summary>
   /// Demonstrates serializing an object 
   /// marked with data contract attributes
   /// using json serializer
   public class Sample24 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();

         CustomerWithDataContract customer = new CustomerWithDataContract
         {
            CustomerNumber = 1,
            CustomerName = "PDSA, Inc.",
            CustomerType = 2,
         };

         try
         {
            // Create a serializer 
            DataContractJsonSerializer serializer =
               new DataContractJsonSerializer(typeof(CustomerWithDataContract));

            // Create a stream
            Stream stream = Utility.CreateFileStream("Sample23.txt");

            // Call serialize
            serializer.WriteObject(stream, customer);

            // Close the stream
            stream.Close();
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
