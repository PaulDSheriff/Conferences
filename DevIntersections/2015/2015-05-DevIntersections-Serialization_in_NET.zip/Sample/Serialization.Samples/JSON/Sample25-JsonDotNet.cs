﻿using Newtonsoft.Json;
using System;
using System.Diagnostics;
using System.IO;

namespace Serialization.Samples
{
   /// <summary>
   /// 
   /// </summary>
   public class Sample25 : ISample
   {
      public void RunDemo()
      {
         Debugger.Break();

         CustomerWithDataContract customer = new CustomerWithDataContract
         {
            CustomerNumber = 1,
            CustomerName = "PDSA, Inc.",
            CustomerType = 2,
         };

         try
         {
            // Create a stream
            Stream stream = Utility.CreateFileStream("Sample24.txt");
            StreamWriter writer = new StreamWriter(stream);

            // Create a JsonTextWriter to output to the stream
            using (JsonWriter jw = new JsonTextWriter(writer))
            {
               jw.Formatting = Formatting.Indented;
               JsonSerializer serializer = new JsonSerializer();
               serializer.Serialize(jw, customer);
            }

            // Close the stream
            stream.Close();
         }
         catch (Exception ex)
         {
            Debug.WriteLine(ex);
         }
      }
   }
}
