﻿using System;
using System.Collections.Generic;

namespace SamplesData
{
  /// <summary>
  /// Class to hold a collection of pager items to display on a page
  /// </summary>
  public class PDSAPagerItemCollection : List<PDSAPagerItem>
  {
    #region Constructor
    /// <summary>
    /// Constructor for the PDSAPagerItemCollection class
    /// </summary>
    /// <param name="pagerInfo">An instance of a PDSAPager object</param>
    public PDSAPagerItemCollection(PDSAPager pagerInfo)
    {
      // Initialize the collection of pager items
      Init(pagerInfo);
    }
    #endregion

    #region Init Method
    private void Init(PDSAPager pagerInfo)
    {
      int itemIndex = 0;
      int start = 0;
      int i = 0;
      bool displayNextPager = false;

      Add(new PDSAPagerItem(PDSAPagerCommands.FirstText,
                            PDSAPagerCommands.First,
                            (pagerInfo.PageIndex == 0), PDSAPagerCommands.FirstTooltipText));
      itemIndex++;
      Add(new PDSAPagerItem(PDSAPagerCommands.PreviousText,
                            PDSAPagerCommands.Previous,
                            (pagerInfo.PageIndex == 0), PDSAPagerCommands.PreviousTooltipText));
      itemIndex++;

      if (pagerInfo.PageIndex >= pagerInfo.VisiblePagesToDisplay)
      {
        Add(new PDSAPagerItem(PDSAPagerCommands.PreviousPageText,
                              (pagerInfo.PageIndex - pagerInfo.VisiblePagesToDisplay).ToString(),
                               false, PDSAPagerCommands.PreviousPageTooltipText));
        itemIndex++;
      }

      // Figure out start page

      start = Convert.ToInt32(Math.Round(Convert.ToDecimal(pagerInfo.PageIndex / pagerInfo.VisiblePagesToDisplay), 0, MidpointRounding.AwayFromZero));
      start = (start * pagerInfo.VisiblePagesToDisplay);
      start = (start < 0 ? 0 : start);

      for (i = start; i < pagerInfo.TotalPages; i++)
      {
        Add(new PDSAPagerItem(i, pagerInfo.PageIndex,
                              PDSAPagerCommands.PageText + " " + (i + 1).ToString()));
        itemIndex++;
        if (i == (start + pagerInfo.VisiblePagesToDisplay - 1))
        {
          displayNextPager = true;
          break;
        }
      }
      if (displayNextPager)
      {
        Add(new PDSAPagerItem(PDSAPagerCommands.NextPageText,
                              (i + 1).ToString(),
                              false, PDSAPagerCommands.NextPageTooltipText));
        itemIndex++;
      }

      Add(new PDSAPagerItem(PDSAPagerCommands.NextText,
                            PDSAPagerCommands.Next,
                            (pagerInfo.TotalPages - 1 == pagerInfo.PageIndex), PDSAPagerCommands.NextTooltipText));
      itemIndex++;
      Add(new PDSAPagerItem(PDSAPagerCommands.LastText,
                            PDSAPagerCommands.Last,
                            (pagerInfo.TotalPages - 1 == pagerInfo.PageIndex), PDSAPagerCommands.LastTooltipText));
    }
    #endregion
  }
}
