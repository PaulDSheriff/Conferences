﻿
namespace SamplesData
{
  public enum SortDirection
  {
    None,
    Ascending,
    Descending
  }
}
