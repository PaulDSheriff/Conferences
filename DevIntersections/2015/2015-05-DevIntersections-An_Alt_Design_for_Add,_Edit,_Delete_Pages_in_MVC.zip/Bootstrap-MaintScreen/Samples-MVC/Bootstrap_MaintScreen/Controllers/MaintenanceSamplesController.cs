﻿using System.Web.Mvc;
using SamplesData;

namespace Bootstrap_MaintScreen.Controllers
{
  public class MaintenanceSamplesController : Controller
  {
    //********************************************************
    //* Search and Grid
    //********************************************************
    public ActionResult Maintenance01()
    {
      MaintenanceViewModel01 vm = new MaintenanceViewModel01();

      vm.HandleRequest();

      return View(vm);
    }

    [HttpPost]
    public ActionResult Maintenance01(MaintenanceViewModel01 vm)
    {
      vm.HandleRequest();

      // NOTE: Must clear the model state in order to bind
      //       the @Html helpers to the new model values
      ModelState.Clear();

      return View(vm);
    }

    //********************************************************
    //* Detail and Validation
    //********************************************************
    public ActionResult Maintenance02()
    {
      MaintenanceViewModel02 vm = new MaintenanceViewModel02();

      vm.HandleRequest();

      return View(vm);
    }

    [HttpPost]
    public ActionResult Maintenance02(MaintenanceViewModel02 vm)
    {
      if (!ModelState.IsValid && vm.EventCommand == "save")
      {
        vm.IsValid = false;
        vm.SetModeAfterValidation();
      }
      else
      {
        vm.HandleRequest();

        // NOTE: Must clear the model state in order to bind
        //       the @Html helpers to the new model values
        ModelState.Clear();
      }

      return View(vm);
    }

    //********************************************************
    //* Editing
    //********************************************************
    public ActionResult Maintenance03()
    {
      ProductMaintenanceViewModel vm = new ProductMaintenanceViewModel();

      vm.HandleRequest();

      return View(vm);
    }

    [HttpPost]
    public ActionResult Maintenance03(ProductMaintenanceViewModel vm)
    {
      if (!ModelState.IsValid && vm.EventCommand == "save")
      {
        vm.IsValid = false;
        vm.SetModeAfterValidation();
      }
      else
      {
        vm.HandleRequest();

        // NOTE: Must clear the model state in order to bind
        //       the @Html helpers to the new model values
        ModelState.Clear();
      }

      return View(vm);
    }

    //********************************************************
    //* Complete Maintenance Page
    //********************************************************
    public ActionResult Maintenance04()
    {
      ProductMaintenanceViewModel vm = new ProductMaintenanceViewModel();

      vm.HandleRequest();

      return View(vm);
    }

    [HttpPost]
    public ActionResult Maintenance04(ProductMaintenanceViewModel vm)
    {
      if (!ModelState.IsValid && vm.EventCommand == "save")
      {
        vm.IsValid = false;
        vm.SetModeAfterValidation();
      }
      else
      {
        vm.HandleRequest();

        // NOTE: Must clear the model state in order to bind
        //       the @Html helpers to the new model values
        ModelState.Clear();
      }

      return View(vm);
    }
  }
}