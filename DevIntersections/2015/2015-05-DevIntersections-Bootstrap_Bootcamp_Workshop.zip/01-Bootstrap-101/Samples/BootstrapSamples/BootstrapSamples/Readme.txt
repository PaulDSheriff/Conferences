﻿Bootstrap Samples
----------------------------------------------------
These samples illustrate many of the various classes that make up Bootstrap.
We are using bootstrap 3.2.0.

BreakPoints01.html - Shows the 4 defined breakpoints
Grid01.html - 12 column Grid system
Grid02.html - Using offsets
Grid03.html - 2 column layout

Helper01.html - Text Helper Classes (Color)
Helper02.html - Background Helper Classes (Color)

Button01.html - Button Helper Classes (Color)
Button02.html - Buttons in a Group, as Radio Buttons, as Check Boxes
Button03.html - Toolbar of buttons, justified buttons
Button04.html - Drop Down Buttons

Text01.html - Justification, Capitalization, Address, Full Name and Email
Text02.html - h1, h2, p, Block quote, block quote reverse and other textual components
Well01.html - Using 'well' class
Well02.html - Well, 2 columns, <header>, <footer>, 'lead' and 'text-muted' classes. 
              Multiple 'container' classes
              Added page styles

Glyphs.html - Glyph icons

Image01.html - Use img-responsive to scale pictures
Image02.html - Shaping images
Image03.html - Wrap text around image

List01.html - ol and ul lists
List02.html - Definition lists
List03.html - List Groups, Custom List Groups, Badges

Table01.html - table, table-bordered, table-responsive
Table02.html - table-hover, table-condensed, table-striped

Form01.html - Contact Us. Shows usage of radio buttons.
Form02.html - Review Album. Horizontal Form. Shows usage of check boxes and 'text-center'
Form03.html - Login screen. Shows input groups.

Panel01.html - Basic layout of a panel
Panel02.html - Login screen using a panel
Panel03.html - Styling the body of the panel