﻿using System.Web;
using System.Web.UI;

namespace BootstrapBusinessUI.Components
{
  public class WebValidationError : IValidator
  {
    private WebValidationError(string message)
    {
      ErrorMessage = message;
      IsValid = false;
    }

    public string ErrorMessage { get; set; }
    public bool IsValid { get; set; }
    public void Validate()
    {
    }

    public static void AddErrorMessage(string message)
    {
      Page currentPage = HttpContext.Current.Handler as Page;

      currentPage.Validators.Add(new WebValidationError(message));
    }
  }
}