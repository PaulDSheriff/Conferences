﻿using System;
using SamplesData;

namespace BootstrapBusinessUI.Samples
{
  public partial class MemberProfileView3_WithTabs : System.Web.UI.Page
  {
    MemberProfileViewModel vm = new MemberProfileViewModel();

    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
      {
        vm.LoadStates(Server.MapPath("~/Xml/USStates.xml"));
        State.DataSource = vm.States;
        State.DataBind();

        vm.LoadQuestions(Server.MapPath("~/Xml/SecurityQuestions.xml"));
        Questions.DataSource = vm.Questions;
        Questions.DataBind();
      }
    }


    protected void btnSave_Click(object sender, EventArgs e)
    {
      UserData entity = new UserData();

      if (Page.IsValid)
      {
        entity.FirstName = First.Text;
        entity.LastName = Last.Text;
        entity.Address1 = Address1.Text;
        entity.Apartment = Apt.Text;
        entity.City = City.Text;
        entity.State = State.SelectedValue;
        if (!string.IsNullOrEmpty(BirthDate.Text))
        {
          entity.BirthDate = Convert.ToDateTime(BirthDate.Text);
        }
        entity.Email = Email.Text;
        entity.Password = Password.Text;
        entity.SecurityQuestion = Questions.SelectedValue;
        entity.SecurityAnswer = SecurityAnswer.Text;

        System.Diagnostics.Debugger.Break();
      }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
      Response.Redirect("Home.aspx");
    }
  }
}