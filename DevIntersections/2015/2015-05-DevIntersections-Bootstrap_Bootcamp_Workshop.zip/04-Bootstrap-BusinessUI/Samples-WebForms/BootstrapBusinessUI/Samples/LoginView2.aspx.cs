﻿using System;
using SamplesData;

namespace BootstrapBusinessUI.Samples
{
  public partial class LoginView2 : System.Web.UI.Page
  {
    protected void btnSignIn_Click(object sender, EventArgs e)
    {
      UserData entity = new UserData();

      if (Page.IsValid)
      {
        entity.Email = Email.Text;
        entity.Password = Password.Text;
        entity.IsRememberMeChecked = RememberMe.Checked;

        System.Diagnostics.Debugger.Break();
      }
    }
  }
}