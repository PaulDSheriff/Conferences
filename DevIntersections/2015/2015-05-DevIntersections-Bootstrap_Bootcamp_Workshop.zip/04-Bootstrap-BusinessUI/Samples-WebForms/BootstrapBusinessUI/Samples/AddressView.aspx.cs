﻿using System;
using System.Web.UI;
using SamplesData;

namespace BootstrapBusinessUI.Samples
{
  public partial class AddressView1 : System.Web.UI.Page
  {
    AddressViewModel _ViewModel = new AddressViewModel();

    #region OnPreInit Method
    protected override void OnPreInit(EventArgs e)
    {
      // Must override EnableViewState on Master Page
      BootstrapBusinessUI.MasterPages.Site master = Page.Master as BootstrapBusinessUI.MasterPages.Site;
      master.EnableViewState = true;

      base.OnPreInit(e);
    }
    #endregion

    #region Page_Load Event
    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
      {
        _ViewModel.LoadCountries(Server.MapPath("~/Xml/Countries.xml"));
        _ViewModel.LoadStates(Server.MapPath("~/Xml/USStates.xml"));
        _ViewModel.LoadProvinces(Server.MapPath("~/Xml/CanadianProvinces.xml"));
        Country.DataSource = _ViewModel.Countries;
        Country.DataBind();
        USState.DataSource = _ViewModel.States;
        USState.DataBind();
        Province.DataSource = _ViewModel.Provinces;
        Province.DataBind();

        _ViewModel.SetDisplay(Address.AddressTypeEnum.US);

        ShowDetails(_ViewModel.Entity.AddressType);
      }
    }
    #endregion

    #region btnSubmit_Click Event
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (Page.IsValid)
      {
        Address addr = GetAddressData();

        System.Diagnostics.Debugger.Break();
      }
    }
    #endregion

    #region btnCancel_Click Event
    protected void btnCancel_Click(object sender, EventArgs e)
    {
      Response.Redirect("Home.aspx");
    }
    #endregion

    #region SelectedIndexChanged Event on Country DropDown
    protected void Country_SelectedIndexChanged(object sender, System.EventArgs e)
    {
      if (Country.SelectedItem != null)
      {
        _ViewModel.SetAddressTypeEnum(Country.SelectedItem.Value);
        ShowDetails(_ViewModel.Entity.AddressType);
      }
    }
    #endregion

    #region ShowDetails Method
    public void ShowDetails(Address.AddressTypeEnum addressType)
    {
      Country.SelectedValue = _ViewModel.Entity.CountryCode;
      WebListHelper.DropDownFindByValue(ref USState, _ViewModel.Entity.StateCode);
      WebListHelper.DropDownFindByValue(ref Province, _ViewModel.Entity.StateCode);

      divAddress3.Visible = _ViewModel.IsAddress3Visible;
      divVillage.Visible = _ViewModel.IsVillageVisible;
      divZipExt.Visible = _ViewModel.IsZipExtVisible;
      divUSState.Visible = _ViewModel.IsUSStateVisible;
      divProvince.Visible = _ViewModel.IsProvinceVisible;
      lblZipPostal.Text = _ViewModel.ZipPostalLabel;
      ZipPostal.Attributes["placeholder"] = _ViewModel.ZipPostalLabel;
      ZipPostal.Attributes["title"] = _ViewModel.ZipPostalLabel;
      ZipPostal.TextMode = System.Web.UI.WebControls.TextBoxMode.SingleLine;
      if (_ViewModel.Entity.AddressType == Address.AddressTypeEnum.US)
      {
        ZipPostal.TextMode = System.Web.UI.WebControls.TextBoxMode.Number;
      }
    }
    #endregion

    #region GetAddressData Method
    public Address GetAddressData()
    {
      _ViewModel.Entity.CountryCode = Country.SelectedItem.Value;
      _ViewModel.Entity.CountryName = Country.SelectedItem.Text;
      _ViewModel.Entity.Address1 = Address1.Text;
      _ViewModel.Entity.Address2 = Address2.Text;
      _ViewModel.Entity.Address3 = Address3.Text;
      _ViewModel.Entity.Village = Village.Text;
      _ViewModel.Entity.City = City.Text;
      _ViewModel.Entity.PostalCode = ZipPostal.Text;
      _ViewModel.Entity.PostalCodeExt = ZipExtension.Text;

      if (USState.Visible)
      {
        _ViewModel.Entity.StateCode = USState.SelectedItem.Value;
        _ViewModel.Entity.StateName = USState.SelectedItem.Text;
      }
      else if (Province.Visible)
      {
        _ViewModel.Entity.StateCode = Province.SelectedItem.Value;
        _ViewModel.Entity.StateName = Province.SelectedItem.Text;
      }
      else
      {
        // When country is 'other'
        _ViewModel.Entity.StateCode = "";
        _ViewModel.Entity.StateName = "";
      }

      return _ViewModel.Entity;
    }
    #endregion
  }
}