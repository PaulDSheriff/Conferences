﻿
namespace SamplesData
{
  public class USState
  {
     public string StateCodeDisplay { get; set; }
     public string StateCode { get; set; }
     public string StateName { get; set; }
     public string Capital { get; set; }
  }
}