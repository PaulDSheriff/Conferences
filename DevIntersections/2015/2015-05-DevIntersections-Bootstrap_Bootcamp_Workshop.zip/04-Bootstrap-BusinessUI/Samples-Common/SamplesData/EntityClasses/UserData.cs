﻿using System;
using System.ComponentModel.DataAnnotations;

namespace SamplesData
{
  public class UserData : PDSAEntityBase
  {
    #region Constructor
    public UserData() : base()
    {
      Init();
    }
    #endregion

    #region Init Method
    public override void Init()
    {
      base.Init();

      Email = string.Empty;
      Password = string.Empty;
      ConfirmPassword = string.Empty;
      IsRememberMeChecked = false;
      IsAgreeToTermsChecked = false;
      FirstName = string.Empty;
      LastName = string.Empty;
      Address1 = string.Empty;
      Apartment = string.Empty;
      City = string.Empty;
      State = string.Empty;
      PostalCode = string.Empty;
      BirthMonth = 1;
      BirthDay = 1;
      BirthYear = DateTime.Now.Year;
      BirthDate = DateTime.Now;
      SecurityQuestion = string.Empty;
      SecurityAnswer = string.Empty;
    }
    #endregion

    #region Public Properties
    [Required(ErrorMessage="Email is required.")]
    public string Email { get; set; }
    public string Password { get; set; }
    public string NewPassword { get; set; }
    public string ConfirmPassword { get; set; }
    public bool IsRememberMeChecked { get; set; }
    public bool IsAgreeToTermsChecked { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Address1 { get; set; }
    public string Apartment { get; set; }
    public string City { get; set; }
    public string State { get; set; }
    public string PostalCode { get; set; }
    public int BirthMonth { get; set; }
    public int BirthDay { get; set; }
    public int BirthYear { get; set; }
    public DateTime BirthDate { get; set; }
    public string SecurityQuestion { get; set; }
    public string SecurityAnswer { get; set; }
    #endregion
  }
}
