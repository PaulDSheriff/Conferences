using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace SamplesData
{
  public class MemberProfileViewModel : PDSAViewModelBase
  {
    #region Constructor
    public MemberProfileViewModel()
      : base()
    {
      Init();
    }
    #endregion

    #region Init Method
    public override void Init()
    {
      base.Init();

      Entity = new UserData();
      LoadMonths();
      LoadYears();
      LoadDays();
    }
    #endregion

    #region Public Properties
    public List<int> Days { get; set; }
    public List<DateMonthData> Months { get; set; }
    public List<USState> States { get; set; }
    public List<SecurityQuestion> Questions { get; set; }
    public List<int> Years { get; set; }
    public UserData Entity { get; set; }
    #endregion

    #region LoadQuestions Method
    public void LoadQuestions(string fileName)
    {
      SecurityQuestionManager mgr = new SecurityQuestionManager();

      Questions = mgr.BuildCollection(fileName);
    }
    #endregion

    #region LoadMonths Method
    public void LoadMonths()
    {
      DateManager mgr = new DateManager();

      Months = mgr.MonthsLoad();
    }
    #endregion

    #region LoadYears Method
    public void LoadYears()
    {
      DateManager mgr = new DateManager();

      Years = mgr.YearsPastLoad();
    }
    #endregion

    #region LoadDays Method
    public void LoadDays()
    {
      DateManager mgr = new DateManager();

      Days = mgr.AllPotentialDaysLoad();
    }
    #endregion

    #region LoadStates Method
    public void LoadStates(string fileName)
    {
      USStateManager mgr = new USStateManager();

      States = mgr.BuildCollection(fileName);
    }
    #endregion

    #region Validate Method
    public override bool Validate()
    {
      base.Validate();

      return Entity.Validate();
    }
    #endregion
  }
}