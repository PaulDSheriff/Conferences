﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SamplesData
{
  /// <summary>
  /// Base class for View Model classes
  /// </summary>
  public class PDSAViewModelBase : PDSAEntityBase
  {
    #region Constructor
    public PDSAViewModelBase() : base()
    {
      Init();
    }
    #endregion

    #region Init Method
    public override void Init()
    {
      base.Init();
    }
    #endregion

    #region Public Properties
    public string EventArgument { get; set; }
    public string EventCommand { get; set; }
    #endregion

    #region Validate Method
    /// <summary>
    /// Override this method to validate your entity object
    /// </summary>
    /// <returns>True if entity is valid</returns>
    public override bool Validate()
    {
      return base.Validate();
    }
    #endregion
  }
}
