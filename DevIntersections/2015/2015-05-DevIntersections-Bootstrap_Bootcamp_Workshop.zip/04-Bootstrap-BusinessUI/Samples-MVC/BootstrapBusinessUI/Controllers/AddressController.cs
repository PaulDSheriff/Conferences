﻿using System.Web.Mvc;
using SamplesData;

namespace BootstrapBusinessUI.Controllers
{
  public class AddressController : Controller
  {
    public ActionResult Address()
    {
      AddressViewModel vm = null;
      
      vm = CreateAddressViewModel();

      return View(vm);
    }

    private AddressViewModel CreateAddressViewModel()
    {
      AddressViewModel vm = new AddressViewModel();

      InitViewModel(vm);

      return vm;
    }

    private void InitViewModel(AddressViewModel vm)
    {
      vm.LoadCountries(Server.MapPath("~/Xml/Countries.xml"));
      vm.LoadProvinces(Server.MapPath("~/Xml/CanadianProvinces.xml"));
      vm.LoadStates(Server.MapPath("~/Xml/USStates.xml"));
    }
   
    [HttpGet]
    public ActionResult ChangeCountryCode(string countryCode)
    {
      AddressViewModel vm = CreateAddressViewModel();

      if (!string.IsNullOrEmpty(countryCode))
      {
        vm.SetAddressTypeEnum(countryCode);
      }

      return PartialView("_Address", vm);
    }

    [HttpPost]
    public ActionResult Address(AddressViewModel vm)
    {
      bool ret = vm.Validate();

      if(!ModelState.IsValid)
      {
        // Do something
      }

      // Add some additional error messages
      //if(vm.Entity.StateCode != "CA")
      //{
      //  ModelState.AddModelError("StateCode", "State Code must be CA");
      //  ret = false;
      //}

      if (ret)
      {
        return RedirectToAction("Index", "Home");
      }
      else
      {
        vm.IsValid = false;
        InitViewModel(vm);
        return View(vm);
      }
    }
  }
}