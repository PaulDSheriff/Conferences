﻿using System.Web.Mvc;
using SamplesData;

namespace BootstrapBusinessUI.Controllers
{
  public class WizardController : Controller
  {
    public ActionResult Wizard()
    {
      UserData model = new UserData();

      model.Email = "PSheriff@pdsa.com";

      return View(model);
    }

    [HttpPost]
    public ActionResult Wizard(UserData model)
    {
      bool ret = model.Validate();
      
      if (ret)
      {
        return RedirectToAction("Index", "Home");
      }
      else
      {
        return View(model);
      }
    }    
  }
}