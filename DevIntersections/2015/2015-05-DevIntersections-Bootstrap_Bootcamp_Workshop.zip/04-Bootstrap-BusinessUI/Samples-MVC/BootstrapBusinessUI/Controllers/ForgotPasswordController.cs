﻿using System.Web.Mvc;
using SamplesData;

namespace BootstrapBusinessUI.Controllers
{
  public class ForgotPasswordController : Controller
  {
    public ActionResult ForgotPassword1()
    {
      UserData model = new UserData();

      model.Email = "PSheriff@pdsa.com";

      return View(model);
    }

    [HttpPost]
    public ActionResult ForgotPassword1(UserData model)
    {
      bool ret = model.Validate();

      if (ret)
      {
        return RedirectToAction("Index", "Home");
      }
      else
      {
        return View(model);
      }
    }
    
    public ActionResult ForgotPassword2()
    {
      UserData model = new UserData();

      model.Email = "PSheriff@pdsa.com";

      return View(model);
    }

    [HttpPost]
    public ActionResult ForgotPassword2(UserData model)
    {
      bool ret = model.Validate();

      if (ret)
      {
        return RedirectToAction("Index", "Home");
      }
      else
      {
        return View(model);
      }
    }

    public ActionResult ChangePassword1()
    {
      UserData model = new UserData();

      model.Email = "PSheriff@pdsa.com";

      return View(model);
    }

    [HttpPost]
    public ActionResult ChangePassword1(UserData model)
    {
      bool ret = model.Validate();

      if (ret)
      {
        return RedirectToAction("Index", "Home");
      }
      else
      {
        return View(model);
      }
    }
  }
}