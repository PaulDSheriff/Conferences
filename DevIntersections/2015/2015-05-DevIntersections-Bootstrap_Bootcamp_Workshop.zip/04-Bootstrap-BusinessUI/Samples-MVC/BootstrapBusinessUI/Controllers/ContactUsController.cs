﻿using System.Web.Mvc;
using SamplesData;

namespace BootstrapBusinessUI.Controllers
{
  public class ContactUsController : Controller
  {
    public ActionResult ContactUs1()
    {
      ContactUs model = new ContactUs();

      model.Url = "http://";

      return View(model);
    }

    [HttpPost]
    public ActionResult ContactUs1(ContactUs model)
    {
      bool ret = model.Validate();

      // Uncomment the following to test any custom messages
      //ModelState.AddModelError("Test", "This is a test message");
      //ret = false;

      if (ret)
      {
        return RedirectToAction("Index", "Home");
      }
      else
      {
        return View(model);
      }
    }

    public ActionResult ContactUs2()
    {
      ContactUs model = new ContactUs();

      return View(model);
    }

    [HttpPost]
    public ActionResult ContactUs2(ContactUs model)
    {
      if (model.Validate())
      {
        return RedirectToAction("Index", "Home");
      }
      else
      {
        return View(model);
      }
    }
  }
}