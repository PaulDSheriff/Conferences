﻿/* ***************************** */
/* BEGIN: PDSA Date Range Picker */
/* ***************************** */
$(function () {
  $("#pdsaDateApply").click(function () {
    var from = $("[data-pdsa-date-from='true']");
    if (from != undefined) {
      from.val($("#pdsaDateFrom").val());
    }
    var to = $("[data-pdsa-date-to='true']");
    if (to != undefined) {
      to.val($("#pdsaDateTo").val());
    }
    pdsaCalendarClose();
  });

  $("#daterangepopup").click(function (e) {
    $(".pdsa-date-range").css({
      "position": "absolute",
      "left": e.pageX + 'px',
      "top": e.pageY + 'px'
    });
    $(".pdsa-date-range").toggle('show');
  });

  $("#pdsaDateCancel").click(function () {
    pdsaCalendarClose();
  });

  $("#pdsadatelist .list-group-item").click(function () {
    // Get data- value
    var func = $(this).data("pdsa-date-func");
    var d = new Date();

    // Unhighlight the last selected item
    $("#pdsadatelist").children().removeClass("list-group-item-selected");
    // Highlight the current item
    $(this).addClass("list-group-item-selected");

    switch (func.toLowerCase()) {
      case "today":
        $("#pdsaDateFrom").val(d.toLocaleDateString());
        $("#pdsaDateTo").val(d.toLocaleDateString());
        break;

      case "yesterday":
        d.setDate(d.getDate() - 1);
        $("#pdsaDateFrom").val(d.toLocaleDateString());
        $("#pdsaDateTo").val(d.toLocaleDateString());
        break;

      case "last30days":
        var de = new Date(d.getFullYear(), d.getMonth(), d.getDay() - 30);
        $("#pdsaDateFrom").val(de.toLocaleDateString());
        $("#pdsaDateTo").val(d.toLocaleDateString());
        break;

      case "thismonth":
        var dm = new Date(d.getFullYear(), d.getMonth(), 1);
        var de = new Date(d.getFullYear(), d.getMonth() + 1, 1);
        de.setDate(de.getDate() - 1);
        $("#pdsaDateFrom").val(dm.toLocaleDateString());
        $("#pdsaDateTo").val(de.toLocaleDateString());
        break;

      case "lastmonth":
        var dm = new Date(d.getFullYear(), d.getMonth() - 1, 1);
        var de = new Date(d.getFullYear(), d.getMonth(), 1);
        de.setDate(de.getDate() - 1);
        $("#pdsaDateFrom").val(dm.toLocaleDateString());
        $("#pdsaDateTo").val(de.toLocaleDateString());
        break;

      case "nextmonth":
        var dm = new Date(d.getFullYear(), d.getMonth() + 1, 1);
        var de = new Date(d.getFullYear(), d.getMonth() + 2, 1);
        de.setDate(de.getDate() - 1);
        $("#pdsaDateFrom").val(dm.toLocaleDateString());
        $("#pdsaDateTo").val(de.toLocaleDateString());
        break;

      case "thisyear":
        var dm = new Date(d.getFullYear(), 0, 1);
        var de = new Date(d.getFullYear(), 11, 31);
        $("#pdsaDateFrom").val(dm.toLocaleDateString());
        $("#pdsaDateTo").val(de.toLocaleDateString());
        break;

      default:
        break;
    }
  });
});

function pdsaCalendarClose() {
  $(".pdsa-date-range").toggle('show');
}
/* *************************** */
/* END: PDSA Date Range Picker */
/* *************************** */