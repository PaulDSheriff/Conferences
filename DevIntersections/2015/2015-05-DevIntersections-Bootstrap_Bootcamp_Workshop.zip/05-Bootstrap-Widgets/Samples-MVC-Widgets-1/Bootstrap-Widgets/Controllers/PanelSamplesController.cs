﻿using System.Web.Mvc;

namespace Bootstrap_Widgets.Controllers
{
  public class PanelSamplesController : Controller
  {
    public ActionResult Panel01()
    {
      return View();
    }

    public ActionResult Panel02()
    {
      return View();
    }
  }
}