﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NavbarHorizontal
{
  public class PDSAMenuItemManager
  {
    public PDSAMenuItemManager()
    {
      Init();
    }

    public List<PDSAMenuItem> Menus { get; set; }

    public void Init()
    {
      Menus = new List<PDSAMenuItem>();
      LoadMenusMock();
    }

    public void LoadMenusMock()
    {
      PDSAMenuItem entity = new PDSAMenuItem();
      PDSAMenuItem subEntity = new PDSAMenuItem();

      entity.MenuId = 1;
      entity.ParentMenuId = 0;
      entity.MenuTitle = "Home";
      entity.DisplayOrder = 10;
      entity.MenuAction = "Home.aspx";
      Menus.Add(entity);

      entity = new PDSAMenuItem();
      entity.MenuId = 2;
      entity.ParentMenuId = 0;
      entity.MenuTitle = "Maintenance";
      entity.DisplayOrder = 20;
      Menus.Add(entity);

      subEntity = new PDSAMenuItem();
      subEntity.MenuId = 3;
      subEntity.ParentMenuId = 2;
      subEntity.MenuTitle = "Users";
      subEntity.DisplayOrder = 10;
      subEntity.MenuAction = "Users.aspx";
      entity.Menus.Add(subEntity);

      subEntity = new PDSAMenuItem();
      subEntity.MenuId = 4;
      subEntity.ParentMenuId = 2;
      subEntity.MenuTitle = "Roles";
      subEntity.DisplayOrder = 20;
      subEntity.MenuAction = "Roles.aspx";
      entity.Menus.Add(subEntity);
      
      subEntity = new PDSAMenuItem();
      subEntity.MenuId = 5;
      subEntity.ParentMenuId = 2;
      subEntity.MenuTitle = "Map Users to Roles";
      subEntity.DisplayOrder = 30;
      subEntity.MenuAction = "MapRoles.aspx";
      entity.Menus.Add(subEntity);


      entity = new PDSAMenuItem();
      entity.MenuId = 6;
      entity.ParentMenuId = 0;
      entity.MenuTitle = "Reports";
      entity.DisplayOrder = 30;
      Menus.Add(entity);

      subEntity = new PDSAMenuItem();
      subEntity.MenuId = 7;
      subEntity.ParentMenuId = 6;
      subEntity.MenuTitle = "Report 1";
      subEntity.DisplayOrder = 10;
      subEntity.MenuAction = "Report1.aspx";
      entity.Menus.Add(subEntity);

      subEntity = new PDSAMenuItem();
      subEntity.MenuId = 8;
      subEntity.ParentMenuId = 6;
      subEntity.MenuTitle = "Report 2";
      subEntity.DisplayOrder = 20;
      subEntity.MenuAction = "Report2.aspx";
      entity.Menus.Add(subEntity);


      entity = new PDSAMenuItem();
      entity.MenuId = 9;
      entity.ParentMenuId = 0;
      entity.MenuTitle = "Lookup";
      entity.DisplayOrder = 40;
      Menus.Add(entity);

      subEntity = new PDSAMenuItem();
      subEntity.MenuId = 10;
      subEntity.ParentMenuId = 9;
      subEntity.MenuTitle = "Logs";
      subEntity.DisplayOrder = 10;
      subEntity.MenuAction = "Logs.aspx";
      entity.Menus.Add(subEntity);

      subEntity = new PDSAMenuItem();
      subEntity.MenuId = 11;
      subEntity.ParentMenuId = 9;
      subEntity.MenuTitle = "Resources";
      subEntity.DisplayOrder = 20;
      subEntity.MenuAction = "Resources.aspx";
      entity.Menus.Add(subEntity);

      subEntity = new PDSAMenuItem();
      subEntity.MenuId = 12;
      subEntity.ParentMenuId = 9;
      subEntity.MenuTitle = "Lookup Tables";
      subEntity.DisplayOrder = 30;
      subEntity.MenuAction = "LookupTables.aspx";
      entity.Menus.Add(subEntity);

    }
  }
}