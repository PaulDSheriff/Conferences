﻿using System.Collections.Generic;

namespace NavbarHorizontal
{
  public class MenuItemSimpleManager
  {
    public MenuItemSimpleManager()
    {
      Init();
    }

    public List<MenuItemSimple> Menus { get; set; }

    public void Init()
    {
      Menus = new List<MenuItemSimple>();
      LoadMenusMock();
    }

    public void LoadMenusMock()
    {
      MenuItemSimple entity = new MenuItemSimple();

      entity.MenuId = 1;
      entity.ParentMenuId = 0;
      entity.MenuTitle = "Home";
      entity.DisplayOrder = 10;
      entity.MenuAction = "Home.aspx";
      Menus.Add(entity);

      entity = new MenuItemSimple();
      entity.MenuId = 2;
      entity.ParentMenuId = 0;
      entity.MenuTitle = "Maintenance";
      entity.MenuAction = "Maintenance.aspx";
      entity.DisplayOrder = 20;
      Menus.Add(entity);

      entity = new MenuItemSimple();
      entity.MenuId = 3;
      entity.ParentMenuId = 0;
      entity.MenuTitle = "Reports";
      entity.MenuAction = "Reports.aspx";
      entity.DisplayOrder = 30;
      Menus.Add(entity);

      entity = new MenuItemSimple();
      entity.MenuId = 4;
      entity.ParentMenuId = 0;
      entity.MenuTitle = "Lookup";
      entity.MenuAction = "Lookup.aspx";
      entity.DisplayOrder = 30;
      Menus.Add(entity);
    }
  }
}