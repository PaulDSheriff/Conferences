﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NavbarHorizontal
{
  public class PDSAMenuItem
  {
    public PDSAMenuItem()
    {
      MenuId = 0;
      ParentMenuId = 0;
      MenuTitle = string.Empty;
      DisplayOrder = 10;
      MenuAction = string.Empty;
      Menus = new List<PDSAMenuItem>();
    }

    public int MenuId { get; set; }
    public int ParentMenuId { get; set; }
    public string MenuTitle { get; set; }
    public int DisplayOrder { get; set; }
    public string MenuAction { get; set; }

    public List<PDSAMenuItem> Menus { get; set; }

    public override string ToString()
    {
      return MenuTitle;
    }
  }
}