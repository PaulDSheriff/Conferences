﻿Explanation of Samples
-------------------------------------------------------------------
BootstrapSample.master - Master page with bootstrap CSS and navigation
  Also shows how to keep track of the 'active' menu
NavBarInMasterPage.aspx - A simple page using the bootstrap master

The rest of the pages are simply pages that are navigated to from the master page navigation
NavBarInMasterPageDashboard.aspx
NavBarInMasterPageLookup.aspx
NavBarInMasterPageMaint.aspx
NavBarInMasterPageSettings.aspx
