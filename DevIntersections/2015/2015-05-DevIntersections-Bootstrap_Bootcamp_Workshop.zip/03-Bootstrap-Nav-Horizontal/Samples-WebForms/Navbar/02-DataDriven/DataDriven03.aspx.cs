﻿using System;
using System.Collections.Generic;
using System.Web.UI;

namespace NavbarHorizontal
{
  public partial class DataDriven03 : System.Web.UI.Page
  {
    protected List<PDSAMenuItem> Menus { get; set; }

    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
      {
        LoadMenus();
      }
    }

    private void LoadMenus()
    {
      PDSAMenuItemManager mgr = new PDSAMenuItemManager();

      Menus = mgr.Menus;
    }
  }
}