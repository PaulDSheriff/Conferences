﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace NavbarHorizontal
{
  public partial class DataDriven02 : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
      {
        LoadMenus();
      }
    }

    private void LoadMenus()
    {
      PDSAMenuItemManager mgr = new PDSAMenuItemManager();

      repMenus.DataSource = mgr.Menus;
      repMenus.DataBind();
    }

    protected void repMenus_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      PDSAMenuItem mi;
      HtmlGenericControl ctl;
      HyperLink hl;
      Repeater rep;

      if (e.Item.ItemType == ListItemType.Item || 
          e.Item.ItemType == ListItemType.AlternatingItem)
      {
        mi = (PDSAMenuItem)e.Item.DataItem;
        // Assign class to <li> for top menu
        ctl = (HtmlGenericControl)e.Item.FindControl("liTopMenu");
        if (ctl != null)
        {
          if (mi.Menus.Count > 0)
          {
            ctl.Attributes.Add("class", "dropdown");

            hl = (HyperLink)e.Item.FindControl("lnkMenu");
            if (hl != null)
            {
              hl.Attributes.Add("data-toggle", "dropdown");
              hl.Attributes.Add("class", "dropdown-toggle");
            }

            // Bind the sub menus
            rep = (Repeater)e.Item.FindControl("repSubMenus");
            if(rep != null)
            {
              rep.DataSource = mi.Menus;
              rep.DataBind();
            }
          }
          else
          {
            ctl = (HtmlGenericControl)e.Item.FindControl("caret");
            if (ctl != null)
            {
              ctl.Attributes.Add("class", "hide");
            }
          }
        }
      }
    }
  }
}