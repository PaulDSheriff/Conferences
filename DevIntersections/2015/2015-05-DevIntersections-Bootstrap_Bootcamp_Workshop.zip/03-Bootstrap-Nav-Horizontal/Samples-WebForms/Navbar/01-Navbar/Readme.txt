﻿Explanation of Samples
-------------------------------------------------------------------
Navbar01.aspx - 'static' navigation bar
Navbar02.aspx - 'static' 'inverse' navigation bar
Navbar03.aspx - 'fixed' 'inverse' navigation bar
Navbar04.aspx - NavBar on the bottom

Navbar05.aspx - Collapsing 'fixed' 'inverse' navigation bar
Navbar06.aspx - Two Line Header

Navbar07.aspx - Drop down menu
Navbar08.aspx - Pull Logout Right
Navbar09.aspx - Avatar in Drop Down