﻿using System;

namespace NavbarHorizontal
{
  public partial class Default : System.Web.UI.Page
  {
  }
}