﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NavbarHorizontal.Controllers
{
  public class NavbarController : Controller
  {
    public ActionResult Navbar01()
    {
      return View();
    }

    public ActionResult Navbar02()
    {
      return View();
    }

    public ActionResult Navbar03()
    {
      return View();
    }

    public ActionResult Navbar04()
    {
      return View();
    }

    public ActionResult Navbar05()
    {
      return View();
    }

    public ActionResult Navbar06()
    {
      return View();
    }

    public ActionResult Navbar07()
    {
      return View();
    }

    public ActionResult Navbar08()
    {
      return View();
    }

    public ActionResult Navbar09()
    {
      return View();
    }
  }
}