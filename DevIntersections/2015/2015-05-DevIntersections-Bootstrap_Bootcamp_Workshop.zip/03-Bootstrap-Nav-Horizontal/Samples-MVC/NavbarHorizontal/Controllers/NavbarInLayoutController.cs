﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NavbarHorizontal.Controllers
{
  public class NavbarInLayoutController : Controller
  {
    public ActionResult NavBarInLayout()
    {
      return View();
    }

    public ActionResult NavBarInLayoutDashboard()
    {
      return View();
    }

    public ActionResult NavBarInLayoutMaint()
    {
      return View();
    }

    public ActionResult NavBarInLayoutSettings()
    {
      return View();
    }

    public ActionResult NavBarInLayoutLookup()
    {
      return View();
    }
  }
}