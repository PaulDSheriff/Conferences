﻿Explanation of Samples
-------------------------------------------------------------------
Navbar01 - 'static' navigation bar
Navbar02 - 'static' 'inverse' navigation bar
Navbar03 - 'fixed' 'inverse' navigation bar
Navbar04 - NavBar on the bottom

Navbar05 - Collapsing 'fixed' 'inverse' navigation bar
Navbar06 - Two Line Header

Navbar07 - Drop down menu
Navbar08 - Pull Logout Right
Navbar09 - Avatar in Drop Down