﻿Explanation of Samples
-------------------------------------------------------------------
~/Views/Shared/_LayoutWithNav.cshtml - Layout page with bootstrap CSS and navigation
  Also shows how to keep track of the 'active' menu

The rest of the pages are simply pages that are navigated to from the master page navigation
NavBarInLayout
NavBarInLayoutDashboard
NavBarInLayoutLookup
NavBarInLayoutMaint
NavBarInLayoutSettings
