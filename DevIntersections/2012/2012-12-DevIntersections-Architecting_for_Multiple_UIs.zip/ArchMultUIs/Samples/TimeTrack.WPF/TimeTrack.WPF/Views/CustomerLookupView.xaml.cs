﻿using System.Windows;
using System.Windows.Controls;

using TimeTrack.EntityClasses;
using TimeTrack.ViewModels;

namespace TimeTrack.WPF
{
  public partial class CustomerLookupView : Window
  {
    private CustomerViewModel _ViewModel = null;

    #region Constructor
    public CustomerLookupView()
    {
      InitializeComponent();

      // Grab the Instance of the ViewModel
      _ViewModel = (CustomerViewModel)this.Resources["viewModel"];
    }
    #endregion

    #region Loaded Event Procedure
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      _ViewModel.GetCustomers();
    }
    #endregion

    private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      // Get Selected Customer and 
      // Store into Application Level
      (Application.Current as App).
        TimeSheetModel.SelectedCustomer =
          (Customer)lstData.SelectedItem;

      this.Close();
    }

    #region TextChanged Event
    private void txtName_TextChanged(object sender, TextChangedEventArgs e)
    {
      _ViewModel.FilterCustomers(txtName.Text.Trim());
    }
    #endregion
  }
}
