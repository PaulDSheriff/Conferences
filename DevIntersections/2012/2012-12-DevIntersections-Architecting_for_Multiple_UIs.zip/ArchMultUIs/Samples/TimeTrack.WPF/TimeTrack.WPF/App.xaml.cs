﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

using TimeTrack.ViewModels;

namespace TimeTrack.WPF
{
  public partial class App : Application
  {

    /// <summary>
    /// Get/Set the current TimeSheet View Model
    /// </summary>
    public TimeSheetAddViewModel TimeSheetModel { get; set; }

    protected override void OnStartup(StartupEventArgs e)
    {
      base.OnStartup(e);

      InitTimeSheetViewModel();
    }

    /// <summary>
    /// Ensure that the "Global" TimeSheet View Model is valid
    /// </summary>
    public void InitTimeSheetViewModel()
    {
      if ((Application.Current as App).TimeSheetModel == null)
      {
        // Create new time sheet view model
        (Application.Current as App).TimeSheetModel = new TimeSheetAddViewModel();
        // Initialize to valid start state
        (Application.Current as App).TimeSheetModel.Init();
      }
    }
  }
}
