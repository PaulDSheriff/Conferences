using System.Runtime.Serialization;
using System.Collections.Generic;

using Common.Library;
using TimeTrack.DataClasses;
using TimeTrack.EntityClasses;

namespace TimeTrack.Services
{
  /// <summary>
  /// Class for sending data back to the client about the result of calling the WCF service
  /// </summary>
  [DataContract]
  public class TimeSheetResponse : ResponseBase
  {
    [DataMember]
    public TimeSheet DetailData { get; set; }

    [DataMember]
    public TimeSheets DataCollection { get; set; }

    [DataMember]
    public List<ValidationMessage> ValidationMessages { get; set; }
  }
}

