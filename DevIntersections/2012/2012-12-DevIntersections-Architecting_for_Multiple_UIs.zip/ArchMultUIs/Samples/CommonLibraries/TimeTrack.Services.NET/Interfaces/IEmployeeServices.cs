using System.ServiceModel;

using TimeTrack.DataClasses;
using TimeTrack.EntityClasses;

namespace TimeTrack.Services
{
  [ServiceContract(Namespace = "http://TimeTrack.Services")]
  public interface IEmployeeServices
  {
    [OperationContract]
    EmployeeResponse GetEmployee(Employee entity);

    [OperationContract]
    EmployeeResponse GetEmployees();
  }
}
