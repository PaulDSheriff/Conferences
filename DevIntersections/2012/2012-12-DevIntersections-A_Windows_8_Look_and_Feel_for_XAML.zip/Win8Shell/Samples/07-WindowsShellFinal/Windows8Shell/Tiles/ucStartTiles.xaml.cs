﻿using System.Windows.Controls;

namespace Windows8Shell
{
  public partial class ucStartTiles : UserControl
  {
    public ucStartTiles()
    {
      InitializeComponent();
    }
  }
}
