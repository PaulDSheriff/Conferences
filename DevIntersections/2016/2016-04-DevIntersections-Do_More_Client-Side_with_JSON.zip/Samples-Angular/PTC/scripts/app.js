﻿(function () {
  'use strict';

  angular.module('ptcApp', []);
})();
