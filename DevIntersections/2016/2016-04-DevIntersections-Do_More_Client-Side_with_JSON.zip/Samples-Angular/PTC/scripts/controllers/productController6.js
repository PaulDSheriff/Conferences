﻿(function () {
  'use strict';

  angular.module('ptcApp').controller('ProductController', ProductController);

  function ProductController($scope, $http) {
    // Property Declarations
    var vm = $scope;          // Reference to $scope
    var dataService = $http;  // Reference to $http

    // Public properties
    vm.product = {};
    vm.products = [];
    vm.uiState = {};

    // Public events
    vm.addClick = addClick;
    vm.cancelClick = cancelClick;
    vm.editClick = editClick;
    vm.deleteClick = deleteClick;
    vm.saveClick = saveClick;

    // Private Variables
    const pageMode = {
      LIST: 'List',
      EDIT: 'Edit',
      ADD: 'Add',
      EXCEPTION: 'Exception',
      VALIDATION: 'Validation'
    };

    // Initialize controller
    init();

    // Get all products
    getAll();

    // Initialize variables
    function init() {
      // Initialize UI State
      vm.uiState = initUIState();
      setUIState(pageMode.LIST);
    }

    function getAll() {
      dataService.get("/api/Product")
        .then(function (result) {
          vm.products = result.data;

        }, function (error) {
          // TODO: Handle exception here
        });
    }

    // Event procedures
    function addClick() {
      addMode();
    }

    function cancelClick() {
      listMode();
    }

    function editClick(id) {
      get(id);

      setUIState(pageMode.EDIT);
    }

    function deleteClick(id) {
      // TODO: Delete data here

      setUIState(pageMode.LIST);
    }

    function saveClick() {
      saveData();
    }

    // Set Add Mode
    function addMode() {
      setUIState(pageMode.ADD);
    }

    // Set List Mode
    function listMode() {
      setUIState(pageMode.LIST);
    }

    // Get a Product and go into Edit Mode
    function get(id) {
      // Call Web API to get a product
      dataService.get("/api/Product/" + id)
        .then(function (result) {
          // Display product
          vm.product = result.data;

          // Fix date field to local format
          vm.product.IntroductionDate = new
            Date(vm.product.IntroductionDate).toLocaleDateString();

          setUIState(pageMode.EDIT);
        }, function (error) {
          // TODO: Handle exception here
        });
    }

    // Delete data
    function deleteData(id) {
      if (confirm("Delete this Product?")) {
        // TODO: Delete the product here
      }
    }

    // Save data
    function saveData() {
      // Insert or Update the data
      if (vm.uiState.mode === pageMode.ADD) {
        insertData();
      }
      else if (vm.uiState.mode === pageMode.EDIT) {
        updateData();
      }

      if (vm.uiState.mode === pageMode.EXCEPTION ||
          vm.uiState.mode === pageMode.VALIDATION) {
        // Check for validation error
        setUIState(pageMode.VALIDATION);
      }
      else {
        setUIState(pageMode.LIST);
      }
    }

    // Insert a new product
    function insertData() {
      // Check data
      if (validate()) {
        dataService.post(
          "/api/Product",
          JSON.stringify(vm.product))
        .then(function (result) {
          // Update product object
          vm.product = result.data;

          // Add Product to Array
          vm.products.push(vm.product);

          setUIState(pageMode.LIST);
        }, function (error) {
          // TODO: Handle exception here
        });
      }
    }

    // Update a product
    function updateData() {
      // Check data
      if (validate()) {
        dataService.put("/api/Product/" +
            vm.product.ProductId,
            JSON.stringify(vm.product))
        .then(function (result) {
          // Update product object
          vm.product = result.data;

          // Get index of this product
          var index = vm.products.map(function (p)
          { return p.ProductId; }).indexOf(vm.product.ProductId);

          // Update product in array
          vm.products[index] = vm.product;

          setUIState(pageMode.LIST);
        }, function (error) {
          // TODO: Handle exception here
        });
      }
    }

    // Perform client-side validation
    function validate() {
      var ret = true;
      
      if (vm.product.IntroductionDate != null) {
        // Fix up date - NOTE: Assumes a valid date
        vm.product.IntroductionDate =
            new Date(vm.product.IntroductionDate
                .replace(/\u200E/g, ''))
                .toISOString();
      }

      return ret;
    }

    // Create the uiState object literal
    function initUIState() {
      return {
        mode: pageMode.LIST,
        isDetailAreaVisible: false,
        isListAreaVisible: false,
        isMessageAreaVisible: false,
        isSearchAreaVisible: false,
        messages: []
      };
    }

    // Set appropriate UI state
    function setUIState(state) {
      // Set page state
      vm.uiState.mode = state;
      switch (state) {
        case pageMode.LIST:
          vm.uiState.isDetailAreaVisible = false;
          vm.uiState.isListAreaVisible = true;
          vm.uiState.isSearchAreaVisible = true;
          vm.uiState.isMessageAreaVisible = false;
          break;
        case pageMode.ADD:
          vm.uiState.isDetailAreaVisible = true;
          vm.uiState.isListAreaVisible = false;
          vm.uiState.isSearchAreaVisible = false;
          vm.uiState.messages = [];
          break;
        case pageMode.EDIT:
          vm.uiState.isDetailAreaVisible = true;
          vm.uiState.isListAreaVisible = false;
          vm.uiState.isSearchAreaVisible = false;
          vm.uiState.messages = [];
          break;
        case pageMode.EXCEPTION:
          vm.uiState.isMessageAreaVisible = true;
          break;
        case pageMode.VALIDATION:
          vm.uiState.isMessageAreaVisible = true;
          break;
      }
    }
  }
})();