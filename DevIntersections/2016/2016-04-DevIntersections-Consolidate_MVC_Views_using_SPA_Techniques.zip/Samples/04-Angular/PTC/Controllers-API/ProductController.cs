﻿using System.Web.Http;
using PTCData;
using System.Collections.Generic;
using System.Web.Http.ModelBinding;

namespace PTC.Controllers
{
  public class ProductController : ApiController
  {
    private ModelStateDictionary ValidationErrors { get; set; }

    [HttpGet()]
    public IHttpActionResult Get() {
      IHttpActionResult ret = null;
      TrainingProductViewModel vm =
        new TrainingProductViewModel();

      // Get all Products
      vm.Get();
      if (vm.Products.Count > 0) {
        ret = Ok(vm.Products);
      }
      else {
        ret = NotFound();
      }

      return ret;
    }

    [HttpGet()]
    public IHttpActionResult Get(int id) {
      IHttpActionResult ret;
      TrainingProduct prod = new TrainingProduct();
      TrainingProductViewModel vm =
        new TrainingProductViewModel();

      prod = vm.Get(id);

      if (prod == null) {
        ret = NotFound();
      }
      else {
        ret = Ok(prod);
      }

      return ret;
    }

    /// <summary>
    /// This method is used to search for products based on criteria typed in by user
    /// </summary>
    /// <param name="searchEntity">The data to search for</param>
    /// <returns>A list of products</returns>
    [HttpPost()]
    [Route("api/Product/Search")]
    public IHttpActionResult Search(
              TrainingProduct searchEntity) {
      IHttpActionResult ret = null;
      TrainingProductViewModel vm =
        new TrainingProductViewModel();

      // Search for Products
      vm.SearchEntity = searchEntity;
      vm.Get();
      if (vm.Products.Count > 0) {
        ret = Ok(vm.Products);
      }
      else {
        ret = NotFound();
      }

      return ret;
    }

    [HttpPut()]
    public IHttpActionResult Put(int id,
                                 TrainingProduct product) {
      IHttpActionResult ret = null;
      TrainingProductViewModel vm =
        new TrainingProductViewModel();

      vm.Entity = product;
      vm.Mode = "Edit";
      vm.Save();

      if (vm.IsValid) {
        ret = Ok(product);
      }
      else if (vm.ValidationErrors.Count > 0) {
        ret = BadRequest(ConvertToModelState(vm.ValidationErrors));
      }
      else {
        ret = NotFound();
      }

      return ret;
    }

    [HttpPost()]
    public IHttpActionResult Post(TrainingProduct product) {
      IHttpActionResult ret = null;
      TrainingProductViewModel vm =
        new TrainingProductViewModel();

      vm.Entity = product;
      vm.Mode = "Add";
      vm.Save();

      if (vm.IsValid) {
        ret = Created<TrainingProduct>(
               Request.RequestUri +
                product.ProductId.ToString(), 
                 product);
      }
      else {
        ret = BadRequest(ConvertToModelState(vm.ValidationErrors));
      }

      return ret;
    }

    private ModelStateDictionary ConvertToModelState(List<KeyValuePair<string, string>> errors) {
      ValidationErrors = new ModelStateDictionary();

      foreach (KeyValuePair<string, string> item in errors) {
        ValidationErrors.AddModelError(item.Key, item.Value);
      }

      return ValidationErrors;
    }


    [HttpDelete()]
    public IHttpActionResult Delete(int id) {
      IHttpActionResult ret = null;
      TrainingProductViewModel vm =
        new TrainingProductViewModel();

      // Get the product
      vm.Entity = vm.Get(id);
      // Did we find the product?
      if (vm.Entity.ProductId > 0) {
        // Delete the product
        vm.Delete(id);

        ret = Ok(true);
      }
      else {
        ret = NotFound();
      }

      return ret;
    }
  }
}