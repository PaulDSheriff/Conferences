﻿(function () {
  'use strict';
  
  // Add controller to our Angular module
  angular.module('ptcApp')
   .controller('PTCController', PTCController);

  // Controller for Product page
  function PTCController($scope, $http) {
    var vm = $scope;
    var dataService = $http;

    vm.product = {};
    vm.products = [];
    vm.uiState = {};
    const pageMode = {
      LIST: 'List',
      EDIT: 'Edit',
      ADD: 'Add',
      EXCEPTION: 'Exception',
      VALIDATION: 'Validation'
    }

    // Initialize UI State
    vm.uiState = initUIState();

    // Initialize Search Input
    vm.searchInput = {
      productName: ''
    };

    // Hook up events
    vm.deleteClick = deleteClick;
    vm.editClick = productGet;
    vm.search = search;
    vm.resetSearch = resetSearch;
    vm.addClick = addClick;
    vm.saveClick = saveClick;
    vm.cancelClick = cancelClick;

    // Initialize List of Products
    productList();

    // Initialize a new product
    function initEntity() {
      return {
        ProductId: 0,
        ProductName: '',
        IntroductionDate: null,
        Url: 'http://www.pdsa.com',
        Price: 0
      };
    }

    // Initialize the UI State object
    function initUIState() {
      return {
        mode: pageMode.LIST,
        isDetailAreaVisible: false,
        isListAreaVisible: false,
        isMessageAreaVisible: true,
        isSearchAreaVisible: false,
        errorCode: '',
        errorText: '',
        errorMessage: '',
        messages: [{ propertyName: '', message: 'Please wait while loading products...'}]
      };
    }

    function productDelete(productId) {
      dataService.delete("/api/Product/" + productId)
        .then(function (result) {
          // Get the complete list again
          productList();

          setUIState(pageMode.LIST);
        }, function (error) {
          handleException(error);
        });
    }

    function resetSearch() {
      // Clear search entries using data binding
      vm.searchInput.productName = '';

      // Get all products
      productList();
    }

    function formClear() {
      vm.product = initEntity();
    }

    function productAdd() {
      dataService.post("/api/Product", JSON.stringify(vm.product))
        .then(function (result) {
          // Get the complete list again
          productList();

          setUIState(pageMode.LIST);
        }, function (error) {
          handleException(error);
        });
    }

    function productUpdate() {
      dataService.put("/api/Product/" + vm.product.ProductId,
                      JSON.stringify(vm.product))
        .then(function (result) {
          // Get the complete list again
          productList();

          setUIState(pageMode.LIST);
        }, function (error) {
          handleException(error);
        });
    }

    // Get all Products
    function productList() {
      dataService.get("/api/Product")
        .then(function (result) {
          // Update collection with data from Web API
          vm.products = result.data;

          setUIState(pageMode.LIST);
        }, function (error) {
          handleException(error);
        });
    }

    // Call Web API to get a product
    function productGet(productId) {      
      dataService.get("/api/Product/" + productId)
        .then(function (result) {
          // Display product         
          vm.product = result.data;

          setUIState(pageMode.EDIT);
        }, function (error) {
          handleException(error);
        });
    }

    // Search for Products
    function search() {
      // Create JSON object
      var searchEntity = {
        ProductName:
          vm.searchInput.productName
      };

      dataService.post("/api/Product/Search", searchEntity)
        .then(function (result) {
          // Update collection with data from Web API
          vm.products = result.data;

          setUIState(pageMode.LIST);
        }, function (error) {
          handleException(error);
        });
    }

    function setUIState(state) {
      switch (state) {
        case pageMode.LIST:
          vm.uiState.isDetailAreaVisible = false;
          vm.uiState.isListAreaVisible = true;
          vm.uiState.isSearchAreaVisible = true;
          vm.uiState.isMessageAreaVisible = false;
          break;
        case pageMode.ADD:
          vm.uiState.isDetailAreaVisible = true;
          vm.uiState.isListAreaVisible = false;
          vm.uiState.isSearchAreaVisible = false;
          break;
        case pageMode.EDIT:
          vm.uiState.isDetailAreaVisible = true;
          vm.uiState.isListAreaVisible = false;
          vm.uiState.isSearchAreaVisible = false;
          break;
        case pageMode.EXCEPTION:
          vm.uiState.isMessageAreaVisible = true;
          break;
        case pageMode.VALIDATION:
          vm.uiState.isMessageAreaVisible = true;
          break;
      }
    }

    // Add or Update product data
    function saveClick() {
      if (vm.uiState.mode === pageMode.EDIT) {
        productUpdate();
      } else {
        productAdd();
      }
    }

    // Delete a product
    function deleteClick(productId) {
      if (confirm("Delete this Product?")) {
        productDelete(productId);
      }
    }

    // Cancel Add or Edit
    function cancelClick() {
      setUIState(pageMode.LIST);
    }

    // Put page into Add mode
    function addClick() {
      // Clear all input fields
      formClear();

      // Set UI State
      setUIState(pageMode.ADD);
    }

    // Handle exceptions from data service calls
    function handleException(error) {
      var newState = pageMode.EXCEPTION;
      var msg = {
        property: '',
        message: ''
      };

      vm.uiState.messages = [];
      vm.uiState.errorCode = error.status;
      vm.uiState.errorText = error.statusText;

      switch (error.status) {
        case 400:
          // 'Bad Request' means we are throwing 
          // back model state errors
          newState = pageMode.VALIDATION;
          vm.uiState.messages = [];
          var errors = error.data.ModelState;

          // Loop through and get all 
          // validation errors
          for (var key in errors) {
            for (var i = 0; i < errors[key].length; i++) {
              msg = {
                property: key,
                message: errors[key][i]
              };
              vm.uiState.messages.push(msg);
            }
          }

          break;

        case 404:
          // 'Not Found' means the data you are requesting 
          // can not be found in the database
          msg = {
            property: '',
            message: 'The Product you were requesting could not be found'
          };
          vm.uiState.messages.push(msg);

          break;

        case 500:
          // Display error message thrown from the server
          msg = {
            property: '',
            message: error.data.ExceptionMessage
          };
          vm.uiState.messages.push(msg);

          break;

        default:
          msg = {
            property: '',
            message: 'Status: ' +
                      error.status +
                      ' - Error Message: ' +
                      error.statusText
          };
          vm.uiState.messages.push(msg);

          break;
      }

      // Set UI State to Exception or Validation
      setUIState(newState);
    }
  }
})();