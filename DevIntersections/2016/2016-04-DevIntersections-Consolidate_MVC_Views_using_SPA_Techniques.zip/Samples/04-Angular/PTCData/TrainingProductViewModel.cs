﻿using System;
using System.Collections.Generic;
using PTCCommon;

namespace PTCData
{
  public class TrainingProductViewModel : ViewModelBase
  {
    public TrainingProductViewModel()
       : base() {
      // Initialize other variables
      Products = new List<TrainingProduct>();
      SearchEntity = new TrainingProduct();
      Entity = new TrainingProduct();
    }

    public List<TrainingProduct> Products { get; set; }
    public TrainingProduct SearchEntity { get; set; }
    public TrainingProduct Entity { get; set; }

    public override void Init() {
      Products = new List<TrainingProduct>();
      SearchEntity = new TrainingProduct();
      Entity = new TrainingProduct();

      base.Init();
    }

    public override void HandleRequest() {
      // This is an example of adding on a new command
      switch (EventCommand.ToLower()) {
        case "newcommand":
          break;

      }

      base.HandleRequest();
    }

    public override void Add() {
      IsValid = true;

      // Initialize Entity Object
      Entity = new TrainingProduct();
      Entity.IntroductionDate = DateTime.Now;
      Entity.Url = string.Empty;
      Entity.Price = 0;

      base.Add();
    }

    public override void Edit() {
      TrainingProductManager mgr =
       new TrainingProductManager();

      // Get Product Data
      Entity = mgr.Get(
        Convert.ToInt32(EventArgument));

      base.Edit();
    }

    public override void Save() {
      TrainingProductManager mgr =
        new TrainingProductManager();

      if (Mode == "Add") {
        mgr.Insert(Entity);
      }
      else {
        mgr.Update(Entity);
      }

      // Set any validation errors
      ValidationErrors = mgr.ValidationErrors;

      // Set mode based on validation errors
      base.Save();
    }

    public override void Delete() {
      Delete(Convert.ToInt32(EventArgument));
    }

    public void Delete(int id) {
      TrainingProductManager mgr =
        new TrainingProductManager();

      // Create new entity
      Entity = new TrainingProduct();

      // Set primary key
      Entity.ProductId = id;

      // Call data layer to delete record
      mgr.Delete(Entity);

      // Reload the Data
      Get();

      base.Delete();
    }

    public override void ResetSearch() {
      SearchEntity = new TrainingProduct();

      IsValid = true;

      base.ResetSearch();
    }

    public override void Get() {
      TrainingProductManager mgr = new TrainingProductManager();

      Products = mgr.Get(SearchEntity);

      base.Get();
    }
    
    public TrainingProduct Get(int productId) {
      TrainingProductManager mgr = new TrainingProductManager();

      Entity = mgr.Get(productId);

      return Entity;
    }
  }
}
