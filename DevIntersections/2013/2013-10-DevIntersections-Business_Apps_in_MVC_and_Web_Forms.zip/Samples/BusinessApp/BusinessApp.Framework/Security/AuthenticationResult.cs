﻿
namespace BusinessApp.Framework.Security
{
   public enum AuthenticationResult
   {
      Success,
      Failure
   }
}
