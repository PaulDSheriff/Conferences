﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessApp.Framework.Logging
{
   public class LoggingProvider
   {
      public void Log(string message)
      {
         ///
      }

      public void Log(string message, string eventName)
      {
      }

      public void Log(Exception ex)
      {

      }

      public void Log(Exception ex, string extraInfo)
      {

      }
   }
}
