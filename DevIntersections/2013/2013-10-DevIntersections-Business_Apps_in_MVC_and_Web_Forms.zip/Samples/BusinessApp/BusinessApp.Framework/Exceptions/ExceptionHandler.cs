﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessApp.Framework.Exceptions
{
   public class ExceptionHandler
   {
      public void Publish(Exception ex) { }
   }
}
