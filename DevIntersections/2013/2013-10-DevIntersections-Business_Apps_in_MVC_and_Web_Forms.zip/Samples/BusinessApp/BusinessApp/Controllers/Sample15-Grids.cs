﻿using System.Web.Mvc;
using BusinessApp.Utilities;
using BusinessApp.ViewModels;

namespace BusinessApp.Controllers
{
   /// <summary>
   /// Sample 15 - Grids and Filters - Controller
   /// </summary>
   public class Sample15Controller : WebController
   {
      public ActionResult Index()
      {
         CustomerIndexViewModel viewModel = new CustomerIndexViewModel();
         viewModel.LoadAll();
         return View(viewModel);
      }

      [HttpPost]
      public ActionResult Index(CustomerIndexViewModel viewModel)
      {
         viewModel.LoadAll();
         this.ModelState.Clear();
         return View(viewModel);
      }
   }
}