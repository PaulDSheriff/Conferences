﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusinessApp.BusinessLayer;
using BusinessApp.BusinessLayer.Context;
using BusinessApp.BusinessLayer.Entities;
using BusinessApp.Utilities;

namespace BusinessApp.Controllers
{
   /// <summary>
   /// Sample 01 - Wizard Steps - Controller
   /// </summary>
   public class Sample01Controller : WebController
   {
      #region Data Context

      private BusinessAppDataContext _dataContext = null;

      private BusinessAppDataContext DataContext
      {
         get
         {
            if (_dataContext == null) _dataContext = new BusinessAppDataContext();
            return _dataContext;
         }
      }

      #endregion
      
      public ActionResult Index()
      {
         return RedirectToAction("Step1");
      }

      public ActionResult Step1()
      {
         Customer customer = new Customer();
         return View(customer);
      }

      [HttpPost]
      public ActionResult Step1(Customer customer)
      {
         this.UserSession.WizardPackage = new WizardPackage();
         this.UserSession.WizardPackage.Customer = customer;
         return RedirectToAction("Step2");
      }

      public ActionResult Step2()
      {
         Project project = new Project();
         return View(project);
      }

      [HttpPost]
      public ActionResult Step2(Project project)
      {
         this.UserSession.WizardPackage.Project = project;
         return RedirectToAction("Step3");
      }

      public ActionResult Step3()
      {
         Task task = new Task();
         return View(task);
      }

      [HttpPost]
      public ActionResult Step3(Task task)
      {
         this.UserSession.WizardPackage.Task = task;
         return RedirectToAction("Finished");
      }

      public ActionResult Finished()
      {
         WizardPackage package = this.UserSession.WizardPackage;

         Customer customer = package.Customer;
         this.DataContext.Customers.Add(customer);
         this.DataContext.SaveChanges();

         Project project = package.Project;
         project.CustomerId = customer.CustomerId;
         this.DataContext.Projects.Add(project);
         this.DataContext.SaveChanges();

         Task task = package.Task;
         task.ProjectId = project.ProjectId;
         this.DataContext.Tasks.Add(task);
         this.DataContext.SaveChanges();

         return View();
      }
   }
}
