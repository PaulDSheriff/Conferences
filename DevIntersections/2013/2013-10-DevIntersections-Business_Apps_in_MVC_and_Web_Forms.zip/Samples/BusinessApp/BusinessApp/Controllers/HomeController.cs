﻿using System.Web.Mvc;
using BusinessApp.Utilities;

namespace BusinessApp.Controllers
{
   /// <summary>
   /// Home Page Controller
   /// </summary>
   public class HomeController : WebController
   {
      #region Get Index

      public ActionResult Index()
      {
         return View();
      }

      #endregion

      #region Post Index

      /// <summary>
      /// Handle the command buttons
      /// </summary>
      /// <param name="command">Value of the button name</param>
      /// <returns></returns>
      [HttpPost]
      public ActionResult Index(string command)
      {
         ActionResult result = null;

         switch (command)
         {
            case "Wizard Steps":
               result = Redirect("~/Sample01");
               break;
            case "Multiple Pages":
               result = Redirect("~/Sample02");
               break;
            case "Single Page":
               result = Redirect("~/Sample03");
               break;
            case "Report Viewer":
               result = Redirect("~/Reporting/ReportViewer.aspx");
               break;
            case "Maintenance":
               result = Redirect("~/Maintenance/ManageLookups.aspx");
               break;
         }

         return result;
      }

      #endregion
   }
}
