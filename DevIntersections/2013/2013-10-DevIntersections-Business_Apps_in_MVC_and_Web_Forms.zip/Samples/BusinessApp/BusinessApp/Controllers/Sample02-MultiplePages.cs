﻿using System;
using System.Web.Mvc;
using BusinessApp.Utilities;
using BusinessApp.ViewModels;

namespace BusinessApp.Controllers
{
   /// <summary>
   /// Sample 02 - Multiple View Pages - Controller
   /// </summary>
   /// <remarks>
   /// Demonstrates using multiple view pages 
   /// to handle the add, edit and delete cycle.
   /// </remarks>
   public class Sample02Controller : WebController
   {
      public ActionResult Index()
      {
         TimesheetViewModel viewModel = new TimesheetViewModel();

         this.UserSession.Today = DateTime.Now;

         if (this.UserSession.LastActionMessage != null)
         {
            ViewBag.Message = this.UserSession.LastActionMessage;
            this.UserSession.LastActionMessage = null;
         }
         else
         {
            ViewBag.Message = string.Empty;
         }
         
         viewModel.LoadTimesheet();

         return View(viewModel);
      }

      [HttpPost]
      public ActionResult Index(TimesheetViewModel viewModel)
      {
         ActionResult result = null;

         if (viewModel.EventTarget == "add")
         {
            result = RedirectToAction("Edit", new { id = -1 });
         }
         else
         {
            ViewBag.Message = string.Empty;
            viewModel.LoadTimesheet();
            result = View(viewModel);
         }

         return result;
      }

      public ActionResult Edit(int id)
      {
         TimesheetViewModel viewModel = new TimesheetViewModel();
         if (id > 0)
         {
            viewModel.Edit(id);
         }
         return View(viewModel);
      }

      [HttpPost]
      public ActionResult Edit(TimesheetViewModel viewModel)
      {
         ActionResult result = null;

         try
         {
            viewModel.Save();
            this.UserSession.LastActionMessage = "Timesheet entry saved.";
            result = RedirectToAction("Index");
         }
         catch (Exception ex)
         {
            this.ModelState.AddModelError("Exception", ex);
            result = View(viewModel);
         }

         return result;
      }

      public ActionResult Delete(int id)
      {
         TimesheetViewModel vm = new TimesheetViewModel();
         vm.Load(id);
         return View(vm);
      }

      [HttpPost]
      public ActionResult Delete(TimesheetViewModel viewModel)
      {
         ActionResult result = null;

         try
         {
            viewModel.Delete(viewModel.TimesheetEntryId);
            this.UserSession.LastActionMessage = "Timesheet entry deleted.";
            result = RedirectToAction("Index");
         }
         catch (Exception ex)
         {
            this.ModelState.AddModelError("Exception", ex.Message);
            viewModel.Load(viewModel.CustomerId);
            result = View(viewModel);
         }

         return result;
      }
   }
}