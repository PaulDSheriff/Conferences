﻿using System.Web.Mvc;
using BusinessApp.Utilities;

namespace BusinessApp.Controllers
{
   /// <summary>
   /// Sample 13 - Overall Style and Theme - Controller
   /// </summary>
   public class Sample13Controller : WebController
   {
      public ActionResult Index()
      {
         return View();
      }

      public ActionResult Grid()
      {
         return View();
      }

      public ActionResult Edit()
      {
         return View();
      }

   }
}
