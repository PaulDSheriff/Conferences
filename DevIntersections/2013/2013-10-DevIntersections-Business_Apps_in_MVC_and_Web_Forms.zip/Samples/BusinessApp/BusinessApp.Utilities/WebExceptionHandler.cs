﻿using System;

namespace BusinessApp.Utilities
{
   public class WebExceptionHandler
   {
      public static void Publish(Exception ex)
      {
         //LoggingProvider logger;
      }
   }
}
