﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace BusinessApp.Utilities
{
   public class WebUserSession
   {
      public static WebUserSession Instance { get; set; }

      public DateTime Today
      {
         get
         {
            return Convert.ToDateTime(HttpContext.Current.Session["Today"]);
         }
         set
         {
            HttpContext.Current.Session["Today"] = value;
         }
      }

      public string LastActionMessage
      {
         get
         {
            string result = null;

            if (HttpContext.Current.Session["LastActionMessage"] != null)
            {
               result = HttpContext.Current.Session["LastActionMessage"].ToString();
            }

            return result;
         }
         set
         {
            HttpContext.Current.Session["LastActionMessage"] = value;
         }
      }

      public WizardPackage WizardPackage
      {
         get
         {
            WizardPackage result = null;

            if (HttpContext.Current.Session["WizardPackage"] != null)
            {
               result = (WizardPackage)HttpContext.Current.Session["WizardPackage"];
            }

            return result;
         }
         set
         {
            HttpContext.Current.Session["WizardPackage"] = value;
         }
      }
   }
}
