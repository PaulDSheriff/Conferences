﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BusinessApp.BusinessLayer.Entities;

namespace BusinessApp.Utilities
{
   public class WizardPackage
   {
      public Customer Customer { get; set; }
      public Project Project { get; set; }
      public Task Task { get; set; }
   }
}
