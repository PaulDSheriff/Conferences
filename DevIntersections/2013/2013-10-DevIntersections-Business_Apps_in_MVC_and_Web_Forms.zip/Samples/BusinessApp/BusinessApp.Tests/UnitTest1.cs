﻿using System;
using BusinessApp.BusinessLayer.Context;
using BusinessApp.BusinessLayer.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BusinessApp.Tests
{
   [TestClass]
   public class TestDataContext
   {
      [TestMethod]
      public void TestMethod1()
      {
         BusinessAppDataContext dc = new BusinessAppDataContext();
         
         Customer customer = new Customer();
         customer.CompanyName = "PDSA, Inc.";
         
         dc.Customers.Add(customer);

         dc.SaveChanges();
      }
   }
}
