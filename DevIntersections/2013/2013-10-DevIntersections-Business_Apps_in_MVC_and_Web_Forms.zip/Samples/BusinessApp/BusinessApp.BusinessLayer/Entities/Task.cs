﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessApp.BusinessLayer.Entities
{
   [Table("Task")]
   public class Task
   {
      [Key]
      [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
      public int TaskId { get; set; }

      public int ProjectId { get; set; }

      [Display(Name = "Task Name")]
      [Required(ErrorMessage = "Task name is required.")]
      public string TaskName { get; set; }

      [Display(Name = "Estimated Hours")]
      [Required(ErrorMessage = "Estimated hours is required.")]
      public double EstimatedHours { get; set; }
   }
}
