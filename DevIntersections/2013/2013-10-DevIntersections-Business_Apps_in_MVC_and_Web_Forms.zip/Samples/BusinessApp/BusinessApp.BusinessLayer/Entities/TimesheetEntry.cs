﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BusinessApp.BusinessLayer
{
   [Table("TimesheetEntry")]
   public class TimesheetEntry
   {
      [Key]
      [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
      public int TimesheetEntryId { get; set; }

      public int CustomerId { get; set; }

      public int ProjectId { get; set; }

      public int TaskId { get; set; }

      [Required(ErrorMessage = "Description is required.")]
      public string Description { get; set; }

      [Required(ErrorMessage = "Hours is required")]
      public double Hours { get; set; }
   }
}
