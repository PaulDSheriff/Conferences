﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BusinessApp.BusinessLayer.Entities
{
   [Table("Customer")]
   public class Customer
   {
      [Key]
      [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
      public int CustomerId { get; set; }

      [Display(Name = "Customer Name")]
      [Required(ErrorMessage = "Customer name is required.")]
      public string CompanyName { get; set; }

      [Display(Name = "Website URL")]
      public string WebsiteURL { get; set; }
      
      //public short ConcurrencyValue { get; set; }
      //public System.DateTime InsertDate { get; set; }
      //public string InsertName { get; set; }
      //public System.DateTime UpdateDate { get; set; }
      //public string UpdateName { get; set; }
   }
}
