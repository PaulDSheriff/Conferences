﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BusinessApp.BusinessLayer.Entities
{
   [Table("Project")]
   public class Project
   {
      [Key]
      [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
      public int ProjectId { get; set; }

      public int CustomerId { get; set; }

      [Display(Name = "Project Name")]
      [Required(ErrorMessage = "Project name is required.")]
      public string ProjectName { get; set; }
   }
}
