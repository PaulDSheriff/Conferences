﻿using System;
using System.Data.Entity;
using System.Linq;
using BusinessApp.BusinessLayer.Entities;

namespace BusinessApp.BusinessLayer.Context
{
   public class BusinessAppDataContext : DbContext, IDisposable
   {
      public DbSet<Customer> Customers { get; set; }

      public DbSet<Project> Projects { get; set; }

      public DbSet<BusinessApp.BusinessLayer.Entities.Task> Tasks { get; set; }

      public DbSet<TimesheetEntry> Timesheets { get; set; }

      public IQueryable<Customer> GetCustomers()
      {
         return this.Set<Customer>();
      }

      //public List<DashboardItem> GetDashboardItems()
      //{
      //   return this.Database
      //      .SqlQuery<DashboardItem>("EXEC DashboardItemSummary")
      //      .ToList<DashboardItem>();
      //}
   }
}
