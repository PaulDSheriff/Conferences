﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessApp.BusinessLayer.LookupTables
{
   public class LookupValueCollection : List<LookupValue>
   {
   }
}
