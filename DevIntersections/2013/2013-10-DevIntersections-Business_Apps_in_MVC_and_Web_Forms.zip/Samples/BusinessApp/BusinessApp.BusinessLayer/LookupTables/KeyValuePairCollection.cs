﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessApp.BusinessLayer.LookupTables
{
   public class KeyValuePairCollection : List<KeyValuePair>
   {
   }
}
