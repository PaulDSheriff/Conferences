﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using BusinessApp.BusinessLayer.Context;

namespace BusinessApp.BusinessLayer
{
   public class TimesheetManager
   {
      #region Data Context

      private BusinessAppDataContext _dataContext = null;

      private BusinessAppDataContext DataContext
      {
         get
         {
            if (_dataContext == null) _dataContext = new BusinessAppDataContext();
            return _dataContext;
         }
      }

      #endregion

      public TimesheetEntry Select(int id)
      {
         TimesheetEntry result = null;

         result = this.DataContext.Timesheets.Find(id);

         return result;
      }

      public void Insert(TimesheetEntry entry)
      {
         this.DataContext.Timesheets.Add(entry);
         this.DataContext.SaveChanges();

         this.NewPrimaryKey = entry.TimesheetEntryId;
      }

      public void Update(TimesheetEntry updated)
      {
         this.DataContext.Timesheets.Attach(updated);
         var entry = this.DataContext.Entry(updated);
         entry.Property(e => e.Description).IsModified = true;
         entry.Property(e => e.Hours).IsModified = true;
         this.DataContext.SaveChanges();
      }

      public void Delete(int id)
      {
         TimesheetEntry entry = this.DataContext.Timesheets.Find(id);
         this.DataContext.Timesheets.Remove(entry);
         this.DataContext.SaveChanges();
      }

      public List<TimesheetEntry> GetTimesheet()
      {
         List<TimesheetEntry> result = new List<TimesheetEntry>();
         result = this.DataContext.Timesheets.ToList<TimesheetEntry>();
         return result;
      }

      public int NewPrimaryKey { get; set; }
   }
}
