using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using BusinessApp.BusinessLayer.Context;
using BusinessApp.BusinessLayer.Entities;

namespace BusinessApp.BusinessLayer
{
   /// <summary>
   /// 
   /// </summary>
   public class CustomerManager
   {
      private string _companyNameFilter;

      #region Data Context

      private BusinessAppDataContext _dataContext = null;

      private BusinessAppDataContext DataContext
      {
         get
         {
            if (_dataContext == null) _dataContext = new BusinessAppDataContext();
            return _dataContext;
         }
      }

      #endregion
      
      public List<Customer> GetCustomers()
      {
         List<Customer> result = null;

         result = new List<Customer>();

         if (string.IsNullOrWhiteSpace(_companyNameFilter))
         {
            result = this.DataContext.Customers.ToList<Customer>();
         }
         else
         {
            result = this.DataContext.Customers
               .Where(c => c.CompanyName == _companyNameFilter)
               .ToList<Customer>();
         }

         return result;
      }

      public void Insert(Customer entity)
      {

      }

      public void Update(Customer entity)
      {

      }

      public void Delete(Customer entity)
      {

      }

      public Customer Select(int id)
      {
         Customer result = null;

         return result;
      }

      public void SetFilters(string companyNameFilter)
      {
         _companyNameFilter = companyNameFilter;
      }

      public int NewPrimaryKey { get; set; }
   }
}

