﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using BusinessApp.BusinessLayer;

namespace BusinessApp.ViewModels
{
   public class TimesheetViewModel
   {
      #region Properties

      public TimesheetEntry TimesheetEntry { get; set; }

      private List<TimesheetEntry> _timesheet;

      public List<TimesheetEntry> Timesheet
      {
         get
         {
            if (_timesheet == null)
            {
               _timesheet = new List<TimesheetEntry>();
            }
            return _timesheet;
         }
         set
         {
            _timesheet = value;
         }
      }

      public bool IsMessageVisible { get; set; }
      public bool IsEditPanelVisible { get; set; }
      public bool IsButtonPanelVisible { get; set; }
      public bool IsFilterPanelVisible { get; set; }
      public string MessageText { get; set; }
      public bool RefreshGrid { get; set; }
      public int TimesheetEntryId { get; set; }
      public int CustomerId { get; set; }
      public int ProjectId { get; set; }
      public int TaskId { get; set; }

      [Required]
      [Display(Name = "Description")]
      public string Description { get; set; }
      
      [Required]
      [Display(Name = "Hours")]
      public double Hours { get; set; }

      [Display(Name = "Description")]
      public string DescriptionFilter { get; set; }

      #endregion

      public TimesheetViewModel()
      {
         this.IsEditPanelVisible = false;
         this.IsButtonPanelVisible = false;
         this.IsFilterPanelVisible = true;
      }

      public void Edit(object p)
      {
         int id = Convert.ToInt32(p);

         this.Load(id);

         this.TimesheetEntryId = this.TimesheetEntry.TimesheetEntryId;
         this.Description = this.TimesheetEntry.Description;
         this.CustomerId = this.TimesheetEntry.CustomerId;
         this.ProjectId = this.TimesheetEntry.ProjectId;
         this.TaskId = this.TimesheetEntry.TaskId;
         this.Hours = this.TimesheetEntry.Hours;

         this.IsEditPanelVisible = true;
         this.IsButtonPanelVisible = true;
         this.IsFilterPanelVisible = false;
      }

      public void Delete(object p)
      {
         int id = Convert.ToInt32(p);

         TimesheetManager manager = new TimesheetManager();
         manager.Delete(id);

         this.IsEditPanelVisible = false;
         this.IsButtonPanelVisible = false;
         this.IsFilterPanelVisible = true;

         this.RefreshGrid = true;
      }

      public void Handle(Exception ex)
      {
         this.IsMessageVisible = true;
         this.MessageText = ex.Message;
      }

      private void CreateEntry()
      {
         if (this.TimesheetEntry == null)
         {
            this.TimesheetEntry = new TimesheetEntry();
         }

         this.TimesheetEntry.TimesheetEntryId = this.TimesheetEntryId;
         this.TimesheetEntry.Description = this.Description;
         this.TimesheetEntry.Hours = this.Hours;
         this.TimesheetEntry.CustomerId = 1;
         this.TimesheetEntry.ProjectId = 1;
         this.TimesheetEntry.TaskId = 1;
      }

      public void Save()
      {
         TimesheetManager manager = new TimesheetManager();

         // Create an instance and perform data conversion for web forms
         this.CreateEntry();

         if (this.TimesheetEntry.TimesheetEntryId > 0)
         {
            manager.Update(this.TimesheetEntry);
         }
         else
         {
            manager.Insert(this.TimesheetEntry);
            this.TimesheetEntryId = manager.NewPrimaryKey;
         }

         this.IsEditPanelVisible = false;
         this.IsButtonPanelVisible = false;
         this.IsFilterPanelVisible = true;
         this.RefreshGrid = true;
      }

      public void Cancel()
      {
         this.IsEditPanelVisible = false;
         this.IsButtonPanelVisible = false;
         this.IsFilterPanelVisible = true;
      }

      public void LoadTimesheet()
      {
         TimesheetManager manager = new TimesheetManager();
         this.Timesheet = manager.GetTimesheet();
      }

      public void Load(int id)
      {
         TimesheetManager manager = new TimesheetManager();
         this.TimesheetEntry = manager.Select(id);
      }

      public void Add()
      {
         this.TimesheetEntry = new TimesheetEntry();

         this.IsEditPanelVisible = true;
         this.IsButtonPanelVisible = true;
         this.IsFilterPanelVisible = false;
      }

      public string EventTarget { get; set; }
      public string EventArgument { get; set; }
   }
}
