﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BusinessApp.BusinessLayer;
using System.ComponentModel.DataAnnotations;
using BusinessApp.BusinessLayer.Entities;

namespace BusinessApp.ViewModels
{
   public class CustomerIndexViewModel
   {
      [Display(Name = "Company Name")]
      [StringLength(32)]
      public string CompanyNameFilter { get; set; }

      public string EventTarget { get; set; }

      public string EventArgument { get; set; }

      public List<Customer> Customers { get; set; }

      public void LoadAll()
      {
         CustomerManager manager = null;

         manager = new CustomerManager();
         if (!string.IsNullOrWhiteSpace(this.EventTarget))
         {
            switch (this.EventTarget)
            {
               case "refresh":
                  manager.SetFilters(this.CompanyNameFilter);
                  break;
               case "reset":
                  this.CompanyNameFilter = string.Empty;
                  break;
            }
         }
         
         this.Customers = manager.GetCustomers();
      }
   }
}
