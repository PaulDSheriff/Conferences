﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using TimeTrack.EntityClasses;
using TimeTrack.ViewModels;

namespace TimeTrack.Silverlight
{
  public partial class ProjectLookupView : ChildWindow
  {
    private ProjectViewModel _ViewModel = null;

    #region Constructor
    public ProjectLookupView()
    {
      InitializeComponent();

      // Grab the Instance of the ViewModel
      _ViewModel = (ProjectViewModel)this.Resources["viewModel"];
    }
    #endregion

    #region Loaded Event
    private void ChildWindow_Loaded(object sender, RoutedEventArgs e)
    {
      _ViewModel.GetProjectsByCustomers((Application.Current as App).TimeSheetModel.SelectedCustomer);
    }
    #endregion

    #region SelectionChanged Event
    private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      // Get Selected Customer and Store into Application Level
      (Application.Current as App).TimeSheetModel.SelectedProject = (Project)lstData.SelectedItem;

      this.DialogResult = true;
    }
    #endregion

    #region TextChanged Event
    private void txtName_TextChanged(object sender, TextChangedEventArgs e)
    {
      _ViewModel.FilterProjects(txtName.Text.Trim());
    }
    #endregion

    private void CancelButton_Click(object sender, RoutedEventArgs e)
    {
      this.DialogResult = false;
    }
  }
}

