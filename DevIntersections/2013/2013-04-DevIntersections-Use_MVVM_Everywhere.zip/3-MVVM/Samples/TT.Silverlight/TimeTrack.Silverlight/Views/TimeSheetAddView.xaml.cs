﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using TimeTrack.EntityClasses;
using TimeTrack.ViewModels;

namespace TimeTrack.Silverlight
{
  public partial class TimeSheetAddView : UserControl
  {
    public TimeSheetAddViewModel _ViewModel = null;

    #region Constructor
    public TimeSheetAddView()
    {
      InitializeComponent();

      // Ensure TimeSheet View Model object is valid
      (Application.Current as App).InitTimeSheetViewModel();

      // Get Application-Wide TimeSheetAddViewModel instance
      _ViewModel = (Application.Current as App).TimeSheetModel;

      // Set ViewModel object to Page's Data Context
      this.DataContext = _ViewModel;
    }
    #endregion

    #region Reset_Click Event Procedure
    private void Reset_Click(object sender, EventArgs e)
    {
      _ViewModel.Init();
    }
    #endregion

    #region Select Customer Event
    private void btnCustomers_Click(object sender, RoutedEventArgs e)
    {
      CustomerLookupView win = new CustomerLookupView();

      win.Closed += new EventHandler(customerWindow_Closed);
      win.Show();
    }

    void customerWindow_Closed(object sender, EventArgs e)
    {
      Customer cust;

      cust = (Application.Current as App).TimeSheetModel.SelectedCustomer;
      if (cust != null && cust.CustomerId != -1)
        _ViewModel.SelectedCustomer = (Application.Current as App).TimeSheetModel.SelectedCustomer;
    }
    #endregion

    #region Select Project Event
    private void btnProject_Click(object sender, RoutedEventArgs e)
    {
      if (_ViewModel.SelectedCustomer == null || _ViewModel.SelectedCustomer.CustomerId == -1)
        MessageBox.Show("Select a Customer First", "Select Customer", MessageBoxButton.OK);
      else
      {
        ProjectLookupView win = new ProjectLookupView();

        win.Closed += new EventHandler(projectWindow_Closed);
        win.Show(); 
      }
    }

    void projectWindow_Closed(object sender, EventArgs e)
    {
      if ((Application.Current as App).TimeSheetModel.SelectedProject != null)
        _ViewModel.SelectedProject = (Application.Current as App).TimeSheetModel.SelectedProject;
    }
    #endregion

    #region Select Employee Event
    private void btnEmployee_Click(object sender, RoutedEventArgs e)
    {
      EmployeeLookupView win = new EmployeeLookupView();

      win.Closed += new EventHandler(employeeWindow_Closed);
      win.Show();
    }

    void employeeWindow_Closed(object sender, EventArgs e)
    {
      if ((Application.Current as App).TimeSheetModel.SelectedEmployee != null)
        _ViewModel.SelectedEmployee = (Application.Current as App).TimeSheetModel.SelectedEmployee;
    }
    #endregion

    #region Save Event
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      // Insert new Time Sheet entry
      _ViewModel.Insert();
    }
    #endregion

    #region Cancel Event
    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {

    }
    #endregion
  }
}
