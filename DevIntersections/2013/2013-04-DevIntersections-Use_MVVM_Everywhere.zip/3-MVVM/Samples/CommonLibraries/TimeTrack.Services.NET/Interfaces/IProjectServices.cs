using System.ServiceModel;

using TimeTrack.DataClasses;
using TimeTrack.EntityClasses;

namespace TimeTrack.Services
{
  [ServiceContract(Namespace = "http://TimeTrack.Services")]
  public interface IProjectServices
  {
    [OperationContract]
    ProjectResponse GetProject(Project entity);

    [OperationContract]
    ProjectResponse GetProjectsByCustomer(Customer entity);
  }
}
