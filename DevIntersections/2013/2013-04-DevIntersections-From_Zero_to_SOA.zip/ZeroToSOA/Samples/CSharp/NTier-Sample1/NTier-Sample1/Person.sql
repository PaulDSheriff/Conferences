﻿/****** Object:  Table [dbo].[Person]    Script Date: 02/14/2011 22:11:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Person](
	[PersonId] [int] IDENTITY(1,1) NOT NULL,
	[FirstName] [varchar](50) NOT NULL,
	[LastName] [varchar](50) NOT NULL,
	[EmailAddress] [varchar](250) NULL,
PRIMARY KEY NONCLUSTERED 
(
	[PersonId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[Person] ON
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (1, N'Paul                ', N'Shaefer', N'Pauls@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (2, N'Michael             ', N'Kawoski', N'Michaelk@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (3, N'Sara', N'Winchell', N'Saraw@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (4, N'John                ', N'Kroon', N'Johnk@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (5, N'Tim                 ', N'Nicker', N'Timn@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (6, N'Russ                ', N'Martlog', N'Russm@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (7, N'John                ', N'Boron', N'Johnb@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (8, N'James', N'Birdy', N'Jamesb@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (9, N'Trey                ', N'Chen', N'Treyc@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (10, N'Jim                 ', N'Jones', N'Jimj@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (11, N'John                ', N'Pittsburgh', N'Johnp@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (12, N'Jeanne              ', N'Russell', N'Jeanner@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (13, N'David               ', N'Lafeet', N'Davidl@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (14, N'Khanh               ', N'Voon', N'Khanhv@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (15, N'Jim                 ', N'Russell', N'Jimr@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (16, N'David               ', N'Tarkas', N'Davidt@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (17, N'Craig               ', N'Showman', N'Craigs@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (18, N'Brooks              ', N'Anderson', N'Brooksa@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (19, N'Mark                ', N'Parks', N'Markp@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (20, N'Keith               ', N'Nashville', N'Keithn@netinc.com')
INSERT [dbo].[Person] ([PersonId], [FirstName], [LastName], [EmailAddress]) VALUES (21, N'Jane                ', N'Joan', N'Janej@netinc.com')
SET IDENTITY_INSERT [dbo].[Person] OFF
