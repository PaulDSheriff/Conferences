﻿namespace NTier_Sample2
{
  public class Person : ObjectBase
  {
    #region Private Variables
    private int _PersonId = 0;
    private string _FirstName = string.Empty;
    private string _LastName = string.Empty;
    private string _EmailAddress = string.Empty;
    private string _Message = string.Empty;
    #endregion

    #region Public Properties
    public int PersonId
    {
      get { return _PersonId; }
      set
      {
        if (_PersonId != value)
        {
          _PersonId = value;
          RaisePropertyChanged("PersonId");
        }
      }
    }

    public string FirstName
    {
      get { return _FirstName; }
      set
      {
        if (_FirstName != value)
        {
          _FirstName = value;
          RaisePropertyChanged("FirstName");
        }
      }
    }

    public string LastName
    {
      get { return _LastName; }
      set
      {
        if (_LastName != value)
        {
          _LastName = value;
          RaisePropertyChanged("LastName");
        }
      }
    }

    public string EmailAddress
    {
      get { return _EmailAddress; }
      set
      {
        if (_EmailAddress != value)
        {
          _EmailAddress = value;
          RaisePropertyChanged("EmailAddress");
        }
      }
    }

    public string Message
    {
      get { return _Message; }
      set
      {
        if (_Message != value)
        {
          _Message = value;
          RaisePropertyChanged("Message");
        }
      }
    }
    #endregion
  }
}
