﻿using System;
using System.Runtime.Serialization;

namespace NTier.Common
{
  public enum OperationResult
  {
    Unknown,
    Success,
    Exception,
    Failure,
    ValidationFailed,
    NoRecords
  }

  [DataContract]
  public class ResponseBase
  {
    public ResponseBase()
    {
      Status = OperationResult.Unknown;
      RowsAffected = 0;
      FriendlyErrorMessage = string.Empty;
      ErrorMessage = string.Empty;
      ErrorMessageExtended = string.Empty;
    }

    [DataMember]
    public OperationResult Status { get; set; }

    [DataMember]
    public int RowsAffected { get; set; }

    [DataMember]
    public string FriendlyErrorMessage { get; set; }

    [DataMember]
    public string ErrorMessage { get; set; }

    [DataMember]
    public string ErrorMessageExtended { get; set; }
  }
}
