using System.ServiceModel;

using NTier.EntityClasses;

namespace NTier.Services
{
  [ServiceContract(Namespace = "http://NTier.Services")]
  public interface IPersonServices
  {
    [OperationContract]
    PersonResponse GetPerson(Person entity);

    [OperationContract]
    PersonResponse GetPersons();

    [OperationContract]
    PersonResponse Update(Person entity);
  }
}
