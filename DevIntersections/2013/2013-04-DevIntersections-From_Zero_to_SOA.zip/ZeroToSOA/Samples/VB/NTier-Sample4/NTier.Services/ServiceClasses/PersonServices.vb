Imports NTier.Common
Imports NTier.EntityClasses
Imports NTier.DataClasses

Partial Public Class PersonServices
  Implements IPersonServices

#Region "GetPerson Method"
  Public Function GetPerson(ByVal entity As Person) As PersonResponse Implements IPersonServices.GetPerson
    Dim ret As New PersonResponse()
    Dim mgr As PersonManager = Nothing

    Try
      mgr = New PersonManager(AppConfig.ConnectString)

      ret.DetailData = mgr.GetPerson(entity.PersonId)
      ret.Status = OperationResult.Success
    Catch ex As Exception
      ret.ErrorMessage = ex.Message
      ret.ErrorMessageExtended = ex.ToString()
      ret.Status = OperationResult.Exception
    End Try

    Return ret
  End Function
#End Region

#Region "BuildCollection Methods"
  Public Function GetPersons() As PersonResponse Implements IPersonServices.GetPersons
    Dim ret As New PersonResponse()
    Dim mgr As PersonManager = Nothing

    Try
      mgr = New PersonManager(AppConfig.ConnectString)

      ret.DataCollection = mgr.GetPersons()
      If ret.DataCollection.Count > 0 Then
        ret.Status = OperationResult.Success
      Else
        ret.Status = OperationResult.NoRecords
        ret.ErrorMessage = mgr.Message
        ret.FriendlyErrorMessage = "No records were found for this table."
      End If
    Catch ex As Exception
      ret.ErrorMessage = ex.Message
      ret.ErrorMessageExtended = ex.ToString()
      ret.Status = OperationResult.Exception
    End Try

    Return ret
  End Function
#End Region

#Region "Update Method"
  Public Function Update(entity As Person) As PersonResponse Implements IPersonServices.Update
    Dim ret As New PersonResponse()
    Dim mgr As PersonManager = Nothing

    Try
      mgr = New PersonManager(AppConfig.ConnectString)

      ret.RowsAffected = mgr.UpdatePerson(entity)
      If ret.RowsAffected = 0 Then
        If mgr.Message <> String.Empty Then
          ret.Status = OperationResult.Failure
          ret.FriendlyErrorMessage = mgr.Message
          ret.ErrorMessage = mgr.Message
        Else
          ret.Status = OperationResult.NoRecords
          ret.FriendlyErrorMessage = "The record(s) you were trying to update could no be found."
          ret.ErrorMessage = ret.FriendlyErrorMessage
        End If
      Else
        ret.DetailData = entity
        ret.ErrorMessage = mgr.Message
        ret.Status = OperationResult.Success
      End If
    Catch ex As Exception
      ret.ErrorMessage = ex.Message
      ret.ErrorMessageExtended = ex.ToString()
      ret.Status = OperationResult.Exception
    End Try

    Return ret
  End Function
#End Region
End Class