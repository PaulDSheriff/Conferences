﻿Public Class Person
  Inherits ObjectBase

#Region "Private Variables"
  Private _PersonId As Integer = 0
  Private _FirstName As String = String.Empty
  Private _LastName As String = String.Empty
  Private _EmailAddress As String = String.Empty
  Private _Message As String = String.Empty
#End Region

#Region "Public Properties"
  Public Property PersonId() As Integer
    Get
      Return _PersonId
    End Get
    Set(ByVal value As Integer)
      If _PersonId <> value Then
        _PersonId = value
        RaisePropertyChanged("PersonId")
      End If
    End Set
  End Property

  Public Property FirstName() As String
    Get
      Return _FirstName
    End Get
    Set(ByVal value As String)
      If _FirstName <> value Then
        _FirstName = value
        RaisePropertyChanged("FirstName")
      End If
    End Set
  End Property

  Public Property LastName() As String
    Get
      Return _LastName
    End Get
    Set(ByVal value As String)
      If _LastName <> value Then
        _LastName = value
        RaisePropertyChanged("LastName")
      End If
    End Set
  End Property

  Public Property EmailAddress() As String
    Get
      Return _EmailAddress
    End Get
    Set(ByVal value As String)
      If _EmailAddress <> value Then
        _EmailAddress = value
        RaisePropertyChanged("EmailAddress")
      End If
    End Set
  End Property

  Public Property Message() As String
    Get
      Return _Message
    End Get
    Set(ByVal value As String)
      If _Message <> value Then
        _Message = value
        RaisePropertyChanged("Message")
      End If
    End Set
  End Property
#End Region
End Class
