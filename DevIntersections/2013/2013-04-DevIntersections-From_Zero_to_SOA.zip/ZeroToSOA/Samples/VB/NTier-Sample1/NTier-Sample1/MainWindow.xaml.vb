﻿Imports System.Data
Imports System.Data.SqlClient

Class MainWindow
  Private Sub Window_Loaded(ByVal sender As Object, ByVal e As RoutedEventArgs)
    lstData.DataContext = GetPersons()
  End Sub

  Private Sub lstData_SelectionChanged(ByVal sender As Object, ByVal e As SelectionChangedEventArgs)
    FormShow()
  End Sub

  Private Sub FormShow()
    Dim dt As DataTable = GetPerson(Convert.ToInt32(lstData.SelectedValue))
    Dim dr As DataRow

    dr = dt.Rows(0)
    txtPersonId.Text = dr("PersonId").ToString()
    txtFirstName.Text = dr("FirstName").ToString()
    txtLastName.Text = dr("LastName").ToString()
    txtEmailAddress.Text = dr("EmailAddress").ToString()
  End Sub

  Private Sub btnUpdate_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    If Validate() Then
      UpdatePerson()
    End If
  End Sub

  Private Function Validate() As Boolean
    Dim ret As Boolean = False
    Dim msg As String = String.Empty

    If txtFirstName.Text.Trim() = String.Empty Then
      msg &= "First Name must be filled in." + Environment.NewLine
    End If
    If txtLastName.Text.Trim() = String.Empty Then
      msg &= "Last Name must be filled in." + Environment.NewLine
    End If
    If txtEmailAddress.Text.Trim() = String.Empty Then
      msg &= "Email Address must be filled in." + Environment.NewLine
    End If

    If msg = String.Empty Then
      ret = True
    Else
      MessageBox.Show(msg)
    End If

    Return ret
  End Function


#Region "GetPersons Method"
  Private Function GetPersons() As DataTable
    ' 2-Tier approach to data retrieval
    Dim ret As New DataTable()
    Dim sql As String = String.Empty
    Dim da As SqlDataAdapter = Nothing

    sql = "SELECT PersonId, LastName "
    sql += " FROM Person "
    sql += " ORDER BY LastName "
    Try
      da = New SqlDataAdapter(sql, AppConfig.ConnectString)
      da.Fill(ret)
    Catch ex As Exception
      MessageBox.Show(ex.Message)
    End Try

    Return ret
  End Function
#End Region

#Region "GetPerson Method"
  Private Function GetPerson(ByVal personId As Integer) As DataTable
    Dim ret As New DataTable()
    Dim sql As String = String.Empty
    Dim da As SqlDataAdapter = Nothing
    Dim cmd As SqlCommand = Nothing
    Dim parm As SqlParameter = Nothing

    sql = "SELECT PersonId, FirstName, LastName, EmailAddress "
    sql += " FROM Person "
    sql += " WHERE PersonId = @PersonId"
    Try
      cmd = New SqlCommand(sql, New SqlConnection(AppConfig.ConnectString))
      parm = New SqlParameter("@PersonId", personId)
      cmd.Parameters.Add(parm)

      da = New SqlDataAdapter(cmd)
      da.Fill(ret)
    Catch ex As Exception
      MessageBox.Show(ex.Message)
    End Try

    Return ret
  End Function
#End Region

#Region "UpdatePerson Method"
  Private Function UpdatePerson() As Integer
    Dim ret As Integer = 0
    Dim sql As String = String.Empty
    Dim cmd As SqlCommand = Nothing
    Dim parm As SqlParameter = Nothing

    sql = "UPDATE Person "
    sql += " SET FirstName = @FirstName, "
    sql += "     LastName = @LastName, "
    sql += "     EmailAddress = @EmailAddress"
    sql += " WHERE PersonId = @PersonId"
    Try
      cmd = New SqlCommand(sql, New SqlConnection(AppConfig.ConnectString))
      parm = New SqlParameter("@FirstName", txtFirstName.Text)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@LastName", txtLastName.Text)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@EmailAddress", txtEmailAddress.Text)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@PersonId", Convert.ToInt32(txtPersonId.Text))
      cmd.Parameters.Add(parm)
      cmd.Connection.Open()
      ret = cmd.ExecuteNonQuery()
    Catch ex As Exception
      MessageBox.Show(ex.Message)
    Finally
      If cmd IsNot Nothing Then
        If cmd.Connection IsNot Nothing Then
          cmd.Connection.Close()
          cmd.Connection.Dispose()
          cmd.Dispose()
        End If
      End If
    End Try

    Return ret
  End Function
#End Region

End Class
