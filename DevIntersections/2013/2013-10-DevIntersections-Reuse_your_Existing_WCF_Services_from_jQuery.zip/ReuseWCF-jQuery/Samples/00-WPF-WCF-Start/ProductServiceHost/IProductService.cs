﻿using System.Collections.Generic;
using System.ServiceModel;

using ProductDataLayer;

namespace ProductServiceHost
{
  [ServiceContract]
  public interface IProductService
  {
    [OperationContract]
    List<Product> GetProducts();

    [OperationContract]
    Product GetProduct(int productId);

    [OperationContract]
    int Insert(Product entity);

    [OperationContract]
    bool Update(Product entity);

    [OperationContract]
    bool Delete(Product entity);
  }
}
