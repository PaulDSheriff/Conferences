﻿using System;
using System.Windows;

using WPFToWCF.ProductServiceReference;

namespace WPFToWCF
{
  public partial class MainWindow : Window
  {
    #region Constructor
    public MainWindow()
    {
      InitializeComponent();
    }
    #endregion

    private int _ProductId = 0;

    #region Window_Loaded Event Procedure
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      DisplayRowsRead();
    }
    #endregion

    #region DisplayRowsRead Method
    private void DisplayRowsRead()
    {
      if (lstData.Items.Count > 0)
        txtRowsRead.Text = lstData.Items.Count.ToString("###,###");
      else
        txtRowsRead.Text = "0";
    }
    #endregion

    private void btnGetProducts_Click(object sender, RoutedEventArgs e)
    {
      ProductServiceClient client = new ProductServiceClient();

      lstData.DataContext = client.GetProducts();
      client.Close();

      DisplayRowsRead();
    }

    private void btnInsert_Click(object sender, RoutedEventArgs e)
    {
      ProductServiceClient client = new ProductServiceClient();
      Product entity = new Product();

      entity.ProductName = "A New Product";
      entity.IntroductionDate = Convert.ToDateTime("1/1/2013 08:00am");
      entity.Cost = 10;
      entity.Price = 20;
      entity.IsDiscontinued = false;

      _ProductId = client.Insert(entity);
      client.Close();
    }

    private void btnUpdate_Click(object sender, RoutedEventArgs e)
    {
      ProductServiceClient client = new ProductServiceClient();
      Product entity = new Product();

      entity.ProductId = _ProductId;
      entity.ProductName = "A CHANGED Product";
      entity.IntroductionDate = Convert.ToDateTime("2/1/2013 08:00am");
      entity.Cost = 20;
      entity.Price = 30;
      entity.IsDiscontinued = false;

      client.Update(entity);
      client.Close();
    }

    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      ProductServiceClient client = new ProductServiceClient();
      Product entity = new Product();

      entity.ProductId = _ProductId;

      client.Delete(entity);
      client.Close();
    }
  }
}
