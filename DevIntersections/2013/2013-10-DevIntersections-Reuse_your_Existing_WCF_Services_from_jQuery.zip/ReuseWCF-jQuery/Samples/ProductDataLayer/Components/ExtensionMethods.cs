﻿using System;
using System.Data;

namespace ProductDataLayer
{
  public static class ExtensionMethods
  {
    public static T GetDataAs<T>(this DataRow dr, string colName, T defaultValue = default(T)) where T : struct
    {
      object value = dr[colName];

      if (value.Equals(DBNull.Value))
        return (T)defaultValue;
      else
        return (T)value;
    }
  }
}
