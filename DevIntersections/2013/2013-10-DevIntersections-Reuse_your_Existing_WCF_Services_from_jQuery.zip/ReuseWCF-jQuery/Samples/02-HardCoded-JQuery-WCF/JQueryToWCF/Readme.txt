﻿To run this project you must first load the \ProductServiceHost\ProductServiceHost.sln and run that project.

You need to make sure that the Product table is in a database and you have modified the Web.Config file's connection string to point to that database in the WCF project.

After starting that WCF Service you can now run this project.