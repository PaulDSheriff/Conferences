﻿using System;
using System.Collections.ObjectModel;
using Common.Library;
using MVV_Simple_CS.Services;

namespace MVVM_Simple
{
  public class ProductViewModelSimple : ViewModelBase
  {
    bool _IsAddMode = false;

    #region Private UI Variables
    private bool _IsSaveEnabled = false;
    private bool _IsCancelEnabled = false;
    private bool _IsAddEnabled = true;
    private bool _IsListEnabled = true;
    private bool _IsDetailEnabled = false;
    private int _SelectedListIndex = -1;
    private string _Message = string.Empty;

    private ObservableCollection<Product> _DataCollection;
    private Product _DetailData;
    #endregion

    #region UI Properties
    public bool IsSaveEnabled
    {
      get { return _IsSaveEnabled; }
      set
      {
        if (_IsSaveEnabled != value)
        {
          _IsSaveEnabled = value;
          RaisePropertyChanged("IsSaveEnabled");
        }
      }
    }

    public bool IsCancelEnabled
    {
      get { return _IsCancelEnabled; }
      set
      {
        if (_IsCancelEnabled != value)
        {
          _IsCancelEnabled = value;
          RaisePropertyChanged("IsCancelEnabled");
        }
      }
    }

    public bool IsAddEnabled
    {
      get { return _IsAddEnabled; }
      set
      {
        if (_IsAddEnabled != value)
        {
          _IsAddEnabled = value;
          RaisePropertyChanged("IsAddEnabled");
        }
      }
    }

    public bool IsListEnabled
    {
      get { return _IsListEnabled; }
      set
      {
        if (_IsListEnabled != value)
        {
          _IsListEnabled = value;
          RaisePropertyChanged("IsListEnabled");
        }
      }
    }

    public int SelectedListIndex
    {
      get { return _SelectedListIndex; }
      set
      {
        if (_SelectedListIndex != value)
        {
          _SelectedListIndex = value;
          RaisePropertyChanged("SelectedListIndex");
        }
      }
    }

    public bool IsDetailEnabled
    {
      get { return _IsDetailEnabled; }
      set
      {
        if (_IsDetailEnabled != value)
        {
          _IsDetailEnabled = value;
          RaisePropertyChanged("IsDetailEnabled");
        }
      }
    }

    public bool IsAddMode
    {
      get { return _IsAddMode; }
      set
      {
        if (_IsAddMode != value)
        {
          _IsAddMode = value;
          RaisePropertyChanged("IsAddMode");
        }
      }
    }

    public string Message
    {
      get { return _Message; }
      set
      {
        if (_Message != value)
        {
          _Message = value;
          RaisePropertyChanged("Message");
        }
      }
    }
    #endregion

    #region DataCollection Property
    public ObservableCollection<Product> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region DetailData Property
    public Product DetailData
    {
      get { return _DetailData; }
      set
      {
        _DetailData = value;
        RaisePropertyChanged("DetailData");
      }
    }
    #endregion

    #region SetNormalUIDisplay Method
    public void SetNormalUIDisplay()
    {
      IsAddMode = false;
      IsAddEnabled = true;
      IsSaveEnabled = false;
      IsCancelEnabled = false;
      IsListEnabled = true;
      IsDetailEnabled = false;
    }
    #endregion

    #region SetEditUIDisplay Method
    public void SetEditUIDisplay()
    {
      IsAddEnabled = false;
      IsSaveEnabled = true;
      IsCancelEnabled = true;
      IsListEnabled = false;
      IsDetailEnabled = true;
      Message = string.Empty;
    }
    #endregion

    #region LoadAll Method
    public void LoadAll()
    {
      try
      {
        ProductServices client = new ProductServices();
        ProductResponse resp;

        resp = client.GetProducts();
        if (resp.Status == OperationResult.Success)
        {
          DataCollection = new ObservableCollection<Product>(resp.DataCollection);
          SelectedListIndex = 0;
        }
        else
          Message = resp.ErrorMessage;
      }
      catch
      {
        // Ignore exception in design time
      }
    }
    #endregion

    #region AddRecord Method
    public void AddRecord()
    {
      SetEditUIDisplay();
      IsAddMode = true;

      // Create Empty Object for UI to Display
      DetailData = new Product();
      DetailData.IntroductionDate = DateTime.Now;
      DetailData.IsDiscontinued = false;
    }
    #endregion

    #region CancelEdit Method
    public void CancelEdit()
    {
      SetNormalUIDisplay();

      IsAddMode = false;
      Message = string.Empty;

      // TODO: Write Code to Undo Here
    }
    #endregion

    #region SaveData Method
    public void SaveData()
    {
      if (IsAddMode)
        InsertData();
      else
        UpdateData();

      SetNormalUIDisplay();
    }
    #endregion

    #region Insert Data
    public void InsertData()
    {
      ProductServices client = new ProductServices();
      ProductResponse resp;

      // Insert Product
      resp = client.Insert(DetailData);
      if (resp.Status == OperationResult.Exception)
        Message = resp.ErrorMessage;
      else
      {
        DataCollection.Add(DetailData);
        Message = "Insert Successful";
      }
    }
    #endregion

    #region Update Data
    public void UpdateData()
    {
      ProductServices client = new ProductServices();
      ProductResponse resp;

      // Insert Product
      resp = client.Insert(DetailData);
      if (resp.Status == OperationResult.Exception)
        Message = resp.ErrorMessage;
      else
        Message = "Update Successful";
    }
    #endregion
  }
}
