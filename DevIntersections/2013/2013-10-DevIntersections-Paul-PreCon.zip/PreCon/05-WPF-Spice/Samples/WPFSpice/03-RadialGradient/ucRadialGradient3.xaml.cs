﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFSpice
{
  /// <summary>
  /// Interaction logic for ucRadialGradient3.xaml
  /// </summary>
  public partial class ucRadialGradient3 : UserControl
  {
    public ucRadialGradient3()
    {
      InitializeComponent();
    }
    
    private void Button_Click(object sender, RoutedEventArgs e)
    {
      brushBackground.GradientOrigin = new Point(Convert.ToDouble(txtOriginStart.Text), Convert.ToDouble(txtOriginEnd.Text));
    }
  }
}
