﻿using System;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace WPFSpice
{
  public abstract class UserControlAnimation
  {
    #region Constructor
    public UserControlAnimation(Panel contentArea)
    {
      AnimationTime = 1000;
      AnimationRunning = false;
      _CurrentStoryBoard = new Storyboard();
      _NewStoryBoard = new Storyboard();
      _CurrentControl = null;
      _ControlToRemove = null;
      _NewControl = null;
      _ContentArea = contentArea;
    }
    #endregion

    #region Public/Protected Properties
    public bool AnimationRunning { get; set; }
    public int AnimationTime { get; set; }

    protected Storyboard _CurrentStoryBoard { get; set; }
    protected Storyboard _NewStoryBoard { get; set; }
    protected UserControl _CurrentControl { get; set; }
    protected UserControl _ControlToRemove { get; set; }
    protected UserControl _NewControl { get; set; }
    protected Panel _ContentArea { get; set; }
    #endregion

    #region Animate Method
    public void Animate(UserControl newControl)
    {
      if (!AnimationRunning)
      {
        _ControlToRemove = _CurrentControl;
        _NewControl = newControl;
        PrepareCurrent();
        PrepareNew();
        AnimateControls();
      }
    }
    #endregion

    #region Setup Current Control's Transform
    protected abstract void PrepareCurrent();

    protected void CurrentStoryBoard_Completed(object sender, EventArgs e)
    {
      _CurrentStoryBoard.Stop();
      _CurrentStoryBoard.Completed -= new EventHandler(CurrentStoryBoard_Completed);
      if(_ControlToRemove != null)
        // Remove the Old Control from the Visual Tree
        _ContentArea.Children.Remove(_ControlToRemove);

      AnimationRunning = false;
    }
    #endregion

    #region Setup New Controls StoryBoard
    protected abstract void PrepareNew();

    protected void NewStoryBoard_Completed(object sender, EventArgs e)
    {
      _NewStoryBoard.Stop();
      _NewStoryBoard.Completed -= new EventHandler(NewStoryBoard_Completed);

      if (_NewControl != null)
        _CurrentControl = _NewControl;

      AnimationRunning = false;
    }
    #endregion

    #region Animate the Controls
    private void AnimateControls()
    {
      AnimationRunning = true;
      if (_CurrentControl != null)
        _CurrentStoryBoard.Begin();
      if (_NewControl != null)
        _NewStoryBoard.Begin();
    }
    #endregion
  }
}
