﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFSpice
{
  /// <summary>
  /// Interaction logic for ucRightLeft.xaml
  /// </summary>
  public partial class ucRightLeft : UserControl
  {
    // Create Opacity Animation Class
    private UserControlRightLeftAnimation _Animation = null;

    public ucRightLeft()
    {
      InitializeComponent();

      // Initialize the Animation Object with the Content Area to Draw the Controls
      _Animation = new UserControlRightLeftAnimation(contentArea);
    }

    private void btnHome_Click(object sender, RoutedEventArgs e)
    {
      if (!_Animation.AnimationRunning)
        _Animation.Animate(null);
    }

    private void btnCustomers_Click(object sender, RoutedEventArgs e)
    {
      if (!_Animation.AnimationRunning)
        _Animation.Animate(new ucPage1());
    }

    private void btnInvoices_Click(object sender, RoutedEventArgs e)
    {
      if (!_Animation.AnimationRunning)
        _Animation.Animate(new ucPage2());
    }

    private void btnVendors_Click(object sender, RoutedEventArgs e)
    {
      if (!_Animation.AnimationRunning)
        _Animation.Animate(new ucPage3());
    }
  }
}
