﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Linq

Public Class ProductManager
#Region "GetProducts Method"
  ''' <summary>
  ''' This method uses a custom extension method on a DataReader called Field to retrieve data.
  ''' The Field method works will nullable types.
  ''' </summary>
  ''' <returns>A List of Product objects</returns>
  Public Function GetProducts() As List(Of Product)
    Dim cmd As SqlCommand = Nothing
    Dim ret As New List(Of Product)()
    Dim entity As Product = Nothing

    cmd = New SqlCommand("SELECT * FROM Product")
    Using cnn As SqlConnection = New SqlConnection("Server=Localhost;Database=Sandbox;Integrated Security=Yes")
      cmd.Connection = cnn
      cmd.Connection.Open()
      Using rdr As SqlDataReader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While rdr.Read()
          entity = New Product()

          entity.ProductId = rdr.Field(Of System.Nullable(Of Integer))("ProductId")
          entity.ProductName = rdr.Field(Of String)("ProductName")
          entity.IntroductionDate = rdr.Field(Of System.Nullable(Of DateTime))("IntroductionDate")
          entity.Cost = rdr.Field(Of System.Nullable(Of Decimal))("Cost")
          entity.Price = rdr.Field(Of System.Nullable(Of Decimal))("Price")
          entity.IsDiscontinued = rdr.Field(Of System.Nullable(Of Boolean))("IsDiscontinued")

          ret.Add(entity)
        End While
      End Using
    End Using

    Return ret
  End Function
#End Region
End Class
