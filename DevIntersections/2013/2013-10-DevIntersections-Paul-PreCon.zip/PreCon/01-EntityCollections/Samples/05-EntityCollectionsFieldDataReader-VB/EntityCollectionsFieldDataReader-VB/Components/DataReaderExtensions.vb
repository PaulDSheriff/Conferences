﻿Imports System.Data.SqlClient

Public Module DataReaderExtensions
  <System.Runtime.CompilerServices.Extension()> _
  Public Function Field(Of T)(rdr As SqlDataReader, columnName As String) As Object
    If rdr(columnName).Equals(DBNull.Value) Then
      Return Nothing
    Else
      Return DirectCast(rdr(columnName), T)
    End If
  End Function
End Module
