﻿Class MainWindow

  Private Sub Window_Loaded(sender As System.Object, e As System.Windows.RoutedEventArgs)
    DisplayRowsRead()
  End Sub

#Region "DisplayRowsRead Method"
  Private Sub DisplayRowsRead()
    If lstData.Items.Count > 0 Then
      txtRowsRead.Text = lstData.Items.Count.ToString("###,###")
    Else
      txtRowsRead.Text = "0"
    End If
  End Sub
#End Region

  Private Sub btnLinq_Click(sender As Object, e As RoutedEventArgs) Handles btnLinq.Click
    Dim mgr As New ProductManager()

    lstData.View = PDSAListView.CreateGridViewColumns(GetType(Product))
    lstData.DataContext = mgr.GetProducts()
    DisplayRowsRead()
  End Sub

End Class
