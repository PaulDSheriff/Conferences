﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Linq

Public Class ProductManager
#Region "GetProducts Method"
  ''' <summary>
  ''' This method uses DataRow.Field&lt;T&gt;() method to retrieve data.
  ''' The Field method works will nullable types.
  ''' </summary>
  ''' <returns>A List of Product objects</returns>
  Public Function GetProducts() As List(Of Product)
    Dim dt As New DataTable()
    Dim da As SqlDataAdapter = Nothing

    da = New SqlDataAdapter("SELECT * FROM Product", AppSettings.Instance.ConnectString)

    da.Fill(dt)

    Dim query = (From dr In dt.AsEnumerable() Select New Product() With { _
      .ProductId = dr.Field(Of Nullable(Of Integer))("ProductId"), _
      .ProductName = dr.Field(Of String)("ProductName"), _
      .IntroductionDate = dr.Field(Of Nullable(Of DateTime))("IntroductionDate"), _
      .Cost = dr.Field(Of Nullable(Of Decimal))("Cost"), _
      .Price = dr.Field(Of Nullable(Of Decimal))("Price"), _
      .IsDiscontinued = dr.Field(Of Nullable(Of Boolean))("IsDiscontinued") _
    })

    Return query.ToList()
  End Function
#End Region
End Class
