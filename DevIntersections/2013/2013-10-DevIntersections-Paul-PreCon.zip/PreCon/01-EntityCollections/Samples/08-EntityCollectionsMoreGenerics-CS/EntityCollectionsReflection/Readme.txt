﻿In this version we change the 'object' in DataConvert class to T
We also make it an optional parameter and default it to 'default(T)'
We also changed the name to GetDataAs()

The second change is to turn the GetDataAs into an extension method 
  on the DataRow and rename ConvertTo() to GetDataAs()
