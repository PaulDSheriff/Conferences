﻿using System;

namespace EntityCollectionsReflection
{
  public class DataConvert
  {
    public static T ConvertTo<T>(object value, object defaultValue) where T : struct
    {
      if (value == DBNull.Value)
        return (T)defaultValue;
      else
        return (T)value;
    }

    // Modified the ConvertTo() method to use T for the default value and to default it to the correct type
    // This simplifies the usage to entity.Cost = DataConvert.GetDataAs<decimal>(dr["Cost"]);
    public static T GetDataAs<T>(object value, T defaultValue = default(T)) where T : struct
    {
      if (value == DBNull.Value)
        return (T)defaultValue;
      else
        return (T)value;
    }
  }
}
