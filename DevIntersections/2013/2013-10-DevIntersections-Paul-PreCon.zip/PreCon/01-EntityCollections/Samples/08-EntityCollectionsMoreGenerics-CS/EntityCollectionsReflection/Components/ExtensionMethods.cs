﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Reflection;
using System.Data.SqlClient;

namespace EntityCollectionsReflection
{
  public static class ExtensionMethods
  {
    public static T GetDataAs<T>(this DataRow dr, string colName, T defaultValue = default(T)) where T : struct
    {
      object value = dr[colName];

      if (value.Equals(DBNull.Value))
        return (T)defaultValue;
      else
        return (T)value;
    }

    public static List<T> GetEntityCollection<T>(this DataTable dt) where T : new()
    {
      List<T> ret = new List<T>();
      T entity;

      // Get all the properties in Entity Class
      PropertyInfo[] props = typeof(T).GetProperties();

      foreach (DataRow dr in dt.Rows)
      {
        // Create new instance of Entity
        entity = new T();

        // Set all properties from the column names
        // NOTE: This assumes your column names are the 
        //       same name as your class property names
        foreach (PropertyInfo col in props)
        {
          if (dr[col.Name] == DBNull.Value)
            col.SetValue(entity, null, null);
          else
            col.SetValue(entity, dr[col.Name], null);
        }

        ret.Add(entity);
      }

      return ret;
    }
    
    public static List<T> GetEntityCollection<T>(this IDataReader rdr) where T : new()
    {
      List<T> ret = new List<T>();
      T entity;

      // Get all the properties in Entity Class
      PropertyInfo[] props = typeof(T).GetProperties();

      while (rdr.Read())
      {
        // Create new instance of Entity
        entity = new T();

        // Set all properties from the column names
        // NOTE: This assumes your column names are the 
        //       same name as your class property names
        foreach (PropertyInfo col in props)
        {
          if (rdr[col.Name].Equals(DBNull.Value))
            col.SetValue(entity, null, null);
          else
            col.SetValue(entity, rdr[col.Name], null);
        }

        ret.Add(entity);
      }

      return ret;
    }    
  }
}
