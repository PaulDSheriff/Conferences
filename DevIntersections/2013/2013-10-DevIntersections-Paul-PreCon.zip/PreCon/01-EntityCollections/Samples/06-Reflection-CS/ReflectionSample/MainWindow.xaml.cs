﻿using System.Windows;
using System.Reflection;
using System;

namespace EntityCollectionsReflection
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    #region InvokeMember Method
    private void btnSetProperty1_Click(object sender, RoutedEventArgs e)
    {
      Product entity = new Product();
      typeof(Product).InvokeMember("ProductName",
        BindingFlags.SetProperty,
          Type.DefaultBinder, entity,
           new Object[] { "A New Product" });

      MessageBox.Show(entity.ProductName);
    }
    #endregion

    #region SetValue Method
    private void btnSetProperty2_Click(object sender, RoutedEventArgs e)
    {
      Product entity = new Product();

      typeof(Product).GetProperty("ProductName").
        SetValue(entity, "A New Product", null);

      MessageBox.Show(entity.ProductName);
    }
    #endregion
  }
}
