﻿using System;
using System.Data.SqlClient;

namespace EntityCollectionsDataReaderField
{

  public static class DataReaderExtensions
  {
    public static dynamic Field<T>(this SqlDataReader rdr, string columnName)
    {
      if (rdr[columnName].Equals(DBNull.Value))
        return null;
      else
        return (T)rdr[columnName];
    }
  }
}
