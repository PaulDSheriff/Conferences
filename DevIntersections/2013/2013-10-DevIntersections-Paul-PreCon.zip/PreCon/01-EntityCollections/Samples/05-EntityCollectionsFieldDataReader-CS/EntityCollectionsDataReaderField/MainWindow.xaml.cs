﻿using System.Windows;
using System.Diagnostics;

namespace EntityCollectionsDataReaderField
{
  public partial class MainWindow : Window
  {
    #region Constructor
    public MainWindow()
    {
      InitializeComponent();
    }
    #endregion

    #region Window_Loaded Event Procedure
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      DisplayRowsRead();
    }
    #endregion

    #region DisplayRowsRead Method
    private void DisplayRowsRead()
    {
      if (lstData.Items.Count > 0)
        txtRowsRead.Text = lstData.Items.Count.ToString("###,###");
      else
        txtRowsRead.Text = "0";
    }
    #endregion

    private void btnReader_Click(object sender, RoutedEventArgs e)
    {
      ProductManager mgr = new ProductManager();
      
      lstData.View = PDSAListView.CreateGridViewColumns(typeof(Product));
      lstData.DataContext = mgr.GetProducts();
      DisplayRowsRead();
    }
  }
}
