﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace NTier_Sample1
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      lstData.DataContext = GetPersons();
    }

    #region GetPersons Method
    private DataTable GetPersons()
    {
      // 2-Tier approach to data retrieval
      DataTable ret = new DataTable();
      string sql = string.Empty;
      SqlDataAdapter da = null;

      sql = "SELECT PersonId, LastName ";
      sql += " FROM Person ";
      sql += " ORDER BY LastName ";
      try
      {
        da = new SqlDataAdapter(sql, AppConfig.ConnectString);
        da.Fill(ret);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }

      return ret;
    }
    #endregion

    #region SelectionChanged & FormShow
    private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      FormShow();
    }

    private void FormShow()
    {
      DataTable dt = GetPerson(Convert.ToInt32(lstData.SelectedValue));
      DataRow dr;

      dr = dt.Rows[0];
      txtPersonId.Text = dr["PersonId"].ToString();
      txtFirstName.Text = dr["FirstName"].ToString();
      txtLastName.Text = dr["LastName"].ToString();
      txtEmailAddress.Text = dr["EmailAddress"].ToString();
    }
    #endregion

    #region GetPerson Method
    private DataTable GetPerson(int personId)
    {
      DataTable ret = new DataTable();
      string sql = string.Empty;
      SqlDataAdapter da = null;
      SqlCommand cmd = null;
      SqlParameter parm = null;

      sql = "SELECT PersonId, FirstName, LastName, EmailAddress ";
      sql += " FROM Person ";
      sql += " WHERE PersonId = @PersonId";
      try
      {
        cmd = new SqlCommand(sql, new SqlConnection(AppConfig.ConnectString));
        parm = new SqlParameter("@PersonId", personId);
        cmd.Parameters.Add(parm);

        da = new SqlDataAdapter(cmd);
        da.Fill(ret);
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }

      return ret;
    }
    #endregion

    #region Update Click and Validate Methods
    private void btnUpdate_Click(object sender, RoutedEventArgs e)
    {
      if (Validate())
        UpdatePerson();
    }

    private bool Validate()
    {
      bool ret = false;
      string msg = string.Empty;

      if (txtFirstName.Text.Trim() == string.Empty)
        msg += "First Name must be filled in." + Environment.NewLine;
      if (txtLastName.Text.Trim() == string.Empty)
        msg += "Last Name must be filled in." + Environment.NewLine;
      if (txtEmailAddress.Text.Trim() == string.Empty)
        msg += "Email Address must be filled in." + Environment.NewLine;

      if (msg == string.Empty)
        ret = true;
      else
        MessageBox.Show(msg);

      return ret;
    }
    #endregion

    #region UpdatePerson Method
    private int UpdatePerson()
    {
      int ret = 0;
      string sql = string.Empty;
      SqlCommand cmd = null;
      SqlParameter parm = null;

      sql = "UPDATE Person ";
      sql += " SET FirstName = @FirstName, ";
      sql += "     LastName = @LastName, ";
      sql += "     EmailAddress = @EmailAddress";
      sql += " WHERE PersonId = @PersonId";
      try
      {
        cmd = new SqlCommand(sql, new SqlConnection(AppConfig.ConnectString));
        parm = new SqlParameter("@FirstName", txtFirstName.Text);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@LastName", txtLastName.Text);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@EmailAddress", txtEmailAddress.Text);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@PersonId", Convert.ToInt32(txtPersonId.Text));
        cmd.Parameters.Add(parm);
        cmd.Connection.Open();
        ret = cmd.ExecuteNonQuery();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      finally
      {
        if(cmd != null)
          if (cmd.Connection != null)
          {
            cmd.Connection.Close();
            cmd.Connection.Dispose();
            cmd.Dispose();
          }
      }

      return ret;
    }
    #endregion
  }
}
