﻿using System.Windows;
using System.Windows.Controls;
using Microsoft.Phone.Controls;

using TimeTrack.EntityClasses;
using TimeTrack.ViewModels;

namespace TimeTrack.WinPhone
{
  public partial class CustomerLookupView : PhoneApplicationPage
  {
    private CustomerViewModel _ViewModel = null;

    #region Constructor
    public CustomerLookupView()
    {
      InitializeComponent();

      // Grab the Instance of the ViewModel
      _ViewModel = (CustomerViewModel)this.Resources["viewModel"];
    }
    #endregion

    #region Loaded Event Procedure
    private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
    {
      _ViewModel.GetCustomers();
    }
    #endregion

    private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      // Get Selected Customer and 
      // Store into Application Level
      (Application.Current as App).
        TimeSheetModel.SelectedCustomer = 
          (Customer)lstData.SelectedItem;

      NavigationService.GoBack();
    }

    #region TextChanged Event
    private void txtName_TextChanged(object sender, TextChangedEventArgs e)
    {
      _ViewModel.FilterCustomers(txtName.Text.Trim());
    }
    #endregion
  }
}