﻿using System.Windows;
using System.Windows.Controls;

using Common.Library;

namespace TimeTrack.WinPhone
{
  public partial class ucHeader : UserControl
  {
    public string PageHeader
    {
      get { return PageTitle.Text; }
      set { PageTitle.Text = value; }
    }

    public ucHeader()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      ApplicationTitle.Text = WinPhoneCommon.GetApplicationTitle();
    }
  }
}
