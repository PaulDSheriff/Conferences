﻿$(function () {
  $('#Customers').change(function () {
    var url = '/TimeSheetAdd/ProjectsForCustomer/' + $('#Customers').val();
    $.getJSON(url, function (data) {
      var items = '';
      $.each(data, function (i, project) {
        items += "<option value='" + project.Value + "'>" + project.Text + "</option>";
      });
      $('#Projects').html(items);
    });
  });
});