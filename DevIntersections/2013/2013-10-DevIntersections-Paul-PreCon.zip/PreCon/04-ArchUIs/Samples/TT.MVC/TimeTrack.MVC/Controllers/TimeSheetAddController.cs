﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TimeTrack.ViewModels;

namespace TimeTrack.MVC.Controllers
{
  public class TimeSheetAddController : Controller
  {
    public ActionResult TimeSheetAdd()
    {
      TimeSheetAddViewModel viewModel = new TimeSheetAddViewModel(false);

      viewModel.PrepareForNew();

      // NOTE: Customers and Employees are loaded when the View Model are created
      // Just caching them here so we can retrieve them later
      HttpContext.Session.Add("Customers", viewModel.Customers);
      HttpContext.Session.Add("Employees", viewModel.Employees);

      return View(viewModel);
    }

    // NOTE: The parameter name must be 'Id' in order to work.
    public ActionResult ProjectsForCustomer(int Id)
    {
      TimeSheetAddViewModel viewModel = new TimeSheetAddViewModel(false);

      viewModel.GetProjectsByCustomer(Id);
      HttpContext.Session.Add("Projects", viewModel.Projects);

      return Json(new SelectList(viewModel.Projects.ToArray(), "ProjectId", "ProjectName"),
        JsonRequestBehavior.AllowGet);
    }

    [HttpPost]
    public ActionResult TimeSheetAdd(TimeSheetAddViewModel viewModel)
    {
      // Must set to Synchronous
      viewModel.UseAsync = false;
      
      // Get Data From Cache
      viewModel.Customers = (ObservableCollection<EntityClasses.Customer>)Session["Customers"];
      viewModel.Employees = (ObservableCollection<EntityClasses.Employee>)Session["Employees"];
      if(Session["Projects"] != null)
        viewModel.Projects = (ObservableCollection<EntityClasses.Project>)Session["Projects"];

      // Get data from Drop-Down Lists
      viewModel.SelectedCustomer.CustomerId = Convert.ToInt32(HttpContext.Request["Customers"]);
      viewModel.SelectedProject.ProjectId = Convert.ToInt32(HttpContext.Request["Projects"]);
      viewModel.SelectedEmployee.EmployeeId = Convert.ToInt32(HttpContext.Request["Employees"]);

      // If drop downs are not filled in, a zero is filled in, we need it to be -1
      if (viewModel.SelectedCustomer.CustomerId == 0)
        viewModel.SelectedCustomer.CustomerId = -1;
      if (viewModel.SelectedProject.ProjectId == 0)
        viewModel.SelectedProject.ProjectId = -1;
      if (viewModel.SelectedEmployee.EmployeeId == 0)
        viewModel.SelectedEmployee.EmployeeId = -1;

      viewModel.Insert();

      if (!viewModel.IsValidationAreaVisible)
      {
        // Reset for next entry
        viewModel.Hours = 1;
        viewModel.Description = string.Empty;

        // Use RedirectToAction to have bindings reset.
        return RedirectToAction("TimeSheetAdd", viewModel);
      }
      else
      {
        return View("TimeSheetAdd", viewModel);
      }
    }
  }
}
