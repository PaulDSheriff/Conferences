﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using ShirtCommon;

namespace WPFViewModel
{
  public partial class MainWindow : Window
  {
    private ShirtViewModel _ViewModel = null;

    public MainWindow()
    {
      InitializeComponent();

      _ViewModel = (ShirtViewModel)this.Resources["viewModel"];
      _ViewModel.LoadAll();
    }

    private void ListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (e.AddedItems.Count > 0)
        _ViewModel.ShirtId = Convert.ToInt32(((DataRowView)e.AddedItems[0]).Row["ShirtId"]);
    }

    private void btnAdd_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.SetAddMode();
    }

    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.Save();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.Cancel();
    }

    private void btnEdit_Click(object sender, RoutedEventArgs e)
    {
      // Display the current Record
      lstData.SelectedItem = ((Button)sender).DataContext;

      _ViewModel.SetEditMode();
    }

    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      // Display the current Record
      lstData.SelectedItem = ((Button)sender).DataContext;

      if (MessageBox.Show("Delete the Shirt " + _ViewModel.ShirtName + "?", "Delete?", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
        _ViewModel.DeleteAShirt(_ViewModel.ShirtId);
    }
  }
}