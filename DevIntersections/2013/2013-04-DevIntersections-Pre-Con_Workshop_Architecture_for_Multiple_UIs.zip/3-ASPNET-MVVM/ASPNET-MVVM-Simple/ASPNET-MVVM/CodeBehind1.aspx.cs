﻿using System;

namespace ASPNET_MVVM
{
  public partial class CodeBehind1 : System.Web.UI.Page
  {
    protected void chkBenefits_CheckedChanged(object sender, EventArgs e)
    {
      chk401k.Enabled = chkBenefits.Checked;
      chkHealthCare.Enabled = chkBenefits.Checked;
      if (chkBenefits.Checked == false)
      {
        chk401k.Checked = false;
        chkHealthCare.Checked = false;
      }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      // Write code here to save the data


    }
  }
}