﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ASPNET_MVVM
{
  public class MVVM1ViewModel
  {
    private bool _HasBenefits = false;
    private bool _Has401k = false;
    private bool _HasHealthCare = false;
    private bool _Is401kEnabled = false;
    private bool _IsHealthCareEnabled = false;

    public bool HasBenefits
    {
      get { return _HasBenefits; }
      set { 
        _HasBenefits = value;
        Is401kEnabled = value;
        IsHealthCareEnabled = value;
        if (_HasBenefits == false)
        {
          Has401k = false;
          HasHealthCare = false;
        }
      }
    }

    public bool Has401k
    {
      get { return _Has401k; }
      set { _Has401k = value; }
    }

    public bool HasHealthCare
    {
      get { return _HasHealthCare; }
      set { _HasHealthCare = value; }
    }
    
    public bool Is401kEnabled
    {
      get { return _Is401kEnabled; }
      set { _Is401kEnabled = value; }
    }

    public bool IsHealthCareEnabled
    {
      get { return _IsHealthCareEnabled; }
      set { _IsHealthCareEnabled = value; }
    }

    public void Save()
    {
    }
  }
}