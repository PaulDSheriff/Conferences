﻿using System;

namespace ASPNET_MVVM
{
  public partial class MVVM1 : System.Web.UI.Page
  {
    private MVVM1ViewModel _ViewModel = null;

    protected void Page_Load(object sender, EventArgs e)
    {
      _ViewModel = new MVVM1ViewModel();
    }

    protected void chkBenefits_CheckedChanged(object sender, EventArgs e)
    {
      // Set property from check box that changes
      _ViewModel.HasBenefits = chkBenefits.Checked;

      // Refresh all properties
      chk401k.Enabled = _ViewModel.Is401kEnabled;
      chkHealthCare.Enabled = _ViewModel.IsHealthCareEnabled;
      chk401k.Checked = _ViewModel.Has401k;
      chkHealthCare.Checked = _ViewModel.HasHealthCare;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      _ViewModel.Has401k = chk401k.Checked;
      _ViewModel.HasHealthCare = chkHealthCare.Checked;

      _ViewModel.Save();
    }
  }
}