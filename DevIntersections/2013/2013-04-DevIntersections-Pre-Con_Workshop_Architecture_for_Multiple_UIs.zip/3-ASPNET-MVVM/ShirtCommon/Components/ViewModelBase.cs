﻿using System;
using System.Collections.ObjectModel;

namespace Common.Library
{
  [Serializable()]
  public class ViewModelBase : CommonBase
  {
    #region Constructor
    public ViewModelBase() : base()
    {
    }
    #endregion

    #region Private Variables
    private bool _IsAddMode = false;
    private bool _IsAddVisible = false;
    private bool _IsSaveVisible = false;
    private bool _IsCancelVisible = false;
    private bool _IsEditVisible = false;
    private bool _IsExceptionVisible = false;
    private bool _IsValidationVisible = false;
    private bool _IsListEnabled = false;
    private string _MessageToDisplay = string.Empty;
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set IsAddMode
    /// </summary>
    public bool IsAddMode
    {
      get { return _IsAddMode; }
      set
      {
        if (_IsAddMode != value)
        {
          _IsAddMode = value;
          RaisePropertyChanged("IsAddMode");
        }
      }
    }

    /// <summary>
    /// Get/Set IsAddVisible
    /// </summary>
    public bool IsAddVisible
    {
      get { return _IsAddVisible; }
      set
      {
        if (_IsAddVisible != value)
        {
          _IsAddVisible = value;
          RaisePropertyChanged("IsAddVisible");
        }
      }
    }

    /// <summary>
    /// Get/Set IsSaveVisible
    /// </summary>
    public bool IsSaveVisible
    {
      get { return _IsSaveVisible; }
      set
      {
        if (_IsSaveVisible != value)
        {
          _IsSaveVisible = value;
          RaisePropertyChanged("IsSaveVisible");
        }
      }
    }

    /// <summary>
    /// Get/Set IsCancelVisible
    /// </summary>
    public bool IsCancelVisible
    {
      get { return _IsCancelVisible; }
      set
      {
        if (_IsCancelVisible != value)
        {
          _IsCancelVisible = value;
          RaisePropertyChanged("IsCancelVisible");
        }
      }
    }

    /// <summary>
    /// Get/Set IsEditVisible
    /// </summary>
    public bool IsEditVisible
    {
      get { return _IsEditVisible; }
      set
      {
        if (_IsEditVisible != value)
        {
          _IsEditVisible = value;
          RaisePropertyChanged("IsEditVisible");
        }
      }
    }

    /// <summary>
    /// Get/Set IsExceptionVisible
    /// </summary>
    public bool IsExceptionVisible
    {
      get { return _IsExceptionVisible; }
      set
      {
        if (_IsExceptionVisible != value)
        {
          _IsExceptionVisible = value;
          RaisePropertyChanged("IsExceptionVisible");
        }
      }
    }

    /// <summary>
    /// Get/Set IsValidationVisible
    /// </summary>
    public bool IsValidationVisible
    {
      get { return _IsValidationVisible; }
      set
      {
        if (_IsValidationVisible != value)
        {
          _IsValidationVisible = value;
          RaisePropertyChanged("IsValidationVisible");
        }
      }
    }

    /// <summary>
    /// Get/Set IsListEnabled
    /// </summary>
    public bool IsListEnabled
    {
      get { return _IsListEnabled; }
      set
      {
        if (_IsListEnabled != value)
        {
          _IsListEnabled = value;
          RaisePropertyChanged("IsListEnabled");
        }
      }
    }


    /// <summary>
    /// Get/Set MessageToDisplay
    /// </summary>
    public string MessageToDisplay
    {
      get { return _MessageToDisplay; }
      set
      {
        if (_MessageToDisplay != value)
        {
          _MessageToDisplay = value;
          RaisePropertyChanged("MessageToDisplay");
        }
      }
    }

    /// <summary>
    /// Get/Set the List of Validation Messages
    /// </summary>
    public ObservableCollection<ValidationMessage> ValidationMessages = new ObservableCollection<ValidationMessage>();
    #endregion

    #region Init Method
    public virtual void Init()
    {
      IsExceptionVisible = false;
      IsValidationVisible = false;
      IsListEnabled = true;

      MessageToDisplay = string.Empty;
      ValidationMessages.Clear();
    }
    #endregion

    #region SetAddMode Method
    public virtual void SetAddMode()
    {
      IsAddMode = true;

      SetUIEditMode();
    }
    #endregion

    #region SetEditMode Method
    public virtual void SetEditMode()
    {
      IsAddMode = false;

      SetUIEditMode();
    }
    #endregion

    #region SetUIEditMode Method
    protected virtual void SetUIEditMode()
    {
      IsEditVisible = true;
      IsAddVisible = false;
      IsSaveVisible = true;
      IsCancelVisible = true;
      IsListEnabled = false;
    }
    #endregion

    #region SetUIEditMode Method
    protected virtual void SetUINormalMode()
    {
      IsEditVisible = false;
      IsAddVisible = true;
      IsSaveVisible = false;
      IsCancelVisible = false;
      IsValidationVisible = false;
      IsListEnabled = true;

      ValidationMessages.Clear();
    }
    #endregion

    #region DisplayMessages
    protected virtual void DisplayMessages(string msg)
    {
      IsExceptionVisible = true;
      MessageToDisplay = msg;
    }
    #endregion
  }
}
