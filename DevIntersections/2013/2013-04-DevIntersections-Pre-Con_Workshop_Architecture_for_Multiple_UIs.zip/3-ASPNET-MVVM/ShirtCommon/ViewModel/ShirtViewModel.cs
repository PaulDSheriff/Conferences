﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

using Common.Library;
using System.Collections.ObjectModel;

namespace ShirtCommon
{
  [Serializable()]
  public class ShirtViewModel : ViewModelBase
  {
    #region Constructor
    public ShirtViewModel() : base()
    {
      SetUINormalMode();
      Init();
    }
    #endregion

    #region Private Variables
    private string _ShirtName = string.Empty;

    private int _ShirtId = 0;
    private int _ColorId = 0;
    private int _SizeId = 0;

    private DataTable _Shirts;
    private DataTable _Colors;
    private DataTable _Sizes;
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set ShirtName
    /// </summary>
    public string ShirtName
    {
      get { return _ShirtName; }
      set
      {
        if (_ShirtName != value)
        {
          _ShirtName = value;
          RaisePropertyChanged("ShirtName");
        }
      }
    }

    /// <summary>
    /// Get/Set ShirtId
    /// </summary>
    public int ShirtId
    {
      get { return _ShirtId; }
      set
      {
        if (_ShirtId != value)
        {
          _ShirtId = value;
          RaisePropertyChanged("ShirtId");
          DisplayAShirt(value);
        }
      }
    }

    /// <summary>
    /// Get/Set ColorId
    /// </summary>
    public int ColorId
    {
      get { return _ColorId; }
      set
      {
        if (_ColorId != value)
        {
          _ColorId = value;
          RaisePropertyChanged("ColorId");
        }
      }
    }

    /// <summary>
    /// Get/Set SizeId
    /// </summary>
    public int SizeId
    {
      get { return _SizeId; }
      set
      {
        if (_SizeId != value)
        {
          _SizeId = value;
          RaisePropertyChanged("SizeId");
        }
      }
    }

    /// <summary>
    /// Get/Set Shirts
    /// </summary>
    public DataTable Shirts
    {
      get { return _Shirts; }
      set
      {
        if (_Shirts != value)
        {
          _Shirts = value;
          RaisePropertyChanged("Shirts");
        }
      }
    }

    /// <summary>
    /// Get/Set Colors
    /// </summary>
    public DataTable Colors
    {
      get { return _Colors; }
      set
      {
        if (_Colors != value)
        {
          _Colors = value;
          RaisePropertyChanged("Colors");
        }
      }
    }

    /// <summary>
    /// Get/Set Sizes
    /// </summary>
    public DataTable Sizes
    {
      get { return _Sizes; }
      set
      {
        if (_Sizes != value)
        {
          _Sizes = value;
          RaisePropertyChanged("Sizes");
        }
      }
    }
    #endregion

    #region Init Method
    public override void Init()
    {
      base.Init();

      ShirtId = -1;
      ShirtName = string.Empty;
      ColorId = -1;
      SizeId = -1;
    }
    #endregion

    #region LoadAll Method
    public void LoadAll()
    {
      LoadShirts();
      LoadColors();
      LoadSizes();
    }
    #endregion

    #region LoadShirts Method
    public void LoadShirts()
    {
      DataTable dt = null;

      try
      {
        dt = DataLayer.GetDataTable("SELECT * FROM vwShirts",
          AppSettings.ConnectString);

        Shirts = dt;

        SetUINormalMode();
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }
    }
    #endregion

    #region DisplayAShirt Method
    public void DisplayAShirt(int id)
    {
      string sql;
      SqlCommand cmd;
      DataTable dt = null;

      ShirtId = id;
      sql = "SELECT * FROM Shirts WHERE ShirtId = @ShirtId";
      try
      {
        cmd = new SqlCommand(sql);
        cmd.Parameters.Add(new SqlParameter("@ShirtId", id));
        cmd.Connection = new SqlConnection(AppSettings.ConnectString);

        dt = DataLayer.GetDataTable(cmd);
        if (dt.Rows.Count > 0)
        {
          ShirtName = dt.Rows[0]["ShirtName"].ToString();
          ColorId = Convert.ToInt32(dt.Rows[0]["ColorId"]);
          SizeId = Convert.ToInt32(dt.Rows[0]["SizeId"]);
        }

        IsAddMode = false;
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }
    }
    #endregion

    #region LoadColors Method
    public void LoadColors()
    {
      DataTable dt = null;

      try
      {
        dt = DataLayer.GetDataTable("SELECT * FROM ShirtColors",
          AppSettings.ConnectString);

        Colors = dt;
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }
    }
    #endregion

    #region LoadSizes Method
    public void LoadSizes()
    {
      DataTable dt = null;

      try
      {
        dt = DataLayer.GetDataTable("SELECT * FROM ShirtSizes",
          AppSettings.ConnectString);

        Sizes = dt;
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }
    }
    #endregion

    #region DeleteAShirt Method
    public bool DeleteAShirt(int id)
    {
      bool ret = false;
      string sql;
      SqlCommand cmd;
      int rows = 0;

      sql = "DELETE FROM Shirts WHERE ShirtId = @ShirtId";
      try
      {
        cmd = new SqlCommand(sql);
        cmd.Parameters.Add(new SqlParameter("@ShirtId", id));
        cmd.Connection = new SqlConnection(AppSettings.ConnectString);

        rows = DataLayer.ExecuteSQL(cmd);

        if (rows == 1)
          ret = true;

        if(ret)
          // Redisplay all Shirts
          LoadShirts();
        else
          DisplayMessages("Can't find Shirt to Delete");
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }

      return ret;
    }
    #endregion

    #region Save Method
    public void Save()
    {
      bool ret = false;

      if (Validate())
      {
        if (IsAddMode)
        {
          ret = InsertData();
        }
        else
        {
          ret = UpdateData();
        }
      }

      if (ret)
        SetUINormalMode();
    }
    #endregion

    #region Cancel Method
    public void Cancel()
    {
      SetUINormalMode();
    }
    #endregion

    #region Validate Method
    private bool Validate()
    {
      bool ret = false;

      ValidationMessages.Clear();

      if (string.IsNullOrEmpty(ShirtName))
        ValidationMessages.Add(new ValidationMessage("Shirt Name must be filled in."));
      if (ColorId == -1)
        ValidationMessages.Add(new ValidationMessage("Shirt Color must be selected."));
      if (SizeId == -1)
        ValidationMessages.Add(new ValidationMessage("Shirt Size must be selected."));

      ret = (ValidationMessages.Count == 0);

      if (!ret)
      {
        IsValidationVisible = true;
      }

      return ret;
    }
    #endregion

    #region InsertData Method
    private bool InsertData()
    {
      bool ret = false;
      string sql;
      SqlCommand cmd;
      int rows = 0;

      sql = "INSERT INTO Shirts(ShirtName, SizeId, ColorId) ";
      sql += " VALUES(@ShirtName, @SizeId, @ColorId) ";

      try
      {
        cmd = new SqlCommand(sql);
        cmd.Connection = new SqlConnection(AppSettings.ConnectString);
        cmd.Parameters.Add(new SqlParameter("@ShirtName", ShirtName));
        cmd.Parameters.Add(new SqlParameter("@SizeId", Convert.ToInt32(SizeId)));
        cmd.Parameters.Add(new SqlParameter("@ColorId", Convert.ToInt32(ColorId)));

        rows = DataLayer.ExecuteSQL(cmd);

        ret = (rows == 1);

        // Reload All Shirts
        if (ret)
          LoadShirts();
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }

      return ret;
    }
    #endregion

    #region UpdateData Method
    private bool UpdateData()
    {
      bool ret = false;
      string sql;
      SqlCommand cmd;
      int rows = 0;

      sql = "UPDATE Shirts SET ";
      sql += " ShirtName = @ShirtName, ";
      sql += " SizeId = @SizeId, ";
      sql += " ColorId = @ColorId ";
      sql += " WHERE ShirtId = @ShirtId ";

      try
      {
        cmd = new SqlCommand(sql);
        cmd.Connection = new SqlConnection(AppSettings.ConnectString);
        cmd.Parameters.Add(new SqlParameter("@ShirtName", ShirtName));
        cmd.Parameters.Add(new SqlParameter("@SizeId", SizeId));
        cmd.Parameters.Add(new SqlParameter("@ColorId", ColorId));
        cmd.Parameters.Add(new SqlParameter("@ShirtId", ShirtId));

        rows = DataLayer.ExecuteSQL(cmd);

        ret = (rows == 1);

        // Reload All Shirts
        if (ret)
          LoadShirts();
        else
          DisplayMessages("Can't Find Shirt Id: " + ShirtId.ToString() + " to update it."); 
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }

      return ret;
    }
    #endregion

    #region SetAddMode Method
    public override void SetAddMode()
    {
      base.SetAddMode();

      ShirtName = string.Empty;
    }
    #endregion
  }
}