﻿Simple WCF Service
---------------------------------------------------
In order to run this sample you will need to run the \SqlScript\Product.sql script in a SQL Server database.
Then you need to modify the connection string in the App.Config file to point to the server and database where you installed this Product table.
