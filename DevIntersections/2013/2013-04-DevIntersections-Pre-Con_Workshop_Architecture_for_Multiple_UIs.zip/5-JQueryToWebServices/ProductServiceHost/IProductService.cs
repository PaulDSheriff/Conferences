﻿using System.Collections.Generic;
using System.ServiceModel;

using System.ServiceModel.Web;
using ProductDataLayer;

namespace ProductServiceHost
{
  [ServiceContract]
  public interface IProductService
  {
    [OperationContract]
    [WebGet(ResponseFormat = WebMessageFormat.Json)]
    List<Product> GetProducts();

[OperationContract]
[WebInvoke(Method = "POST",
        BodyStyle = WebMessageBodyStyle.WrappedRequest,
        ResponseFormat = WebMessageFormat.Json,
        RequestFormat = WebMessageFormat.Json
      )]
Product GetProduct(int productId);

[OperationContract]
[WebInvoke(Method = "POST",
        BodyStyle = WebMessageBodyStyle.WrappedRequest,
        ResponseFormat = WebMessageFormat.Json,
        RequestFormat = WebMessageFormat.Json
      )]
bool Insert(Product entity);

    [OperationContract]
    [WebInvoke(Method = "POST",
       BodyStyle = WebMessageBodyStyle.WrappedRequest,
       ResponseFormat = WebMessageFormat.Json,
       RequestFormat = WebMessageFormat.Json
     )]
    bool Update(Product entity);

    [OperationContract]
    [WebInvoke(Method = "POST",
       BodyStyle = WebMessageBodyStyle.WrappedRequest,
       ResponseFormat = WebMessageFormat.Json,
       RequestFormat = WebMessageFormat.Json
     )]
    bool DeleteByPK(Product entity);
  }
}
