﻿using System.Windows;
using System.Windows.Controls;

namespace TimeTrack.Silverlight
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private void btnDisplayTimeSheets_Click(object sender, RoutedEventArgs e)
    {
      DisplayUserControl(new TimeSheetsDisplayView());
    }

    private void btnAddTimeSheet_Click(object sender, RoutedEventArgs e)
    {
      DisplayUserControl(new TimeSheetAddView());
    }

    private void DisplayUserControl(UserControl uc)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(uc);
    }
  }
}
