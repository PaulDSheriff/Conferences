using System;
using System.Collections.Generic;

using Common.Library;
using TimeTrack.DataClasses;
using TimeTrack.EntityClasses;

namespace TimeTrack.Services
{
  /// <summary>
	/// Class called by a WCF Service
	/// All methods return a "Response Class". 
	/// This allows us to do all exception handling here and not have to throw any custom exceptions
	/// You can return all error messages from here. 
	/// Those messages could be data-driven. That way if you want to change them, you only have to change them on the server
	/// </summary>
  public partial class TimeSheetServices : ITimeSheetServices
  {
    #region CreateTimeSheetDataObject Method
    private TimeSheetData CreateTimeSheetDataObject()
    {
      TimeSheetData ret = new TimeSheetData();

      ret.ConnectString = ret.GetConnectString("TimeTrack");

      return ret;
    }
    #endregion

    #region GetTimeSheet Method
    public TimeSheetResponse GetTimeSheet(TimeSheet entity)
    {
      TimeSheetResponse ret = new TimeSheetResponse();
      TimeSheetData data = null;

      try
      {
        data = CreateTimeSheetDataObject();

        ret.DetailData = data.GetTimeSheet(entity);
        ret.RowsAffected = data.RowsAffected;
        ret.Status = OperationResult.Success;
        if (ret.RowsAffected == 0)
        {
          ret.Status = OperationResult.NoRecords;
          ret.FriendlyErrorMessage = "The record you were looking for was not found.";
        }
      }
      catch (Exception ex)
      {
				// Perform any exception logging here

				// Set Return Properties
				ret.ErrorMessage = ex.Message;
        ret.ErrorMessageExtended = ex.ToString();
        ret.Status = OperationResult.Exception;
      }

      return ret;
    }
    #endregion

    #region GetAllTimeSheets Method
    public TimeSheetResponse GetAllTimeSheets()
    {
      return GetTimeSheets(null);
    }
    #endregion

    #region GetTimeSheetsByCustomer Method
    public TimeSheetResponse GetTimeSheetsByCustomer(Customer entity)
    {
      return GetTimeSheets(entity);
    }
    #endregion

    #region GetTimeSheets Method
    /// <summary>
    /// Returns all time sheets if you pass a Null into the entity parameter. Otherwise returns time sheets just for that customer
    /// </summary>
    /// <param name="entity">A customer entity object, or a null</param>
    /// <returns>A collection of Time Sheet objects</returns>
    protected TimeSheetResponse GetTimeSheets(Customer entity)
    {
      TimeSheetResponse ret = new TimeSheetResponse();
      TimeSheetData data = null;

      try
      {
        data = CreateTimeSheetDataObject();

        if (entity == null)
          ret.DataCollection = data.GetAllTimeSheets();
        else
          ret.DataCollection = data.GetTimeSheetsByCustomer(entity);

        ret.RowsAffected = data.RowsAffected;
        if (ret.DataCollection != null)
        {
          if (ret.DataCollection.Count > 0)
            ret.Status = OperationResult.Success;
          else
          {
            ret.Status = OperationResult.NoRecords;
            ret.FriendlyErrorMessage = "No records were found for this table.";
          }
        }
      }
      catch (Exception ex)
      {
				// Perform any exception logging here

				// Set Return Properties
				ret.ErrorMessage = ex.Message;
        ret.ErrorMessageExtended = ex.ToString();
        ret.Status = OperationResult.Exception;
      }

      return ret;
    }
    #endregion

    #region Validate Method
    /// <summary>
    /// Validate Time Sheet Data
    /// This method might belong in a validation class instead of here
    /// Just here for simplicity
    /// </summary>
    /// <returns>True if values are valid, false if not</returns>
    public List<ValidationMessage> Validate(TimeSheet entity)
    {
      List<ValidationMessage> ret = new List<ValidationMessage>();
      decimal decValue;

      if (entity.CustomerId == -1)
        ret.Add(new ValidationMessage("A Customer Must Be Selected", "CustomerName"));
      if (entity.ProjectId == -1)
        ret.Add(new ValidationMessage("A Project Must Be Selected", "ProjectName"));
      if (entity.EmployeeId == -1)
        ret.Add(new ValidationMessage("An Employee Must Be Selected", "LastName"));
      if (entity.TaskDate == null || entity.TaskDate == DateTime.MinValue)
        ret.Add(new ValidationMessage("A Task Date Must Be Filled In", "TaskDate"));
      else
      {
        if (entity.TaskDate < DateTime.Now.AddDays(-7))
          ret.Add(new ValidationMessage("Task Date must be greater " + DateTime.Now.AddDays(-7).ToShortDateString(), "TaskDate"));
        if (entity.TaskDate > DateTime.Now)
          ret.Add(new ValidationMessage("Task Date must today's date or less.", "TaskDate"));
      }
      if (!decimal.TryParse(entity.Hours.ToString(), out decValue))
        ret.Add(new ValidationMessage("Hours Must Be A Decimal Number", "Hours"));
      else
      {
        if (decValue <= 0)
          ret.Add(new ValidationMessage("Hours Must Be Greater Than 0", "Hours"));
        if (decValue > 12)
          ret.Add(new ValidationMessage("Hours Must Be Less Than Or Equal To 12", "Hours"));
      }
      if (entity.Description.Trim() == string.Empty)
        ret.Add(new ValidationMessage("A Description Must Be Entered", "Description"));
      else
        if (entity.Description.Trim().Length < 4)
          ret.Add(new ValidationMessage("A Description Must Have More Than 4 Characters", "Description"));

      return ret;
    }
    #endregion

    #region Insert Method
    public TimeSheetResponse Insert(TimeSheet entity)
    {
      TimeSheetResponse ret = new TimeSheetResponse();
      TimeSheetData data = null;
      List<ValidationMessage> messages;

      try
      {
        messages = Validate(entity);
        if (messages.Count == 0)
        {
          data = CreateTimeSheetDataObject();

          ret.RowsAffected = data.Insert(entity);
          if (ret.RowsAffected > 0)
          {
            // In case any data changed
            ret.DetailData = data.Entity;
            ret.Status = OperationResult.Success;
          }
          else
          {
            ret.Status = OperationResult.NoRecords;
            ret.FriendlyErrorMessage = "No Records Were Inserted.";
          }
        }
        else
        {
          ret.Status = OperationResult.ValidationFailed;
          ret.FriendlyErrorMessage = "Time Sheet Entry is not valid.";
          ret.ErrorMessage = ret.FriendlyErrorMessage;
          ret.ValidationMessages = messages;
        }
      }
      catch (Exception ex)
      {
				// Perform any exception logging here

				// Set Return Properties
				ret.ErrorMessage = ex.Message;
        ret.ErrorMessageExtended = ex.ToString();
        ret.Status = OperationResult.Exception;
      }

      return ret;
    }
    #endregion
  }
}

