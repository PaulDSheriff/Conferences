﻿using System.Windows;

namespace WPF_MessageBox
{
  public partial class App : Application
  {
  }
}
