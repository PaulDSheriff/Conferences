using System.Collections.Generic;
using System.Runtime.Serialization;

using NTier.Common;
using NTier.EntityClasses;

namespace NTier.Services
{
  [DataContract]
  public class PersonResponse : ResponseBase
  {
    [DataMember]
    public Person DetailData { get; set; }

    [DataMember]
    public List<Person> DataCollection { get; set; }
  }
}

