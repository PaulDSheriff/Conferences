﻿using PDSA.MessageBroker;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

// The User Control item template is documented at http://go.microsoft.com/fwlink/?LinkId=234236

namespace ProductSample
{
  public sealed partial class ProductDetail : UserControl
  {
    public ProductDetail()
    {
      this.InitializeComponent();
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      PDSAMessageBrokerMessage arg = new PDSAMessageBrokerMessage();

      arg.MessageName = "ProductList";

      // Send message
      (Application.Current as App).MessageBroker.SendMessage(arg);
    }
  }
}
