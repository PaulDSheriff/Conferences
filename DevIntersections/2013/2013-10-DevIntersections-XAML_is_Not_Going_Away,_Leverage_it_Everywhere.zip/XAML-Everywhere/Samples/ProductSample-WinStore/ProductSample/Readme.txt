﻿MainPage
  <Grid x:Name="ContentPanel"

In ProductList
  xmlns:vm="using ProductViewModels";
  Use ListView instead of ListBox
  
TextBlock does allow 'StringFormat=c'
Added StringFormatConverter class