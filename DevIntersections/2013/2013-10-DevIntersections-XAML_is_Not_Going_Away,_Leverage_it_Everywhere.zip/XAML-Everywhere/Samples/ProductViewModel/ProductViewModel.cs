﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Xml.Linq;

using ProductEntity;
using Common.Library;
using ProductViewModels.ProductServiceReference;

namespace ProductViewModels
{
  public class ProductViewModel : CommonCollectionBase<Product>
  {
    #region Constructor
    public ProductViewModel()
    {
      GetProducts();
    }
    #endregion

    #region DetailData Property
    private Product _DetailData;

    public Product DetailData
    {
      get { return _DetailData; }
      set
      {
        _DetailData = value;
        RaisePropertyChanged("DetailData");
      }
    }
    #endregion

    #region DataCollection Property
    private ObservableCollection<Product> _DataCollection;

    public ObservableCollection<Product> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region GetProducts Method
    ProductServiceClient _Client = null;

    public void GetProducts()
    {
      DataCollection = new ObservableCollection<Product>();

      try
      {
        _Client = new ProductServiceClient();

        _Client.GetProductsCompleted += client_GetProductsCompleted;
        _Client.GetProductsAsync();
      }
      catch
      {
        CloseClient();
      }
    }

    void client_GetProductsCompleted(object sender, GetProductsCompletedEventArgs e)
    {
      if (e.Error == null)
        DataCollection = new ObservableCollection<Product>(e.Result);
      else
        DataCollection = CreateMock();

      CloseClient();
    }

    private void CloseClient()
    {
      if (_Client != null)
      {
        _Client.CloseAsync();
        _Client.GetProductsCompleted -= client_GetProductsCompleted;
      }
    }
    #endregion

    #region CreateMock Method
    private ObservableCollection<Product> CreateMock()
    {
      ObservableCollection<Product> ret = new ObservableCollection<Product>();
      Product prod = new Product();

      prod.ProductId = 1;
      prod.ProductName = "Test Product 1";
      prod.Price = 100;
      prod.ProductType = "Book";

      ret.Add(prod);

      prod = new Product();

      prod.ProductId = 2;
      prod.ProductName = "Test Product 2";
      prod.Price = 200;
      prod.ProductType = "Video";

      ret.Add(prod);

      return ret;
    }
    #endregion
  }
}
