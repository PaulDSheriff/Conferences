﻿using System.Collections.Generic;

namespace BindingSample
{
  #region Customers Class
  public class Customers : List<Customer>
  {
  }
  #endregion

  public class Customer : Common.Library.CommonBase
  {
    private string _FirstName = string.Empty;
    private string _LastName = string.Empty;

    /// <summary>
    /// Get/Set First Name
    /// </summary>
    public string FirstName
    {
      get { return _FirstName; }
      set
      {
        if (_FirstName != value)
        {
          _FirstName = value;
          RaisePropertyChanged("FirstName");
        }
      }
    }

    /// <summary>
    /// Get/Set Last Name
    /// </summary>
    public string LastName
    {
      get { return _LastName; }
      set
      {
        if (_LastName != value)
        {
          _LastName = value;
          RaisePropertyChanged("LastName");
        }
      }
    }

    /// <summary>
    /// Get the Full Name
    /// </summary>
    public string FullName
    {
      get { return FirstName + " " + LastName; }
      set { }
    }
  }
}
