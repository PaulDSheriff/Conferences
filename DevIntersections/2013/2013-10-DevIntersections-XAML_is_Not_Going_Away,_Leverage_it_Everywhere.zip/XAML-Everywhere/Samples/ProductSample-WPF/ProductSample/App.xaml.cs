﻿using System.Windows;
using PDSA.MessageBroker;

namespace ProductSample
{
  public partial class App : Application
  {
    /// <summary>
    /// Get/Set the Message Broker
    /// </summary>
    public PDSAMessageBroker MessageBroker { get; set; }

    protected override void OnStartup(StartupEventArgs e)
    {
      base.OnStartup(e);

      MessageBroker = new PDSAMessageBroker();
    }
  }
}
