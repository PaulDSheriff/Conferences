﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PDSA.MessageBroker;

namespace ProductSample
{
  public partial class MainWindow : Window
  {
    #region Constructor
    public MainWindow()
    {
      InitializeComponent();
      
      // Initialize the Message Broker Events
      (Application.Current as App).MessageBroker.MessageReceived +=
       new MessageReceivedEventHandler(MessageBroker_MessageReceived);
    }
    #endregion

    void MessageBroker_MessageReceived(object sender, PDSAMessageBrokerEventArgs e)
    {
      switch (e.MessageName)
      {
        case "ProductList":
          ContentPanel.Children.Clear();
          ContentPanel.Children.Add(new ProductList());
          break;

        case "ProductDetail":
          ProductDetail uc = new ProductDetail();
          // Set DataContext to the Product object
          uc.DataContext = e.Message.MessageBody;

          ContentPanel.Children.Clear();
          ContentPanel.Children.Add(uc);
          break;
      }
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      ContentPanel.Children.Add(new ProductList());
    }
  }
}
